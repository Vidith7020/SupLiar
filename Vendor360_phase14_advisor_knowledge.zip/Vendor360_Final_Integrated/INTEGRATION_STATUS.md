# Integration status — after Phase 6 (package side)

Only things that were actually executed are marked as done.

## Executed earlier (Phase 4 package, sandbox with network)
- `pytest tests`: 38 passed. `npm run typecheck` and `npm run build`: OK.
- Real status checks (`v360_status`: PASS / PARTIAL / CHECK REQUIRED) replace the old unconditional banners in Cells 19, 19.1, 20, 21, 23, 24A, 24C, 26C.
- Onboarding Cost = supplier-level median INR unit price (tiered, day_rate, usage, blended_rate). Range 0 - 277,830, median about 62,280. 32 of 40 suppliers have a value; 8 have only lump-sum pricing and start at the portfolio median (explained on the page). The bounded 0-1 cost KPI used by MCDA is unchanged.

## Changed in Phase 5
- Gemini scenario call in `backend/modules/scenario.py` now has a request timeout (default 30 s, env `GEMINI_TIMEOUT_SECONDS`). On timeout the existing error path returns the local explanation.
- The unused onboarding checklist (`GET /api/onboarding`, `GET /api/export/onboarding`) is removed from `backend/api.py`, along with its test and one line in `tests/test_phase1.py`. Nothing was deleted outright: the code is kept, readable and inactive, in `archive/unused_onboarding_checklist/`. The Onboarding page uses `/api/onboarding/config` and `/api/onboarding/assess`, which are unchanged.
- Checks: `py_compile` in the sandbox, then the full suite in a real Colab runtime (user-run, see below).

## Executed in a real Colab runtime on the Phase 5 zip (user-run)
- `pytest tests`: 36 passed, 1 skipped, 0 failed (3 min 28 s). The skipped test is the Node check of `normalizeSupplier`, which skips until `npm ci` has run.
- After `npm ci` in `frontend/`: `pytest tests/test_phase4.py -k normalize`: 1 passed. So all 37 tests have passed.
- Onboarding page opened in the browser (screenshots): ranges Cost 0 - 2,77,830, Capacity 0 - 36,000; portfolio-median input gives 50 in every dimension except Reliability 48.7; the lump-sum Cost note is shown.

## NOT executed
- `npm run typecheck` / `npm run build` on the Phase 5 zip (no frontend files changed in Phase 5; the app was served in Colab, so a build did run when the launcher started, but its output was not reviewed).
- Live Gemini call of any kind (including the timeout). See Phase 6 below.
- Numeric validation of Gemini output against the verified context in `ai.py` (not implemented). The Cell 24C Gemini call already has a 60 s timeout.

## Values shown to users
- FX rates (`config/fx_rates.json`: EUR 98, USD 88, CHF 105, as of 2026-10-05) are indicative placeholders; the Trends page labels them "indicative rates".
- Capacity range is 0 - 36000 (computed from data after the 999999 placeholder was replaced); reliability "better than" for 22.34 is 41.0 against 38.5 in the old screenshot. Both unconfirmed.
- Alibaba Cloud International has no reliability KPI. The Action column (ESCALATE/REVIEW/MONITOR) can differ from the score-based status. No per-supplier "estimated capacity" marker in the UI.

## Phase 6 — on-demand Gemini (written, only partly checked)
What was added
- `backend/gemini_client.py`: key from `GEMINI_API_KEY`, 30 s timeout, lazy SDK import, JSON parsing, a check that flags numbers in Gemini's text that cannot be matched to engine data. Nothing is sent to Gemini at startup, at import or in tests.
- API: `GET /api/gemini/status`, `POST /api/insights/gemini`, and `POST /api/advisor` now accepts `use_gemini` (default false, behaviour unchanged). If Gemini fails the engine's own answer is returned with the reason.
- UI: "AI insights" card on the Executive Dashboard with a Generate button; "Explain with Gemini" switch on the Advisor page. Both are disabled with an explanation when no key is set.
- `launch_colab.py` copies the Colab secret `GEMINI_API_KEY` into the environment (never printed).
- `tests/test_gemini.py`: 11 new tests (6 helper tests, 5 API tests using a faked model call).

Actually executed in the build sandbox (no FastAPI, no network, no Colab)
- `py_compile` of the changed Python files and the new test file.
- The helper's logic run directly with a faked model call: no-key fallback, JSON parsing incl. code fences, unmatched-number detection, rounding tolerance, key scrubbed from errors, key absent from the browser-facing data.
- TypeScript syntax parse of `App.tsx` and `api/vendor360.ts` (0 syntax errors).

NOT executed
- `pytest` (the 5 new API tests and the existing suite) after these changes.
- `npm run typecheck` and `npm run build` (the sandbox has no frontend packages, so types were not checked).
- Any real Gemini call. The default model name `gemini-3.8-flash` is the one the project already used and was not confirmed against your account; if Gemini reports a model error, set `GEMINI_MODEL`.
- Browser check of the new card and switch.
