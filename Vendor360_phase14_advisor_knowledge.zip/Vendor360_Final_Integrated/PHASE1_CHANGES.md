# Phase 1 — what changed

## backend/api.py
- `/api/portfolio`: slim schema (35 columns -> merged KPI table, no duplicate `*_extra` / `entity_*`), all six raw KPIs (`*_kpi`), display scores (`*_score`: direction-aware percentile 0-100), `score` (MCDA x100), supplier-level `rank`, risk fields, decision text, category, country.
- `/api/supplier/{id}`, `/api/risk`: same merged data.
- `/api/scenario`: returns weights, baseline vs scenario rank, rank change and a generated explanation from the engine's own output.
- `/api/advisor`: deterministic router over engine outputs (risk, supplier-specific, top suppliers, what-if). No Gemini.
- NEW `/api/dependency` (award concentration, HHI), `/api/onboarding` (readiness from contract/restriction/pricing data), `/api/quality`, `/api/export/{portfolio|risk|decision|kpi}`.
- `/api/trends`: awarded rows only; value reported per currency, never summed.
- CORS: `allow_credentials=False` (was invalid with `*`).
- Fix: scenario engine crashed on a clean start (its output folder was deleted at boot); folder is now created before each run, calls are serialised with a lock and stdout is no longer printed per request.

## frontend
- `src/api/vendor360.ts`: typed live schema, retry with backoff, readable errors, no UI-side status guessing.
- `src/App.tsx`: removed all hard-coded numbers/names (151, 84.2, 38.4, 2/3/14/132, "Vertex Systems", "Alex Morgan", demo suppliers). Every page reads the API. Silent demo fallback removed: loading and error states with Retry instead.
- Profile follows the selected supplier; What-If calls the engine; Advisor calls the API; Comparison, Trends, Sustainability, Dependency, Onboarding, Data Quality, Export, Settings, Help are real pages.
- CSS: fixed the broken rank-list grid (was overridden by a generic flex rule), larger fonts there, select/state/compare styles.
- `npm run typecheck` script added; `package-lock.json` now included.

## tests
- `tests/test_phase1.py` (4 tests).

## Not touched
- Notebook, `modules/*.py` (engine logic unchanged: scores are exactly the engine's), Docker, Colab launcher.
