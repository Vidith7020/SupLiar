# Phase 7 — What-If Scenarios redesign
Changed: frontend/src/App.tsx (WhatIf component rewritten), frontend/src/index.css (appended `wi-*` block), frontend/src/api/vendor360.ts (ScenarioResult gains optional `interpretation`, already returned by /api/scenario).
No backend change.
New on the page: quick-scenario cards (one click runs), "how the engine read your scenario" (per-dimension priority, weight, delta vs neutral, matched phrase), KPI strip (recommended supplier, biggest climber, biggest drop, suppliers re-ranked), neutral-vs-scenario weight bars, generated scenario summary, combined baseline-vs-scenario ranking table (Top 10 / All / Climbers / Fallers).
All numbers come from the /api/scenario payload and the portfolio; the summary sentences are computed from them, nothing fabricated.
Default scenario text changed to "What if we prioritize reliability and risk?" (see known engine issues below).
Run in sandbox: tsc --noEmit, vite build, real backend + Playwright screenshot. NOT run: pytest, Colab.
Known engine issues (not changed): "reliability becomes more important than cost" gives Cost the same boosted weight as Reliability; "reduce the importance of cost" raises Cost weight to 44%.
