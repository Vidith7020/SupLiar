from backend.pipeline import run_backend
if __name__ == "__main__":
    result=run_backend("/content", execute_ai=False)
    print("Vendor360 backend completed:", result["ok"])
    for x in result["results"]: print(x)
