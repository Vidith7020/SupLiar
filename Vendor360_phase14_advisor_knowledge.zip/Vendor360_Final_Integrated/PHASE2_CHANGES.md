# Phase 2 — what changed

## Executed and tested (tests/test_phase2.py, 7/7 pass; real pipeline, no Gemini key, no network)
1. **One supplier-level rank** (`modules/supplier_decision.py`): `supplier_mcda_rank` is recomputed from `mcda_score`
   (ties share the lowest rank), `mcda_rank` is an alias of it, the old category-level rank is kept as
   `category_level_mcda_rank`. An assertion fails the run if a higher score ever gets a worse rank. Config note and
   `rank_column_used` corrected.
2. **One risk rule** (`modules/risk_radar.py`): status and band both come from `risk_radar_score` only
   (`RISK_THRESHOLDS`): <25 Stable, 25-<35 Watch, 35-<45 Emerging Risk, >=45 Critical; band LOW = Stable/Watch,
   MEDIUM = Emerging Risk, HIGH = Critical. A built-in assertion fails if they disagree. Rule exposed in
   `/api/portfolio` schema note and the DI metadata JSON.
   Result: 2 Critical / 10 Emerging Risk / 16 Watch / 12 Stable (was 9 / 0 / 24 / 7 with 5 of 9 Critical in the LOW band).
   Signals and recommended action stay visible as separate columns; they no longer override the status.
3. **Decision text** (`modules/decision_intelligence.py`): wording depends on supplier rank (top quarter "Recommended",
   middle "Mid-ranked", bottom quarter "Lower-ranked ... consider only with mitigation").
4. **INR conversion** (`config/fx_rates.json`, `modules/foundation.py` `vendor360_prepare`, also called from `analytics.py`
   because it reloads the CSVs): unit_price, expedited_unit_price and total_value converted BEFORE aggregation.
   **The rates (EUR 98, USD 88, CHF 105 per 1 unit -> INR) are indicative project values, not a live feed.** Edit the file to change them.
5. **Cost KPI like-for-like**: after INR conversion each price becomes a percentile within its pricing_model + category_l2
   (0 = cheapest). Bounded 0-1. Caveat: some peer groups still mix units (cloud storage per-GB vs per-TB).
6. **Capacity 999999**: replaced by the median of real values in the same category_l1 for the affected suppliers
   (estimated, not measured). Disclosed on the Data Quality page via `preparation.capacity`; `capacity_estimated` flag in `/api/portfolio`.
7. `/api/trends`: one INR value per month (`award_value_inr`) plus the FX table used; `/api/quality` returns the preparation log.

## Ranking change versus the Phase 0 baseline (executed)
Rank 1 stays Visium Data Engineering; rank 40 stays Alibaba Cloud International. MCDA score range 0.363 (was 0.366) .. 0.699 (was 0.784).
Spearman rank correlation vs baseline: 0.83; 34 of 40 suppliers changed rank, largest moves up: DEPT Agency +17, Artefact Analytics +15,
Infosys Consulting +10; largest down: Insight Technology Group -13, Steelcase Americas -12, Deloitte -12.
Most of the change comes from the cost method (price percentile instead of raw mixed-unit prices).

## NOT executed (this sandbox has no network)
- FastAPI endpoints (fastapi/uvicorn not installable): `api.py` edits are syntax-checked only; `tests/test_phase1.py` was not re-run.
- Frontend: `App.tsx` edits are small string/type changes but `tsc`/`npm run build` were NOT run (no node_modules). Run `npm install && npm run typecheck && npm run build`.
- Per-supplier "est." marker next to capacity values in the UI was not added (API provides `capacity_estimated`).
- Browser rendering, Docker, Colab, Streamlit, live Gemini.

## Known remaining items
- Alibaba Cloud International still has no reliability KPI; "reliability over cost" What-If can still lift it artificially.
- Action column (ESCALATE/REVIEW/MONITOR) is signal-based and can differ from the score-based status.
- Phases 3-5 not started.
