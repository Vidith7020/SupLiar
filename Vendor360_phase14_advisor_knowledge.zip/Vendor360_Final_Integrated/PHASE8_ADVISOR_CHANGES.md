# Phase 8b — Conversational advisor, richer Gemini, interpreter fixes
Triggered by the screenshot where "big business, cost is no issue, quality/reliability/sustainability are major needs, risk lowest possible" was answered with "2 suppliers are Critical" and a list of the RISKIEST suppliers.

## Root causes found
1. `api.py` routed on single substrings. "risk" (as a requirement) and "problem" (in "no problem having high cost") sent the sentence to the risk-list branch. The richer router in `vendor360_engine/advisor.py` was never imported.
2. Gemini was told to use only a context that held name/rank/score/risk, so it truthfully said the data has no cost/quality/reliability/sustainability scores, and it explained the wrong engine answer.
3. The scenario interpreter read the sentence as quality=mild, reliability=mild (the list "quality, reliability, and sustainability are major needs" was cut in two), and "X more important than Y" raised BOTH X and Y.

## Changes
- NEW `backend/advisor_core.py` (pure python, unit-tested): intent first, keywords second. Requirement statements -> scenario engine -> recommendation (with "how I read this", Stable pick when risk matters, trade-off). Also: profile, compare (named / "the top three" / "them"), alternatives, dimension leaders, lowest risk, risk list, category, sustainability, award concentration, trends, data quality, portfolio, greeting/thanks/help, honest fallback. Follow-ups are resolved from the conversation ("them", "the first one", "why?", "and what if cost mattered more?" continues the previous scenario). Answers keep the old fields (title, why, evidence, next_step, suppliers, engine) and add reply, follow_ups, actions, intent, understood, scenario_text.
- NEW `backend/advisor_context.py`: Gemini now sees every supplier with all six dimensions, raw values, flags, strengths/concerns, completeness; category summaries; per-dimension leaders and laggards; award concentration and monthly trends (with likely-incomplete months); a glossary of scales. Focused suppliers (those in the engine answer) also get their full explanations. Same context feeds the executive insights.
- `backend/gemini_client.py`: new advisor rules (analyst, not a recomputer), conversation history in the prompt (fenced, trimmed), the engine answer is the main source but Gemini may say it missed the point and answer from CONTEXT, replies end with 2-3 follow-up questions, temperature 0.3 (falls back if the SDK rejects the config). `clean_advisor` keeps `follow_ups`. Number verification now also covers numbers Gemini quotes from the engine answer.
- `backend/api.py`: `/api/advisor` accepts `history`; uses advisor_core; dependency/trends payloads are built lazily.
- `backend/vendor360_engine/scenario_engine.py`: lists with a shared predicate ("A, B and C are major needs") stay together; "risk should be the lowest possible" / "as low as possible" = strong; "X more important than Y", "Y less important than X", "prioritise X over Y" raise X and lower Y; "key" counts as a priority word. Checked against a 29-phrase corpus old vs new: 9 phrases changed, all intended, none regressed.
- Frontend: AI Advisor is a chat: conversational reply (light markdown), "How I read this", supplier chips with risk dot, action links, clickable follow-up questions, "How this answer was built" details, history sent back each turn, Gemini analysis label. `frontend/src/api/vendor360.ts` types updated.

## Verification (sandbox)
- `python tests/test_advisor_core.py`: 28/28 (no pytest/FastAPI needed). Covers the exact sentence from the screenshot, intent routing, follow-ups, garbage history, engine failure, determinism over 28 odd inputs, interpreter regressions, Gemini context/prompt.
- `api.advisor()` exercised against minimal FastAPI/pydantic stand-ins with patched engine functions (history round-trip, Gemini on with a fake model, backward-compatible fields).
- Chat UI bundled with esbuild and driven in Chromium against a local server running the real advisor_core: question, follow-up chip, pronoun follow-up, Gemini mode. 0 runtime errors. tsc clean against stubbed React types.
- NOT run: pytest (the two API tests at the bottom of test_advisor_core.py skip without FastAPI), the real backend/engine, a real Gemini call, `vite build`, Colab.

## Known limits
- No real Gemini call was made: the prompt, context and parsing are tested with a fake model. Prompt size is ~40k characters at most for 40 suppliers; if your model rejects that, lower `_leaders(n)` or drop `sub_categories` in advisor_context.
- Gemini may still quote a figure that is not in the context; the UI shows the existing "check these numbers" warning when that happens.
- Intent routing is rule-based. Unusual phrasing falls to the "I need a bit more to go on" answer (or, with Gemini on, Gemini answers from the full context).
