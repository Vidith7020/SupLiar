"""Check that the four source datasets are present in ./data and show the folders the backend will use.

Nothing is copied into /content any more: the backend reads the datasets straight from <project>/data
(VENDOR360_INPUT_DIR) and writes generated files to a separate folder (VENDOR360_WORKDIR), so generated
CSVs can never be re-ingested.
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED = ["suppliers.csv", "pricing.csv", "categories.csv", "historical_awards.csv"]
DEFAULT_WORK = "/content/vendor360_work"


def settings() -> dict:
    return {
        "VENDOR360_INPUT_DIR": os.environ.get("VENDOR360_INPUT_DIR", str(ROOT / "data")),
        "VENDOR360_WORKDIR": os.environ.get("VENDOR360_WORKDIR", DEFAULT_WORK),
    }


def main() -> dict:
    cfg = settings()
    data = Path(cfg["VENDOR360_INPUT_DIR"])
    missing = [n for n in REQUIRED if not (data / n).exists()]
    if missing:
        raise FileNotFoundError(f"Missing source datasets in {data}: {', '.join(missing)}")
    if not (ROOT / "config" / "fx_rates.json").exists():
        raise FileNotFoundError("config/fx_rates.json is missing (needed for the INR conversion).")
    print("Source datasets OK:", data)
    print("Generated output folder:", cfg["VENDOR360_WORKDIR"])
    return cfg


if __name__ == "__main__":
    main()
