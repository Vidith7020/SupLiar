Archived, NOT active code.

These pieces belong to the old onboarding checklist (GET /api/onboarding and
GET /api/export/onboarding). The React Onboarding page does not use them; it uses
GET /api/onboarding/config and POST /api/onboarding/assess, which are unchanged.

Files are .txt so Python and pytest never import them. To restore, paste the code back into
backend/api.py / the tests and rename nothing else.
