# Phase 9 — UI polish
Frontend only (src/App.tsx, src/index.css). No backend change.
- Flowing aurora background (4 blurred colour blobs, 40-60s drift, respects reduced-motion).
- Colour themes: Ember (default), Ocean, Aurora, Forest. Picker in the top bar, remembered in localStorage. Accent colours in index.css are now CSS variables.
- Insights toggle in the top bar hides/shows every insight panel (and the Gemini card); each insight panel also has its own Hide/Show fold button with smooth height animation.
- Charts sit in soft rounded inner frames; glass-style cards; aligned grid rhythm.
Not run here: npm ci / vite build / real tsc (no network). Only a syntax-level tsc check was done - please run `npm run typecheck && npm run build`.

## Phase 10 addendum
- Default theme is now Indigo (indigo/violet/cyan/pink aurora, lower opacity, 55-85s drift); Ember kept as an option.
- Insights are hidden by default; top-bar "Insights" switch reveals all panels. Dashboard AI/Gemini cards sit behind a "Show AI Insight" disclosure.
- Dashboard: KPI row, chart + risk radar, top suppliers + early warnings.
- Skeleton loading states; calmer error box; risk badges carry shape glyphs (▲ ◆ ● ✓) plus text.
- Not run: npm ci / build / browser check (no network in this sandbox).

## Phase 11 (combined)
Insights switch defaults ON, each panel starts folded; Calm/Vivid aurora switch in the theme menu (Vivid = Phase 9 intensity); Indigo default with Ember kept; badges/skeletons/disclosure from Phase 10 kept.

## Phase 12 (final combined, Phase 9 base)
Ember default; original Phase 9 Dashboard layout and open-by-default insights restored. Background widened to 5 blobs with 5-colour palettes per theme (Ember: red/orange/amber/rose). Remaining hard-coded warm colours in charts/buttons/switches now follow the theme. Kept from later phases: shape-glyph risk badges, skeleton loading, focus outlines, Indigo theme. Not built or browser-tested here.

## Phase 13 (merged advisor build)
Merged the other Claude's Phase 8 advisor/Gemini work onto Phase 12 via 3-way merge from the Phase 8 base. Backend (advisor_core.py, advisor_context.py, api.py, gemini_client.py, scenario_engine.py), api client, tests and docs taken as-is (we never edited them). App.tsx merged with no conflicts; index.css had one append conflict, resolved by keeping both, with advisor colours mapped to theme variables and shape-coded risk dots. Not run: pytest, npm build, browser.
