"""Start Vendor360 in Colab (or any machine with Python + Node 18+).

  1. checks the datasets,
  2. starts the API on 127.0.0.1:8000 (reached only through the frontend proxy, not exposed),
  3. waits until GET /api/health reports status "ready" (the pipeline takes ~15 s),
  4. builds the frontend and serves the built app on 0.0.0.0:5173 (Vite preview server).

The Vite preview server is a convenience server, not a hardened production deployment.
Run:  python launch_colab.py      (or `%run launch_colab.py` in a notebook)
"""
from __future__ import annotations
import json, os, subprocess, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FRONTEND = ROOT / "frontend"
API_PORT, UI_PORT = 8000, 5173
LOG_DIR = Path(os.environ.get("VENDOR360_LOG_DIR", "/tmp"))


def _get(url: str, timeout: float = 3.0):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.status, r.read().decode("utf-8", "replace")


def _health():
    try:
        status, body = _get(f"http://127.0.0.1:{API_PORT}/api/health")
        return json.loads(body) if status == 200 else None
    except Exception:
        return None


def _tail(path: Path, n: int = 25) -> str:
    try:
        return "\n".join(path.read_text(errors="replace").splitlines()[-n:])
    except Exception:
        return "(no log)"


def start_api(env: dict) -> subprocess.Popen | None:
    if _health() is not None:
        if os.environ.get("GEMINI_API_KEY") and _api_has_key() is False:
            print("API is running without the Gemini key; restarting it with the key...")
            _stop_api()
        else:
            print("API already running on port", API_PORT)
            return None
    log = LOG_DIR / "vendor360_api.log"
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "backend.api:app", "--host", "127.0.0.1", "--port", str(API_PORT)],
        cwd=str(ROOT), env={**os.environ, **env}, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    print("API process started (pid %d), log: %s" % (proc.pid, log))
    return proc


def wait_ready(proc: subprocess.Popen | None, timeout: float = 240.0) -> dict:
    """Poll /api/health. Returns the health dict when ready; raises on error/timeout/crash."""
    t0, last = time.time(), None
    while time.time() - t0 < timeout:
        if proc is not None and proc.poll() is not None:
            raise RuntimeError("API process exited:\n" + _tail(LOG_DIR / "vendor360_api.log"))
        h = _health()
        if h is not None:
            if h.get("status") != last:
                last = h.get("status"); print(f"  health: {last}")
            if h.get("status") == "ready":
                return h
            if h.get("status") == "error":
                raise RuntimeError("Backend pipeline failed: %s" % h.get("error"))
        time.sleep(2)
    raise TimeoutError(f"Backend not ready after {timeout:.0f}s. Last log lines:\n" + _tail(LOG_DIR / "vendor360_api.log"))


def start_frontend() -> subprocess.Popen | None:
    try:
        _get(f"http://127.0.0.1:{UI_PORT}/", 2)
        print("Frontend already running on port", UI_PORT)
        return None
    except Exception:
        pass
    npm = "npm"
    install = [npm, "ci"] if (FRONTEND / "package-lock.json").exists() else [npm, "install"]
    for cmd in (install, [npm, "run", "build"]):
        print("$", " ".join(cmd))
        r = subprocess.run(cmd, cwd=str(FRONTEND), capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"`{' '.join(cmd)}` failed:\n{(r.stdout + r.stderr)[-2000:]}")
    log = LOG_DIR / "vendor360_frontend.log"
    proc = subprocess.Popen([npm, "run", "preview", "--", "--host", "0.0.0.0", "--port", str(UI_PORT), "--strictPort"],
                            cwd=str(FRONTEND), stdout=open(log, "w"), stderr=subprocess.STDOUT)
    for _ in range(60):
        if proc.poll() is not None:
            raise RuntimeError("Frontend server exited:\n" + _tail(log))
        try:
            _get(f"http://127.0.0.1:{UI_PORT}/", 2)
            return proc
        except Exception:
            time.sleep(1)
    raise TimeoutError("Frontend did not answer on port %d:\n%s" % (UI_PORT, _tail(log)))


def _load_gemini_key() -> bool:
    """Optional: copy the Colab secret GEMINI_API_KEY into this process's environment so the API
    (started below) can use it. The key is never printed and nothing is sent to Gemini at startup.
    Returns True when a key is present in the environment afterwards."""
    key = (os.environ.get("GEMINI_API_KEY") or "").strip()
    source = "environment"
    if not key:
        source = "Colab secret"
        try:
            from google.colab import userdata
            key = (userdata.get("GEMINI_API_KEY") or "").strip()
        except ImportError:
            print("Gemini: not running in Colab and GEMINI_API_KEY is not set; Gemini buttons will say so.")
            return False
        except Exception as exc:  # name mismatch or 'Notebook access' toggle is off
            print("Gemini: could not read the Colab secret GEMINI_API_KEY (%s: %s)." % (type(exc).__name__, exc))
            print("        Open the key icon in Colab, check the name and switch 'Notebook access' on.")
            return False
    if not key:
        print("Gemini: no key set; the Gemini buttons will say so. Everything else works without it.")
        return False
    os.environ["GEMINI_API_KEY"] = key
    print("Gemini: key loaded from the %s (used only when a Gemini button is clicked)." % source)
    if not key.startswith("AIza") or len(key) != 39:
        print("        Note: Google AI Studio keys normally start with 'AIza' and are 39 characters; "
              "yours has %d. If Gemini calls fail with an authentication error, create a new key." % len(key))
    return True


def _api_has_key() -> bool | None:
    """Ask the running API whether it sees a Gemini key. None = could not tell."""
    try:
        status, body = _get(f"http://127.0.0.1:{API_PORT}/api/gemini/status")
        return bool(json.loads(body).get("configured")) if status == 200 else None
    except Exception:
        return None


def _stop_api() -> None:
    """Stop whatever is serving the API port so it can be restarted with a fresh environment."""
    for cmd in (["fuser", "-k", f"{API_PORT}/tcp"], ["pkill", "-f", "uvicorn backend.api:app"]):
        try:
            subprocess.run(cmd, capture_output=True, timeout=10)
        except Exception:
            pass
    for _ in range(20):
        if _health() is None:
            return
        time.sleep(0.5)
    raise RuntimeError(f"Could not stop the old API on port {API_PORT}. Run Runtime > Restart session and try again.")


def main() -> dict:
    sys.path.insert(0, str(ROOT))
    import prepare_colab
    env = prepare_colab.main()
    _load_gemini_key()
    api = start_api(env)
    print("Waiting for the backend pipeline (about 15 s)...")
    health = wait_ready(api)
    ui = start_frontend()
    print(f"Vendor360 is ready: UI http://localhost:{UI_PORT}  (API health: {health.get('status')})")
    return {"api": api, "ui": ui, "health": health}


if __name__ == "__main__":
    main()
    # Keep the processes alive when run as a plain script.
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
