# Phase 4 / 5 (package side) — what changed

## Executed and tested (sandbox; `pytest tests` = 38 passed; `npm run typecheck` and `npm run build` OK)
1. **Onboarding Cost = real INR unit price** (your decision). Supplier-level median INR unit price over per-unit pricing models
   (tiered, day_rate, usage, blended_rate); lump-sum models (fixed, performance, subscription) are excluded. Range 0 - 277,830,
   median about 62,280. 8 of 40 suppliers have only lump-sum pricing and start at the portfolio median. The bounded 0-1 cost KPI used by
   MCDA is unchanged (tested). Files: `backend/modules/foundation.py` (VENDOR360_ONBOARDING_PRICE), `backend/onboarding.py`,
   `backend/api.py`, `frontend/src/App.tsx`, `frontend/src/api/vendor360.ts`.
2. **Real PASS checks (P5)**: helper `v360_status` (PASS / PARTIAL / CHECK REQUIRED) in `foundation.py`. Replaced the unconditional banners of
   Cells 19, 19.1, 20, 21, 23, 24A, 24C and 26C; removed the static "validation" lines in Cell 21. Cell 26 reads anomalies from `Vendor360_Cell19/`.
3. **Phase 5 tests**: `tests/test_phase4.py` (status semantics, failing check is reported, onboarding INR rule recomputed from source files,
   HTTP health/portfolio/onboarding/scenario tests on real FastAPI, Node test of `normalizeSupplier` via `frontend/tests/normalize.test.mjs`).
   Phase 3 onboarding tests updated for the new Cost range.

## NOT done / NOT run
- Notebook `Vendor360_V4_Final.ipynb` is NOT modified (P1-P5 port, Streamlit P2/P3/P4, Cell 25 Gemini timeout, SDK mix, 24C validation).
- Streamlit never run. No live Gemini call. No browser check of the Onboarding page. Not run in a real Colab runtime.
- FX rates in `config/fx_rates.json` are indicative placeholders.
- Open decisions: reliability 41.0 vs 38.5; capacity range 0-36000; keep/delete unused `/api/onboarding` + `/api/export/onboarding`.
