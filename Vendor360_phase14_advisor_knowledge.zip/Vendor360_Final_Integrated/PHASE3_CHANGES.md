# Phase 3 — what changed (Colab-only; Docker dropped by decision)

## Executed and tested (tests/test_phase3.py 10/10, tests/test_phase2.py 7/7; real pipeline, no Gemini key, no network)
1. **No hard-coded `/content`** (68 references in 7 modules). Two settings: `VENDOR360_WORKDIR` (generated files, default `/content`)
   and `VENDOR360_INPUT_DIR` (source CSVs, default = work dir). `pipeline.run_backend(work_dir, execute_ai=False, input_dir=None)` injects
   `V360_WORK` / `V360_INPUT` into the shared namespace; the modules use them. Verified with separate temp folders: sources untouched,
   nothing written to or read from `/content`.
2. **Idempotent re-runs.** Ingestion ignores any file whose name starts with `Vendor360_`. A second run in a shared, dirty folder gives identical
   scores/ranks (checked), and results equal the Phase 2 baseline (max score difference 0.0, same ranks).
3. **Startup.** `_boot()` runs in a background thread; `/api/health` returns `status: starting | ready | error` (plus `ok`, `backend_ready`, `error`,
   `workdir`, `input_dir`). Data endpoints answer 503 "still starting" until ready. Boot deletes only `Vendor360_*` entries in the work folder
   (user files are kept; tested).
4. **Frontend waits for startup**: `getJson` polls every 2 s for up to 90 s on the 503 "still starting" answer without using up retries.
5. **CORS**: `*` replaced by localhost origins (override: `VENDOR360_CORS_ORIGINS`); methods limited to GET/POST. The Colab launcher binds the API to `127.0.0.1`
   (reached only via the frontend `/api` proxy).
6. **Dependencies**: one `requirements.txt` (backend copy removed), now with `ipython`, `httpx`; unused `plotly` and widget-only `ipywidgets` removed
   (range-bounded, not exact pins — see below).
7. **Colab**: notebook glob now matches `Vendor360_FINAL_FIGMA_INTEGRATED*.zip`; no `rmtree` of the old project; `launch_colab.py` starts the API,
   polls `/api/health`, builds and serves the frontend (`npm ci`, `npm run build`, `npm run preview`), no `sleep(5)`. `prepare_colab.py` now only validates the data files
   (no copy into `/content`).
8. **Docs/config**: `.env.example`, `frontend/README_VENDOR360_INTEGRATION.md` (correct `/api`, `scenario_text`), `index.html` placeholders, `AGENTS.md`, root `README.md`, `.gitignore`.
9. **Packaging**: notebook with outputs (2.1 MB) moved to `reference/` with outputs cleared (0.85 MB, not used at runtime). `exec` shared-namespace design documented in README and `pipeline.py`.
10. **Removed** `Dockerfile` and `docker-compose.yml` (could not work and are out of scope).

## NOT executed (this sandbox has no network)
- Real FastAPI/uvicorn: `api.py` was exercised by calling its functions with a light FastAPI stub, not through HTTP. `tests/test_phase1.py` (endpoint tests) was updated to wait for readiness but **not run**.
- Frontend: `getJson` change, `index.html` and docs were not type-checked or built (no `node_modules`, `npm ci` impossible offline). Run `npm ci && npm run typecheck && npm run build`.
- `launch_colab.py` and the Colab notebook: syntax/JSON-checked and string-tested only; never run in Colab. `pip install -r requirements.txt` was not run, so the version ranges are unverified against Colab.
- Browser rendering, live Gemini.

## Observations
- The MCDA minimum is **0.255** on both the Phase 2 package and this one (the Phase 2 notes say 0.363). Max 0.699, rank 1 Visium Data Engineering. I did not find which number is right in the notes; the code output is the reference.
- The old PASS banners printed by the notebook-derived modules (e.g. "STATUS: PASS (6/6)") are still unconditional — that is Phase 4 (P5).
- The Vite server still uses `host 0.0.0.0` / `allowedHosts: true` (needed for Colab's proxy hostnames, no login). Documented in README.

## Colab run result (user, real runtime) and follow-up fixes
Executed in Colab: `pytest tests` 21 passed / 1 failed; `npm ci`, `tsc --noEmit` (0 errors) and `npm run build` OK; `launch_colab.py` reached `health: ready`;
`/api/health`, `/api/portfolio` (40 rows) and `/api/scenario` returned data.
- The one failure was a **stale assertion** in `tests/test_phase1.py` (it still expected `value_by_currency`; Phase 2 replaced it with `award_value_inr`). Test updated; not re-run in Colab yet.
- Test suite took 3 min because every `TestClient` session re-ran the pipeline; the API lifespan now skips booting if already `ready`.
- Added an explicit `preview.proxy` for `/api` in `vite.config.ts` (Vite's preview server defaults to `server.proxy`; now stated outright).
- `localhost:5173` is not reachable from a browser in Colab: open the URL printed by `google.colab.kernel.proxyPort(5173)`.

## Onboarding page: replaced by the original Portfolio-Fit readiness assessment
My earlier "rework" kept a contract/restriction/pricing checklist that was never the intended module. It is replaced by a port of the original
Streamlit "Supplier Onboarding Readiness" page (logic read from the source notebook, cell 64):
- `backend/onboarding.py` (pure, deterministic): allowed ranges, direction-aware better-than %, Strong >=75 / Above average >=50 / Watch >=25 / Weak <25,
  Portfolio Fit Index = mean of better-than %, assessment (REVIEW REQUIRED / MANAGEMENT REVIEW / READY FOR MANAGEMENT REVIEW), strengths, attention areas,
  management recommendation, business interpretation, completeness (x/9), "needs information" when identity fields are missing, 422 on out-of-range input.
- `GET /api/onboarding/config`, `POST /api/onboarding/assess` (also `preview:true` for the live completeness bar). Nothing is stored; the portfolio is never modified.
- React page: Existing / New supplier, ranges table, form (inputs clamped to range, new supplier starts at portfolio medians), completeness bar, results.
  The UI contains no scoring logic. No Gemini involved.
- Verified against your screenshots: with portfolio-median input, Quality/Risk/Sustainability/Capacity = 50 and Reliability = 48.7; with input #2,
  Quality 90.0, Risk 40.0, Sustainability 77.5, Capacity 57.5 and "MANAGEMENT REVIEW" all match.
- Known differences from the screenshots: (1) **Cost** is now a price position (0 = cheapest .. 1 = most expensive) because Phase 2 replaced the raw mixed-currency
  price; range 0-1 instead of 0-268320. (2) Reliability for 22.34 gives 41.0, not 38.5 (portfolio data changed slightly after the Phase 1/2 fixes; cause not isolated).
  (3) Capacity range is 0-36000 instead of 0-2e+06 because the 999999 placeholder no longer inflates the maximum.
- Existing suppliers are compared against the whole portfolio including themselves (as in the original; ties are not counted as better).
Tests: 14/14 in test_phase3.py (new: original-rule match, weak/ready/edge cases, range rejection, portfolio untouched). TSX only syntax-checked here.
