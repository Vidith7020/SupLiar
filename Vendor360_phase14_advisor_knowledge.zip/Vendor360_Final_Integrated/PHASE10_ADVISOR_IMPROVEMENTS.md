# Phase 10 — Advisor reliability
- `launch_colab.py`: restarts a stale API that has no Gemini key; clear error when the Colab secret can't be read.
- `gemini_client.py`: tries fallback models (gemini-2.5-flash, gemini-2.0-flash) when the configured one is not found for the key; one retry on 429/503/timeouts; asks for JSON mime type; errors rewritten in plain words (bad key, quota, model, timeout); reports the model that actually answered.
- `advisor_core.py`: supplier names tolerate typos ("Computacentre", "Accentur"), only for one close, distinctive first word, so ordinary questions don't match.
- Tests: 31/31 in `python tests/test_advisor_core.py`. `tests/test_gemini.py` needs pytest and was not run here.
- Not run: real Gemini call, Colab, vite build.
