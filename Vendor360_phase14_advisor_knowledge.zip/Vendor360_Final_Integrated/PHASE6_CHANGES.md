# Phase 6 — on-demand Gemini
New: backend/gemini_client.py, tests/test_gemini.py.
Changed: backend/api.py (advisor split into engine answer + optional Gemini layer; status and insights endpoints), launch_colab.py (Colab secret -> environment), frontend/src/App.tsx, frontend/src/api/vendor360.ts, frontend/src/index.css, requirements.txt (comments only), INTEGRATION_STATUS.md.
Behaviour without a key or with use_gemini=false: identical to Phase 5.
Checked in sandbox: py_compile, helper logic with a faked model, TSX syntax parse. NOT run: pytest, npm typecheck/build, a real Gemini call, browser.
