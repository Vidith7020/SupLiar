# Phase 14: local advisor that answers beyond the data

The advisor (no Gemini needed) now answers three new kinds of question in addition to everything it already did:

1. **General procurement questions**: "What key features should a big business seek in a supplier?", "Why is dual sourcing important?",
   "How should I negotiate?", "Should we consolidate suppliers?", "What should an SLA include?", "What is vendor lock-in?"
2. **Questions about Vendor360 itself**: how the MCDA score works, what the Risk Radar statuses mean, why a top-ranked supplier can be high risk,
   why rankings change with priorities, what HHI is, what the dimension numbers mean.
3. **Portfolio suggestions**: "What do you suggest we focus on?", "How can we improve our supplier portfolio?" give a prioritised action list
   computed from your rows (risk first, then backup, concentration, ESG, data gaps, cost trap).

## How it works
- `backend/advisor_kb_a.py`, `advisor_kb_b.py`, `advisor_kb_c.py`: 62 hand-written topics (selection, TCO, KPIs, due diligence, risk, dual sourcing,
  concentration, contracts and SLAs, negotiation, payment terms, ESG, cyber, fraud, onboarding, SRM, sector guidance, Vendor360 methodology).
- `backend/advisor_knowledge.py`: ranks topics with a small BM25-style scorer (stemming, synonyms, keyword phrases), reads the question style
  (why / how / list / should / compare / pitfalls / example), the buyer (large business, SME, startup, public sector) and the sector
  (IT, logistics, manufacturing, services, facilities), then composes the answer. Pure python, no model, no network, deterministic.
- Data hooks add an **"In your portfolio"** paragraph computed only from engine values (never invented): suitability against a stated bar,
  cheapest-but-flagged suppliers, risk exposure, backup gaps, concentration, ESG gaps, data gaps, country mix, rank vs risk.
- Follow-ups work: "Tell me more", "Give me an example", "What mistakes should I avoid?", "Explain it simply", "What about for a small business?".
  The frontend sends `topic_ids` back in the history so the advisor knows which topic you are on.
- Unmatched procurement questions get a short "how I would think about it" framework; unrelated ones get a polite scope message.
- Questions about your data are unchanged: `which suppliers...`, `who is...`, `how many...`, named suppliers, what-ifs and requirement statements still go to the
  existing deterministic engine. A regression run of 56 data questions shows 0 routing changes.
- Gemini mode: when the engine answer is general guidance, the prompt tells Gemini to keep its substance and take every portfolio statement from CONTEXT.

## Files changed
New: `backend/advisor_knowledge.py`, `advisor_kb_a.py`, `advisor_kb_b.py`, `advisor_kb_c.py`, `tests/test_advisor_knowledge.py`.
Edited: `backend/advisor_core.py` (routing, history `topic_ids`, new intents `knowledge`, `suggestions`, `framework`, `out_of_scope`, `about`),
`backend/gemini_client.py` (one conditional prompt sentence), `frontend/src/App.tsx` and `frontend/src/api/vendor360.ts` (send `topic_ids`, new starter chip, hint text).

## Run
    python tests/test_advisor_core.py        # 31/31
    python tests/test_advisor_knowledge.py   # 22/22

## Honest notes
- The knowledge is general practice written by hand, labelled as such in every answer ("How this answer was built"). It has no statistics beyond
  clearly marked rules of thumb (HHI bands, 60/40-style splits). Contract and compliance answers say they are not legal advice.
- Not run here: the frontend build (no node_modules in the sandbox) and the HTTP tests that need the real data files / FastAPI backend.
  The frontend change is two optional fields and two strings.
- Risk Radar thresholds quoted in the app_risk_radar topic (Stable <25, Watch 25-35, Emerging 35-45, Critical >=45) match the current engine constants; update
  that topic if you retune them.
