# Phase 8 — Insights on six pages
Pages: Risk Monitoring, Performance Trends, Dependency Analysis, Sustainability, Supplier Directory, Supplier Comparison.
No backend change. Every sentence is built from values the API already returns (counts, means, medians, differences, shares); nothing is estimated for missing data.

Changed: frontend/src/App.tsx (six page components + shared `InsightPanel` / `MiniBar`), frontend/src/index.css (appended `ins-*` block),
frontend/src/api/vendor360.ts (SupplierRecord gains `capacityEstimated`, read from the `capacity_estimated` field /api/portfolio already returns).
New: frontend/src/insights.ts — pure functions, no React, so the logic is unit-testable.

What each page now says
- Risk: exposure headline (% critical/emerging, watch), most common risk signal, top-10 recommended suppliers that carry a warning, category with the highest average risk, country clustering of flagged suppliers, highest-risk supplier with the best Stable alternative in its category. New panels: average risk by category, signal frequency. Queue table gains MCDA rank and "Safer alternative".
- Trends: first/last month flagged as incomplete when awards < 50% of the median month (excluded from direction checks), lead time / risk / savings direction (flat = under 3% change; never raises a warning with fewer than 4 complete months), savings range, average contract value. Metric tabs on the chart, month-on-month arrows in the table. KPI averages are now award-weighted and no longer treat missing values as 0.
- Dependency: most concentrated category, top-3 share, heavily used suppliers that carry a risk warning, awards vs MCDA rank mismatch, thin categories (<=2 suppliers), single-source sub-categories with the sole supplier's status. Tables gain share bars, MCDA rank, risk status.
- Sustainability: share below the 70 review line, weakest category, top-10 suppliers under the line, low-ESG + risk-warning overlap, ESG-vs-MCDA correlation (stated as correlation only), missing-data count. New: band distribution, leaders, laggards.
- Directory: leader, risk-action count, strong-but-flagged suppliers, incomplete-data count, category leaders strip, category filter, "Key takeaway" column (engine strengths/concerns text).
- Comparison: verdict, trade-offs vs the leader, risk differences, fastest delivery, category caveat, head-to-head bars, "best supplier by priority", raw lead-time and capacity rows (capacity flagged "(estimated)" where the engine substituted a placeholder).

Verification done (sandbox): tsc with stubbed React types (no @types/react offline) = clean; insight functions run on CSV-derived trends/dependency and a synthetic portfolio incl. empty/1-item edge cases; the real App bundled with esbuild and rendered in Chromium against a mock API: all six pages render, 0 runtime errors, insight links, category filter and trend tabs work.
NOT run: pytest, `npm ci` / `vite build` / real `tsc` with @types/react, the real backend, Colab. Tailwind preflight was not loaded in the browser check, so spacing may differ slightly from the real build.
The mock portfolio used for the browser check is synthetic (statuses/ranks invented to exercise every code path); do not read any screenshot as real engine output.
