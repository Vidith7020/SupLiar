# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 58 =====

# ============================================================
# CELL 26B — VENDOR360 DECISION INTELLIGENCE INTEGRATION
# ============================================================
import os
import json
import numpy as np
import pandas as pd

DI_OUT_DIR = V360_WORK + "/Vendor360_Cell26B"
os.makedirs(DI_OUT_DIR, exist_ok=True)

# Use already-computed backend objects; never recompute raw analytics here.
_di_kpi = supplier_kpi_df.copy() if "supplier_kpi_df" in globals() else pd.DataFrame()
_di_risk = risk_radar_df.copy() if "risk_radar_df" in globals() else (risk_radar.copy() if "risk_radar" in globals() else pd.DataFrame())


def _first_existing(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None

_di_id = _first_existing(_di_kpi, ["supplier_id", "entity_id", "vendor_id"])
_di_name = _first_existing(_di_kpi, ["supplier_name", "entity_name", "vendor_name"])
if _di_id is None:
    raise ValueError("Decision Intelligence could not detect a supplier/entity ID.")
if _di_name is None:
    _di_kpi["supplier_name"] = _di_kpi[_di_id].astype(str)
    _di_name = "supplier_name"

_di_mcda = _first_existing(_di_kpi, ["mcda_score", "mcda__overall_score", "overall_score"])
_di_rank = _first_existing(_di_kpi, ["supplier_mcda_rank", "mcda_rank"])
if _di_rank is None and _di_mcda:
    _di_kpi["supplier_mcda_rank"] = pd.to_numeric(_di_kpi[_di_mcda], errors="coerce").rank(ascending=False, method="min")
    _di_rank = "supplier_mcda_rank"

# Merge operational risk into the decision view only after MCDA is complete.
_risk_id = _first_existing(_di_risk, ["supplier_id", "entity_id", "vendor_id"])
if _risk_id is not None:
    _di_risk2 = _di_risk.rename(columns={_risk_id: _di_id})
else:
    _di_risk2 = pd.DataFrame(columns=[_di_id])

_keep_risk = [c for c in [
    _di_id, "risk_radar_score", "risk_radar_status", "risk_radar_action",
    "risk_radar_flags", "risk_affected_dimensions", "risk_explanation",
    "risk_radar_recommendation"
] if c in _di_risk2.columns]

_decision = _di_kpi.copy()
if _keep_risk:
    _decision = _decision.merge(
        _di_risk2[_keep_risk].drop_duplicates(subset=[_di_id]),
        on=_di_id, how="left"
    )

# Deterministic supplier strengths/weaknesses from available KPI dimensions.
_dimension_cols = {
    "Cost": "cost_kpi", "Quality": "quality_kpi", "Reliability": "reliability_kpi",
    "Risk": "risk_kpi", "Sustainability": "sustainability_kpi", "Capacity": "capacity_kpi"
}
_direction_map = {}
try:
    _direction_map = {str(k).lower(): str(v).lower() for k, v in kpi_directions.items()}
except Exception:
    pass

for dim, col in _dimension_cols.items():
    if col not in _decision.columns:
        continue
    vals = pd.to_numeric(_decision[col], errors="coerce")
    if vals.notna().sum() < 2:
        continue
    lo, hi = vals.min(), vals.max()
    norm = pd.Series(0.5, index=_decision.index) if hi == lo else (vals - lo) / (hi - lo)
    direction = _direction_map.get(dim.lower(), "higher")
    if direction == "lower":
        norm = 1 - norm
    _decision[f"_performance__{dim}"] = norm

_perf_cols = [c for c in _decision.columns if c.startswith("_performance__")]
def _fmt_dim(name):
    return str(name).replace("_", " ").strip().title()
def _contributors(row, positive=True, n=3):
    items = []
    for c in _perf_cols:
        v = pd.to_numeric(row.get(c), errors="coerce")
        if pd.notna(v):
            items.append((_fmt_dim(c.replace("_performance__", "")), float(v)))
    items.sort(key=lambda x: x[1], reverse=positive)
    return "; ".join(f"{name} ({value:.2f})" for name, value in items[:n]) or "No comparable dimension data"

def _decision_explanation(row):
    positives = _contributors(row, True)
    negatives = _contributors(row, False)
    risk_status = str(row.get("risk_radar_status", "Unavailable"))
    risk_score = pd.to_numeric(row.get("risk_radar_score"), errors="coerce")
    risk_text = f"risk score {risk_score:.1f} ({risk_status})" if pd.notna(risk_score) else f"risk status {risk_status}"
    # Phase 2: wording depends on the supplier-level rank so rank 39/40 is never "Recommended".
    _rk = pd.to_numeric(row.get(_di_rank), errors="coerce") if _di_rank in row.index else np.nan
    _n = int(_decision[_di_rank].notna().sum()) if _di_rank in _decision.columns else 0
    if pd.isna(_rk) or _n == 0:
        _lead = "Assessed on available business dimensions"
    elif _rk <= max(1, round(_n * 0.25)):
        _lead = "Recommended on available business dimensions"
    elif _rk <= round(_n * 0.75):
        _lead = "Mid-ranked on available business dimensions"
    else:
        _lead = "Lower-ranked on available business dimensions; consider only with mitigation"
    return f"{_lead}, with strongest contributors: {positives}. Main trade-offs/weaknesses: {negatives}. Operational context: {risk_text}."

_decision["positive_contributors"] = _decision.apply(lambda r: _contributors(r, True), axis=1)
_decision["negative_contributors"] = _decision.apply(lambda r: _contributors(r, False), axis=1)
_decision["decision_explanation"] = _decision.apply(_decision_explanation, axis=1)

# Decision position keeps recommendation and risk visibly separate.
def _position(row):
    rank = pd.to_numeric(row.get(_di_rank), errors="coerce") if _di_rank else np.nan
    status = str(row.get("risk_radar_status", "")).lower()
    if "critical" in status:
        return "High MCDA / Critical" if pd.notna(rank) and rank <= 3 else "Critical"
    if "emerging" in status:
        return "Recommended with Mitigation" if pd.notna(rank) and rank <= 3 else "Review"
    if "watch" in status:
        return "Recommended with Monitoring" if pd.notna(rank) and rank <= 3 else "Monitor"
    return "Recommended" if pd.notna(rank) and rank <= 3 else "Consider"

_decision["decision_position"] = _decision.apply(_position, axis=1)
_decision["recommended_action"] = _decision.apply(
    lambda r: str(r.get("risk_radar_recommendation", "Use MCDA ranking together with current risk status.")), axis=1
)

# Public output — only decision fields, no internal normalization columns.
_public_cols = [
    _di_id, _di_name, _di_mcda, _di_rank,
    "risk_radar_score", "risk_radar_status", "risk_radar_action",
    "positive_contributors", "negative_contributors", "risk_affected_dimensions",
    "risk_explanation", "decision_position", "decision_explanation", "recommended_action"
]
_public_cols = [c for c in _public_cols if c and c in _decision.columns]
decision_intelligence_df = _decision[_public_cols].copy()

if _di_mcda and _di_mcda in decision_intelligence_df.columns:
    decision_intelligence_df = decision_intelligence_df.sort_values(_di_mcda, ascending=False, na_position="last")

# Supplier-level lookup helper: useful for Why A? and Compare A vs B in Streamlit.
def explain_supplier(supplier_id):
    match = decision_intelligence_df[decision_intelligence_df[_di_id].astype(str) == str(supplier_id)]
    if match.empty:
        return None
    return match.iloc[0].to_dict()

def compare_suppliers(supplier_a, supplier_b):
    a = explain_supplier(supplier_a)
    b = explain_supplier(supplier_b)
    if a is None or b is None:
        return None
    return pd.DataFrame([a, b])

def run_what_if_scenario(scenario_text):
    if "run_advisor" not in globals():
        raise RuntimeError("Cell 25 scenario engine is not available. Run Cell 25 first.")
    result = run_advisor(scenario_text, engine="Local Deterministic")
    baseline = decision_intelligence_df.copy()
    scenario_rank = result["ranking"].copy()
    sid = _first_existing(scenario_rank, [_di_id, "supplier_id", "entity_id"])
    sscore = _first_existing(scenario_rank, ["scenario__decision_score"])
    srank = _first_existing(scenario_rank, ["scenario__rank"])
    if sid is None or sscore is None or srank is None:
        return result
    scenario_view = scenario_rank[[sid, sscore, srank]].copy()
    scenario_view.columns = [_di_id, "scenario_score", "scenario_rank"]
    scenario_view[_di_id] = scenario_view[_di_id].astype(str)
    baseline["_join_id"] = baseline[_di_id].astype(str)
    scenario_view["_join_id"] = scenario_view[_di_id].astype(str)
    out = baseline.merge(scenario_view.drop(columns=[_di_id]), on="_join_id", how="left")
    if _di_rank:
        out["baseline_rank"] = pd.to_numeric(out[_di_rank], errors="coerce")
    else:
        out["baseline_rank"] = np.nan
    out["rank_change"] = out["baseline_rank"] - out["scenario_rank"]
    if _di_mcda:
        out["baseline_score"] = pd.to_numeric(out[_di_mcda], errors="coerce")
    else:
        out["baseline_score"] = np.nan
    out["score_change"] = out["scenario_score"] - out["baseline_score"]
    out["scenario_explanation"] = out.apply(
        lambda r: f"Rank {r['baseline_rank']:.0f} → {r['scenario_rank']:.0f}; score change {r['score_change']:+.3f}. The change reflects the scenario's revised business priorities across available dimensions." if pd.notna(r.get("scenario_rank")) and pd.notna(r.get("baseline_rank")) else "Scenario result unavailable for this supplier.",
        axis=1
    )
    return {"ranking": out.sort_values("scenario_rank", na_position="last"), "interpretation": result.get("interpretation"), "weights": result.get("weights"), "recommendation": result.get("recommendation"), "score": result.get("score")}

# Save for Streamlit / export.
decision_intelligence_df.to_csv(
    os.path.join(DI_OUT_DIR, "Vendor360_Decision_Intelligence.csv"), index=False
)
with open(os.path.join(DI_OUT_DIR, "Vendor360_Decision_Intelligence_Metadata.json"), "w", encoding="utf-8") as f:
    json.dump({
        "module": "Decision Intelligence",
        "mcda_is_recommendation_score": True,
        "risk_is_operational_context_only": True,
        "available_dimensions": [d for d,c in _dimension_cols.items() if c in _decision.columns],
        "risk_status_levels": ["Stable", "Watch", "Emerging Risk", "Critical"],
        "risk_thresholds": {k: v for k, v in RISK_THRESHOLDS.items()} if "RISK_THRESHOLDS" in globals() else None,
        "what_if_supported": "Cell 25 run_advisor + deterministic baseline/scenario comparison"
    }, f, indent=2)

print("=" * 70)
print("VENDOR360 CELL 26B — DECISION INTELLIGENCE")
print("=" * 70)
print(f"Decision rows: {len(decision_intelligence_df):,}")
print("✓ Why/Explainability fields generated")
print("✓ MCDA recommendation kept separate from operational risk")
print("✓ Compare helper ready")
print("✓ What-If baseline/scenario helper ready")
print(f"✓ Output: {DI_OUT_DIR}/Vendor360_Decision_Intelligence.csv")

decision_intelligence_df.head(10)


# ===== ORIGINAL NOTEBOOK CELL 60 =====

# ============================================================
# CELL 26C — VENDOR360 DECISION INTELLIGENCE VALIDATION
# ============================================================
_required = [
    "risk_radar_status", "risk_explanation", "positive_contributors",
    "negative_contributors", "decision_explanation", "decision_position"
]
_validation = {
    "Risk Radar 4-level status": all(c in risk_radar_df.columns for c in ["risk_radar_status"]),
    "Risk explanation": all(c in risk_radar_df.columns for c in ["risk_explanation"]),
    "Decision Intelligence generated": "decision_intelligence_df" in globals() and len(decision_intelligence_df) > 0,
    "Why explainability": all(c in decision_intelligence_df.columns for c in ["positive_contributors", "negative_contributors", "decision_explanation"]),
    "Decision position": "decision_position" in decision_intelligence_df.columns,
    "Export saved": v360_file_ok(V360_WORK + "/Vendor360_Cell26B/Vendor360_Decision_Intelligence.csv"),
    "One decision row per supplier in the KPI table": len(decision_intelligence_df) == len(supplier_kpi_df),
    "Decision text present for every supplier": ("decision_explanation" in decision_intelligence_df.columns) and bool(decision_intelligence_df["decision_explanation"].astype(str).str.strip().ne("").all()),
}
print("=" * 70)
print("VENDOR360 CELL 26C — FINAL DECISION INTELLIGENCE VALIDATION")
print("=" * 70)
_status_26c = v360_status("CELL 26C", {k: bool(v) for k, v in _validation.items()})
if _status_26c == "PASS":
    print("Vendor360 Decision Intelligence backend is ready for Streamlit integration.")
