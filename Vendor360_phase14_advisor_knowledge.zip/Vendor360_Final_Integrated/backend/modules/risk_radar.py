# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 56 =====

# ============================================================
# CELL 26 — VENDOR360 DECISION INTELLIGENCE / RISK RADAR
# ============================================================
# Purpose:
#   Build an adaptive supplier Risk Radar and Early Warning Engine.
#
# Uses existing outputs:
#   - Vendor360_Analysis_Base.csv
#   - Vendor360_Supplier_KPI_Comparison.csv
#   - MCDA_Results.csv
#   - Anomaly_Results.json
#
# Does NOT rerun ML models.
#
# Risk bands:
#   LOW    : <40
#   MEDIUM : 40–59.99
#   HIGH   : >=60
#
# ============================================================

import os
import re
import json
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ============================================================
# 1. PATHS
# ============================================================

BASE_PATH = V360_WORK + "/Vendor360_Analysis_Base.csv"
KPI_PATH = V360_WORK + "/Vendor360_Cell23/Vendor360_Supplier_KPI_Comparison.csv"
MCDA_PATH = V360_WORK + "/Vendor360_Cell19/MCDA_Results.csv"
ANOMALY_PATH = V360_WORK + "/Vendor360_Cell19/Anomaly_Results.json"  # written by Cell 19 (was Cell20)

OUT_DIR = V360_WORK + "/Vendor360_Cell26"

os.makedirs(
    OUT_DIR,
    exist_ok=True
)


# ============================================================
# 2. LOAD EXISTING OUTPUTS
# ============================================================

if not os.path.exists(BASE_PATH):

    raise FileNotFoundError(
        "Vendor360_Analysis_Base.csv not found. Run Cell 17 first."
    )

base = pd.read_csv(BASE_PATH)


kpi = None

if os.path.exists(KPI_PATH):

    try:

        kpi = pd.read_csv(KPI_PATH)

    except Exception:

        kpi = None


mcda = None

if os.path.exists(MCDA_PATH):

    try:

        mcda = pd.read_csv(MCDA_PATH)

    except Exception:

        mcda = None


anomaly_summary = {}

if os.path.exists(ANOMALY_PATH):

    try:

        with open(
            ANOMALY_PATH,
            "r",
            encoding="utf-8"
        ) as f:

            anomaly_summary = json.load(f)

    except Exception:

        anomaly_summary = {}


# ============================================================
# 3. HELPER FUNCTIONS
# ============================================================

def norm_text(x):

    return re.sub(
        r"[^a-z0-9]+",
        "_",
        str(x).strip().lower()
    ).strip("_")


def find_column(
    df,
    patterns,
    exclude=None
):

    if df is None or df.empty:

        return None

    exclude = exclude or []

    cols = list(df.columns)


    # Exact normalized matches

    for pattern in patterns:

        p = norm_text(pattern)

        for col in cols:

            c = norm_text(col)

            if (
                c == p
                and col not in exclude
            ):

                return col


    # Token / substring scoring

    candidates = []

    for col in cols:

        if col in exclude:

            continue

        c = norm_text(col)

        score = 0

        for pattern in patterns:

            p = norm_text(pattern)

            if p in c:

                score += len(p)

            tokens = p.split("_")

            for token in tokens:

                if (
                    len(token) >= 4
                    and token in c
                ):

                    score += 2

        if score > 0:

            candidates.append(
                (score, col)
            )


    if candidates:

        candidates.sort(
            reverse=True
        )

        return candidates[0][1]


    return None


def find_all_columns(
    df,
    patterns,
    exclude=None
):

    if df is None or df.empty:

        return []

    exclude = exclude or []

    found = []

    for col in df.columns:

        if col in exclude:

            continue

        c = norm_text(col)

        for pattern in patterns:

            p = norm_text(pattern)

            if p in c:

                found.append(col)

                break

    return list(
        dict.fromkeys(found)
    )


def safe_numeric(series):

    return pd.to_numeric(
        series,
        errors="coerce"
    )


def percentile_score(
    series,
    higher_is_worse=True
):

    s = safe_numeric(series)

    if s.notna().sum() == 0:

        return pd.Series(
            np.nan,
            index=series.index
        )

    if s.nunique(
        dropna=True
    ) <= 1:

        return pd.Series(
            50.0,
            index=series.index
        )

    ranks = s.rank(
        method="average",
        pct=True
    )

    if higher_is_worse:

        result = ranks * 100

    else:

        result = (
            1 - ranks
        ) * 100

    return result


def normalize_positive_score(
    series
):

    return percentile_score(
        series,
        higher_is_worse=False
    )


def normalize_negative_score(
    series
):

    return percentile_score(
        series,
        higher_is_worse=True
    )


# ============================================================
# 4. DETECT ENTITY FIELDS
# ============================================================

entity_id_col = find_column(
    base,
    [
        "entity_id",
        "supplier_id",
        "vendor_id",
        "provider_id",
        "company_id",
        "id"
    ]
)


entity_name_col = find_column(
    base,
    [
        "entity_name",
        "supplier_name",
        "vendor_name",
        "provider_name",
        "company_name",
        "name"
    ]
)


if entity_id_col is None:

    raise ValueError(
        "Could not identify a supplier/entity ID column."
    )


if entity_name_col is None:

    entity_name_col = entity_id_col


# ============================================================
# 5. SUPPLIER-LEVEL BASE
# ============================================================

df = base.copy()

df[entity_id_col] = (
    df[entity_id_col]
    .astype(str)
    .str.strip()
)


supplier = (
    df
    .groupby(
        entity_id_col,
        dropna=False
    )
    .first()
    .reset_index()
)


# ============================================================
# 6. MERGE CELL 23 SUPPLIER KPI OUTPUT
# ============================================================

if (
    kpi is not None
    and not kpi.empty
):

    kpi_id = find_column(
        kpi,
        [
            "supplier_id",
            "entity_id",
            "vendor_id"
        ]
    )

    if kpi_id is not None:

        kpi_copy = kpi.copy()

        kpi_copy[kpi_id] = (
            kpi_copy[kpi_id]
            .astype(str)
            .str.strip()
        )


        keep_cols = [

            c

            for c in kpi_copy.columns

            if (
                c == kpi_id
                or c not in supplier.columns
            )

        ]


        kpi_copy = (
            kpi_copy[
                keep_cols
            ]
        )


        supplier = supplier.merge(
            kpi_copy,
            left_on=entity_id_col,
            right_on=kpi_id,
            how="left",
            suffixes=(
                "",
                "_kpi"
            )
        )


        if (
            kpi_id != entity_id_col
            and kpi_id in supplier.columns
        ):

            supplier.drop(
                columns=[
                    kpi_id
                ],
                inplace=True
            )


# ============================================================
# 7. MERGE MCDA SCORE
# ============================================================

mcda_score_col = None
mcda_id_col = None


if (
    mcda is not None
    and not mcda.empty
):

    mcda_id_col = find_column(
        mcda,
        [
            "supplier_id",
            "entity_id",
            "vendor_id"
        ]
    )


    mcda_score_col = find_column(
        mcda,
        [
            "overall_score",
            "mcda_overall_score",
            "mcda_score"
        ]
    )


supplier_mcda_col = find_column(
    supplier,
    [
        "mcda_score",
        "supplier_mcda_score"
    ]
)


if supplier_mcda_col is not None:

    supplier[
        "risk_radar_mcda_score"
    ] = safe_numeric(
        supplier[
            supplier_mcda_col
        ]
    )


elif (
    mcda is not None
    and mcda_id_col
    and mcda_score_col
):

    mcda_copy = mcda.copy()

    mcda_copy[
        mcda_id_col
    ] = (
        mcda_copy[
            mcda_id_col
        ]
        .astype(str)
        .str.strip()
    )


    mcda_temp = (
        mcda_copy
        .groupby(
            mcda_id_col
        )[mcda_score_col]
        .mean()
        .reset_index()
    )


    mcda_temp.rename(
        columns={
            mcda_score_col:
                "risk_radar_mcda_score"
        },
        inplace=True
    )


    supplier = supplier.merge(
        mcda_temp,
        left_on=entity_id_col,
        right_on=mcda_id_col,
        how="left"
    )


    if (
        mcda_id_col != entity_id_col
        and mcda_id_col
        in supplier.columns
    ):

        supplier.drop(
            columns=[
                mcda_id_col
            ],
            inplace=True
        )


else:

    supplier[
        "risk_radar_mcda_score"
    ] = np.nan


# ============================================================
# 8. SEMANTIC DIMENSION DETECTION
# ============================================================

risk_cols = find_all_columns(
    supplier,
    [
        "risk_score",
        "risk_rating",
        "risk_level",
        "risk"
    ]
)


risk_cols = [

    c

    for c in risk_cols

    if not any(

        x in norm_text(c)

        for x in [
            "review_flag",
            "radar_score",
            "risk_contribution"
        ]

    )

]


quality_cols = find_all_columns(
    supplier,
    [
        "quality_score",
        "quality_rating",
        "quality_acceptance",
        "quality"
    ]
)


quality_cols = [

    c

    for c in quality_cols

    if "risk" not in norm_text(c)

]


reliability_cols = find_all_columns(
    supplier,
    [
        "reliability_score",
        "on_time_delivery",
        "delivery_reliability",
        "on_time",
        "lead_time"
    ]
)


reliability_cols = [

    c

    for c in reliability_cols

    if "risk" not in norm_text(c)

]


sustainability_cols = find_all_columns(
    supplier,
    [
        "sustainability_score",
        "esg_score",
        "sustainability",
        "esg"
    ]
)


capacity_cols = find_all_columns(
    supplier,
    [
        "capacity_per_month",
        "capacity",
        "monthly_capacity"
    ]
)


disruption_cols = find_all_columns(
    supplier,
    [
        "disruption_incidents",
        "disruptions",
        "incident_count"
    ]
)


dependency_cols = find_all_columns(
    supplier,
    [
        "business_dependency",
        "dependency",
        "dependency_score"
    ]
)


restriction_cols = find_all_columns(
    supplier,
    [
        "is_restricted",
        "restricted",
        "restriction"
    ]
)


status_cols = find_all_columns(
    supplier,
    [
        "contract_status",
        "supplier_status",
        "status"
    ]
)


# ============================================================
# 9. REPRESENTATIVE DIMENSION VALUES
# ============================================================

def representative_numeric(
    df,
    columns
):

    valid = []

    for col in columns:

        if col in df.columns:

            s = safe_numeric(
                df[col]
            )

            if s.notna().sum() > 0:

                valid.append(s)


    if not valid:

        return pd.Series(
            np.nan,
            index=df.index
        )


    temp = pd.concat(
        valid,
        axis=1
    )


    return temp.mean(
        axis=1,
        skipna=True
    )


supplier[
    "risk_radar_risk_value"
] = representative_numeric(
    supplier,
    risk_cols
)


supplier[
    "risk_radar_quality_value"
] = representative_numeric(
    supplier,
    quality_cols
)


supplier[
    "risk_radar_reliability_value"
] = representative_numeric(
    supplier,
    reliability_cols
)


supplier[
    "risk_radar_sustainability_value"
] = representative_numeric(
    supplier,
    sustainability_cols
)


supplier[
    "risk_radar_capacity_value"
] = representative_numeric(
    supplier,
    capacity_cols
)


supplier[
    "risk_radar_disruption_value"
] = representative_numeric(
    supplier,
    disruption_cols
)


supplier[
    "risk_radar_dependency_value"
] = representative_numeric(
    supplier,
    dependency_cols
)


# ============================================================
# 10. RISK CONTRIBUTIONS
# ============================================================

# D4:
# Distinguish a true risk score from a safety/health score.
# If a companion risk band exists, the numeric score is
# treated as a safety score:
# higher = safer = lower operational risk.

_risk_band_cols = find_all_columns(
    supplier,
    [
        "risk_band",
        "risk_level",
        "risk_category",
        "risk_rating_band"
    ]
)


_risk_band_present = any(

    c in supplier.columns
    and supplier[c].notna().any()

    for c in _risk_band_cols

)


if _risk_band_present:

    supplier[
        "risk_signal__risk"
    ] = percentile_score(
        supplier[
            "risk_radar_risk_value"
        ],
        higher_is_worse=False
    )

else:

    supplier[
        "risk_signal__risk"
    ] = percentile_score(
        supplier[
            "risk_radar_risk_value"
        ],
        higher_is_worse=True
    )


supplier[
    "risk_signal__quality"
] = normalize_positive_score(
    supplier[
        "risk_radar_quality_value"
    ]
)


# D3:
# Lead-time / delay days are lower-is-better.
# On-time/reliability scores are higher-is-better.

_reliability_names = " ".join(
    str(c).lower()
    for c in reliability_cols
)


_reliability_is_lower_better = any(

    x in _reliability_names

    for x in [
        "lead_time",
        "leadtime",
        "delay_days",
        "delivery_days",
        "days"
    ]

)


supplier[
    "risk_signal__reliability"
] = percentile_score(
    supplier[
        "risk_radar_reliability_value"
    ],
    higher_is_worse=
        _reliability_is_lower_better
)


supplier[
    "risk_signal__sustainability"
] = normalize_positive_score(
    supplier[
        "risk_radar_sustainability_value"
    ]
)


supplier[
    "risk_signal__capacity"
] = normalize_positive_score(
    supplier[
        "risk_radar_capacity_value"
    ]
)


supplier[
    "risk_signal__disruption"
] = percentile_score(
    supplier[
        "risk_radar_disruption_value"
    ],
    higher_is_worse=True
)


supplier[
    "risk_signal__dependency"
] = percentile_score(
    supplier[
        "risk_radar_dependency_value"
    ],
    higher_is_worse=True
)


# MCDA is NOT included in operational risk.
# It remains available for decision intelligence.


# ============================================================
# 11. RESTRICTION / STATUS SIGNALS
# ============================================================

supplier[
    "risk_signal__restriction"
] = 0.0


supplier[
    "risk_signal__status"
] = 0.0


restriction_col = (
    restriction_cols[0]
    if restriction_cols
    else None
)


status_col = (
    status_cols[0]
    if status_cols
    else None
)


if restriction_col:

    def restriction_flag(x):

        s = str(x).strip().lower()

        return (
            100.0
            if s in [
                "true",
                "1",
                "yes",
                "y",
                "restricted"
            ]
            else 0.0
        )


    supplier[
        "risk_signal__restriction"
    ] = (
        supplier[
            restriction_col
        ]
        .apply(
            restriction_flag
        )
    )


if status_col:

    def status_risk(x):

        s = str(x).strip().lower()

        if any(

            word in s

            for word in [
                "expired",
                "inactive",
                "blocked",
                "suspended",
                "terminated"
            ]

        ):

            return 100.0

        return 0.0


    supplier[
        "risk_signal__status"
    ] = (
        supplier[
            status_col
        ]
        .apply(
            status_risk
        )
    )


# ============================================================
# 12. ANOMALY SIGNAL
# ============================================================

# Cell 20 provides an overall anomaly summary.
# We do not falsely assign anomalies to individual suppliers.

supplier[
    "risk_signal__anomaly"
] = np.nan


anomaly_available = bool(
    anomaly_summary
)


# ============================================================
# 13. BUILD ADAPTIVE RISK SCORE
# ============================================================

signal_columns = [

    "risk_signal__risk",

    "risk_signal__quality",

    "risk_signal__reliability",

    "risk_signal__sustainability",

    "risk_signal__capacity",

    "risk_signal__disruption",

    "risk_signal__dependency",

    "risk_signal__restriction",

    "risk_signal__status"

]


available_signal_columns = []


for col in signal_columns:

    if col in supplier.columns:

        if (
            supplier[col]
            .notna()
            .sum()
            > 0
        ):

            available_signal_columns.append(
                col
            )


# Original working weights

weights = {

    "risk_signal__risk": 2.0,

    "risk_signal__quality": 1.25,

    "risk_signal__reliability": 1.50,

    "risk_signal__sustainability": 0.75,

    "risk_signal__capacity": 1.00,

    "risk_signal__disruption": 1.50,

    "risk_signal__dependency": 1.00,

    "risk_signal__restriction": 2.50,

    "risk_signal__status": 2.00

}


active_weights = {

    col: weights[col]

    for col
    in available_signal_columns

}


weight_total = sum(
    active_weights.values()
)


if weight_total == 0:

    supplier[
        "risk_radar_score"
    ] = np.nan

else:

    weighted_sum = pd.Series(
        0.0,
        index=supplier.index
    )


    weight_used = pd.Series(
        0.0,
        index=supplier.index
    )


    for col, weight in (
        active_weights.items()
    ):

        values = supplier[col]

        available = (
            values.notna()
        )


        weighted_sum.loc[
            available
        ] += (
            values.loc[
                available
            ]
            * weight
        )


        weight_used.loc[
            available
        ] += weight


    supplier[
        "risk_radar_score"
    ] = np.where(

        weight_used > 0,

        weighted_sum
        / weight_used,

        np.nan

    )


# ============================================================
# 14. RISK BAND
# ============================================================
# UPDATED ONLY:
#
# LOW    : <40
# MEDIUM : 40–59.99
# HIGH   : >=60
#
# Underlying risk score is unchanged.

# Phase 2: ONE threshold rule drives both the 4-level status and the 3-level band,
# so they can never contradict each other.
#   score <  25 : Stable          -> LOW
#   25 - <35    : Watch           -> LOW
#   35 - <45    : Emerging Risk   -> MEDIUM
#   score >= 45 : Critical        -> HIGH
RISK_THRESHOLDS = {
    "watch_from": 25.0,
    "emerging_from": 35.0,
    "critical_from": 45.0,
    "status_to_band": {"Stable": "LOW", "Watch": "LOW", "Emerging Risk": "MEDIUM", "Critical": "HIGH"},
    "rule": "status and band are both derived from risk_radar_score only",
}

def risk_status_from_score(score):

    if pd.isna(score):

        return "Insufficient Data"

    if score >= RISK_THRESHOLDS["critical_from"]:

        return "Critical"

    if score >= RISK_THRESHOLDS["emerging_from"]:

        return "Emerging Risk"

    if score >= RISK_THRESHOLDS["watch_from"]:

        return "Watch"

    return "Stable"


def risk_band(score):

    _st = risk_status_from_score(score)

    if _st == "Insufficient Data":

        return "Unavailable"

    return RISK_THRESHOLDS["status_to_band"][_st]


supplier[
    "risk_radar_band"
] = (
    supplier[
        "risk_radar_score"
    ]
    .apply(risk_band)
)


# ============================================================
# 15. INDIVIDUAL EARLY-WARNING SIGNALS
# ============================================================

def percentile_threshold(
    series,
    pct,
    default=np.nan
):

    s = safe_numeric(
        series
    ).dropna()


    if len(s) == 0:

        return default


    return float(
        s.quantile(pct)
    )


risk_threshold = percentile_threshold(
    supplier[
        "risk_radar_risk_value"
    ],
    0.75
)


quality_threshold = percentile_threshold(
    supplier[
        "risk_radar_quality_value"
    ],
    0.25
)


reliability_threshold = percentile_threshold(
    supplier[
        "risk_radar_reliability_value"
    ],
    0.25
)


sustainability_threshold = percentile_threshold(
    supplier[
        "risk_radar_sustainability_value"
    ],
    0.25
)


capacity_threshold = percentile_threshold(
    supplier[
        "risk_radar_capacity_value"
    ],
    0.25
)


disruption_threshold = percentile_threshold(
    supplier[
        "risk_radar_disruption_value"
    ],
    0.75
)


dependency_threshold = percentile_threshold(
    supplier[
        "risk_radar_dependency_value"
    ],
    0.75
)


# ============================================================
# 16. BUILD EXPLANATIONS
# ============================================================

def build_flags(row):

    flags = []


    if (
        pd.notna(
            risk_threshold
        )
        and pd.notna(
            row[
                "risk_radar_risk_value"
            ]
        )
        and row[
            "risk_radar_risk_value"
        ] >= risk_threshold
    ):

        flags.append(
            "High risk indicator"
        )


    if (
        pd.notna(
            quality_threshold
        )
        and pd.notna(
            row[
                "risk_radar_quality_value"
            ]
        )
        and row[
            "risk_radar_quality_value"
        ] <= quality_threshold
    ):

        flags.append(
            "Low quality performance"
        )


    if (
        pd.notna(
            reliability_threshold
        )
        and pd.notna(
            row[
                "risk_radar_reliability_value"
            ]
        )
        and row[
            "risk_radar_reliability_value"
        ] <= reliability_threshold
    ):

        flags.append(
            "Low delivery reliability"
        )


    if (
        pd.notna(
            sustainability_threshold
        )
        and pd.notna(
            row[
                "risk_radar_sustainability_value"
            ]
        )
        and row[
            "risk_radar_sustainability_value"
        ] <= sustainability_threshold
    ):

        flags.append(
            "Low sustainability performance"
        )


    if (
        pd.notna(
            capacity_threshold
        )
        and pd.notna(
            row[
                "risk_radar_capacity_value"
            ]
        )
        and row[
            "risk_radar_capacity_value"
        ] <= capacity_threshold
    ):

        flags.append(
            "Low relative capacity"
        )


    if (
        pd.notna(
            disruption_threshold
        )
        and pd.notna(
            row[
                "risk_radar_disruption_value"
            ]
        )
        and row[
            "risk_radar_disruption_value"
        ] >= disruption_threshold
    ):

        flags.append(
            "High disruption history"
        )


    if (
        pd.notna(
            dependency_threshold
        )
        and pd.notna(
            row[
                "risk_radar_dependency_value"
            ]
        )
        and row[
            "risk_radar_dependency_value"
        ] >= dependency_threshold
    ):

        flags.append(
            "High dependency exposure"
        )


    if (
        row.get(
            "risk_signal__restriction",
            0
        ) >= 100
    ):

        flags.append(
            "Supplier restricted"
        )


    if (
        row.get(
            "risk_signal__status",
            0
        ) >= 100
    ):

        flags.append(
            "Supplier status concern"
        )


    return flags


supplier[
    "risk_radar_flags_list"
] = supplier.apply(
    build_flags,
    axis=1
)


supplier[
    "risk_radar_signal_count"
] = (
    supplier[
        "risk_radar_flags_list"
    ]
    .apply(len)
)


supplier[
    "risk_radar_flags"
] = (
    supplier[
        "risk_radar_flags_list"
    ]
    .apply(

        lambda x:
            "; ".join(x)
            if x
            else
            "No major early-warning signal detected"

    )
)


# ============================================================
# 17. ESCALATION STATUS
# ============================================================

def escalation_status(row):

    score = row[
        "risk_radar_score"
    ]

    signals = row[
        "risk_radar_signal_count"
    ]


    if pd.isna(score):

        return "INSUFFICIENT DATA"


    if (
        score >= 75
        or signals >= 3
        or row.get(
            "risk_signal__restriction",
            0
        ) >= 100
        or row.get(
            "risk_signal__status",
            0
        ) >= 100
    ):

        return "ESCALATE"


    if (
        score >= 50
        or signals >= 2
    ):

        return "REVIEW"


    return "MONITOR"


supplier[
    "risk_radar_action"
] = supplier.apply(
    escalation_status,
    axis=1
)


# ============================================================
# 18. FOUR-LEVEL DECISION-INTELLIGENCE RISK STATUS
# ============================================================

def risk_radar_status(row):

    # Phase 2: derived from the same score thresholds as risk_band (see RISK_THRESHOLDS).
    # Early-warning signals and the recommended action stay visible as separate columns
    # but no longer override the score-based status.
    score = pd.to_numeric(
        row.get(
            "risk_radar_score"
        ),
        errors="coerce"
    )

    return risk_status_from_score(score)


supplier[
    "risk_radar_status"
] = supplier.apply(
    risk_radar_status,
    axis=1
)

# Phase 2: real consistency check - status and band must agree under the single rule.
_bad = supplier[
    supplier["risk_radar_status"].map(RISK_THRESHOLDS["status_to_band"]).fillna("Unavailable")
    != supplier["risk_radar_band"]
]
assert len(_bad) == 0, f"risk status/band contradiction in {len(_bad)} suppliers"
print("✓ risk status and band consistent for", len(supplier), "suppliers")


# ============================================================
# 19. RISK EXPLANATION
# ============================================================

def build_risk_explanation(
    row
):

    flags = str(
        row.get(
            "risk_radar_flags",
            ""
        )
    )


    status = str(
        row.get(
            "risk_radar_status",
            "Insufficient Data"
        )
    )


    affected = []


    for dim, col in [

        (
            "Risk",
            "risk_radar_risk_value"
        ),

        (
            "Quality",
            "risk_radar_quality_value"
        ),

        (
            "Reliability",
            "risk_radar_reliability_value"
        ),

        (
            "Sustainability",
            "risk_radar_sustainability_value"
        ),

        (
            "Capacity",
            "risk_radar_capacity_value"
        ),

        (
            "Disruption",
            "risk_radar_disruption_value"
        ),

        (
            "Dependency",
            "risk_radar_dependency_value"
        )

    ]:

        value = pd.to_numeric(
            row.get(col),
            errors="coerce"
        )


        if pd.notna(value):

            affected.append(
                dim
            )


    if (
        flags
        and
        flags !=
        "No major early-warning signal detected"
    ):

        return (

            f"{status}: {flags}. "
            f"Affected dimensions: "
            f"{', '.join(affected) if affected else 'available risk indicators'}."

        )


    return (

        f"{status}: no major early-warning "
        f"signal detected across the available "
        f"risk dimensions."

    )


supplier[
    "risk_affected_dimensions"
] = supplier.apply(

    lambda r:

        "; ".join([

            d

            for d, c in [

                (
                    "Risk",
                    "risk_radar_risk_value"
                ),

                (
                    "Quality",
                    "risk_radar_quality_value"
                ),

                (
                    "Reliability",
                    "risk_radar_reliability_value"
                ),

                (
                    "Sustainability",
                    "risk_radar_sustainability_value"
                ),

                (
                    "Capacity",
                    "risk_radar_capacity_value"
                ),

                (
                    "Disruption",
                    "risk_radar_disruption_value"
                ),

                (
                    "Dependency",
                    "risk_radar_dependency_value"
                )

            ]

            if pd.notna(
                pd.to_numeric(
                    r.get(c),
                    errors="coerce"
                )
            )

        ]),

    axis=1

)


supplier[
    "risk_explanation"
] = supplier.apply(
    build_risk_explanation,
    axis=1
)


# ============================================================
# 20. MANAGEMENT RECOMMENDATION
# ============================================================

def recommendation(row):

    action = row[
        "risk_radar_action"
    ]

    flags = str(
        row[
            "risk_radar_flags"
        ]
    )


    if action == "ESCALATE":

        if (
            "Supplier restricted"
            in flags
        ):

            return (
                "Escalate to procurement/compliance "
                "for restriction review before "
                "continuing supplier reliance."
            )


        return (
            "Conduct management review and investigate "
            "the flagged risk drivers before major "
            "supplier commitments."
        )


    if action == "REVIEW":

        return (
            "Review supplier performance and monitor "
            "the identified risk drivers more closely."
        )


    if action == "MONITOR":

        return (
            "Continue routine supplier monitoring; "
            "no immediate escalation indicated."
        )


    return (
        "Insufficient information for a reliable "
        "risk recommendation."
    )


supplier[
    "risk_radar_recommendation"
] = supplier.apply(
    recommendation,
    axis=1
)


# ============================================================
# 21. SUPPLIER RISK RANKING
# ============================================================

supplier[
    "risk_radar_rank"
] = (
    supplier[
        "risk_radar_score"
    ]
    .rank(
        ascending=False,
        method="min"
    )
)


supplier.sort_values(
    by="risk_radar_score",
    ascending=False,
    inplace=True,
    na_position="last"
)


# ============================================================
# 22. RISK SIGNAL TABLE
# ============================================================

signal_rows = []


for _, row in supplier.iterrows():

    supplier_id = row[
        entity_id_col
    ]


    supplier_name = row.get(
        entity_name_col,
        supplier_id
    )


    for col in available_signal_columns:

        signal_name = (
            col
            .replace(
                "risk_signal__",
                ""
            )
            .replace(
                "_",
                " "
            )
            .title()
        )


        value = row[col]


        if pd.isna(value):

            continue


        signal_rows.append({

            "supplier_id":
                supplier_id,

            "supplier_name":
                supplier_name,

            "risk_signal":
                signal_name,

            "risk_contribution":
                round(
                    float(value),
                    2
                )

        })


risk_signals = pd.DataFrame(
    signal_rows
)


# ============================================================
# 23. SUMMARY TABLE
# ============================================================

summary_rows = []


summary_rows.append({

    "metric":
        "Suppliers evaluated",

    "value":
        int(
            len(supplier)
        )

})


summary_rows.append({

    "metric":
        "High risk suppliers",

    "value":
        int(
            (
                supplier[
                    "risk_radar_band"
                ]
                == "HIGH"
            ).sum()
        )

})


summary_rows.append({

    "metric":
        "Medium risk suppliers",

    "value":
        int(
            (
                supplier[
                    "risk_radar_band"
                ]
                == "MEDIUM"
            ).sum()
        )

})


summary_rows.append({

    "metric":
        "Low risk suppliers",

    "value":
        int(
            (
                supplier[
                    "risk_radar_band"
                ]
                == "LOW"
            ).sum()
        )

})


summary_rows.append({

    "metric":
        "Suppliers requiring escalation",

    "value":
        int(
            (
                supplier[
                    "risk_radar_action"
                ]
                == "ESCALATE"
            ).sum()
        )

})


summary_rows.append({

    "metric":
        "Suppliers requiring review",

    "value":
        int(
            (
                supplier[
                    "risk_radar_action"
                ]
                == "REVIEW"
            ).sum()
        )

})


summary_rows.append({

    "metric":
        "Suppliers for routine monitoring",

    "value":
        int(
            (
                supplier[
                    "risk_radar_action"
                ]
                == "MONITOR"
            ).sum()
        )

})


summary_rows.append({

    "metric":
        "Available risk signals",

    "value":
        len(
            available_signal_columns
        )

})


summary_rows.append({

    "metric":
        "Anomaly summary available",

    "value":
        bool(
            anomaly_available
        )

})


risk_summary = pd.DataFrame(
    summary_rows
)


# ============================================================
# 24. CLEAN FINAL RISK RADAR OUTPUT
# ============================================================

preferred_columns = [

    entity_id_col,

    entity_name_col,

    "risk_radar_rank",

    "risk_radar_score",

    "risk_radar_band",

    "risk_radar_status",

    "risk_radar_signal_count",

    "risk_radar_flags",

    "risk_affected_dimensions",

    "risk_explanation",

    "risk_radar_action",

    "risk_radar_recommendation",

    "risk_radar_mcda_score",

    "risk_radar_risk_value",

    "risk_radar_quality_value",

    "risk_radar_reliability_value",

    "risk_radar_sustainability_value",

    "risk_radar_capacity_value",

    "risk_radar_disruption_value",

    "risk_radar_dependency_value"

]


final_cols = [

    c

    for c in preferred_columns

    if c in supplier.columns

]


risk_radar = supplier[
    final_cols
].copy()


for col in risk_radar.select_dtypes(
    include=[np.number]
).columns:

    risk_radar[col] = (
        risk_radar[col]
        .round(4)
    )


# ============================================================
# 25. CONFIGURATION
# ============================================================

config = {

    "cell":
        "26",

    "module":
        "Vendor360 Decision Intelligence / Risk Radar",

    "purpose":
        (
            "Adaptive supplier early-warning "
            "and risk monitoring using existing "
            "Vendor360 analytical outputs."
        ),

    "does_not_rerun_models":
        True,

    "source_files": {

        "analysis_base":
            BASE_PATH,

        "supplier_kpi":
            KPI_PATH
            if os.path.exists(KPI_PATH)
            else None,

        "mcda":
            MCDA_PATH
            if os.path.exists(MCDA_PATH)
            else None,

        "anomaly_summary":
            ANOMALY_PATH
            if os.path.exists(
                ANOMALY_PATH
            )
            else None

    },

    "entity_id":
        entity_id_col,

    "entity_name":
        entity_name_col,

    "detected_dimensions": {

        "risk":
            risk_cols,

        "quality":
            quality_cols,

        "reliability":
            reliability_cols,

        "sustainability":
            sustainability_cols,

        "capacity":
            capacity_cols,

        "disruption":
            disruption_cols,

        "dependency":
            dependency_cols,

        "restriction":
            restriction_cols,

        "status":
            status_cols

    },

    "available_risk_signals":
        available_signal_columns,

    "risk_signal_weights":
        active_weights,

    # UPDATED
    "risk_band_thresholds": {

        "low":
            "<40",

        "medium":
            "40-59.99",

        "high":
            ">=60"

    },

    "decision_actions": [

        "MONITOR",

        "REVIEW",

        "ESCALATE"

    ],

    "important_limitation":
        (
            "Risk Radar identifies relative "
            "early-warning signals from available "
            "supplier data. It does not prove future "
            "supplier failure and should support, "
            "not replace, management review."
        )

}


# ============================================================
# 26. METADATA
# ============================================================

metadata = {

    "status":
        "PASS",

    "rows_evaluated":
        int(
            len(risk_radar)
        ),

    "risk_signals_detected":
        len(
            available_signal_columns
        ),

    "high_risk_count":
        int(
            (
                risk_radar[
                    "risk_radar_band"
                ]
                == "HIGH"
            ).sum()
        ),

    "medium_risk_count":
        int(
            (
                risk_radar[
                    "risk_radar_band"
                ]
                == "MEDIUM"
            ).sum()
        ),

    "low_risk_count":
        int(
            (
                risk_radar[
                    "risk_radar_band"
                ]
                == "LOW"
            ).sum()
        ),

    "escalation_count":
        int(
            (
                risk_radar[
                    "risk_radar_action"
                ]
                == "ESCALATE"
            ).sum()
        ),

    "review_count":
        int(
            (
                risk_radar[
                    "risk_radar_action"
                ]
                == "REVIEW"
            ).sum()
        ),

    "monitor_count":
        int(
            (
                risk_radar[
                    "risk_radar_action"
                ]
                == "MONITOR"
            ).sum()
        ),

    "anomaly_summary_available":
        anomaly_available,

    "supplier_level_anomaly_assignment":
        False,

    "model_rerun":
        False

}


# ============================================================
# 27. REPORT
# ============================================================

report_lines = []


report_lines.append(
    "VENDOR360 DECISION INTELLIGENCE / RISK RADAR"
)


report_lines.append(
    "=" * 60
)


report_lines.append("")


report_lines.append(
    f"Suppliers evaluated: "
    f"{len(risk_radar)}"
)


report_lines.append(
    f"Risk signals available: "
    f"{len(available_signal_columns)}"
)


report_lines.append("")


report_lines.append(
    f"HIGH risk: "
    f"{(
        risk_radar[
            'risk_radar_band'
        ]
        == 'HIGH'
    ).sum()}"
)


report_lines.append(
    f"MEDIUM risk: "
    f"{(
        risk_radar[
            'risk_radar_band'
        ]
        == 'MEDIUM'
    ).sum()}"
)


report_lines.append(
    f"LOW risk: "
    f"{(
        risk_radar[
            'risk_radar_band'
        ]
        == 'LOW'
    ).sum()}"
)


report_lines.append("")


report_lines.append(
    "TOP RISK SUPPLIERS"
)


report_lines.append(
    "-" * 60
)


top_risk = risk_radar.head(10)


for _, row in top_risk.iterrows():

    name = row.get(
        entity_name_col,
        row[
            entity_id_col
        ]
    )


    report_lines.append(

        f"{row[entity_id_col]} | "
        f"{name} | "
        f"Score: "
        f"{row['risk_radar_score']:.2f} | "
        f"Band: "
        f"{row['risk_radar_band']} | "
        f"Action: "
        f"{row['risk_radar_action']}"

    )


    report_lines.append(

        f"  Signals: "
        f"{row['risk_radar_flags']}"

    )


report_lines.append("")


report_lines.append(
    "DECISION LOGIC"
)


report_lines.append(
    "-" * 60
)


report_lines.append(
    "Risk Radar combines available relative "
    "risk indicators across risk, quality, "
    "reliability, sustainability, capacity, "
    "disruption, dependency, restriction and status."
)


report_lines.append(
    "The engine adapts to whichever dimensions "
    "are actually available in the input dataset."
)


report_lines.append(
    "Missing dimensions are excluded rather "
    "than fabricated."
)


report_lines.append(
    "Risk Radar is decision support and does "
    "not predict supplier failure with certainty."
)


report_text = "\n".join(
    report_lines
)


# ============================================================
# 28. SAVE OUTPUTS
# ============================================================

risk_radar.to_csv(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Radar.csv"
    ),

    index=False

)


risk_signals.to_csv(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Signals.csv"
    ),

    index=False

)


risk_summary.to_csv(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Summary.csv"
    ),

    index=False

)


with open(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Radar_Config.json"
    ),

    "w",

    encoding="utf-8"

) as f:

    json.dump(
        config,
        f,
        indent=2,
        default=str
    )


with open(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Radar_Metadata.json"
    ),

    "w",

    encoding="utf-8"

) as f:

    json.dump(
        metadata,
        f,
        indent=2,
        default=str
    )


with open(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Radar_Report.txt"
    ),

    "w",

    encoding="utf-8"

) as f:

    f.write(
        report_text
    )


# ============================================================
# 29. DIRECTION / CORRECTNESS METADATA
# ============================================================

risk_radar[
    "risk_radar_mcda_used_as_risk"
] = False


risk_radar_direction_config = {

    "reliability_is_lower_better":
        bool(
            "_reliability_is_lower_better"
            in globals()
            and
            _reliability_is_lower_better
        ),

    "risk_score_band_aware":
        bool(
            "_risk_band_present"
            in globals()
            and
            _risk_band_present
        ),

    "mcda_excluded_from_risk_score":
        True,

    "risk_band_thresholds": {

        "low":
            "<40",

        "medium":
            "40-59.99",

        "high":
            ">=60"

    }

}


with open(

    os.path.join(
        OUT_DIR,
        "Vendor360_Risk_Radar_Direction_Config.json"
    ),

    "w"

) as _f:

    json.dump(
        risk_radar_direction_config,
        _f,
        indent=4
    )


# Expose final backend objects
# for downstream cells / Streamlit.

risk_radar_df = risk_radar.copy()

risk_radar_summary_df = (
    risk_summary.copy()
)


# ============================================================
# 30. VALIDATION
# ============================================================

checks = []


checks.append((
    "Analysis Base loaded",
    os.path.exists(
        BASE_PATH
    )
))


checks.append((
    "Supplier entity detected",
    entity_id_col is not None
))


checks.append((
    "Risk Radar generated",
    len(risk_radar) > 0
))


checks.append((
    "Risk score generated",
    risk_radar[
        "risk_radar_score"
    ]
    .notna()
    .sum()
    > 0
))


checks.append((
    "Risk bands generated",
    risk_radar[
        "risk_radar_band"
    ]
    .notna()
    .all()
))


checks.append((
    "Early-warning flags generated",
    "risk_radar_flags"
    in risk_radar.columns
))


checks.append((
    "Management actions generated",
    "risk_radar_action"
    in risk_radar.columns
))


checks.append((
    "Four-level Risk Radar status generated",
    "risk_radar_status"
    in risk_radar.columns
))


checks.append((
    "Risk explanation generated",
    "risk_explanation"
    in risk_radar.columns
))


checks.append((
    "Configuration saved",
    os.path.exists(
        os.path.join(
            OUT_DIR,
            "Vendor360_Risk_Radar_Config.json"
        )
    )
))


checks.append((
    "Metadata saved",
    os.path.exists(
        os.path.join(
            OUT_DIR,
            "Vendor360_Risk_Radar_Metadata.json"
        )
    )
))


checks.append((
    "Report saved",
    os.path.exists(
        os.path.join(
            OUT_DIR,
            "Vendor360_Risk_Radar_Report.txt"
        )
    )
))


# ============================================================
# 31. DISPLAY
# ============================================================

print(
    "\n" + "=" * 70
)


print(
    "VENDOR360 CELL 26 — "
    "DECISION INTELLIGENCE / RISK RADAR"
)


print(
    "=" * 70
)


print(
    f"\nDataset rows: "
    f"{len(base):,}"
)


print(
    f"Suppliers evaluated: "
    f"{len(risk_radar):,}"
)


print(
    f"\nEntity ID: "
    f"{entity_id_col}"
)


print(
    f"Entity Name: "
    f"{entity_name_col}"
)


print(
    "\nAVAILABLE RISK SIGNALS"
)


for signal in available_signal_columns:

    print(

        "  ✓ "
        +
        signal
        .replace(
            "risk_signal__",
            ""
        )
        .replace(
            "_",
            " "
        )
        .title()

    )


print(
    "\nRISK BAND THRESHOLDS"
)


print(
    "  LOW    : <40"
)


print(
    "  MEDIUM : 40–59.99"
)


print(
    "  HIGH   : >=60"
)


print(
    "\nRISK DISTRIBUTION"
)


print(

    f"  HIGH   : "
    f"{(
        risk_radar[
            'risk_radar_band'
        ]
        == 'HIGH'
    ).sum()}"

)


print(

    f"  MEDIUM : "
    f"{(
        risk_radar[
            'risk_radar_band'
        ]
        == 'MEDIUM'
    ).sum()}"

)


print(

    f"  LOW    : "
    f"{(
        risk_radar[
            'risk_radar_band'
        ]
        == 'LOW'
    ).sum()}"

)


print(
    "\nMANAGEMENT ACTIONS"
)


print(

    f"  ESCALATE : "
    f"{(
        risk_radar[
            'risk_radar_action'
        ]
        == 'ESCALATE'
    ).sum()}"

)


print(

    f"  REVIEW   : "
    f"{(
        risk_radar[
            'risk_radar_action'
        ]
        == 'REVIEW'
    ).sum()}"

)


print(

    f"  MONITOR  : "
    f"{(
        risk_radar[
            'risk_radar_action'
        ]
        == 'MONITOR'
    ).sum()}"

)


print(
    "\nTOP 10 RISK SUPPLIERS"
)


display_cols = [

    entity_id_col,

    entity_name_col,

    "risk_radar_score",

    "risk_radar_band",

    "risk_radar_status",

    "risk_radar_signal_count",

    "risk_radar_action"

]


display(
    risk_radar[
        display_cols
    ].head(10)
)


print(
    "\nVALIDATION"
)


passed = 0


for check_name, result in checks:

    if result:

        print(
            f"  ✓ {check_name}"
        )

        passed += 1

    else:

        print(
            f"  ✗ {check_name}"
        )


print(

    f"\nSTATUS: "
    f"{'PASS' if passed == len(checks) else 'CHECK REQUIRED'}"
    f" ({passed}/{len(checks)} checks passed)"

)


print(
    "\nOUTPUTS"
)


for filename in [

    "Vendor360_Risk_Radar.csv",

    "Vendor360_Risk_Signals.csv",

    "Vendor360_Risk_Summary.csv",

    "Vendor360_Risk_Radar_Config.json",

    "Vendor360_Risk_Radar_Metadata.json",

    "Vendor360_Risk_Radar_Report.txt"

]:

    print(

        " ",
        os.path.join(
            OUT_DIR,
            filename
        )

    )


print(
    "\n" + "=" * 70
)