# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 50 =====

# ============================================================
# VENDOR360 — CELL 24B
# GEMINI CONFIGURATION & CONNECTION
# ============================================================
# Gemini configuration only.
# API key is loaded from Google Colab Secrets (recommended),
# so it does NOT need to be entered every time the notebook runs.
# General AI generation remains in Cell 24C.

import os
import importlib.util

print("=" * 70)
print("VENDOR360 — CELL 24B")
print("GEMINI CONFIGURATION & CONNECTION")
print("=" * 70)

# ------------------------------------------------------------
# 1. LOAD GEMINI API KEY
# ------------------------------------------------------------
# Recommended: save a secret named GEMINI_API_KEY once in
# Colab -> Secrets. The key is never printed or stored in the notebook.
#
# Environment variable is also supported for portability.

GEMINI_API_KEY = ""

try:
    from google.colab import userdata

    GEMINI_API_KEY = (
        userdata.get("GEMINI_API_KEY") or ""
    ).strip()

    if GEMINI_API_KEY:
        print("✓ Gemini API key loaded from Colab Secrets")

except Exception:
    pass

if not GEMINI_API_KEY:
    GEMINI_API_KEY = (
        os.environ.get("GEMINI_API_KEY", "")
        .strip()
    )

    if GEMINI_API_KEY:
        print("✓ Gemini API key loaded from environment")

if GEMINI_API_KEY:
    os.environ["GEMINI_API_KEY"] = GEMINI_API_KEY
else:
    print("⚠ Gemini API key not found")
    print("  Add GEMINI_API_KEY once in Colab Secrets.")

# ------------------------------------------------------------
# 2. GEMINI MODEL
# ------------------------------------------------------------

GEMINI_MODEL = os.environ.get(
    "GEMINI_MODEL",
    "gemini-3.8-flash"
).strip()

os.environ["GEMINI_MODEL"] = GEMINI_MODEL

print(f"✓ Gemini model: {GEMINI_MODEL}")

# ------------------------------------------------------------
# 3. PACKAGE CHECK
# ------------------------------------------------------------

PACKAGE_NAME = "google.generativeai"

package_available = (
    importlib.util.find_spec(PACKAGE_NAME)
    is not None
)

if package_available:
    print("✓ google-generativeai package available")
else:
    print("✗ google-generativeai package is not installed")

# ------------------------------------------------------------
# 4. CONNECTION TEST
# ------------------------------------------------------------

GEMINI_CONNECTION_OK = False

if package_available and GEMINI_API_KEY:

    try:
        import google.generativeai as genai

        genai.configure(
            api_key=GEMINI_API_KEY
        )

        model = genai.GenerativeModel(
            GEMINI_MODEL
        )

        response = model.generate_content(
            "Say hello in one short sentence."
        )

        response_text = (
            getattr(response, "text", "")
            or ""
        )

        if response_text.strip():

            GEMINI_CONNECTION_OK = True

            print("\nResponse received:")
            print(response_text)
            print("\nSTATUS: PASS")

        else:

            print("\nSTATUS: REVIEW")
            print("Gemini responded without text.")

    except Exception as e:

        print("\nSTATUS: FAIL")
        print("Error type:", type(e).__name__)
        print("Error:", repr(e))

else:

    print("\nSTATUS: REVIEW")
    print("Gemini connection test skipped.")
    print("Make sure GEMINI_API_KEY is available.")

print("=" * 70)
print(
    "CELL 24B STATUS: PASS"
    if package_available
    and GEMINI_API_KEY
    and GEMINI_CONNECTION_OK
    else
    "CELL 24B STATUS: REVIEW REQUIRED"
)
print("=" * 70)


# ===== ORIGINAL NOTEBOOK CELL 52 =====

# VENDOR360 — CELL 24C
# GENERAL AI INSIGHTS ENGINE
# ============================================================
#
# PURPOSE
# ------------------------------------------------------------
# Creates general supplier/business insights from the verified
# Vendor360 analytical outputs.
#
# FEATURES
# ------------------------------------------------------------
# 1. Cached Insights / Fresh Insights toggle
# 2. Explicit Refresh AI Insights button
# 3. Supplier-level MCDA integration
# 4. Correct supplier-level MCDA ranking
# 5. Category-level MCDA rank is NEVER used for supplier ranking
# 6. Cell 19 MCDA fallback
# 7. Adaptive entity detection
# 8. Adaptive business-dimension detection
# 9. Representative supplier context
# 10. Gemini AI analysis
# 11. 60-second Gemini timeout
# 12. Deterministic local fallback
# 13. JSON output
# 14. TXT output
# 15. AI usage logging
# 16. Data-quality awareness
# 17. No unnecessary Gemini calls
# 18. No fabricated trends/predictions
# 19. Suitable for later Streamlit integration
#
# ============================================================


# ============================================================
# 0. IMPORTS
# ============================================================

import os
import json
import time
import traceback
import numpy as np
import pandas as pd

from datetime import datetime
from concurrent.futures import (
    ThreadPoolExecutor,
    TimeoutError as FutureTimeoutError
)


# ============================================================
# 1. CONFIGURATION
# ============================================================

BASE_PATH = (
    V360_WORK + "/Vendor360_Analysis_Base.csv"
)

KPI_PATH = (
    V360_WORK + "/Vendor360_Cell23/"
    "Vendor360_Supplier_KPI_Comparison.csv"
)

MCDA_PATH = (
    V360_WORK + "/Vendor360_Cell19/"
    "MCDA_Results.csv"
)

CONTEXT_DIR = (
    V360_WORK + "/Vendor360_Cell24"
)

OUTPUT_JSON = (
    f"{CONTEXT_DIR}/"
    "Vendor360_AI_General_Insights.json"
)

OUTPUT_TXT = (
    f"{CONTEXT_DIR}/"
    "Vendor360_AI_General_Insights.txt"
)

USAGE_LOG = (
    f"{CONTEXT_DIR}/"
    "Vendor360_AI_Usage_Log.json"
)

# Gemini maximum execution time
GEMINI_TIMEOUT = 60

# Maximum suppliers sent to AI
MAX_SUPPLIER_CONTEXT = 16

# Maximum suppliers included in prompt
MAX_PROMPT_SUPPLIERS = 16

# Optional Gemini model override
#
# Example:
# os.environ["GEMINI_MODEL"] = "gemini-3.8-flash"
#
GEMINI_MODEL_OVERRIDE = os.environ.get(
    "GEMINI_MODEL",
    ""
).strip()

os.makedirs(
    CONTEXT_DIR,
    exist_ok=True
)


# ============================================================
# 2. OPTIONAL WIDGET SUPPORT
# ============================================================

try:

    import ipywidgets as widgets

    from IPython.display import (
        display,
        clear_output
    )

    WIDGETS_AVAILABLE = True

except Exception:

    WIDGETS_AVAILABLE = False


# ============================================================
# 3. BASIC UTILITIES
# ============================================================

def safe_read_csv(path):

    if not os.path.exists(path):

        return None

    try:

        return pd.read_csv(path)

    except Exception as e:

        print(
            f"⚠ Could not read file:\n"
            f"{path}\n"
            f"Reason: {e}"
        )

        return None


def clean_numeric(series):

    return pd.to_numeric(
        series,
        errors="coerce"
    )


def find_column(
    df,
    candidates
):

    if df is None or df.empty:

        return None

    lower_map = {
        str(col).strip().lower(): col
        for col in df.columns
    }

    # --------------------------------------------------------
    # Exact match
    # --------------------------------------------------------

    for candidate in candidates:

        key = (
            str(candidate)
            .strip()
            .lower()
        )

        if key in lower_map:

            return lower_map[key]

    # --------------------------------------------------------
    # Fuzzy match
    # --------------------------------------------------------

    for candidate in candidates:

        key = (
            str(candidate)
            .strip()
            .lower()
        )

        for col in df.columns:

            if (
                key
                in
                str(col)
                .strip()
                .lower()
            ):

                return col

    return None


# ============================================================
# 4. ENTITY DETECTION
# ============================================================

def detect_entity_columns(df):

    entity_id = find_column(
        df,
        [
            "__vendor360_entity_id",
            "supplier_id",
            "entity_id",
            "supplierid",
            "vendor_id",
            "vendorid",
            "entityid"
        ]
    )

    entity_name = find_column(
        df,
        [
            "__vendor360_entity_name",
            "supplier_name",
            "entity_name",
            "suppliername",
            "vendor_name",
            "vendorname",
            "name"
        ]
    )

    return (
        entity_id,
        entity_name
    )


# ============================================================
# 5. BUSINESS DIMENSION DETECTION
# ============================================================

def detect_dimension_columns(df):

    dimensions = {

        "Cost": [],

        "Quality": [],

        "Reliability": [],

        "Risk": [],

        "Sustainability": [],

        "Capacity": []
    }

    if df is None or df.empty:

        return dimensions

    for col in df.columns:

        c = (
            str(col)
            .lower()
        )

        # ----------------------------------------------------
        # COST
        # ----------------------------------------------------

        if (
            "cost" in c
            or "unit_price" in c
            or "unitprice" in c
            or "price" in c
        ):

            if not any(
                x in c
                for x in [
                    "currency",
                    "pricing_model"
                ]
            ):

                dimensions[
                    "Cost"
                ].append(col)

        # ----------------------------------------------------
        # QUALITY
        # ----------------------------------------------------

        if (
            "quality" in c
            or "defect" in c
            or "acceptance" in c
        ):

            dimensions[
                "Quality"
            ].append(col)

        # ----------------------------------------------------
        # RELIABILITY
        # ----------------------------------------------------

        if (
            "reliability" in c
            or "lead_time" in c
            or "leadtime" in c
            or "on_time" in c
            or "ontime" in c
            or "delivery" in c
        ):

            dimensions[
                "Reliability"
            ].append(col)

        # ----------------------------------------------------
        # RISK
        # ----------------------------------------------------

        if (
            "risk" in c
            or "disruption" in c
            or "financial_health" in c
            or "dependency" in c
        ):

            dimensions[
                "Risk"
            ].append(col)

        # ----------------------------------------------------
        # SUSTAINABILITY
        # ----------------------------------------------------

        if (
            "esg" in c
            or "sustain" in c
            or "environment" in c
            or "carbon" in c
        ):

            dimensions[
                "Sustainability"
            ].append(col)

        # ----------------------------------------------------
        # CAPACITY
        # ----------------------------------------------------

        if (
            "capacity" in c
            or "volume" in c
            or "throughput" in c
        ):

            dimensions[
                "Capacity"
            ].append(col)

    # Remove duplicates
    for dim in dimensions:

        dimensions[dim] = list(
            dict.fromkeys(
                dimensions[dim]
            )
        )

    return dimensions


# ============================================================
# 6. USAGE LOG
# ============================================================

def default_usage_log():

    return {

        "total_attempts": 0,

        "gemini_success": 0,

        "gemini_failures": 0,

        "local_fallbacks": 0,

        "cached_runs": 0,

        "fresh_runs": 0,

        "last_run": None,

        "last_engine": None,

        "last_mode": None,

        "history": []
    }


def load_usage_log():

    if not os.path.exists(
        USAGE_LOG
    ):

        return default_usage_log()

    try:

        with open(
            USAGE_LOG,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        defaults = (
            default_usage_log()
        )

        for key, value in defaults.items():

            if key not in data:

                data[key] = value

        return data

    except Exception:

        return default_usage_log()


def save_usage_log(data):

    try:

        with open(
            USAGE_LOG,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                indent=2,
                ensure_ascii=False,
                default=str
            )

    except Exception as e:

        print(
            f"⚠ Usage log could not be saved: {e}"
        )


# ============================================================
# 7. CELL 24A CONTEXT
# ============================================================

def load_context_file(path):

    if not os.path.exists(path):

        return {}

    try:

        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:

            return json.load(f)

    except Exception:

        return {}


def load_verified_context():

    return {

        "dataset":
            load_context_file(
                f"{CONTEXT_DIR}/"
                "Vendor360_AI_Dataset_Context.json"
            ),

        "supplier":
            load_context_file(
                f"{CONTEXT_DIR}/"
                "Vendor360_AI_Supplier_Context.json"
            ),

        "analysis":
            load_context_file(
                f"{CONTEXT_DIR}/"
                "Vendor360_AI_Analysis_Context.json"
            )
    }


# ============================================================
# 8. GEMINI SETUP
# ============================================================

GEMINI_AVAILABLE = False

genai = None

try:

    import google.generativeai as genai

    GEMINI_AVAILABLE = True

except Exception:

    GEMINI_AVAILABLE = False


def get_gemini_api_key():

    # --------------------------------------------------------
    # Environment variable
    # --------------------------------------------------------

    key = os.environ.get(
        "GEMINI_API_KEY",
        ""
    ).strip()

    if key:

        return key

    # --------------------------------------------------------
    # Colab/global variable
    # --------------------------------------------------------

    try:

        key = globals().get(
            "GEMINI_API_KEY",
            ""
        )

        if key:

            return str(
                key
            ).strip()

    except Exception:

        pass

    return ""


def get_gemini_model():

    if not GEMINI_AVAILABLE:

        return None, None

    api_key = (
        get_gemini_api_key()
    )

    if not api_key:

        return None, None

    try:

        genai.configure(
            api_key=api_key
        )

    except Exception:

        return None, None

    candidates = []

    if GEMINI_MODEL_OVERRIDE:

        candidates.append(
            GEMINI_MODEL_OVERRIDE
        )

    candidates.extend([
        "gemini-3.8-flash"
    ])

    candidates = list(
        dict.fromkeys(
            candidates
        )
    )

    for model_name in candidates:

        try:

            model = (
                genai.GenerativeModel(
                    model_name
                )
            )

            return (
                model,
                model_name
            )

        except Exception:

            continue

    return None, None


# ============================================================
# 9. GEMINI EXECUTION WITH TIMEOUT
# ============================================================

def run_gemini_with_timeout(
    prompt
):

    model, model_name = (
        get_gemini_model()
    )

    if model is None:

        return {

            "success": False,

            "reason":
                "Gemini unavailable or API key not configured.",

            "text": None,

            "model": None,

            "elapsed_seconds": 0
        }

    start = time.time()

    def generate():

        return model.generate_content(
            prompt
        )

    executor = ThreadPoolExecutor(
        max_workers=1
    )

    future = executor.submit(
        generate
    )

    try:

        response = future.result(
            timeout=GEMINI_TIMEOUT
        )

        elapsed = (
            time.time()
            - start
        )

        try:

            text = response.text

        except Exception:

            text = str(
                response
            )

        executor.shutdown(
            wait=False,
            cancel_futures=True
        )

        if (
            not text
            or
            not text.strip()
        ):

            return {

                "success": False,

                "reason":
                    "Gemini returned an empty response.",

                "text": None,

                "model":
                    model_name,

                "elapsed_seconds":
                    round(
                        elapsed,
                        2
                    )
            }

        return {

            "success": True,

            "reason": None,

            "text":
                text.strip(),

            "model":
                model_name,

            "elapsed_seconds":
                round(
                    elapsed,
                    2
                )
        }

    except FutureTimeoutError:

        executor.shutdown(
            wait=False,
            cancel_futures=True
        )

        elapsed = (
            time.time()
            - start
        )

        return {

            "success": False,

            "reason":
                f"Gemini exceeded "
                f"{GEMINI_TIMEOUT}-second timeout.",

            "text": None,

            "model":
                model_name,

            "elapsed_seconds":
                round(
                    elapsed,
                    2
                )
        }

    except Exception as e:

        executor.shutdown(
            wait=False,
            cancel_futures=True
        )

        elapsed = (
            time.time()
            - start
        )

        return {

            "success": False,

            "reason":
                str(e),

            "text": None,

            "model":
                model_name,

            "elapsed_seconds":
                round(
                    elapsed,
                    2
                )
        }


# ============================================================
# 10. LOAD DATA
# ============================================================

print("=" * 70)

print(
    "VENDOR360 — CELL 24C"
)

print(
    "GENERAL AI INSIGHTS ENGINE"
)

print("=" * 70)


# ============================================================
# DATA LOAD
# ============================================================

print(
    "\n[1] DATA LOADED"
)

base_df = safe_read_csv(
    BASE_PATH
)

kpi_df = safe_read_csv(
    KPI_PATH
)

mcda_df = safe_read_csv(
    MCDA_PATH
)

if base_df is None:

    raise FileNotFoundError(
        "Vendor360 Analysis Base not found:\n"
        f"{BASE_PATH}"
    )

print(
    f"Analysis Base : "
    f"{base_df.shape[0]} rows × "
    f"{base_df.shape[1]} columns"
)

if kpi_df is not None:

    print(
        f"Supplier KPI  : "
        f"{kpi_df.shape[0]} rows × "
        f"{kpi_df.shape[1]} columns"
    )

else:

    print(
        "⚠ Supplier KPI file unavailable"
    )

if mcda_df is not None:

    print(
        f"MCDA Results  : "
        f"{mcda_df.shape[0]} rows × "
        f"{mcda_df.shape[1]} columns"
    )

else:

    print(
        "⚠ MCDA Results unavailable"
    )


# ============================================================
# 11. VERIFIED CELL 24A CONTEXT
# ============================================================

print(
    "\n[2] VERIFIED CELL 24A CONTEXT"
)

verified_context = (
    load_verified_context()
)

for key in [
    "dataset",
    "supplier",
    "analysis"
]:

    if verified_context.get(key):

        print(
            f"✓ {key.title()} context: Available"
        )

    else:

        print(
            f"⚠ {key.title()} context: Unavailable"
        )


# ============================================================
# 12. ENTITY DETECTION
# ============================================================

print(
    "\n[3] ENTITY DETECTION"
)

(
    base_entity_id,
    base_entity_name
) = detect_entity_columns(
    base_df
)

if kpi_df is not None:

    (
        kpi_entity_id,
        kpi_entity_name
    ) = detect_entity_columns(
        kpi_df
    )

else:

    kpi_entity_id = None
    kpi_entity_name = None


print(
    "Analysis Base Entity ID   :",
    base_entity_id
)

print(
    "Analysis Base Entity Name :",
    base_entity_name
)

print(
    "Supplier KPI Entity ID    :",
    kpi_entity_id
)

print(
    "Supplier KPI Entity Name  :",
    kpi_entity_name
)

if base_entity_id is None:

    raise ValueError(
        "Could not detect supplier/entity ID."
    )


# ============================================================
# 13. AVAILABLE DIMENSIONS
# ============================================================

print(
    "\n[4] AVAILABLE DIMENSIONS"
)

dimensions = (
    detect_dimension_columns(
        base_df
    )
)

for dim, cols in dimensions.items():

    if cols:

        print(
            f"✓ {dim}"
        )

    else:

        print(
            f"– {dim}: unavailable"
        )


available_dimensions = [
    dim
    for dim, cols
    in dimensions.items()
    if cols
]


# ============================================================
# 14. SUPPLIER-LEVEL MASTER TABLE
# ============================================================

print(
    "\n[5] SUPPLIER-LEVEL MASTER TABLE"
)

if (
    kpi_df is not None
    and
    kpi_entity_id is not None
):

    supplier_df = (
        kpi_df.copy()
    )

    supplier_df[
        kpi_entity_id
    ] = (
        supplier_df[
            kpi_entity_id
        ]
        .astype(str)
        .str.strip()
    )

    print(
        "✓ Using Cell 23 supplier KPI "
        "table as primary supplier-level source"
    )

else:

    print(
        "⚠ Cell 23 supplier KPI table unavailable"
    )

    print(
        "✓ Building supplier-level table "
        "from Analysis Base"
    )

    numeric_cols = (
        base_df
        .select_dtypes(
            include=np.number
        )
        .columns
        .tolist()
    )

    agg_dict = {
        col: "mean"
        for col in numeric_cols
    }

    supplier_df = (
        base_df
        .groupby(
            base_entity_id,
            dropna=False
        )
        .agg(
            agg_dict
        )
        .reset_index()
    )

    if base_entity_name:

        names = (
            base_df[
                [
                    base_entity_id,
                    base_entity_name
                ]
            ]
            .drop_duplicates(
                subset=[
                    base_entity_id
                ]
            )
        )

        supplier_df = (
            supplier_df
            .merge(
                names,
                on=base_entity_id,
                how="left"
            )
        )

    kpi_entity_id = (
        base_entity_id
    )

    kpi_entity_name = (
        base_entity_name
    )


# ============================================================
# 15. MCDA SUPPLIER-LEVEL INTEGRATION
# ============================================================

print(
    "\n[6] MCDA SUPPLIER-LEVEL SCORE"
)

mcda_source = None

mcda_score_column = None


# ============================================================
# PRIORITY 1 — CELL 23 SUPPLIER-LEVEL MCDA
# ============================================================

cell23_mcda_score = (
    find_column(
        supplier_df,
        [
            "mcda_score"
        ]
    )
)

if cell23_mcda_score is not None:

    supplier_df[
        "supplier_mcda_score"
    ] = clean_numeric(
        supplier_df[
            cell23_mcda_score
        ]
    )

    mcda_source = (
        "Cell 23 supplier-level mcda_score"
    )

    mcda_score_column = (
        cell23_mcda_score
    )

    print(
        "✓ Using supplier-level MCDA score: "
        f"{cell23_mcda_score}"
    )


# ============================================================
# PRIORITY 2 — CELL 19 MCDA FALLBACK
# ============================================================

elif mcda_df is not None:

    cell19_score = find_column(
        mcda_df,
        [
            "mcda__overall_score",
            "mcda_overall_score"
        ]
    )

    cell19_entity = find_column(
        mcda_df,
        [
            "entity_id",
            "supplier_id"
        ]
    )

    if (
        cell19_score is not None
        and
        cell19_entity is not None
    ):

        temp_mcda = (
            mcda_df.copy()
        )

        temp_mcda[
            cell19_entity
        ] = (
            temp_mcda[
                cell19_entity
            ]
            .astype(str)
            .str.strip()
        )

        temp_mcda[
            cell19_score
        ] = clean_numeric(
            temp_mcda[
                cell19_score
            ]
        )

        supplier_mcda = (
            temp_mcda
            .groupby(
                cell19_entity
            )[cell19_score]
            .mean()
            .reset_index()
        )

        supplier_mcda.columns = [
            "supplier_join_id",
            "supplier_mcda_score"
        ]

        supplier_df = (
            supplier_df
            .merge(
                supplier_mcda,
                left_on=kpi_entity_id,
                right_on="supplier_join_id",
                how="left"
            )
        )

        supplier_df.drop(
            columns=[
                "supplier_join_id"
            ],
            inplace=True,
            errors="ignore"
        )

        mcda_source = (
            "Cell 19 mcda__overall_score "
            "aggregated to supplier level"
        )

        mcda_score_column = (
            cell19_score
        )

        print(
            "✓ Cell 19 MCDA score "
            "aggregated to supplier level"
        )

    else:

        print(
            "⚠ Cell 19 MCDA fallback unavailable"
        )

else:

    print(
        "⚠ No MCDA source available"
    )


# ============================================================
# 16. TRUE SUPPLIER-LEVEL RANK
# ============================================================

if (
    "supplier_mcda_score"
    in supplier_df.columns
):

    supplier_df[
        "supplier_mcda_score"
    ] = clean_numeric(
        supplier_df[
            "supplier_mcda_score"
        ]
    )

    supplier_df[
        "supplier_mcda_rank"
    ] = (
        supplier_df[
            "supplier_mcda_score"
        ]
        .rank(
            ascending=False,
            method="min"
        )
    )

    supplier_df[
        "supplier_mcda_rank"
    ] = (
        supplier_df[
            "supplier_mcda_rank"
        ]
        .astype("Int64")
    )

    valid_count = int(
        supplier_df[
            "supplier_mcda_score"
        ]
        .notna()
        .sum()
    )

    unscored_count = int(
        supplier_df[
            "supplier_mcda_score"
        ]
        .isna()
        .sum()
    )

    print(
        "✓ Supplier-level MCDA rank recalculated"
    )

    print(
        f"✓ MCDA source: {mcda_source}"
    )

    print(
        f"✓ Suppliers with MCDA score: "
        f"{valid_count}"
    )

    print(
        f"✓ Suppliers ranked: "
        f"{valid_count}"
    )

    print(
        "✓ Original category-level "
        "mcda__rank is NOT used for supplier ranking"
    )

    if "mcda_rank" in supplier_df.columns:

        print(
            "✓ Cell 23 mcda_rank detected "
            "but replaced with fresh supplier-level rank"
        )

else:

    valid_count = 0

    unscored_count = len(
        supplier_df
    )

    print(
        "⚠ Supplier-level MCDA ranking unavailable"
    )


# ============================================================
# 17. DATASET SUMMARY
# ============================================================

dataset_summary = {

    "rows":
        int(
            base_df.shape[0]
        ),

    "columns":
        int(
            base_df.shape[1]
        ),

    "unique_entities":
        int(
            base_df[
                base_entity_id
            ]
            .nunique()
        ),

    "entity_id_column":
        base_entity_id,

    "entity_name_column":
        base_entity_name,

    "available_dimensions":
        available_dimensions,

    "dimension_columns":
        dimensions,

    "mcda_available":
        valid_count > 0,

    "mcda_source":
        mcda_source,

    "mcda_scored_supplier_count":
        valid_count,

    "mcda_unscored_supplier_count":
        unscored_count
}


# ============================================================
# 18. REPRESENTATIVE SUPPLIERS
# ============================================================

print(
    "\n[7] REPRESENTATIVE SUPPLIER CONTEXT"
)

selected_frames = []


# ------------------------------------------------------------
# Top MCDA
# ------------------------------------------------------------

if (
    "supplier_mcda_score"
    in supplier_df.columns
):

    ranked = (
        supplier_df
        .dropna(
            subset=[
                "supplier_mcda_score"
            ]
        )
        .sort_values(
            "supplier_mcda_score",
            ascending=False
        )
    )

    if not ranked.empty:

        selected_frames.append(
            ranked.head(5)
        )

        selected_frames.append(
            ranked.tail(5)
        )


# ------------------------------------------------------------
# Highest risk
# ------------------------------------------------------------

risk_col = None

for candidate in [
    "risk_kpi",
    "risk_score",
    "risk__risk_score",
    "historical_awards_risk_score_at_award"
]:

    if candidate in supplier_df.columns:

        values = clean_numeric(
            supplier_df[
                candidate
            ]
        )

        if values.notna().sum() > 0:

            risk_col = candidate

            temp = (
                supplier_df.copy()
            )

            temp[
                "_vendor360_risk"
            ] = values

            selected_frames.append(
                temp
                .dropna(
                    subset=[
                        "_vendor360_risk"
                    ]
                )
                .sort_values(
                    "_vendor360_risk",
                    ascending=False
                )
                .head(5)
            )

            break


# ------------------------------------------------------------
# Combine
# ------------------------------------------------------------

if selected_frames:

    representative_df = (
        pd.concat(
            selected_frames,
            ignore_index=True
        )
    )

else:

    representative_df = (
        supplier_df.copy()
    )


# ------------------------------------------------------------
# Remove duplicate suppliers
# ------------------------------------------------------------

if (
    kpi_entity_id
    in representative_df.columns
):

    representative_df = (
        representative_df
        .drop_duplicates(
            subset=[
                kpi_entity_id
            ]
        )
    )


representative_df = (
    representative_df
    .head(
        MAX_SUPPLIER_CONTEXT
    )
    .copy()
)


print(
    f"✓ Selected "
    f"{len(representative_df)} "
    f"representative suppliers"
)


# ============================================================
# 19. PREPARE AI SUPPLIER CONTEXT
# ============================================================

def prepare_supplier_context(
    df
):

    records = []

    preferred_fields = [

        "cost_kpi",

        "quality_kpi",

        "reliability_kpi",

        "risk_kpi",

        "sustainability_kpi",

        "capacity_kpi",

        "kpi_completeness_pct",

        "supplier_review_status",

        "risk_review_flag",

        "anomaly_flag"
    ]

    for _, row in df.iterrows():

        record = {}

        # ----------------------------------------------------
        # ID
        # ----------------------------------------------------

        if (
            kpi_entity_id
            in row.index
        ):

            record[
                "supplier_id"
            ] = str(
                row[
                    kpi_entity_id
                ]
            )

        # ----------------------------------------------------
        # NAME
        # ----------------------------------------------------

        if (
            kpi_entity_name
            and
            kpi_entity_name
            in row.index
        ):

            record[
                "supplier_name"
            ] = str(
                row[
                    kpi_entity_name
                ]
            )

        # ----------------------------------------------------
        # MCDA SCORE
        # ----------------------------------------------------

        if (
            "supplier_mcda_score"
            in row.index
        ):

            value = (
                row[
                    "supplier_mcda_score"
                ]
            )

            if pd.notna(value):

                record[
                    "supplier_mcda_score"
                ] = round(
                    float(value),
                    4
                )

        # ----------------------------------------------------
        # MCDA RANK
        # ----------------------------------------------------

        if (
            "supplier_mcda_rank"
            in row.index
        ):

            value = (
                row[
                    "supplier_mcda_rank"
                ]
            )

            if pd.notna(value):

                record[
                    "supplier_mcda_rank"
                ] = int(
                    value
                )

        # ----------------------------------------------------
        # KPI FIELDS
        # ----------------------------------------------------

        for field in preferred_fields:

            if field not in row.index:

                continue

            value = row[field]

            if pd.isna(value):

                continue

            if isinstance(
                value,
                np.integer
            ):

                value = int(
                    value
                )

            elif isinstance(
                value,
                (
                    np.floating,
                    float
                )
            ):

                value = round(
                    float(value),
                    4
                )

            elif isinstance(
                value,
                np.bool_
            ):

                value = bool(
                    value
                )

            else:

                value = str(
                    value
                )

            record[
                field
            ] = value

        records.append(
            record
        )

    return records


supplier_context = (
    prepare_supplier_context(
        representative_df
    )
)

print(
    f"✓ AI supplier context prepared: "
    f"{len(supplier_context)} records"
)


# ============================================================
# 20. LOCAL VERIFIED ANALYSIS ENGINE
# ============================================================

def local_insights(
    supplier_table,
    available_dims,
    dataset_info
):

    result = {

        "engine":
            "Local Deterministic Vendor360 Engine",

        "summary": [],

        "key_findings": [],

        "risk_observations": [],

        "decision_observations": [],

        "trade_offs": [],

        "recommendations": [],

        "data_quality": {},

        "mcda": {}
    }


    # ========================================================
    # GENERAL SUMMARY
    # ========================================================

    result[
        "summary"
    ].append(
        f"Vendor360 analyzed "
        f"{dataset_info['rows']} records "
        f"across "
        f"{dataset_info['unique_entities']} "
        f"unique entities."
    )

    result[
        "summary"
    ].append(
        "Available business dimensions: "
        + ", ".join(
            available_dims
        )
        + "."
    )


    # ========================================================
    # MCDA
    # ========================================================

    if (
        "supplier_mcda_score"
        in supplier_table.columns
    ):

        ranked = (
            supplier_table
            .dropna(
                subset=[
                    "supplier_mcda_score"
                ]
            )
            .sort_values(
                "supplier_mcda_score",
                ascending=False
            )
        )

        if not ranked.empty:

            top = ranked.iloc[0]

            if (
                kpi_entity_name
                and
                kpi_entity_name
                in top.index
            ):

                top_name = str(
                    top[
                        kpi_entity_name
                    ]
                )

            else:

                top_name = str(
                    top[
                        kpi_entity_id
                    ]
                )

            top_score = float(
                top[
                    "supplier_mcda_score"
                ]
            )

            top_rank = int(
                top[
                    "supplier_mcda_rank"
                ]
            )

            result[
                "mcda"
            ] = {

                "top_supplier":
                    top_name,

                "top_supplier_score":
                    round(
                        top_score,
                        4
                    ),

                "top_supplier_rank":
                    top_rank,

                "ranked_supplier_count":
                    int(
                        len(
                            ranked
                        )
                    )
            }

            result[
                "key_findings"
            ].append(
                f"{top_name} has the highest "
                f"supplier-level MCDA score "
                f"({top_score:.4f}) and ranks "
                f"#{top_rank}."
            )

            top_names = []

            for _, row in (
                ranked
                .head(5)
                .iterrows()
            ):

                if (
                    kpi_entity_name
                    and
                    kpi_entity_name
                    in row.index
                ):

                    name = str(
                        row[
                            kpi_entity_name
                        ]
                    )

                else:

                    name = str(
                        row[
                            kpi_entity_id
                        ]
                    )

                top_names.append(
                    name
                )

            result[
                "decision_observations"
            ].append(
                "Top supplier-level MCDA "
                "candidates: "
                + ", ".join(
                    top_names
                )
                + "."
            )

            # ------------------------------------------------
            # Missing MCDA
            # ------------------------------------------------

            unscored = int(
                supplier_table[
                    "supplier_mcda_score"
                ]
                .isna()
                .sum()
            )

            if unscored > 0:

                result[
                    "data_quality"
                ][
                    "mcda_unscored_suppliers"
                ] = unscored

                result[
                    "data_quality"
                ][
                    "mcda_note"
                ] = (
                    "MCDA ranking is unavailable "
                    "for some suppliers because "
                    "their required evaluation "
                    "information is incomplete."
                )


    # ========================================================
    # RISK
    # ========================================================

    risk_col = None

    for candidate in [
        "risk_kpi",
        "risk_score",
        "risk__risk_score"
    ]:

        if candidate in supplier_table.columns:

            vals = clean_numeric(
                supplier_table[
                    candidate
                ]
            )

            if vals.notna().sum() > 0:

                risk_col = candidate

                break

    if risk_col:

        risk_values = clean_numeric(
            supplier_table[
                risk_col
            ]
        )

        median_risk = (
            risk_values
            .median()
        )

        high_risk = supplier_table[
            risk_values
            > median_risk
        ]

        if not high_risk.empty:

            result[
                "risk_observations"
            ].append(
                f"{len(high_risk)} suppliers "
                f"are above the median "
                f"risk indicator."
            )

        temp = (
            supplier_table.copy()
        )

        temp[
            "_risk_value"
        ] = risk_values

        temp = (
            temp
            .dropna(
                subset=[
                    "_risk_value"
                ]
            )
            .sort_values(
                "_risk_value",
                ascending=False
            )
            .head(5)
        )

        risk_list = []

        for _, row in temp.iterrows():

            if (
                kpi_entity_name
                and
                kpi_entity_name
                in row.index
            ):

                name = str(
                    row[
                        kpi_entity_name
                    ]
                )

            else:

                name = str(
                    row[
                        kpi_entity_id
                    ]
                )

            risk_list.append(
                f"{name} "
                f"({float(row['_risk_value']):.2f})"
            )

        if risk_list:

            result[
                "risk_observations"
            ].append(
                "Highest risk indicators: "
                + ", ".join(
                    risk_list
                )
                + "."
            )


    # ========================================================
    # ANOMALIES
    # ========================================================

    anomaly_col = find_column(
        supplier_table,
        [
            "anomaly_flag"
        ]
    )

    if anomaly_col:

        anomaly = clean_numeric(
            supplier_table[
                anomaly_col
            ]
        )

        anomaly_count = int(
            (
                anomaly
                .fillna(0)
                != 0
            ).sum()
        )

        if anomaly_count > 0:

            result[
                "risk_observations"
            ].append(
                f"{anomaly_count} supplier "
                f"records have an anomaly "
                f"flag in the supplier KPI table."
            )


    # ========================================================
    # KPI COMPLETENESS
    # ========================================================

    completeness_col = find_column(
        supplier_table,
        [
            "kpi_completeness_pct"
        ]
    )

    if completeness_col:

        completeness = clean_numeric(
            supplier_table[
                completeness_col
            ]
        )

        if completeness.notna().any():

            result[
                "data_quality"
            ][
                "average_kpi_completeness_pct"
            ] = round(
                float(
                    completeness.mean()
                ),
                2
            )

            result[
                "data_quality"
            ][
                "minimum_kpi_completeness_pct"
            ] = round(
                float(
                    completeness.min()
                ),
                2
            )


    # ========================================================
    # TRADE-OFFS
    # ========================================================

    if (
        "Cost" in available_dims
        and
        "Quality" in available_dims
    ):

        result[
            "trade_offs"
        ].append(
            "Cost and quality should be "
            "reviewed together because a "
            "lower-cost supplier may not "
            "provide the strongest quality outcome."
        )

    if (
        "Cost" in available_dims
        and
        "Reliability" in available_dims
    ):

        result[
            "trade_offs"
        ].append(
            "Supplier selection should consider "
            "the trade-off between cost and "
            "delivery/reliability performance."
        )

    if (
        "Risk" in available_dims
        and
        "Sustainability" in available_dims
    ):

        result[
            "trade_offs"
        ].append(
            "Risk and sustainability indicators "
            "should be considered alongside cost "
            "rather than treated as secondary factors."
        )


    # ========================================================
    # RECOMMENDATIONS
    # ========================================================

    result[
        "recommendations"
    ] = [

        "Use supplier-level MCDA as a transparent decision-support mechanism rather than an automatic purchasing decision.",

        "Review high-risk suppliers separately before final supplier selection.",

        "Investigate suppliers with strong aggregate scores but weak individual dimensions because an overall score can hide trade-offs.",

        "Use Vendor360 periodically to monitor changes in supplier performance, risk and sustainability indicators.",

        "Require additional information before ranking suppliers whose MCDA score is unavailable."
    ]


    # ========================================================
    # MCDA SUMMARY
    # ========================================================

    if dataset_info[
        "mcda_available"
    ]:

        result[
            "summary"
        ].append(
            "Supplier-level MCDA ranking is available "
            "and was recalculated directly from "
            "supplier-level MCDA scores."
        )

    else:

        result[
            "summary"
        ].append(
            "Supplier-level MCDA ranking is "
            "unavailable for this dataset."
        )

    return result


# ============================================================
# 21. GEMINI PROMPT
# ============================================================

def build_gemini_prompt(
    dataset_info,
    supplier_context,
    local_result
):

    compact_supplier_context = (
        supplier_context[
            :MAX_PROMPT_SUPPLIERS
        ]
    )

    prompt = f"""
You are the Vendor360 Business Analysis AI.

Analyze the verified supplier information below and produce
business insights for a procurement and supplier-management
decision-support system.

STRICT RULES:

1. Use ONLY the supplied verified data.
2. Never invent supplier metrics.
3. Never invent historical events.
4. Do not make unsupported future predictions.
5. Do not call an indicator a confirmed business failure.
6. Clearly distinguish risk indicators from confirmed events.
7. If a business dimension is unavailable, say so.
8. MCDA is a decision-support mechanism, not autonomous purchasing.
9. supplier_mcda_score is a SUPPLIER-LEVEL score.
10. supplier_mcda_rank is a SUPPLIER-LEVEL rank recalculated
    from supplier_mcda_score.
11. DO NOT use category-level mcda__rank.
12. Higher supplier_mcda_score means a stronger aggregate MCDA
    result for this analysis.
13. An aggregate score does not eliminate trade-offs between
    individual dimensions.
14. Do not fabricate trends when historical/time-series data
    is unavailable.

DATASET SUMMARY
----------------
{json.dumps(
    dataset_info,
    indent=2,
    default=str
)}

REPRESENTATIVE SUPPLIER DATA
----------------------------
{json.dumps(
    compact_supplier_context,
    indent=2,
    default=str
)}

VERIFIED LOCAL ANALYSIS
-----------------------
{json.dumps(
    local_result,
    indent=2,
    default=str
)}

Produce these sections:

1. EXECUTIVE SUMMARY

2. KEY FINDINGS

3. TOP SUPPLIERS
   Discuss the strongest suppliers using supplier-level MCDA
   score and supplier-level rank where available.

4. RISK OBSERVATIONS
   Highlight suppliers or patterns that deserve management review.

5. TRADE-OFFS
   Explain meaningful cost, quality, reliability, risk,
   sustainability or capacity trade-offs supported by the data.

6. MANAGEMENT RECOMMENDATIONS
   Give practical procurement/supplier-management actions.

7. DATA LIMITATIONS
   Clearly state missing dimensions, incomplete supplier data,
   aggregation limitations and other relevant limitations.

Keep the response concise, professional and suitable for a
Business Analysis & Modelling project presentation.
"""

    return prompt


# ============================================================
# 22. LOAD CACHED INSIGHTS
# ============================================================

def load_cached_insights():

    if not os.path.exists(
        OUTPUT_JSON
    ):

        return None

    try:

        with open(
            OUTPUT_JSON,
            "r",
            encoding="utf-8"
        ) as f:

            cached = json.load(
                f
            )

        if not cached.get(
            "final_analysis"
        ):

            return None

        return cached

    except Exception:

        return None


# ============================================================
# 23. SAVE OUTPUTS
# ============================================================

def save_outputs(
    final_output,
    final_text
):

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            final_output,
            f,
            indent=2,
            ensure_ascii=False,
            default=str
        )

    with open(
        OUTPUT_TXT,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "VENDOR360 — GENERAL AI INSIGHTS\n"
        )

        f.write(
            "=" * 70
            + "\n\n"
        )

        f.write(
            f"Generated: "
            f"{final_output.get('generated_at')}\n"
        )

        f.write(
            f"Mode: "
            f"{final_output.get('mode')}\n"
        )

        f.write(
            f"Engine: "
            f"{final_output.get('engine')}\n"
        )

        f.write(
            f"MCDA Source: "
            f"{final_output.get('mcda', {}).get('source')}\n"
        )

        f.write(
            "\n"
            + "=" * 70
            + "\n\n"
        )

        f.write(
            final_text
        )


# ============================================================
# 24. FRESH ANALYSIS
# ============================================================

def generate_fresh_insights():

    print(
        "\n"
        + "=" * 70
    )

    print(
        "GENERATING FRESH VENDOR360 AI INSIGHTS"
    )

    print(
        "=" * 70
    )


    # ========================================================
    # LOCAL ANALYSIS
    # ========================================================

    print(
        "\n[8] LOCAL VERIFIED ANALYSIS"
    )

    local_result = local_insights(
        supplier_df,
        available_dimensions,
        dataset_summary
    )

    print(
        "✓ Local deterministic analysis generated"
    )


    # ========================================================
    # GEMINI
    # ========================================================

    print(
        "\n[9] GEMINI ANALYSIS"
    )

    prompt = build_gemini_prompt(
        dataset_summary,
        supplier_context,
        local_result
    )

    gemini_result = (
        run_gemini_with_timeout(
            prompt
        )
    )

    usage = load_usage_log()

    usage[
        "total_attempts"
    ] = (
        int(
            usage.get(
                "total_attempts",
                0
            )
        )
        + 1
    )

    usage[
        "fresh_runs"
    ] = (
        int(
            usage.get(
                "fresh_runs",
                0
            )
        )
        + 1
    )

    usage[
        "last_run"
    ] = (
        datetime.now().isoformat()
    )

    usage[
        "last_mode"
    ] = "Fresh"


    # ========================================================
    # GEMINI SUCCESS
    # ========================================================

    if gemini_result[
        "success"
    ]:

        selected_engine = (
            "Gemini"
        )

        final_text = (
            gemini_result[
                "text"
            ]
        )

        usage[
            "gemini_success"
        ] = (
            int(
                usage.get(
                    "gemini_success",
                    0
                )
            )
            + 1
        )

        usage[
            "last_engine"
        ] = "Gemini"

        print(
            "✓ Gemini analysis successful"
        )

        print(
            f"  Model: "
            f"{gemini_result['model']}"
        )

        print(
            f"  Time: "
            f"{gemini_result['elapsed_seconds']} sec"
        )


    # ========================================================
    # LOCAL FALLBACK
    # ========================================================

    else:

        selected_engine = (
            "Local Deterministic Fallback"
        )

        usage[
            "gemini_failures"
        ] = (
            int(
                usage.get(
                    "gemini_failures",
                    0
                )
            )
            + 1
        )

        usage[
            "local_fallbacks"
        ] = (
            int(
                usage.get(
                    "local_fallbacks",
                    0
                )
            )
            + 1
        )

        usage[
            "last_engine"
        ] = (
            "Local Deterministic Fallback"
        )


        # ----------------------------------------------------
        # Build readable local report
        # ----------------------------------------------------

        sections = []


        sections.append(
            "EXECUTIVE SUMMARY\n"
            +
            "\n".join(
                f"- {x}"
                for x
                in local_result[
                    "summary"
                ]
            )
        )


        if local_result[
            "key_findings"
        ]:

            sections.append(
                "KEY FINDINGS\n"
                +
                "\n".join(
                    f"- {x}"
                    for x
                    in local_result[
                        "key_findings"
                    ]
                )
            )


        if local_result[
            "mcda"
        ]:

            mcda = (
                local_result[
                    "mcda"
                ]
            )

            sections.append(
                "TOP SUPPLIER\n"
                f"- Supplier: "
                f"{mcda.get('top_supplier')}\n"
                f"- Supplier-level MCDA score: "
                f"{mcda.get('top_supplier_score')}\n"
                f"- Supplier-level rank: "
                f"#{mcda.get('top_supplier_rank')}"
            )


        if local_result[
            "risk_observations"
        ]:

            sections.append(
                "RISK OBSERVATIONS\n"
                +
                "\n".join(
                    f"- {x}"
                    for x
                    in local_result[
                        "risk_observations"
                    ]
                )
            )


        if local_result[
            "trade_offs"
        ]:

            sections.append(
                "TRADE-OFFS\n"
                +
                "\n".join(
                    f"- {x}"
                    for x
                    in local_result[
                        "trade_offs"
                    ]
                )
            )


        if local_result[
            "decision_observations"
        ]:

            sections.append(
                "DECISION OBSERVATIONS\n"
                +
                "\n".join(
                    f"- {x}"
                    for x
                    in local_result[
                        "decision_observations"
                    ]
                )
            )


        sections.append(
            "MANAGEMENT RECOMMENDATIONS\n"
            +
            "\n".join(
                f"- {x}"
                for x
                in local_result[
                    "recommendations"
                ]
            )
        )


        if local_result[
            "data_quality"
        ]:

            sections.append(
                "DATA LIMITATIONS\n"
                +
                "\n".join(
                    f"- {k}: {v}"
                    for k, v
                    in local_result[
                        "data_quality"
                    ].items()
                )
            )


        final_text = (
            "\n\n".join(
                sections
            )
        )


        print(
            "⚠ Gemini unavailable/failed."
        )

        print(
            f"  Reason: "
            f"{gemini_result['reason']}"
        )

        print(
            "✓ Local deterministic fallback used."
        )


    # ========================================================
    # USAGE HISTORY
    # ========================================================

    usage.setdefault(
        "history",
        []
    )

    usage[
        "history"
    ].append({

        "timestamp":
            datetime.now().isoformat(),

        "mode":
            "Fresh",

        "engine":
            selected_engine,

        "gemini_model":
            gemini_result.get(
                "model"
            ),

        "gemini_success":
            bool(
                gemini_result[
                    "success"
                ]
            ),

        "gemini_elapsed_seconds":
            gemini_result.get(
                "elapsed_seconds",
                0
            ),

        "gemini_failure_reason":
            gemini_result.get(
                "reason"
            ),

        "mcda_source":
            mcda_source,

        "supplier_count":
            int(
                len(
                    supplier_df
                )
            ),

        "available_dimensions":
            available_dimensions
    })

    usage[
        "history"
    ] = usage[
        "history"
    ][-20:]

    save_usage_log(
        usage
    )


    # ========================================================
    # FINAL JSON
    # ========================================================

    final_output = {

        "generated_at":
            datetime.now().isoformat(),

        "mode":
            "Fresh",

        "engine":
            selected_engine,

        "dataset_summary":
            dataset_summary,

        "entity_detection": {

            "analysis_base_entity_id":
                base_entity_id,

            "analysis_base_entity_name":
                base_entity_name,

            "supplier_kpi_entity_id":
                kpi_entity_id,

            "supplier_kpi_entity_name":
                kpi_entity_name
        },

        "available_dimensions":
            available_dimensions,

        "dimension_columns":
            dimensions,

        "mcda": {

            "available":
                valid_count > 0,

            "source":
                mcda_source,

            "score_column":
                mcda_score_column,

            "rank_method":
                "Supplier-level rank recalculated "
                "descending from supplier_mcda_score",

            "category_level_rank_used":
                False,

            "scored_supplier_count":
                valid_count,

            "unscored_supplier_count":
                unscored_count
        },

        "representative_suppliers":
            supplier_context,

        "local_analysis":
            local_result,

        "gemini": {

            "success":
                gemini_result[
                    "success"
                ],

            "model":
                gemini_result.get(
                    "model"
                ),

            "elapsed_seconds":
                gemini_result.get(
                    "elapsed_seconds",
                    0
                ),

            "failure_reason":
                gemini_result.get(
                    "reason"
                )
        },

        "final_analysis":
            final_text
    }


    # ========================================================
    # SAVE
    # ========================================================

    save_outputs(
        final_output,
        final_text
    )

    return (
        final_output,
        usage
    )


# ============================================================
# 25. SHARED RESULT HOLDER
# ============================================================

result_holder = {
    "result": None
}


# ============================================================
# 26. EXECUTION FUNCTION
# ============================================================

def execute_24b(
    mode="cached",
    force_refresh=False
):

    # ========================================================
    # CACHED
    # ========================================================

    if (
        mode == "cached"
        and
        not force_refresh
    ):

        cached = (
            load_cached_insights()
        )

        if cached is not None:

            usage = load_usage_log()

            usage[
                "cached_runs"
            ] = (
                int(
                    usage.get(
                        "cached_runs",
                        0
                    )
                )
                + 1
            )

            usage[
                "last_run"
            ] = (
                datetime.now().isoformat()
            )

            usage[
                "last_mode"
            ] = "Cached"

            usage[
                "last_engine"
            ] = cached.get(
                "engine",
                "Cached"
            )

            usage.setdefault(
                "history",
                []
            )

            usage[
                "history"
            ].append({

                "timestamp":
                    datetime.now().isoformat(),

                "mode":
                    "Cached",

                "engine":
                    cached.get(
                        "engine",
                        "Cached"
                    ),

                "mcda_source":
                    cached.get(
                        "mcda",
                        {}
                    ).get(
                        "source"
                    ),

                "supplier_count":
                    cached.get(
                        "dataset_summary",
                        {}
                    ).get(
                        "unique_entities"
                    )
            })

            usage[
                "history"
            ] = usage[
                "history"
            ][-20:]

            save_usage_log(
                usage
            )

            result_holder[
                "result"
            ] = cached

            print(
                "\n✓ Cached insights loaded."
            )

            print(
                f"Engine: "
                f"{cached.get('engine')}"
            )

            print(
                f"Generated: "
                f"{cached.get('generated_at')}"
            )

            return cached


        print(
            "\n⚠ No valid cached insights found."
        )

        print(
            "→ Automatically generating fresh insights."
        )


    # ========================================================
    # FRESH
    # ========================================================

    fresh_result, _ = (
        generate_fresh_insights()
    )

    result_holder[
        "result"
    ] = fresh_result

    print(
        "\n"
        + "=" * 70
    )

    print(
        "FRESH AI INSIGHTS"
    )

    print(
        "=" * 70
    )

    print(
        fresh_result[
            "final_analysis"
        ]
    )

    print(
        "\n"
        + "=" * 70
    )

    print(
        "✓ Fresh insights saved."
    )

    print(
        f"JSON: {OUTPUT_JSON}"
    )

    print(
        f"TXT : {OUTPUT_TXT}"
    )

    return fresh_result


# ============================================================
# 27. CONTROL PANEL
# ============================================================

print(
    "\n"
    + "=" * 70
)

print(
    "VENDOR360 AI INSIGHTS CONTROL"
)

print(
    "=" * 70
)

print(
    "\nChoose how Cell 24C should behave."
)

print(
    "📦 Cached = use existing insights without calling Gemini."
)

print(
    "✨ Fresh  = generate a new analysis."
)

print(
    "🔄 Refresh = force a fresh analysis."
)


# ============================================================
# 28. WIDGET CONTROL
# ============================================================

if WIDGETS_AVAILABLE:

    mode_toggle = widgets.ToggleButtons(

        options=[
            (
                "📦 Use Cached Insights",
                "cached"
            ),
            (
                "✨ Generate Fresh Insights",
                "fresh"
            )
        ],

        value="cached",

        description="Mode:"
    )

    run_button = widgets.Button(

        description=(
            "▶ Run Selected Mode"
        ),

        button_style="success"
    )

    refresh_button = widgets.Button(

        description=(
            "🔄 Refresh AI Insights"
        ),

        button_style="primary",

        tooltip=(
            "Force a fresh Vendor360 AI analysis"
        )
    )

    status_output = widgets.Output()


    display(
        mode_toggle
    )

    display(
        widgets.HBox([
            run_button,
            refresh_button
        ])
    )

    display(
        status_output
    )


    # ========================================================
    # RUN SELECTED MODE
    # ========================================================

    def on_run_clicked(
        button
    ):

        with status_output:

            clear_output(
                wait=True
            )

            print(
                "=" * 70
            )

            print(
                "VENDOR360 AI INSIGHTS"
            )

            print(
                "=" * 70
            )

            selected_mode = (
                mode_toggle.value
            )

            result = execute_24b(
                mode=selected_mode
            )

            result_holder[
                "result"
            ] = result


    # ========================================================
    # FORCE REFRESH
    # ========================================================

    def on_refresh_clicked(
        button
    ):

        with status_output:

            clear_output(
                wait=True
            )

            print(
                "=" * 70
            )

            print(
                "VENDOR360 AI INSIGHTS — REFRESH"
            )

            print(
                "=" * 70
            )

            result = execute_24b(
                mode="fresh",
                force_refresh=True
            )

            result_holder[
                "result"
            ] = result


    run_button.on_click(
        on_run_clicked
    )

    refresh_button.on_click(
        on_refresh_clicked
    )


    # ========================================================
    # INITIAL STATE
    # ========================================================

    cached_initial = (
        load_cached_insights()
    )

    if cached_initial is not None:

        print(
            "\n✓ Cached insights detected."
        )

        print(
            "No Gemini call is required for the initial state."
        )

        print(
            "Use ▶ Run Selected Mode to execute the selected mode."
        )

        print(
            "Use 🔄 Refresh AI Insights for a forced fresh run."
        )

        # ----------------------------------------------------
        # Load cache without Gemini
        # ----------------------------------------------------

        result_holder[
            "result"
        ] = cached_initial

    else:

        print(
            "\n⚠ No cached insights found."
        )

        print(
            "Generating the first fresh analysis..."
        )

        result_holder[
            "result"
        ] = execute_24b(
            mode="fresh"
        )


# ============================================================
# 29. NON-WIDGET FALLBACK
# ============================================================

else:

    print(
        "\n⚠ ipywidgets unavailable."
    )

    cached = (
        load_cached_insights()
    )

    if cached is not None:

        print(
            "✓ Cached insights loaded."
        )

        result_holder[
            "result"
        ] = cached

    else:

        print(
            "✓ No cache found."
        )

        print(
            "Generating fresh analysis..."
        )

        result_holder[
            "result"
        ] = execute_24b(
            mode="fresh"
        )


# ============================================================
# 30. FINAL RESULT
# ============================================================

result_24b = (
    result_holder[
        "result"
    ]
)


# ============================================================
# 31. FINAL STATUS
# ============================================================

print(
    "\n"
    + "=" * 70
)

print(
    "CELL 24C — FINAL STATUS"
)

print(
    "=" * 70
)

if result_24b is None:

    print(
        "❌ Cell 24C did not produce a result."
    )

else:

    final_dataset_info = (
        result_24b.get(
            "dataset_summary",
            {}
        )
    )

    final_mcda_info = (
        result_24b.get(
            "mcda",
            {}
        )
    )

    print(
        f"Mode           : "
        f"{result_24b.get('mode')}"
    )

    print(
        f"Engine         : "
        f"{result_24b.get('engine')}"
    )

    print(
        f"Supplier count : "
        f"{final_dataset_info.get('unique_entities')}"
    )

    print(
        "Dimensions     : "
        + ", ".join(
            result_24b.get(
                "available_dimensions",
                []
            )
        )
    )

    print(
        f"MCDA source    : "
        f"{final_mcda_info.get('source')}"
    )

    print(
        f"MCDA scored    : "
        f"{final_mcda_info.get('scored_supplier_count')}"
    )

    print(
        f"MCDA unscored  : "
        f"{final_mcda_info.get('unscored_supplier_count')}"
    )

    print(
        f"Category rank used : "
        f"{final_mcda_info.get('category_level_rank_used')}"
    )

    print(
        "\nOUTPUT:"
    )

    print(
        f" {OUTPUT_JSON}"
    )

    print(
        f" {OUTPUT_TXT}"
    )

    print(
        f" {USAGE_LOG}"
    )

    print("\nCELL 24C VALIDATION")
    v360_status("CELL 24C", {
        "result object produced": lambda: isinstance(result_24b, dict),
        "output JSON exists and reloads": lambda: v360_json_ok(OUTPUT_JSON),
        "analysis text file is non-empty": lambda: v360_file_ok(OUTPUT_TXT),
        "scored supplier count is positive": lambda: (final_mcda_info.get("scored_supplier_count") or 0) > 0,
        "engine is labelled (Gemini or local fallback)": lambda: bool(result_24b.get("engine")),
    })


print(
    "=" * 70
)


# ============================================================
# 32. TOP 10 SUPPLIER-LEVEL MCDA VERIFICATION
# ============================================================

if (
    result_24b is not None
    and
    "supplier_mcda_score"
    in supplier_df.columns
):

    verification_cols = [
        kpi_entity_id
    ]

    if (
        kpi_entity_name
        and
        kpi_entity_name
        in supplier_df.columns
    ):

        verification_cols.append(
            kpi_entity_name
        )

    verification_cols.extend([
        "supplier_mcda_score",
        "supplier_mcda_rank"
    ])

    verification = (
        supplier_df[
            verification_cols
        ]
        .dropna(
            subset=[
                "supplier_mcda_score"
            ]
        )
        .sort_values(
            "supplier_mcda_score",
            ascending=False
        )
        .head(10)
    )

    print(
        "\nTOP 10 SUPPLIERS — "
        "SUPPLIER-LEVEL MCDA"
    )

    display(
        verification
    )


# ============================================================
# 33. CELL 24C COMPLETE
# ============================================================

print(
    "\n"
    + "=" * 70
)

print(
    "CELL 24C COMPLETE"
)

print(
    "=" * 70
)

print(
    "✓ Adaptive data handling"
)

print(
    "✓ Supplier-level MCDA"
)

print(
    "✓ Correct supplier-level ranking"
)

print(
    "✓ Cached/Fresh toggle"
)

print(
    "✓ Refresh control"
)

print(
    "✓ Gemini integration"
)

print(
    "✓ Local fallback"
)

print(
    "✓ AI context"
)

print(
    "✓ Data-quality awareness"
)

print(
    "✓ JSON/TXT outputs"
)

print(
    "✓ Usage logging"
)

print(
    "✓ Streamlit-ready outputs"
)

print(
    "\nCELL 24C: ready for Cell 25 only if the validation above says PASS "
    f"(recorded status: {VENDOR360_STATUS.get('CELL 24C', {}).get('status', 'NOT RUN')})"
)

print(
    "=" * 70
)

# ============================================================
