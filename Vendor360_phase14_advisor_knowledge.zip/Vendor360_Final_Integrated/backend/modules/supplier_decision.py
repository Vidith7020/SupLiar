# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 46 =====

# CORRECTED VERSION
# ============================================================

import os
import json
import numpy as np
import pandas as pd

print("=" * 70)
print("VENDOR360 SUPPLIER KPI & COMPARISON ENGINE")
print("=" * 70)

# ------------------------------------------------------------
# 1. PATHS
# ------------------------------------------------------------

BASE_FILE = V360_WORK + "/Vendor360_Analysis_Base.csv"
MCDA_FILE = V360_WORK + "/Vendor360_Cell19/MCDA_Results.csv"
ANOMALY_FILE = V360_WORK + "/Vendor360_Cell19/Anomaly_Results.json"

OUTPUT_DIR = V360_WORK + "/Vendor360_Cell23"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ------------------------------------------------------------
# 2. LOAD BASE
# ------------------------------------------------------------

if not os.path.exists(BASE_FILE):
    raise FileNotFoundError(
        f"Analysis base not found: {BASE_FILE}"
    )

base_df = pd.read_csv(BASE_FILE)

print("\n[1] DATASET")
print("-" * 70)

print(f"Rows                 : {len(base_df)}")
print(f"Columns              : {len(base_df.columns)}")

# ------------------------------------------------------------
# 3. COLUMN DETECTION
# ------------------------------------------------------------

def find_column(df, candidates):

    for candidate in candidates:
        if candidate in df.columns:
            return candidate

    lower_map = {
        str(c).lower(): c
        for c in df.columns
    }

    for candidate in candidates:

        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()]

    return None


def numeric_matching(df, patterns):

    result = []

    for col in df.columns:

        name = str(col).lower()

        if any(
            p.lower() in name
            for p in patterns
        ):

            if pd.api.types.is_numeric_dtype(
                df[col]
            ):
                result.append(col)

    return result


entity_id_col = find_column(
    base_df,
    [
        "entity_id",
        "supplier_id",
        "Supplier ID",
        "vendor_id",
        "Vendor ID"
    ]
)

entity_name_col = find_column(
    base_df,
    [
        "entity_name",
        "supplier_name",
        "Supplier Name",
        "vendor_name",
        "Vendor Name"
    ]
)

if entity_id_col is None:
    raise ValueError(
        "Supplier/entity ID could not be detected."
    )

print(f"Entity ID column     : {entity_id_col}")
print(f"Entity Name column   : {entity_name_col}")

# ------------------------------------------------------------
# 4. BUSINESS FEATURE DETECTION
# ------------------------------------------------------------

feature_map = {

    "cost": numeric_matching(
        base_df,
        [
            "cost__",
            "unit_price",
            "unit_cost",
            "price"
        ]
    ),

    "quality": numeric_matching(
        base_df,
        [
            "quality__",
            "quality_score",
            "quality_acceptance"
        ]
    ),

    "reliability": numeric_matching(
        base_df,
        [
            "reliability",
            "lead_time",
            "on_time",
            "delay"
        ]
    ),

    "risk": numeric_matching(
        base_df,
        [
            "risk__",
            "risk_score"
        ]
    ),

    "sustainability": numeric_matching(
        base_df,
        [
            "sustainability",
            "esg"
        ]
    ),

    "capacity": numeric_matching(
        base_df,
        [
            "capacity"
        ]
    )
}

print("\n[2] DETECTED BUSINESS FEATURES")
print("-" * 70)

for dimension, columns in feature_map.items():

    print(
        f"{dimension.capitalize():<18}: "
        f"{len(columns)} feature(s)"
    )

# ------------------------------------------------------------
# 5. SUPPLIER-LEVEL KPI GENERATION
# ------------------------------------------------------------

print("\n[3] SUPPLIER KPI GENERATION")
print("-" * 70)

supplier_records = []

for supplier_id, group in base_df.groupby(
    entity_id_col,
    dropna=False
):

    record = {
        "supplier_id": supplier_id,
        "supplier_record_count": len(group)
    }

    # Supplier name
    if entity_name_col:

        names = (
            group[entity_name_col]
            .dropna()
            .astype(str)
            .unique()
        )

        record["supplier_name"] = (
            names[0]
            if len(names) > 0
            else str(supplier_id)
        )

    else:

        record["supplier_name"] = str(
            supplier_id
        )

    # --------------------------------------------------------
    # Dimension aggregation
    # --------------------------------------------------------

    # D5: aggregate only semantically compatible source metrics.
    # Raw measures (e.g. ₹ unit cost) must not be averaged with derived
    # scores (e.g. inverse cost score). If multiple source columns have
    # the same business direction, they may be averaged; otherwise the
    # primary semantic measure is selected.
    for dimension in [
        "cost",
        "quality",
        "reliability",
        "risk",
        "sustainability",
        "capacity"
    ]:

        columns = feature_map[dimension]

        def _source_direction(col, dim):
            n = str(col).lower().replace("-", "_").replace(" ", "_")

            # Cost: raw price/cost is lower-is-better; score/rating is
            # normally higher-is-better.
            if dim == "cost":
                if any(x in n for x in ["score", "rating", "index"]):
                    return "higher"
                return "lower"

            # Reliability: lead/delay days are lower-is-better;
            # on-time/reliability scores are higher-is-better.
            if dim == "reliability":
                if any(x in n for x in ["lead_time", "leadtime", "delay_days",
                                         "delivery_days", "days"]):
                    return "lower"
                return "higher"

            # Risk: if a companion band exists and the numeric field is a
            # safety/health score, higher score means lower risk.
            if dim == "risk":
                if any(x in n for x in ["safety", "health"]):
                    return "higher"
                return "lower"

            if dim in ["quality", "sustainability", "capacity"]:
                return "higher"

            return "higher"

        direction_groups = {}
        for col in columns:
            direction_groups.setdefault(
                _source_direction(col, dimension), []
            ).append(col)

        selected_columns = columns

        # Prefer raw business measures over derived score/rating columns
        # when the dimension contains mixed directions.
        if len(direction_groups) > 1:
            preferred = [
                c for c in columns
                if not any(x in str(c).lower()
                           for x in ["score", "rating", "index"])
            ]
            if preferred:
                selected_columns = preferred
            else:
                selected_columns = direction_groups[
                    "higher" if dimension != "cost" else "lower"
                ]

        values = []
        for col in selected_columns:
            series = pd.to_numeric(group[col], errors="coerce")
            if series.notna().any():
                values.append(series.mean())

        record[f"{dimension}_kpi"] = (
            float(np.mean(values)) if values else np.nan
        )

    supplier_records.append(record)


supplier_kpi_df = pd.DataFrame(
    supplier_records
)

print(
    f"Suppliers generated   : "
    f"{len(supplier_kpi_df)}"
)

# ------------------------------------------------------------
# 6. CONTEXT INFORMATION
# ------------------------------------------------------------

context_candidates = [
    "context__category_l2",
    "context__category_l1",
    "context__country",
    "context__region",
    "category_l2",
    "category_l1",
    "country",
    "country_hq",
    "region"
]

available_context = [
    c for c in context_candidates
    if c in base_df.columns
]

for col in available_context:

    grouped = (
        base_df
        .groupby(entity_id_col)[col]
        .apply(
            lambda x: ", ".join(
                sorted(
                    x.dropna()
                    .astype(str)
                    .unique()
                )
            )
        )
        .reset_index()
    )

    grouped.columns = [
        "supplier_id",
        col.replace(
            "context__",
            ""
        ) + "_list"
    ]

    supplier_kpi_df = supplier_kpi_df.merge(
        grouped,
        on="supplier_id",
        how="left"
    )

# ------------------------------------------------------------
# 7. MCDA — CORRECT OVERALL SCORE
# ------------------------------------------------------------

print("\n[4] MCDA INTEGRATION")
print("-" * 70)

if not os.path.exists(MCDA_FILE):

    print("MCDA file not found.")

    supplier_kpi_df["mcda_score"] = np.nan
    supplier_kpi_df["mcda_rank"] = np.nan

else:

    mcda_df = pd.read_csv(
        MCDA_FILE
    )

    print(
        f"MCDA rows             : "
        f"{len(mcda_df)}"
    )

    print(
        f"MCDA columns          : "
        f"{len(mcda_df.columns)}"
    )

    mcda_id_col = find_column(
        mcda_df,
        [
            "entity_id",
            "supplier_id",
            "Supplier ID",
            "vendor_id"
        ]
    )

    # IMPORTANT:
    # Explicitly prefer the overall MCDA score.
    mcda_score_col = find_column(
        mcda_df,
        [
            "mcda__overall_score",
            "overall_score",
            "mcda_score"
        ]
    )

    mcda_rank_col = find_column(
        mcda_df,
        [
            "mcda__rank",
            "mcda_rank",
            "rank"
        ]
    )

    if (
        mcda_id_col is not None
        and mcda_score_col is not None
    ):

        mcda_merge = mcda_df[
            [mcda_id_col, mcda_score_col]
        ].copy()

        mcda_merge.columns = [
            "supplier_id",
            "mcda_score"
        ]

        mcda_merge["mcda_score"] = pd.to_numeric(
            mcda_merge["mcda_score"],
            errors="coerce"
        )

        # If multiple category-level rows exist,
        # calculate supplier-level mean.
        mcda_merge = (
            mcda_merge
            .groupby(
                "supplier_id",
                as_index=False
            )
            ["mcda_score"]
            .mean()
        )

        supplier_kpi_df = supplier_kpi_df.merge(
            mcda_merge,
            on="supplier_id",
            how="left"
        )

        print(
            f"Overall MCDA score   : "
            f"{mcda_score_col}"
        )

    else:

        supplier_kpi_df[
            "mcda_score"
        ] = np.nan

        print(
            "Overall MCDA score could not be detected."
        )

    # --------------------------------------------------------
    # MCDA RANK
    # --------------------------------------------------------

    if (
        mcda_id_col is not None
        and mcda_rank_col is not None
    ):

        rank_merge = mcda_df[
            [mcda_id_col, mcda_rank_col]
        ].copy()

        rank_merge.columns = [
            "supplier_id",
            "mcda_rank"
        ]

        rank_merge["mcda_rank"] = pd.to_numeric(
            rank_merge["mcda_rank"],
            errors="coerce"
        )

        rank_merge = (
            rank_merge
            .groupby(
                "supplier_id",
                as_index=False
            )
            ["mcda_rank"]
            .min()
        )

        supplier_kpi_df = supplier_kpi_df.merge(
            rank_merge,
            on="supplier_id",
            how="left"
        )

    else:

        supplier_kpi_df[
            "mcda_rank"
        ] = np.nan

# ------------------------------------------------------------
# 8. ANOMALY INFORMATION
# ------------------------------------------------------------

print("\n[5] ANOMALY INFORMATION")
print("-" * 70)

anomaly_available = os.path.exists(
    ANOMALY_FILE
)

if anomaly_available:

    with open(
        ANOMALY_FILE,
        "r"
    ) as f:

        anomaly_json = json.load(f)

    print(
        "✓ Overall anomaly results available."
    )

    print(
        "⚠ Supplier-level anomaly assignments "
        "are not present in the current outputs."
    )

else:

    anomaly_json = {}

    print(
        "– Anomaly results unavailable."
    )

supplier_kpi_df[
    "anomaly_flag"
] = "Not individually assigned"

# ------------------------------------------------------------
# 9. RISK REVIEW FLAG
# ------------------------------------------------------------

if (
    "risk_kpi" in supplier_kpi_df.columns
    and
    supplier_kpi_df["risk_kpi"].notna().any()
):

    risk_median = supplier_kpi_df[
        "risk_kpi"
    ].median()

    supplier_kpi_df[
        "risk_review_flag"
    ] = np.where(
        supplier_kpi_df["risk_kpi"]
        > risk_median,
        "Review",
        "Normal"
    )

else:

    supplier_kpi_df[
        "risk_review_flag"
    ] = "Not available"

# ------------------------------------------------------------
# 10. KPI COMPLETENESS
# ------------------------------------------------------------

kpi_columns = [
    "cost_kpi",
    "quality_kpi",
    "reliability_kpi",
    "risk_kpi",
    "sustainability_kpi"
]

available_kpis = [
    c for c in kpi_columns
    if c in supplier_kpi_df.columns
]

supplier_kpi_df[
    "kpi_completeness_pct"
] = (
    supplier_kpi_df[
        available_kpis
    ]
    .notna()
    .mean(axis=1)
    * 100
)

# ------------------------------------------------------------
# 11. REVIEW STATUS
# ------------------------------------------------------------

def determine_status(row):

    flags = []

    if row.get(
        "risk_review_flag"
    ) == "Review":

        flags.append("Risk")

    completeness = row.get(
        "kpi_completeness_pct",
        0
    )

    if (
        pd.notna(completeness)
        and completeness < 60
    ):

        flags.append(
            "Incomplete Data"
        )

    return (
        "Review"
        if flags
        else "Normal"
    )


supplier_kpi_df[
    "supplier_review_status"
] = supplier_kpi_df.apply(
    determine_status,
    axis=1
)

# ------------------------------------------------------------
# 12. NUMERIC CLEANING
# ------------------------------------------------------------

for col in [
    "cost_kpi",
    "quality_kpi",
    "reliability_kpi",
    "risk_kpi",
    "sustainability_kpi",
    "capacity_kpi",
    "mcda_score",
    "mcda_rank",
    "kpi_completeness_pct"
]:

    if col in supplier_kpi_df.columns:

        supplier_kpi_df[col] = pd.to_numeric(
            supplier_kpi_df[col],
            errors="coerce"
        )

# ------------------------------------------------------------
# 13. SORT BY TRUE MCDA SCORE
# ------------------------------------------------------------

if (
    "mcda_score" in supplier_kpi_df.columns
    and
    supplier_kpi_df[
        "mcda_score"
    ].notna().any()
):

    supplier_kpi_df = supplier_kpi_df.sort_values(
        "mcda_score",
        ascending=False,
        na_position="last"
    )

else:

    supplier_kpi_df = supplier_kpi_df.sort_values(
        "supplier_name"
    )

supplier_kpi_df = supplier_kpi_df.reset_index(
    drop=True
)

# ------------------------------------------------------------
# 14. DIMENSION SUMMARY
# ------------------------------------------------------------

dimension_summary = []

for dimension in [
    "cost",
    "quality",
    "reliability",
    "risk",
    "sustainability",
    "capacity"
]:

    columns = feature_map[dimension]

    dimension_summary.append({
        "dimension": dimension,
        "available": len(columns) > 0,
        "source_features": ", ".join(columns),
        "supplier_kpi_column":
            f"{dimension}_kpi"
    })

dimension_summary_df = pd.DataFrame(
    dimension_summary
)

# ------------------------------------------------------------
# 15. SAVE OUTPUTS
# ------------------------------------------------------------

KPI_FILE = (
    f"{OUTPUT_DIR}/"
    "Vendor360_Supplier_KPI_Comparison.csv"
)

# NEW: supplier-level MCDA rank, recomputed from the supplier-level score.
# 'mcda_rank' above is the mean of CATEGORY-level ranks and must not be shown as a supplier rank.
if "mcda_score" in supplier_kpi_df.columns:
    # Phase 2: ONE authoritative supplier-level rank. The Cell 19 category-level rank is kept
    # under an explicit name and 'mcda_rank' becomes an alias of the supplier-level rank.
    if "mcda_rank" in supplier_kpi_df.columns and "category_level_mcda_rank" not in supplier_kpi_df.columns:
        supplier_kpi_df["category_level_mcda_rank"] = supplier_kpi_df["mcda_rank"]
    supplier_kpi_df["supplier_mcda_rank"] = supplier_kpi_df["mcda_score"].rank(
        ascending=False, method="min")
    supplier_kpi_df["mcda_rank"] = supplier_kpi_df["supplier_mcda_rank"]
    # Assertion: a higher score never gets a worse rank.
    _chk = supplier_kpi_df[["mcda_score", "supplier_mcda_rank"]].dropna().sort_values("mcda_score", ascending=False)
    assert _chk["supplier_mcda_rank"].is_monotonic_increasing, "rank inconsistent with mcda_score"
    print("✓ supplier_mcda_rank consistent with mcda_score (checked on", len(_chk), "suppliers)")

supplier_kpi_df.to_csv(
    KPI_FILE,
    index=False
)

dimension_summary_df.to_csv(
    f"{OUTPUT_DIR}/"
    "Vendor360_KPI_Dimension_Summary.csv",
    index=False
)

# NEW: direction of every KPI, derived from its SOURCE columns (lead time is lower-is-better,
# so 'reliability_kpi' built from lead_time_days must not be read as higher-is-better).
import sys as _sys, os as _os
for _p in (_os.environ.get("VENDOR360_ENGINE_DIR"), _os.getcwd(), V360_WORK):
    if _p and _os.path.isdir(_os.path.join(_p, "vendor360_engine")) and _p not in _sys.path:
        _sys.path.insert(0, _p)
from vendor360_engine import mcda as _mcda_cfg

kpi_directions = {}
kpi_direction_notes = {}
for _dim, _cols in feature_map.items():
    _dirs = {c: _mcda_cfg.infer_column_direction(c, _dim) for c in _cols}
    _uniq = set(_dirs.values())
    if len(_uniq) == 1:
        kpi_directions[_dim.capitalize()] = _uniq.pop()
    elif _dirs:
        kpi_directions[_dim.capitalize()] = _mcda_cfg.DIMENSION_DEFAULT.get(_dim, "higher")
        kpi_direction_notes[_dim.capitalize()] = (
            "source columns disagree on direction: " + str(_dirs) + "; dimension default used")

config = {

    "entity_id_column": entity_id_col,

    "entity_name_column": entity_name_col,

    "supplier_count": int(
        len(supplier_kpi_df)
    ),

    "detected_features": feature_map,
    "kpi_directions": kpi_directions,
    "kpi_direction_notes": kpi_direction_notes,
    "mcda_rank_note": "mcda_rank is an alias of supplier_mcda_rank (supplier-level, from mcda_score, ties share the lowest rank); the original category-level rank is kept as category_level_mcda_rank",

    "kpi_columns": [
        c for c in supplier_kpi_df.columns
        if c.endswith("_kpi")
    ],

    "mcda": {
        "available": os.path.exists(MCDA_FILE),
        "score_column_used":
            "mcda__overall_score",
        "rank_column_used":
            "supplier_mcda_rank (recomputed from supplier-level mcda_score)",
        "category_level_rank_column":
            "mcda__rank (kept as category_level_mcda_rank)"
    },

    "anomaly": {
        "summary_available":
            anomaly_available,
        "supplier_level_available":
            False
    },

    "cluster": {
        "supplier_level_available":
            False
    }
}

with open(
    f"{OUTPUT_DIR}/Vendor360_KPI_Config.json",
    "w"
) as f:

    json.dump(
        config,
        f,
        indent=4,
        default=str
    )

# ------------------------------------------------------------
# 16. FINAL SUMMARY
# ------------------------------------------------------------

print("\n[6] KPI SUMMARY")
print("-" * 70)

print(
    f"Suppliers              : "
    f"{len(supplier_kpi_df)}"
)

print(
    f"KPI dimensions         : "
    f"{len(config['kpi_columns'])}"
)

print(
    "MCDA score used        : "
    "mcda__overall_score"
)

print(
    "MCDA rank integrated   : "
    "Yes"
)

print(
    "Supplier anomaly flag  : "
    "Not individually available"
)

print(
    "Supplier cluster       : "
    "Not individually available"
)

print("\nCorrected Preview:")

preview_columns = [
    "supplier_id",
    "supplier_name",
    "cost_kpi",
    "quality_kpi",
    "reliability_kpi",
    "risk_kpi",
    "sustainability_kpi",
    "mcda_score",
    "mcda_rank",
    "risk_review_flag",
    "supplier_review_status"
]

preview_columns = [
    c for c in preview_columns
    if c in supplier_kpi_df.columns
]

print(
    supplier_kpi_df[
        preview_columns
    ].head(10).to_string(
        index=False
    )
)

# ------------------------------------------------------------
# 17. STATUS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("CELL 23 OUTPUTS")
print("=" * 70)

print(
    f"✓ {KPI_FILE}"
)

print(
    f"✓ {OUTPUT_DIR}/"
    "Vendor360_KPI_Dimension_Summary.csv"
)

print(
    f"✓ {OUTPUT_DIR}/"
    "Vendor360_KPI_Config.json"
)

def _c23_rank_ok():
    _t = supplier_kpi_df[["mcda_score", "supplier_mcda_rank"]].dropna().sort_values("mcda_score", ascending=False)
    return len(_t) > 0 and bool(_t["supplier_mcda_rank"].is_monotonic_increasing)

def _c23_identity_ok():
    return {"supplier_id", "supplier_name"}.issubset(supplier_kpi_df.columns) and bool(supplier_kpi_df["supplier_id"].notna().all()) and bool(supplier_kpi_df["supplier_name"].notna().all())

print("\nCELL 23 VALIDATION")
v360_status("CELL 23", {
    "KPI file exists and has rows": lambda: v360_csv_rows(KPI_FILE) > 0,
    "KPI table in the file matches the in-memory table": lambda: v360_csv_rows(KPI_FILE) == len(supplier_kpi_df),
    "dimension summary has rows": lambda: v360_csv_rows(f"{OUTPUT_DIR}/Vendor360_KPI_Dimension_Summary.csv") > 0,
    "config JSON reloads": lambda: v360_json_ok(f"{OUTPUT_DIR}/Vendor360_KPI_Config.json"),
    "one row per supplier id": lambda: supplier_kpi_df["supplier_id"].is_unique,
    "supplier identity (id and name) resolves": _c23_identity_ok,
    "rank is consistent with score (higher score never ranks worse)": _c23_rank_ok,
})

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 48 =====

# ============================================================

import os
import json
import pandas as pd
import numpy as np

print("=" * 70)
print("VENDOR360 AI ANALYSIS CONTEXT BUILDER")
print("=" * 70)

# ------------------------------------------------------------
# 1. PATHS
# ------------------------------------------------------------

BASE_FILE = V360_WORK + "/Vendor360_Analysis_Base.csv"

KPI_FILE = (
    V360_WORK + "/Vendor360_Cell23/"
    "Vendor360_Supplier_KPI_Comparison.csv"
)

KPI_SUMMARY_FILE = (
    V360_WORK + "/Vendor360_Cell23/"
    "Vendor360_KPI_Dimension_Summary.csv"
)

MCDA_FILE = (
    V360_WORK + "/Vendor360_Cell19/"
    "MCDA_Results.csv"
)

CLUSTER_FILE = (
    V360_WORK + "/Vendor360_Cell19/"
    "Clustering_Benchmark.csv"
)

REGRESSION_FILE = (
    V360_WORK + "/Vendor360_Cell19/"
    "Regression_Benchmark.csv"
)

CLASSIFICATION_FILE = (
    V360_WORK + "/Vendor360_Cell19/"
    "Classification_Benchmark.csv"
)

ANOMALY_FILE = (
    V360_WORK + "/Vendor360_Cell19/"
    "Anomaly_Results.json"
)

PCA_FILE = (
    V360_WORK + "/Vendor360_Cell19/"
    "PCA_Results.json"
)

AUDIT_FILE = (
    V360_WORK + "/Vendor360_Cell22/"
    "Vendor360_Audit_Summary.json"
)

OUTPUT_DIR = V360_WORK + "/Vendor360_Cell24"

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

# ------------------------------------------------------------
# 2. HELPER FUNCTIONS
# ------------------------------------------------------------

def load_csv(path):

    if os.path.exists(path):

        try:
            return pd.read_csv(path)

        except Exception as e:

            print(
                f"⚠ Could not read {path}: {e}"
            )

    return None


def load_json(path):

    if os.path.exists(path):

        try:

            with open(
                path,
                "r"
            ) as f:

                return json.load(f)

        except Exception as e:

            print(
                f"⚠ Could not read {path}: {e}"
            )

    return None


def clean_value(value):

    if pd.isna(value):
        return None

    if isinstance(
        value,
        (np.integer,)
    ):
        return int(value)

    if isinstance(
        value,
        (np.floating,)
    ):
        return float(value)

    return value


def dataframe_records(
    df,
    max_rows=None
):

    if df is None:
        return []

    if max_rows is not None:

        df = df.head(
            max_rows
        )

    return json.loads(
        df.to_json(
            orient="records"
        )
    )

# ------------------------------------------------------------
# 3. LOAD CORE DATA
# ------------------------------------------------------------

base_df = load_csv(
    BASE_FILE
)

kpi_df = load_csv(
    KPI_FILE
)

kpi_summary_df = load_csv(
    KPI_SUMMARY_FILE
)

mcda_df = load_csv(
    MCDA_FILE
)

cluster_df = load_csv(
    CLUSTER_FILE
)

regression_df = load_csv(
    REGRESSION_FILE
)

classification_df = load_csv(
    CLASSIFICATION_FILE
)

anomaly_data = load_json(
    ANOMALY_FILE
)

pca_data = load_json(
    PCA_FILE
)

audit_data = load_json(
    AUDIT_FILE
)

if base_df is None:
    raise FileNotFoundError(
        "Vendor360 Analysis Base not found."
    )

if kpi_df is None:
    raise FileNotFoundError(
        "Vendor360 Supplier KPI output not found. "
        "Run Cell 23 first."
    )

print("\n[1] DATA LOADED")
print("-" * 70)

print(
    f"Analysis Base       : "
    f"{base_df.shape[0]} rows × "
    f"{base_df.shape[1]} columns"
)

print(
    f"Supplier KPI table  : "
    f"{kpi_df.shape[0]} suppliers × "
    f"{kpi_df.shape[1]} columns"
)

# ------------------------------------------------------------
# 4. DETECT ENTITY COLUMNS
# ------------------------------------------------------------

def detect_column(
    df,
    candidates
):

    for col in candidates:

        if col in df.columns:
            return col

    return None


entity_id = detect_column(
    base_df,
    [
        "entity_id",
        "supplier_id"
    ]
)

entity_name = detect_column(
    base_df,
    [
        "entity_name",
        "supplier_name"
    ]
)

supplier_id = detect_column(
    kpi_df,
    [
        "supplier_id",
        "entity_id"
    ]
)

supplier_name = detect_column(
    kpi_df,
    [
        "supplier_name",
        "entity_name"
    ]
)

# ------------------------------------------------------------
# 5. AVAILABLE DIMENSIONS
# ------------------------------------------------------------

dimension_map = {

    "Cost":
        "cost_kpi",

    "Quality":
        "quality_kpi",

    "Reliability":
        "reliability_kpi",

    "Risk":
        "risk_kpi",

    "Sustainability":
        "sustainability_kpi",

    "Capacity":
        "capacity_kpi"
}

available_dimensions = []

for dimension, column in (
    dimension_map.items()
):

    if (
        column in kpi_df.columns
        and
        kpi_df[column].notna().any()
    ):

        available_dimensions.append(
            dimension
        )

print("\n[2] AVAILABLE DIMENSIONS")
print("-" * 70)

for dimension in dimension_map:

    symbol = (
        "✓"
        if dimension
        in available_dimensions
        else "–"
    )

    print(
        f"{symbol} {dimension}"
    )

# ------------------------------------------------------------
# 6. DATASET SUMMARY
# ------------------------------------------------------------

dataset_context = {

    "rows":
        int(len(base_df)),

    "columns":
        int(len(base_df.columns)),

    "unique_suppliers":
        int(
            kpi_df[
                supplier_id
            ].nunique()
        )
        if supplier_id
        else None,

    "available_dimensions":
        available_dimensions,

    "analysis_base_columns":
        list(base_df.columns),

    "supplier_kpi_columns":
        list(kpi_df.columns)
}

# ------------------------------------------------------------
# 7. SUPPLIER KPI CONTEXT
# ------------------------------------------------------------

supplier_context_columns = [

    supplier_id,

    supplier_name,

    "cost_kpi",

    "quality_kpi",

    "reliability_kpi",

    "risk_kpi",

    "sustainability_kpi",

    "capacity_kpi",

    "mcda_score",

    "mcda_rank",

    "risk_review_flag",

    "supplier_review_status",

    "kpi_completeness_pct"
]

supplier_context_columns = [

    col
    for col in supplier_context_columns
    if col is not None
    and col in kpi_df.columns
]

supplier_context_df = (
    kpi_df[
        supplier_context_columns
    ].copy()
)

# Convert NaN → None safely
supplier_context_records = []

for record in (
    supplier_context_df.to_dict(
        orient="records"
    )
):

    cleaned = {
        key: clean_value(value)
        for key, value
        in record.items()
    }

    supplier_context_records.append(
        cleaned
    )

# ------------------------------------------------------------
# 8. KPI SUMMARY CONTEXT
# ------------------------------------------------------------

kpi_summary_context = (
    dataframe_records(
        kpi_summary_df
    )
)

# ------------------------------------------------------------
# 9. MCDA CONTEXT
# ------------------------------------------------------------

mcda_context = {

    "available": mcda_df is not None,

    "rows":
        int(len(mcda_df))
        if mcda_df is not None
        else 0,

    "columns":
        list(mcda_df.columns)
        if mcda_df is not None
        else [],

    # Keep a sample rather than blindly
    # sending an enormous table to the LLM.
    "sample":
        dataframe_records(
            mcda_df,
            max_rows=100
        )
}

# ------------------------------------------------------------
# 10. CLUSTERING CONTEXT
# ------------------------------------------------------------

clustering_context = {

    "available":
        cluster_df is not None,

    "rows":
        int(len(cluster_df))
        if cluster_df is not None
        else 0,

    "columns":
        list(cluster_df.columns)
        if cluster_df is not None
        else [],

    "benchmark":
        dataframe_records(
            cluster_df
        )
}

# ------------------------------------------------------------
# 11. PREDICTIVE MODEL CONTEXT
# ------------------------------------------------------------

regression_context = {

    "available":
        regression_df is not None,

    "results":
        dataframe_records(
            regression_df
        )
}

classification_context = {

    "available":
        classification_df is not None,

    "results":
        dataframe_records(
            classification_df
        )
}

# ------------------------------------------------------------
# 12. ANOMALY CONTEXT
# ------------------------------------------------------------

anomaly_context = {

    "available":
        anomaly_data is not None,

    "results":
        anomaly_data
}

# ------------------------------------------------------------
# 13. PCA CONTEXT
# ------------------------------------------------------------

pca_context = {

    "available":
        pca_data is not None,

    "results":
        pca_data
}

# ------------------------------------------------------------
# 14. QUALITY AUDIT CONTEXT
# ------------------------------------------------------------

audit_context = {

    "available":
        audit_data is not None,

    "results":
        audit_data
}

# ------------------------------------------------------------
# 15. IMPORTANT INTERPRETATION RULES
# ------------------------------------------------------------

interpretation_rules = {

    "purpose":
        "Vendor360 is a supplier decision-support "
        "framework, not an autonomous purchasing system.",

    "cost":
        "Lower cost is generally preferable, "
        "but cost should be interpreted alongside "
        "other business dimensions.",

    "quality":
        "Higher quality indicators are generally "
        "preferable.",

    "reliability":
        "Lower historical lead-time indicators "
        "are generally preferable when the metric "
        "represents delivery time.",

    "risk":
        "Lower risk indicators are generally "
        "preferable.",

    "sustainability":
        "Higher sustainability indicators are "
        "generally preferable.",

    "capacity":
        "Capacity is contextual and should be "
        "evaluated against the user's business "
        "requirement rather than automatically "
        "treated as good or bad.",

    "mcda":
        "MCDA is a decision-support method. "
        "Component scores and trade-offs should "
        "remain visible.",

    "anomaly":
        "Anomaly flags identify observations "
        "that may warrant investigation. They "
        "are not proof that a supplier is bad "
        "or risky.",

    "prediction":
        "Predictive results are analytical "
        "evidence and should not automatically "
        "be interpreted as causal relationships.",

    "missing_data":
        "If a dimension is unavailable or "
        "missing, the AI must not invent a value "
        "or claim that the dimension was assessed."
}

# ------------------------------------------------------------
# 16. AI ASSISTANT INSTRUCTIONS
# ------------------------------------------------------------

assistant_instructions = """

You are the Vendor360 AI Advisor.

Your role is to help a business user interpret
supplier analysis and make context-specific,
evidence-based supplier decisions.

You will receive:
1. The user's business requirements or question.
2. Vendor360 analytical results.
3. Supplier KPI information.
4. MCDA results.
5. Model results where available.
6. Data-quality and availability information.

You must reason ONLY from the supplied Vendor360
data and clearly identified user requirements.

The user may describe a business situation naturally,
for example:

"I am a small manufacturer. Cost is important,
but delivery reliability is critical."

"I run a hospital and quality and reliability
are more important than price."

"I need a supplier with strong sustainability
performance."

Interpret the user's priorities and compare them
against the available Vendor360 dimensions.

When appropriate, provide:

- relevant supplier candidates
- why they fit the stated requirements
- important trade-offs
- risks or limitations
- supporting Vendor360 metrics
- areas the user should investigate further

Do NOT simply use the overall MCDA score if the
user has supplied different priorities.

If the user's priorities differ from the default
MCDA weighting, explain that the result is based
on the user's stated priorities.

Do not invent suppliers, metrics, model results,
dimensions, or business facts.

If a required dimension is unavailable, explicitly
say that Vendor360 cannot assess that dimension
from the uploaded dataset.

Anomaly detection results identify observations
for review and are not proof of supplier failure.

Predictive models describe patterns in the available
data and should not automatically be described as
causal.

Recommendations are decision support, not automatic
purchasing decisions.

When there is no clear single option, present the
relevant alternatives and explain the trade-offs
instead of pretending that one option is universally
best.

Always distinguish:
- data-derived fact
- analytical interpretation
- recommendation based on the user's priorities.

"""

# ------------------------------------------------------------
# 17. COMPLETE AI CONTEXT
# ------------------------------------------------------------

ai_context = {

    "vendor360_version":
        "Adaptive Vendor360 BAM Prototype",

    "dataset":
        dataset_context,

    "available_dimensions":
        available_dimensions,

    "supplier_kpis":
        supplier_context_records,

    "kpi_summary":
        kpi_summary_context,

    "mcda":
        mcda_context,

    "clustering":
        clustering_context,

    "regression":
        regression_context,

    "classification":
        classification_context,

    "anomaly_detection":
        anomaly_context,

    "pca":
        pca_context,

    "quality_audit":
        audit_context,

    "interpretation_rules":
        interpretation_rules,

    "assistant_instructions":
        assistant_instructions
}

# ------------------------------------------------------------
# 18. SAVE COMPLETE CONTEXT
# ------------------------------------------------------------

CONTEXT_FILE = (
    f"{OUTPUT_DIR}/"
    "Vendor360_AI_Analysis_Context.json"
)

with open(
    CONTEXT_FILE,
    "w"
) as f:

    json.dump(
        ai_context,
        f,
        indent=4,
        default=str
    )

# ------------------------------------------------------------
# 19. SAVE SUPPLIER CONTEXT
# ------------------------------------------------------------

SUPPLIER_CONTEXT_FILE = (
    f"{OUTPUT_DIR}/"
    "Vendor360_AI_Supplier_Context.json"
)

with open(
    SUPPLIER_CONTEXT_FILE,
    "w"
) as f:

    json.dump(
        supplier_context_records,
        f,
        indent=4,
        default=str
    )

# ------------------------------------------------------------
# 20. SAVE DATASET CONTEXT
# ------------------------------------------------------------

DATASET_CONTEXT_FILE = (
    f"{OUTPUT_DIR}/"
    "Vendor360_AI_Dataset_Context.json"
)

with open(
    DATASET_CONTEXT_FILE,
    "w"
) as f:

    json.dump(
        dataset_context,
        f,
        indent=4,
        default=str
    )

# ------------------------------------------------------------
# 21. SAVE INSTRUCTIONS
# ------------------------------------------------------------

INSTRUCTIONS_FILE = (
    f"{OUTPUT_DIR}/"
    "Vendor360_AI_Assistant_Instructions.txt"
)

with open(
    INSTRUCTIONS_FILE,
    "w"
) as f:

    f.write(
        assistant_instructions.strip()
    )

# ------------------------------------------------------------
# 22. SUMMARY
# ------------------------------------------------------------

print("\n[3] AI CONTEXT")
print("-" * 70)

print(
    f"Supplier records     : "
    f"{len(supplier_context_records)}"
)

print(
    f"Available dimensions : "
    f"{len(available_dimensions)}"
)

print(
    f"MCDA available       : "
    f"{mcda_context['available']}"
)

print(
    f"Clustering available : "
    f"{clustering_context['available']}"
)

print(
    f"Regression available : "
    f"{regression_context['available']}"
)

print(
    f"Classification       : "
    f"{classification_context['available']}"
)

print(
    f"Anomaly results      : "
    f"{anomaly_context['available']}"
)

print(
    f"PCA results          : "
    f"{pca_context['available']}"
)

# ------------------------------------------------------------
# 23. OUTPUTS
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("CELL 24A OUTPUTS")
print("=" * 70)

print(
    f"✓ {CONTEXT_FILE}"
)

print(
    f"✓ {SUPPLIER_CONTEXT_FILE}"
)

print(
    f"✓ {DATASET_CONTEXT_FILE}"
)

print(
    f"✓ {INSTRUCTIONS_FILE}"
)

def _c24a_supplier_ctx_ok():
    import json as _j
    with open(SUPPLIER_CONTEXT_FILE, encoding="utf-8") as _fh:
        _d = _j.load(_fh)
    _n = len(_d) if isinstance(_d, (list, dict)) and not (isinstance(_d, dict) and "suppliers" in _d) else len(_d["suppliers"])
    return _n == len(supplier_kpi_df)

print("\nCELL 24A VALIDATION")
v360_status("CELL 24A", {
    "analysis context JSON exists and reloads": lambda: v360_json_ok(CONTEXT_FILE),
    "supplier context JSON exists and reloads": lambda: v360_json_ok(SUPPLIER_CONTEXT_FILE),
    "dataset context JSON exists and reloads": lambda: v360_json_ok(DATASET_CONTEXT_FILE),
    "assistant instructions file is non-empty": lambda: v360_file_ok(INSTRUCTIONS_FILE),
    "supplier context covers every supplier in the KPI table": _c24a_supplier_ctx_ok,
})

# ============================================================
