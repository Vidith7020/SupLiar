# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 34 =====

#           STANDARDIZATION ENGINE
# ============================================================
#
# PURPOSE
# -------
# Convert either:
#
#   A) MULTIPLE related datasets
#      -> detect relationships
#      -> identify master/base table
#      -> identify analysis grain
#      -> aggregate child tables
#      -> safely combine them
#      -> standardize
#
#   B) ONE dataset
#      -> detect entity/grain
#      -> standardize directly
#
# BOTH paths produce:
#
#   Vendor360_Analysis_Base.csv
#
# Later cells MUST use this standardized file.
#
# OUTPUTS
# -------
# /content/Vendor360_Analysis_Base.csv
# /content/Vendor360_Data_Dictionary.csv
# /content/Vendor360_Metadata.json
# ============================================================

import os
import re
import json
import warnings
from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ============================================================
# 1. CONFIGURATION
# ============================================================

OUTPUT_BASE = V360_WORK + "/Vendor360_Analysis_Base.csv"
OUTPUT_DICT = V360_WORK + "/Vendor360_Data_Dictionary.csv"
OUTPUT_META = V360_WORK + "/Vendor360_Metadata.json"

EXCLUDED_FILES = {
    "Vendor360_Analysis_Base.csv",
    "Vendor360_Data_Dictionary.csv",
    "Vendor360_Metadata.json"
}


# ============================================================
# 2. NORMALIZATION HELPERS
# ============================================================

def normalize_name(value):

    value = str(value).strip().lower()

    value = re.sub(
        r"[^a-z0-9]+",
        "_",
        value
    )

    value = re.sub(
        r"_+",
        "_",
        value
    )

    return value.strip("_")


def clean_columns(df):

    new_columns = []
    seen = {}

    for col in df.columns:

        col = str(col).strip()

        if col not in seen:

            seen[col] = 0
            new_columns.append(col)

        else:

            seen[col] += 1

            new_columns.append(
                f"{col}_{seen[col]}"
            )

    df = df.copy()
    df.columns = new_columns

    return df


# ============================================================
# 3. DISCOVER INPUT FILES
# ============================================================

def discover_files():

    files = []

    for ext in [".csv", ".xlsx", ".xls"]:

        files.extend(
            Path(V360_INPUT).glob(
                f"*{ext}"
            )
        )

    files = [
        f for f in files
        if f.name not in EXCLUDED_FILES
        and not f.name.startswith("Vendor360_")  # never re-ingest generated files
    ]

    return sorted(files)


def load_dataset(path):

    if path.suffix.lower() == ".csv":

        return pd.read_csv(
            path,
            low_memory=False
        )

    elif path.suffix.lower() in [
        ".xlsx",
        ".xls"
    ]:

        return pd.read_excel(path)

    raise ValueError(
        f"Unsupported file: {path.name}"
    )


input_files = discover_files()

if not input_files:

    raise FileNotFoundError(
        f"No CSV/XLS/XLSX datasets found in {V360_INPUT}."
    )


datasets = {}

for path in input_files:

    try:

        df = load_dataset(path)

        df = clean_columns(df)

        datasets[path.name] = df

    except Exception as e:

        print(
            f"⚠ Could not load "
            f"{path.name}: {e}"
        )


if not datasets:

    raise ValueError(
        "No usable datasets were loaded."
    )

# Phase 2: same preparation as foundation.py (INR conversion, capacity placeholder, price normalisation)
if "vendor360_prepare" in globals():
    datasets = vendor360_prepare(datasets)


# ============================================================
# 4. SEMANTIC VOCABULARY
# ============================================================

ENTITY_ID_TERMS = [
    "supplier_id",
    "supplier_code",
    "supplier_key",
    "supplierid",
    "vendor_id",
    "vendor_code",
    "vendor_key",
    "vendorid",
    "seller_id",
    "provider_id",
    "company_id",
    "partner_id",
    "manufacturer_id"
]

ENTITY_NAME_TERMS = [
    "supplier_name",
    "vendor_name",
    "seller_name",
    "provider_name",
    "company_name",
    "partner_name",
    "manufacturer_name",
    "supplier",
    "vendor",
    "seller",
    "provider",
    "company"
]

CONTEXT_TERMS = [
    "category_l1",
    "category_l2",
    "category_l3",
    "category",
    "subcategory",
    "sub_category",
    "product_category",
    "region",
    "country",
    "country_hq",
    "market",
    "business_unit",
    "segment",
    "industry",
    "product_type",
    "service_type"
]

COST_TERMS = [
    "unit_price",
    "unit_cost",
    "purchase_price",
    "quoted_price",
    "price",
    "cost",
    "spend",
    "total_cost",
    "total_value",
    "expense"
]

QUALITY_TERMS = [
    "quality_score",
    "quality_rating",
    "quality_index",
    "defect_rate",
    "defect_pct",
    "rejection_rate",
    "quality"
]

RISK_TERMS = [
    "risk_score",
    "risk_rating",
    "risk_index",
    "risk_level",
    "risk"
]

SUSTAINABILITY_TERMS = [
    "esg_score",
    "esg_rating",
    "sustainability_score",
    "sustainability_rating",
    "sustainability_index",
    "environmental_score",
    "social_score",
    "governance_score",
    "carbon_score",
    "esg"
]

RELIABILITY_TERMS = [
    "lead_time",
    "leadtime",
    "delivery_time",
    "delivery_days",
    "delivery_delay",
    "on_time",
    "on_time_delivery",
    "otd",
    "fulfillment_rate",
    "service_level"
]

CAPACITY_TERMS = [
    "capacity_per_month",
    "monthly_capacity",
    "production_capacity",
    "capacity",
    "max_quantity",
    "maximum_quantity"
]

STATUS_TERMS = [
    "contract_status",
    "status",
    "active",
    "approved",
    "preferred_supplier",
    "preferred",
    "is_restricted",
    "restricted"
]

OUTCOME_TERMS = [
    "award_count",
    "historical_awards",
    "award_rank",
    "awarded",
    "savings_pct",
    "savings",
    "decision"
]

TRANSACTION_ID_TERMS = [
    "award_id",
    "request_id",
    "transaction_id",
    "order_id",
    "po_id",
    "invoice_id",
    "quotation_id",
    "quote_id",
    "event_id"
]

DATE_TERMS = [
    "date",
    "created_at",
    "updated_at",
    "valid_from",
    "valid_to",
    "award_date",
    "required_by_date"
]


# ============================================================
# 5. SEMANTIC SCORING
# ============================================================

def semantic_score(
    column,
    terms
):

    ncol = normalize_name(column)

    best = 0

    for term in terms:

        term = normalize_name(term)

        # Exact semantic match
        if ncol == term:

            best = max(
                best,
                100
            )

        # Prefix match
        elif ncol.startswith(
            term + "_"
        ):

            best = max(
                best,
                80
            )

        # Token-level match
        elif term in ncol.split("_"):

            best = max(
                best,
                60
            )

    return best


# ============================================================
# 6. ENTITY DETECTION
# ============================================================

def detect_entity_id(df):

    candidates = []

    for col in df.columns:

        ncol = normalize_name(col)

        score = 0

        for term in ENTITY_ID_TERMS:

            term = normalize_name(term)

            if ncol == term:

                score = max(
                    score,
                    100
                )

            elif ncol.startswith(
                term + "_"
            ):

                score = max(
                    score,
                    85
                )

        # Generic ID fallback
        if score == 0:

            if (
                ncol.endswith("_id")
                or ncol.endswith("_code")
                or ncol.endswith("_key")
            ):

                score = 30

        # Never treat notes/descriptions as IDs
        if any(
            x in ncol
            for x in [
                "note",
                "description",
                "comment",
                "reason"
            ]
        ):

            score = 0

        if score > 0:

            nunique = df[
                col
            ].nunique(
                dropna=True
            )

            candidates.append(
                (
                    score,
                    col,
                    nunique
                )
            )

    if not candidates:

        return None

    candidates.sort(
        key=lambda x: (
            x[0],
            x[2]
        ),
        reverse=True
    )

    return candidates[0][1]


def detect_entity_name(df):

    candidates = []

    for col in df.columns:

        ncol = normalize_name(col)

        # NEVER allow IDs/codes to become names
        if (
            ncol.endswith("_id")
            or ncol.endswith("_code")
            or ncol.endswith("_key")
            or ncol in [
                "id",
                "code"
            ]
        ):

            continue

        score = 0

        if ncol in [
            "supplier_name",
            "vendor_name",
            "seller_name",
            "provider_name",
            "company_name",
            "partner_name",
            "manufacturer_name"
        ]:

            score = 100

        elif ncol in [
            "supplier",
            "vendor",
            "seller",
            "provider",
            "company"
        ]:

            score = 80

        if score > 0:

            candidates.append(
                (
                    score,
                    col
                )
            )

    if not candidates:

        return None

    candidates.sort(
        key=lambda x: x[0],
        reverse=True
    )

    return candidates[0][1]


# ============================================================
# 7. CONTEXT DETECTION
# ============================================================

def detect_context_columns(df):

    candidates = []

    for col in df.columns:

        score = semantic_score(
            col,
            CONTEXT_TERMS
        )

        if score < 60:
            continue

        nunique = df[
            col
        ].nunique(
            dropna=True
        )

        # Context columns should normally repeat
        if len(df) > 0:

            ratio = (
                nunique / len(df)
            )

            if ratio < 0.95:

                score += 15

        candidates.append(
            (
                score,
                col,
                nunique
            )
        )

    candidates.sort(
        key=lambda x: (
            x[0],
            -x[2]
        ),
        reverse=True
    )

    return [
        x[1]
        for x in candidates[:8]
    ]


# ============================================================
# 8. TRANSACTION / DATE DETECTION
# ============================================================

def detect_transaction_ids(df):

    return [
        col
        for col in df.columns
        if semantic_score(
            col,
            TRANSACTION_ID_TERMS
        ) >= 60
    ]


def detect_dates(df):

    return [
        col
        for col in df.columns
        if semantic_score(
            col,
            DATE_TERMS
        ) >= 60
    ]


# ============================================================
# 9. TABLE INSPECTION
# ============================================================

def inspect_table(
    name,
    df
):

    entity_id = detect_entity_id(df)

    entity_name = detect_entity_name(df)

    contexts = detect_context_columns(df)

    transaction_ids = detect_transaction_ids(df)

    dates = detect_dates(df)

    entity_cardinality = None

    if entity_id:

        entity_cardinality = df[
            entity_id
        ].nunique(
            dropna=True
        )

    return {

        "file": name,

        "rows": len(df),

        "columns": len(df.columns),

        "entity_id": entity_id,

        "entity_name": entity_name,

        "contexts": contexts,

        "transaction_ids":
            transaction_ids,

        "date_columns":
            dates,

        "entity_cardinality":
            entity_cardinality
    }


table_info = {

    name:
    inspect_table(
        name,
        df
    )

    for name, df
    in datasets.items()
}


# ============================================================
# 10. SOURCE MODE
# ============================================================

source_mode = (
    "SINGLE"
    if len(datasets) == 1
    else "MULTIPLE"
)


print("=" * 70)
print(
    "VENDOR360 UNIVERSAL "
    "DATA COMBINATION + STANDARDIZATION"
)
print("=" * 70)

print(
    f"\nSource mode: {source_mode}"
)

print(
    f"Datasets detected: "
    f"{len(datasets)}"
)


for info in table_info.values():

    print(
        f"\n{info['file']}"
    )

    print(
        f"  Rows: "
        f"{info['rows']}"
    )

    print(
        f"  Columns: "
        f"{info['columns']}"
    )

    print(
        f"  Entity ID: "
        f"{info['entity_id']}"
    )

    print(
        f"  Entity Name: "
        f"{info['entity_name']}"
    )

    print(
        f"  Context: "
        f"{info['contexts']}"
    )


# ============================================================
# 11. GLOBAL ENTITY DETECTION
# ============================================================

entity_candidates = []

for name, info in table_info.items():

    if info["entity_id"]:

        entity_candidates.append(
            (
                info["entity_id"],
                name,
                info[
                    "entity_cardinality"
                ]
            )
        )


if not entity_candidates:

    raise ValueError(
        "No reliable entity identifier "
        "could be detected."
    )


frequency = Counter(
    item[0]
    for item in entity_candidates
)


entity_id = sorted(
    frequency.keys(),
    key=lambda x: (
        frequency[x],
        max(
            item[2] or 0
            for item
            in entity_candidates
            if item[0] == x
        )
    ),
    reverse=True
)[0]


entity_name = None

for name, info in table_info.items():

    if (
        info["entity_id"]
        == entity_id
    ):

        if info["entity_name"]:

            entity_name = (
                info["entity_name"]
            )

            break


print("\n" + "-" * 70)
print("GLOBAL ENTITY")
print("-" * 70)

print(
    f"Entity ID: {entity_id}"
)

print(
    f"Entity Name: {entity_name}"
)


# ============================================================
# 12. MASTER TABLE DETECTION
# ============================================================

master_candidates = []

for name, df in datasets.items():

    info = table_info[name]

    if (
        info["entity_id"]
        != entity_id
    ):

        continue

    entity_count = (
        df[
            entity_id
        ]
        .nunique(
            dropna=True
        )
    )

    if entity_count == 0:
        continue

    rows_per_entity = (
        len(df)
        / entity_count
    )

    score = 0

    # Close to one row/entity
    if rows_per_entity <= 1.2:

        score += 60

    elif rows_per_entity <= 2:

        score += 40

    elif rows_per_entity <= 5:

        score += 15

    # Has entity name
    if info["entity_name"]:

        score += 20

    # Has context
    if info["contexts"]:

        score += 10

    # Transaction tables are less likely
    # to be master tables
    if not info["transaction_ids"]:

        score += 10

    master_candidates.append(
        (
            score,
            name,
            rows_per_entity
        )
    )


if not master_candidates:

    raise ValueError(
        "Could not identify a suitable "
        "master/base table."
    )


master_candidates.sort(
    key=lambda x: (
        x[0],
        -x[2]
    ),
    reverse=True
)

master_table_name = (
    master_candidates[0][1]
)

master_df = datasets[
    master_table_name
].copy()

master_info = table_info[
    master_table_name
]


# ============================================================
# 13. DETERMINE ANALYSIS GRAIN
# ============================================================

master_contexts = [
    c
    for c
    in master_info["contexts"]
    if c in master_df.columns
]


grain_columns = [
    entity_id
]


def duplicate_rows(
    df,
    columns
):

    return int(
        df.duplicated(
            subset=columns
        ).sum()
    )


current_duplicates = duplicate_rows(
    master_df,
    grain_columns
)


# Add contexts only when they
# actually reduce duplicate entity rows.

remaining_contexts = (
    master_contexts.copy()
)


while (
    current_duplicates > 0
    and remaining_contexts
):

    candidates = []

    for context in remaining_contexts:

        test_columns = (
            grain_columns
            + [context]
        )

        duplicates = duplicate_rows(
            master_df,
            test_columns
        )

        improvement = (
            current_duplicates
            - duplicates
        )

        candidates.append(
            (
                improvement,
                context,
                duplicates
            )
        )

    candidates.sort(
        key=lambda x: x[0],
        reverse=True
    )

    best = candidates[0]

    improvement = best[0]

    context = best[1]

    new_duplicates = best[2]

    if improvement <= 0:

        break

    grain_columns.append(
        context
    )

    current_duplicates = (
        new_duplicates
    )

    remaining_contexts.remove(
        context
    )


print("\n" + "-" * 70)
print("BASE TABLE / ANALYSIS GRAIN")
print("-" * 70)

print(
    f"Master table: "
    f"{master_table_name}"
)

print(
    f"Base grain: "
    f"{' + '.join(grain_columns)}"
)

print(
    f"Duplicate rows at grain: "
    f"{current_duplicates}"
)


# ============================================================
# 14. VALIDATE RELATIONSHIPS
# ============================================================

def find_relationship(
    child_df
):

    master_norm = {
        normalize_name(c): c
        for c in master_df.columns
    }

    child_norm = {
        normalize_name(c): c
        for c in child_df.columns
    }

    # --------------------------------------------------------
    # A. Full grain relationship
    # --------------------------------------------------------

    master_keys = []
    child_keys = []

    for grain_col in grain_columns:

        n = normalize_name(
            grain_col
        )

        if (
            n in master_norm
            and n in child_norm
        ):

            master_keys.append(
                master_norm[n]
            )

            child_keys.append(
                child_norm[n]
            )

    if len(master_keys) == len(
        grain_columns
    ):

        return {
            "keys": master_keys,
            "child_keys": child_keys,
            "confidence": "HIGH"
        }


    # --------------------------------------------------------
    # B. Entity-only relationship
    # --------------------------------------------------------

    entity_norm = normalize_name(
        entity_id
    )

    if (
        entity_norm in master_norm
        and entity_norm in child_norm
    ):

        return {
            "keys": [
                master_norm[
                    entity_norm
                ]
            ],
            "child_keys": [
                child_norm[
                    entity_norm
                ]
            ],
            "confidence": "MEDIUM"
        }


    return None


relationships = []

for name, child_df in datasets.items():

    if name == master_table_name:
        continue

    relation = find_relationship(
        child_df
    )

    if relation:

        relationships.append(
            {
                "child_table": name,
                "master_table":
                    master_table_name,
                "master_keys":
                    relation["keys"],
                "child_keys":
                    relation["child_keys"],
                "confidence":
                    relation["confidence"]
            }
        )


print("\n" + "-" * 70)
print("VALIDATED RELATIONSHIPS")
print("-" * 70)

if relationships:

    for rel in relationships:

        print(
            f"{rel['child_table']}"
            f" → "
            f"{rel['master_table']}"
            f"\n  Keys: "
            f"{rel['master_keys']}"
            f"\n  Confidence: "
            f"{rel['confidence']}"
        )

else:

    print(
        "No validated child-table "
        "relationships found."
    )


# ============================================================
# 15. DIMENSION CLASSIFICATION
# ============================================================

DIMENSIONS = {

    "cost":
        COST_TERMS,

    "quality":
        QUALITY_TERMS,

    "reliability":
        RELIABILITY_TERMS,

    "risk":
        RISK_TERMS,

    "sustainability":
        SUSTAINABILITY_TERMS,

    "capacity":
        CAPACITY_TERMS,

    "status":
        STATUS_TERMS,

    "outcome":
        OUTCOME_TERMS
}


DIMENSION_PRIORITY = [
    "quality",
    "risk",
    "sustainability",
    "reliability",
    "cost",
    "capacity",
    "status",
    "outcome"
]


def classify_dimension(
    column
):

    scores = {}

    for dimension in DIMENSION_PRIORITY:

        score = semantic_score(
            column,
            DIMENSIONS[
                dimension
            ]
        )

        if score > 0:

            scores[
                dimension
            ] = score

    if not scores:

        return None, 0

    # Highest semantic specificity wins
    best = max(
        scores,
        key=lambda x: (
            scores[x],
            -DIMENSION_PRIORITY.index(
                x
            )
        )
    )

    return (
        best,
        scores[best]
    )


# ============================================================
# 16. SAFE AGGREGATION
# ============================================================

def mode_safe(series):

    values = series.dropna()

    if values.empty:

        return np.nan

    modes = values.mode()

    if len(modes) > 0:

        return modes.iloc[0]

    return values.iloc[0]


def choose_aggregation(
    column,
    dimension,
    df
):

    ncol = normalize_name(
        column
    )

    is_numeric = (
        pd.api.types
        .is_numeric_dtype(
            df[column]
        )
    )

    is_datetime = (
        pd.api.types
        .is_datetime64_any_dtype(
            df[column]
        )
    )

    # Never average dates
    if is_datetime:

        return None


    # --------------------------------------------------------
    # TEXT FIELDS
    # --------------------------------------------------------

    if not is_numeric:

        excluded_text = [
            "note",
            "notes",
            "description",
            "rationale",
            "reason",
            "comment",
            "comments",
            "remarks"
        ]

        if any(
            token in ncol
            for token in excluded_text
        ):

            return None

        # Only stable low-cardinality
        # categorical fields
        if (
            df[column]
            .nunique(
                dropna=True
            )
            <= 20
        ):

            return mode_safe

        return None


    # --------------------------------------------------------
    # NUMERIC FIELDS
    # --------------------------------------------------------

    # Count variables
    if (
        "count" in ncol
        or "number" in ncol
        or "num_" in ncol
    ):

        return "sum"


    # Binary awarded indicator
    if (
        dimension == "outcome"
        and "awarded" in ncol
    ):

        return "sum"


    # Capacity
    if dimension == "capacity":

        return "max"


    # Scores / rates / reliability
    if dimension in [
        "quality",
        "risk",
        "sustainability",
        "reliability"
    ]:

        return "mean"


    # Cost
    if dimension == "cost":

        return "mean"


    # Historical outcomes
    if dimension == "outcome":

        return "mean"


    # Numeric fallback
    return "mean"


def aggregate_child_table(
    child_df,
    child_name,
    child_keys
):

    # --------------------------------------------------------
    # Ensure keys are present
    # --------------------------------------------------------

    child_keys = [
        key
        for key in child_keys
        if key in child_df.columns
    ]

    if not child_keys:

        return None, []


    aggregations = {}

    skipped = []


    for column in child_df.columns:

        if column in child_keys:

            continue


        # Transaction IDs
        if (
            semantic_score(
                column,
                TRANSACTION_ID_TERMS
            )
            >= 60
        ):

            skipped.append(
                column
            )

            continue


        # Dates
        if (
            semantic_score(
                column,
                DATE_TERMS
            )
            >= 60
        ):

            skipped.append(
                column
            )

            continue


        dimension, score = (
            classify_dimension(
                column
            )
        )


        # Strong semantic feature
        if (
            dimension
            and score >= 60
        ):

            aggregation = (
                choose_aggregation(
                    column,
                    dimension,
                    child_df
                )
            )

            if aggregation:

                aggregations[
                    column
                ] = aggregation

            else:

                skipped.append(
                    column
                )

            continue


        # Low-cardinality categorical
        if (
            child_df[column]
            .dtype == "object"
            and
            child_df[column]
            .nunique(
                dropna=True
            )
            <= 20
        ):

            aggregations[
                column
            ] = mode_safe

        else:

            # Do not blindly aggregate unknown fields
            skipped.append(
                column
            )


    # --------------------------------------------------------
    # Always create a record count
    # --------------------------------------------------------

    source_prefix = normalize_name(
        Path(
            child_name
        ).stem
    )

    count_column = (
        f"{source_prefix}"
        "__record_count"
    )


    grouped = (
        child_df
        .groupby(
            child_keys,
            dropna=False
        )
        .size()
        .reset_index(
            name=count_column
        )
    )


    # --------------------------------------------------------
    # Aggregate valid fields
    # --------------------------------------------------------

    if aggregations:

        aggregated = (
            child_df
            .groupby(
                child_keys,
                dropna=False
            )
            .agg(
                aggregations
            )
            .reset_index()
        )


        # Rename non-key columns
        rename_map = {}

        for column in aggregated.columns:

            if column in child_keys:
                continue

            rename_map[
                column
            ] = (
                f"{source_prefix}"
                f"__"
                f"{normalize_name(column)}"
            )

        aggregated = (
            aggregated
            .rename(
                columns=rename_map
            )
        )


        # Add record count
        grouped = grouped.merge(
            aggregated,
            on=child_keys,
            how="left"
        )


    return (
        grouped,
        list(
            grouped.columns
        )
    )


# ============================================================
# 17. BUILD COMBINED ANALYSIS DATASET
# ============================================================
#
# THIS IS THE CORE STEP.
#
# Multiple datasets are actually combined here.
# ============================================================

combined = master_df.copy()

source_audit = {}


source_audit[
    master_table_name
] = {

    "role": "MASTER",

    "input_rows":
        len(master_df),

    "fields_added":
        len(master_df.columns),

    "used": True
}


# ------------------------------------------------------------
# MULTIPLE DATASETS
# ------------------------------------------------------------

for relation in relationships:

    child_name = (
        relation[
            "child_table"
        ]
    )

    child_df = datasets[
        child_name
    ]

    child_keys = (
        relation[
            "child_keys"
        ]
    )

    master_keys = (
        relation[
            "master_keys"
        ]
    )


    # --------------------------------------------------------
    # CRITICAL:
    # If master grain is supplier + category but the child
    # only has supplier_id, aggregate at supplier level.
    #
    # If child contains the full grain, use full grain.
    # --------------------------------------------------------

    aggregated, added_columns = (
        aggregate_child_table(
            child_df,
            child_name,
            child_keys
        )
    )


    if aggregated is None:

        source_audit[
            child_name
        ] = {

            "role":
                "CHILD_SKIPPED",

            "input_rows":
                len(child_df),

            "fields_added":
                0,

            "used":
                False
        }

        continue


    # Rename child keys to master key names
    rename_keys = {}

    for child_key, master_key in zip(
        child_keys,
        master_keys
    ):

        if child_key != master_key:

            rename_keys[
                child_key
            ] = master_key


    aggregated = (
        aggregated
        .rename(
            columns=rename_keys
        )
    )


    # --------------------------------------------------------
    # Validate uniqueness before merge
    # --------------------------------------------------------

    merge_keys = master_keys

    duplicate_child_keys = (
        aggregated
        .duplicated(
            subset=merge_keys
        )
        .sum()
    )


    if duplicate_child_keys > 0:

        raise ValueError(
            f"Unsafe merge detected for "
            f"{child_name}: "
            f"aggregated child table still "
            f"contains duplicate merge keys."
        )


    # --------------------------------------------------------
    # Protect master columns
    # --------------------------------------------------------

    overlapping = (
        set(combined.columns)
        .intersection(
            aggregated.columns
        )
    )

    overlapping -= set(
        merge_keys
    )


    if overlapping:

        aggregated = (
            aggregated
            .drop(
                columns=list(
                    overlapping
                )
            )
        )


    before_columns = set(
        combined.columns
    )


    combined = combined.merge(
        aggregated,
        on=merge_keys,
        how="left"
    )


    new_columns = [
        column
        for column
        in combined.columns
        if column
        not in before_columns
    ]


    source_audit[
        child_name
    ] = {

        "role":
            "CHILD_AGGREGATED_AND_COMBINED",

        "input_rows":
            len(child_df),

        "fields_added":
            len(new_columns),

        "used":
            len(new_columns) > 0
    }


# ============================================================
# 18. REFERENCE TABLES
# ============================================================
#
# Reference tables are enriched only when a unique
# reference key exists.
# ============================================================

reference_audit = {}


for name, df in datasets.items():

    if name == master_table_name:
        continue

    # Already combined as child
    if any(
        r["child_table"] == name
        for r in relationships
    ):
        continue


    possible_keys = []

    for context in master_contexts:

        if (
            context in combined.columns
            and context in df.columns
        ):

            # Reference key must be unique
            if (
                df[context]
                .nunique(
                    dropna=True
                )
                == len(
                    df[context]
                    .dropna()
                )
            ):

                possible_keys.append(
                    context
                )


    if not possible_keys:

        reference_audit[
            name
        ] = {
            "used": False,
            "reason":
                "No safe unique reference key"
        }

        continue


    key = possible_keys[0]

    ref = (
        df
        .drop_duplicates(
            subset=[key]
        )
        .copy()
    )


    keep = [key]

    for column in ref.columns:

        if column == key:
            continue

        if (
            semantic_score(
                column,
                TRANSACTION_ID_TERMS
            )
            >= 60
        ):

            continue

        # Keep descriptive/reference fields
        if (
            ref[column]
            .dtype == "object"
            or
            pd.api.types
            .is_numeric_dtype(
                ref[column]
            )
        ):

            keep.append(
                column
            )


    ref = ref[keep]


    prefix = normalize_name(
        Path(name).stem
    )


    rename_map = {}

    for column in ref.columns:

        if column != key:

            rename_map[
                column
            ] = (
                f"{prefix}"
                f"__"
                f"{normalize_name(column)}"
            )


    ref = ref.rename(
        columns=rename_map
    )


    overlap = (
        set(combined.columns)
        .intersection(
            ref.columns
        )
    )

    overlap -= {key}


    if overlap:

        ref = ref.drop(
            columns=list(overlap)
        )


    before = set(
        combined.columns
    )


    combined = combined.merge(
        ref,
        on=key,
        how="left"
    )


    new_columns = [
        c
        for c in combined.columns
        if c not in before
    ]


    reference_audit[
        name
    ] = {

        "used": len(new_columns) > 0,

        "key": key,

        "fields_added":
            len(new_columns)
    }


# ============================================================
# 19. STANDARDIZATION
# ============================================================

standard = pd.DataFrame(
    index=combined.index
)


# ------------------------------------------------------------
# Identity
# ------------------------------------------------------------

standard[
    "entity_id"
] = combined[
    entity_id
]


if (
    entity_name
    and entity_name in combined.columns
):

    standard[
        "entity_name"
    ] = combined[
        entity_name
    ]

else:

    standard[
        "entity_name"
    ] = (
        standard[
            "entity_id"
        ]
        .astype(str)
    )


used_columns = {
    entity_id
}

if entity_name:

    used_columns.add(
        entity_name
    )


# ------------------------------------------------------------
# Context
# ------------------------------------------------------------

for context in grain_columns[1:]:

    if context in combined.columns:

        output_column = (
            "context__"
            + normalize_name(
                context
            )
        )

        standard[
            output_column
        ] = combined[
            context
        ]

        used_columns.add(
            context
        )


# ------------------------------------------------------------
# Semantic business dimensions
# ------------------------------------------------------------

dimension_features = {

    dimension: []

    for dimension
    in DIMENSIONS
}


for column in combined.columns:

    if column in used_columns:
        continue


    dimension, score = (
        classify_dimension(
            column
        )
    )


    if (
        dimension
        and score >= 60
    ):

        dimension_features[
            dimension
        ].append(
            (
                score,
                column
            )
        )


# Add mapped features
for dimension, candidates in (
    dimension_features.items()
):

    candidates.sort(
        key=lambda x: x[0],
        reverse=True
    )


    for score, source_column in candidates:

        output_column = (
            f"{dimension}__"
            f"{normalize_name(source_column)}"
        )


        if output_column in standard.columns:

            continue


        standard[
            output_column
        ] = combined[
            source_column
        ]


        used_columns.add(
            source_column
        )


# ============================================================
# 20. PRESERVE USEFUL ADDITIONAL FEATURES
# ============================================================

for column in combined.columns:

    if column in used_columns:
        continue


    ncol = normalize_name(
        column
    )


    # Never preserve transaction IDs
    if (
        semantic_score(
            column,
            TRANSACTION_ID_TERMS
        )
        >= 60
    ):

        continue


    # Skip long free-text fields
    if any(
        x in ncol
        for x in [
            "note",
            "notes",
            "description",
            "rationale",
            "comment",
            "reason"
        ]
    ):

        continue


    # Numeric features
    if (
        pd.api.types
        .is_numeric_dtype(
            combined[column]
        )
    ):

        output_column = (
            "extra__"
            + ncol
        )


        if (
            output_column
            not in standard.columns
        ):

            standard[
                output_column
            ] = combined[
                column
            ]


    # Small categorical fields
    elif (
        combined[column]
        .dtype == "object"
        and
        combined[column]
        .nunique(
            dropna=True
        ) <= 30
    ):

        output_column = (
            "extra__"
            + ncol
        )


        if (
            output_column
            not in standard.columns
        ):

            standard[
                output_column
            ] = combined[
                column
            ]


# ============================================================
# 21. CLEAN FINAL BASE
# ============================================================

# Remove completely empty columns
standard = standard.dropna(
    axis=1,
    how="all"
)


# Remove duplicate column names
standard = standard.loc[
    :,
    ~standard.columns.duplicated()
]


# Ensure entity exists
if (
    "entity_id"
    not in standard.columns
):

    raise ValueError(
        "Final analysis base "
        "does not contain entity_id."
    )


if (
    standard[
        "entity_id"
    ]
    .notna()
    .sum()
    == 0
):

    raise ValueError(
        "Final entity_id is completely empty."
    )


# ============================================================
# 22. FINAL GRAIN VALIDATION
# ============================================================

standard_grain = [
    "entity_id"
]


for context in grain_columns[1:]:

    output_column = (
        "context__"
        + normalize_name(
            context
        )
    )

    if output_column in standard.columns:

        standard_grain.append(
            output_column
        )


final_duplicate_rows = (
    standard
    .duplicated(
        subset=standard_grain
    )
    .sum()
)


# ============================================================
# 23. AVAILABLE DIMENSIONS
# ============================================================

available_dimensions = {}

for dimension in DIMENSIONS:

    available_dimensions[
        dimension
    ] = [
        column
        for column
        in standard.columns
        if column.startswith(
            dimension + "__"
        )
    ]


# ============================================================
# 24. SOURCE CONTRIBUTION CHECK
# ============================================================

for name, df in datasets.items():

    if name not in source_audit:

        source_audit[
            name
        ] = {

            "role":
                "NOT_USED",

            "input_rows":
                len(df),

            "fields_added":
                0,

            "used":
                False
        }


# ============================================================
# 25. VALIDATION
# ============================================================

validation = {}


validation[
    "source_mode_detected"
] = source_mode in [
    "SINGLE",
    "MULTIPLE"
]


validation[
    "entity_detected"
] = (
    entity_id is not None
)


validation[
    "master_table_detected"
] = (
    master_table_name
    in datasets
)


validation[
    "combined_dataset_created"
] = (
    len(combined) > 0
)


validation[
    "standardized_dataset_created"
] = (
    len(standard) > 0
)


validation[
    "entity_id_present"
] = (
    "entity_id"
    in standard.columns
)


validation[
    "entity_id_non_empty"
] = (
    standard[
        "entity_id"
    ]
    .notna()
    .any()
)


validation[
    "grain_unique"
] = (
    final_duplicate_rows == 0
)


validation[
    "dimension_detected"
] = (
    sum(
        len(v)
        for v
        in available_dimensions.values()
    ) > 0
)


# For MULTIPLE mode, verify that the engine
# actually combined at least one non-master
# related dataset when such a relationship exists.

if source_mode == "MULTIPLE":

    linked_children = [
        name
        for name, info
        in source_audit.items()
        if (
            info["role"]
            ==
            "CHILD_AGGREGATED_AND_COMBINED"
        )
    ]


    relationship_required = any(
        info["entity_id"]
        == entity_id
        and name != master_table_name
        for name, info
        in table_info.items()
    )


    validation[
        "multi_dataset_combination"
    ] = (
        not relationship_required
        or len(linked_children) > 0
    )

else:

    validation[
        "multi_dataset_combination"
    ] = True


validation[
    "overall_pass"
] = all(
    validation.values()
)


# ============================================================
# 26. SAVE COMBINED + STANDARDIZED DATA
# ============================================================

# Save the final standardized analysis base
standard.to_csv(
    OUTPUT_BASE,
    index=False
)


# ============================================================
# 27. DATA DICTIONARY
# ============================================================

dictionary_rows = []


for column in standard.columns:

    if column == "entity_id":

        dictionary_rows.append(
            {
                "standardized_column":
                    column,

                "business_dimension":
                    "identity",

                "description":
                    "Standardized entity identifier",

                "source":
                    entity_id
            }
        )

        continue


    if column == "entity_name":

        dictionary_rows.append(
            {
                "standardized_column":
                    column,

                "business_dimension":
                    "identity",

                "description":
                    "Standardized entity name",

                "source":
                    entity_name
            }
        )

        continue


    if column.startswith(
        "context__"
    ):

        dictionary_rows.append(
            {
                "standardized_column":
                    column,

                "business_dimension":
                    "context",

                "description":
                    "Analysis context dimension",

                "source":
                    column.replace(
                        "context__",
                        ""
                    )
            }
        )

        continue


    dimension = None

    for candidate in DIMENSIONS:

        if column.startswith(
            candidate + "__"
        ):

            dimension = candidate
            break


    if dimension:

        dictionary_rows.append(
            {
                "standardized_column":
                    column,

                "business_dimension":
                    dimension,

                "description":
                    "Semantically mapped "
                    "Vendor360 feature",

                "source":
                    column.split(
                        "__",
                        1
                    )[1]
            }
        )

    else:

        dictionary_rows.append(
            {
                "standardized_column":
                    column,

                "business_dimension":
                    "additional",

                "description":
                    "Preserved additional "
                    "analysis feature",

                "source":
                    column.replace(
                        "extra__",
                        ""
                    )
            }
        )


dictionary_df = pd.DataFrame(
    dictionary_rows
)


dictionary_df.to_csv(
    OUTPUT_DICT,
    index=False
)


# ============================================================
# 28. METADATA
# ============================================================

metadata = {

    "engine": {
        "name":
            "Vendor360 Universal "
            "Data Combination + "
            "Standardization Engine",

        "version":
            "3.0",

        "adaptive":
            True
    },


    "source_mode":
        source_mode,


    "input_files":
        list(
            datasets.keys()
        ),


    "master_table":
        master_table_name,


    "entity": {

        "entity_id":
            entity_id,

        "entity_name":
            entity_name
    },


    "analysis_grain": {

        "source_columns":
            grain_columns,

        "standardized_columns":
            standard_grain,

        "duplicate_rows":
            int(
                final_duplicate_rows
            )
    },


    "relationships":
        relationships,


    "source_audit":
        source_audit,


    "reference_audit":
        reference_audit,


    "available_dimensions":
        available_dimensions,


    "combined_dataset_shape":
        {
            "rows":
                int(
                    combined.shape[0]
                ),

            "columns":
                int(
                    combined.shape[1]
                )
        },


    "standardized_dataset_shape":
        {
            "rows":
                int(
                    standard.shape[0]
                ),

            "columns":
                int(
                    standard.shape[1]
                )
        },


    "validation":
        validation,


    "outputs": {

        "analysis_base":
            OUTPUT_BASE,

        "data_dictionary":
            OUTPUT_DICT,

        "metadata":
            OUTPUT_META
    }
}


with open(
    OUTPUT_META,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        metadata,
        f,
        indent=2,
        default=str
    )


# ============================================================
# 29. FINAL REPORT
# ============================================================

print("\n")
print("=" * 70)
print(
    "VENDOR360 FINAL STANDARDIZATION RESULT"
)
print("=" * 70)


print(
    f"\nSource mode       : "
    f"{source_mode}"
)


print(
    f"Master table      : "
    f"{master_table_name}"
)


print(
    f"Entity ID         : "
    f"{entity_id}"
)


print(
    f"Entity Name       : "
    f"{entity_name}"
)


print(
    f"Analysis grain    : "
    f"{' + '.join(grain_columns)}"
)


print(
    f"\nCOMBINED DATASET  : "
    f"{combined.shape[0]} rows × "
    f"{combined.shape[1]} columns"
)


print(
    f"FINAL ANALYSIS BASE: "
    f"{standard.shape[0]} rows × "
    f"{standard.shape[1]} columns"
)


# ============================================================
# BUSINESS DIMENSIONS
# ============================================================

print(
    "\nAVAILABLE BUSINESS DIMENSIONS"
)

print("-" * 70)


for dimension, columns in (
    available_dimensions.items()
):

    if columns:

        print(
            f"✓ {dimension.capitalize():18}"
            f": {len(columns)} feature(s)"
        )

    else:

        print(
            f"– {dimension.capitalize():18}"
            f": unavailable"
        )


# ============================================================
# SOURCE AUDIT
# ============================================================

print(
    "\nSOURCE CONTRIBUTION AUDIT"
)

print("-" * 70)


for name, info in source_audit.items():

    status = (
        "✓ USED"
        if info["used"]
        else "– NOT USED"
    )


    print(
        f"{status:12}"
        f"{name:30}"
        f"fields added: "
        f"{info['fields_added']}"
    )


# ============================================================
# VALIDATION
# ============================================================

print(
    "\nVALIDATION"
)

print("-" * 70)


for key, value in validation.items():

    symbol = (
        "✓"
        if value
        else "⚠"
    )

    print(
        f"{symbol} "
        f"{key.replace('_', ' ').title()}"
    )


# ============================================================
# OUTPUTS
# ============================================================

print(
    "\nOUTPUT FILES"
)

print("-" * 70)

print(
    f"✓ {OUTPUT_BASE}"
)

print(
    f"✓ {OUTPUT_DICT}"
)

print(
    f"✓ {OUTPUT_META}"
)


# ============================================================
# FINAL STATUS
# ============================================================

print("\n" + "=" * 70)


if validation[
    "overall_pass"
]:

    print(
        "STATUS: PASS"
    )

    print(
        "Vendor360_Analysis_Base.csv "
        "is ready for Cell 18."
    )

else:

    print(
        "STATUS: REVIEW REQUIRED"
    )

    print(
        "Do NOT continue to Cell 18."
    )


print("=" * 70)

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 36 =====

#           FEATURE & TARGET DETECTION
# ============================================================
#
# INPUT:
#   Vendor360_Analysis_Base.csv
#
# PURPOSE:
#   1. Validate the standardized analysis base
#   2. Inspect data types and missingness
#   3. Detect business dimensions
#   4. Detect numeric / categorical features
#   5. Detect possible targets
#   6. Determine which analytical methods are feasible
#
# IMPORTANT:
#   This cell DOES NOT force a target or model.
#   Cell 19 will select methods adaptively.
# ============================================================

import os
import re
import json
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ============================================================
# 1. LOAD STANDARDIZED DATASET
# ============================================================

BASE_PATH = V360_WORK + "/Vendor360_Analysis_Base.csv"

if not os.path.exists(BASE_PATH):

    raise FileNotFoundError(
        "Vendor360_Analysis_Base.csv was not found. "
        "Run Cell 17 first."
    )


df = pd.read_csv(
    BASE_PATH,
    low_memory=False
)


print("=" * 70)
print(
    "VENDOR360 STANDARDIZED DATA VALIDATION"
)
print("=" * 70)


# ============================================================
# 2. BASIC DATASET INFORMATION
# ============================================================

print("\nDATASET OVERVIEW")
print("-" * 70)

print(
    f"Rows       : {df.shape[0]}"
)

print(
    f"Columns    : {df.shape[1]}"
)

print(
    f"Memory     : "
    f"{df.memory_usage(deep=True).sum() / 1024**2:.2f} MB"
)


# ============================================================
# 3. ENTITY VALIDATION
# ============================================================

required_identity = [
    "entity_id"
]


missing_identity = [
    col
    for col in required_identity
    if col not in df.columns
]


if missing_identity:

    raise ValueError(
        "Missing required identity column(s): "
        + ", ".join(
            missing_identity
        )
    )


print("\nENTITY VALIDATION")
print("-" * 70)

print(
    f"Entity ID column : entity_id"
)

print(
    f"Unique entities  : "
    f"{df['entity_id'].nunique(dropna=True)}"
)

print(
    f"Missing entity IDs: "
    f"{df['entity_id'].isna().sum()}"
)


if "entity_name" in df.columns:

    print(
        f"Entity name column: entity_name"
    )


# ============================================================
# 4. DUPLICATE VALIDATION
# ============================================================

duplicate_rows = (
    df.duplicated()
    .sum()
)


print("\nDUPLICATE VALIDATION")
print("-" * 70)

print(
    f"Exact duplicate rows : "
    f"{duplicate_rows}"
)


# Detect likely analysis grain
grain_columns = [
    "entity_id"
]


context_columns = [
    col
    for col in df.columns
    if col.startswith(
        "context__"
    )
]


grain_columns.extend(
    context_columns
)


grain_duplicate_rows = (
    df.duplicated(
        subset=grain_columns
    )
    .sum()
)


print(
    f"Detected grain       : "
    f"{' + '.join(grain_columns)}"
)

print(
    f"Duplicate grain rows : "
    f"{grain_duplicate_rows}"
)


# ============================================================
# 5. DATA TYPE CLASSIFICATION
# ============================================================

numeric_columns = []

categorical_columns = []

datetime_columns = []

boolean_columns = []

text_columns = []


for column in df.columns:

    series = df[column]


    if pd.api.types.is_bool_dtype(
        series
    ):

        boolean_columns.append(
            column
        )

    elif pd.api.types.is_numeric_dtype(
        series
    ):

        numeric_columns.append(
            column
        )

    elif pd.api.types.is_datetime64_any_dtype(
        series
    ):

        datetime_columns.append(
            column
        )

    elif series.dtype == "object":

        # Try to identify date-like fields
        name = column.lower()

        if (
            "date" in name
            or "time" in name
        ):

            converted = pd.to_datetime(
                series,
                errors="coerce"
            )

            if (
                converted.notna().mean()
                >= 0.80
            ):

                datetime_columns.append(
                    column
                )

            else:

                categorical_columns.append(
                    column
                )

        else:

            unique_ratio = (
                series.nunique(
                    dropna=True
                )
                / max(
                    len(series),
                    1
                )
            )


            if (
                unique_ratio <= 0.30
                or
                series.nunique(
                    dropna=True
                ) <= 30
            ):

                categorical_columns.append(
                    column
                )

            else:

                text_columns.append(
                    column
                )


print("\nDATA TYPES")
print("-" * 70)

print(
    f"Numeric      : "
    f"{len(numeric_columns)}"
)

print(
    f"Categorical  : "
    f"{len(categorical_columns)}"
)

print(
    f"Boolean      : "
    f"{len(boolean_columns)}"
)

print(
    f"Datetime     : "
    f"{len(datetime_columns)}"
)

print(
    f"Text         : "
    f"{len(text_columns)}"
)


# ============================================================
# 6. BUSINESS DIMENSION DETECTION
# ============================================================
#
# Important:
# We use semantic meaning of the COLUMN NAME.
# We do not assume that Cell 17's prefix is always correct.
#
# This allows:
#
# outcome__historical_awards_lead_time_days
#
# to be recognized as RELIABILITY.
# ============================================================

DIMENSION_RULES = {

    "cost": [
        "cost",
        "price",
        "spend",
        "expense",
        "purchase"
    ],

    "quality": [
        "quality",
        "defect",
        "rejection"
    ],

    "reliability": [
        "lead_time",
        "leadtime",
        "delivery_time",
        "delivery_days",
        "delivery_delay",
        "on_time",
        "on_time_delivery",
        "otd",
        "fulfillment",
        "service_level"
    ],

    "risk": [
        "risk"
    ],

    "sustainability": [
        "esg",
        "sustainability",
        "environmental",
        "social_score",
        "governance_score",
        "carbon"
    ],

    "capacity": [
        "capacity"
    ],

    "status": [
        "status",
        "preferred",
        "restricted",
        "approved",
        "contract"
    ],

    "outcome": [
        "award",
        "savings",
        "decision",
        "escalat"
    ]
}


def detect_dimension(
    column
):

    name = (
        column
        .lower()
        .replace(
            "-",
            "_"
        )
    )

    matches = []

    for dimension, terms in (
        DIMENSION_RULES.items()
    ):

        for term in terms:

            if term in name:

                # Reliability gets priority
                # for lead/delivery fields.
                if (
                    dimension
                    == "reliability"
                ):

                    return dimension

                matches.append(
                    dimension
                )

                break


    if not matches:

        return None


    # More specific dimensions first
    priority = [
        "quality",
        "reliability",
        "risk",
        "sustainability",
        "cost",
        "capacity",
        "status",
        "outcome"
    ]


    for dimension in priority:

        if dimension in matches:

            return dimension


    return matches[0]


dimension_columns = {

    dimension: []

    for dimension
    in DIMENSION_RULES
}


for column in df.columns:

    dimension = detect_dimension(
        column
    )

    if dimension:

        dimension_columns[
            dimension
        ].append(
            column
        )


print("\nAVAILABLE BUSINESS DIMENSIONS")
print("-" * 70)


for dimension, columns in (
    dimension_columns.items()
):

    if columns:

        print(
            f"\n✓ {dimension.upper()}"
        )

        for column in columns:

            print(
                f"    • {column}"
            )

    else:

        print(
            f"\n– {dimension.upper()}: "
            f"no matching features"
        )


# ============================================================
# 7. ANALYTICAL FEATURE SET
# ============================================================

# Exclude identity and context fields
# from modelling features.

excluded_for_modeling = set(
    [
        "entity_id",
        "entity_name"
    ]
    + context_columns
)


# Also exclude high-cardinality
# text columns.

model_numeric_features = [
    col
    for col in numeric_columns
    if col not in excluded_for_modeling
]


model_categorical_features = [
    col
    for col in categorical_columns
    if col not in excluded_for_modeling
]


print("\nMODEL-READY FEATURES")
print("-" * 70)

print(
    f"Numeric features     : "
    f"{len(model_numeric_features)}"
)

print(
    f"Categorical features : "
    f"{len(model_categorical_features)}"
)


# ============================================================
# 8. CONSTANT / NEAR-CONSTANT FEATURE DETECTION
# ============================================================

constant_features = []

near_constant_features = []


for column in model_numeric_features:

    nunique = (
        df[column]
        .nunique(
            dropna=True
        )
    )


    if nunique <= 1:

        constant_features.append(
            column
        )

        continue


    value_counts = (
        df[column]
        .value_counts(
            normalize=True,
            dropna=True
        )
    )


    if (
        len(value_counts) > 0
        and value_counts.iloc[0]
        >= 0.95
    ):

        near_constant_features.append(
            column
        )


print("\nFEATURE VARIABILITY")
print("-" * 70)

print(
    f"Constant features     : "
    f"{len(constant_features)}"
)

print(
    f"Near-constant (≥95%)  : "
    f"{len(near_constant_features)}"
)


# ============================================================
# 9. MISSINGNESS ANALYSIS
# ============================================================

missing_summary = pd.DataFrame(
    {
        "column":
            df.columns,

        "missing_count":
            [
                df[c].isna().sum()
                for c in df.columns
            ],

        "missing_pct":
            [
                df[c].isna().mean() * 100
                for c in df.columns
            ]
    }
)


missing_summary = (
    missing_summary
    .sort_values(
        "missing_pct",
        ascending=False
    )
)


print("\nMISSINGNESS")
print("-" * 70)

print(
    f"Columns with missing values: "
    f"{(missing_summary['missing_count'] > 0).sum()}"
)


if (
    missing_summary[
        "missing_count"
    ] > 0
).any():

    print(
        "\nTop missing-value columns:"
    )

    print(
        missing_summary[
            missing_summary[
                "missing_count"
            ] > 0
        ]
        .head(15)
        .to_string(
            index=False
        )
    )

else:

    print(
        "No missing values detected."
    )


# ============================================================
# 10. POSSIBLE TARGET DETECTION
# ============================================================
#
# We DO NOT automatically select a target.
#
# A target is only considered if it has a plausible
# business meaning and enough variation.
# ============================================================

TARGET_PATTERNS = [

    "target",
    "outcome",
    "awarded",
    "award_count",
    "savings",
    "preferred_supplier",
    "risk",
    "quality",
    "performance",
    "score"
]


target_candidates = []


for column in df.columns:

    if column in excluded_for_modeling:
        continue


    if column in constant_features:
        continue


    name = column.lower()


    matched_terms = [
        term
        for term in TARGET_PATTERNS
        if term in name
    ]


    if not matched_terms:
        continue


    series = df[column]


    non_missing = (
        series
        .dropna()
    )


    if len(non_missing) < 20:
        continue


    unique_count = (
        non_missing
        .nunique()
    )


    # Binary candidate
    if unique_count == 2:

        target_type = "binary"


    # Count-like candidate
    elif (
        pd.api.types
        .is_numeric_dtype(
            series
        )
        and
        (non_missing >= 0).all()
        and
        np.allclose(
            non_missing,
            np.round(
                non_missing
            )
        )
    ):

        target_type = "count"


    elif pd.api.types.is_numeric_dtype(
        series
    ):

        target_type = "continuous"


    else:

        target_type = "categorical"


    target_candidates.append(
        {
            "target":
                column,

            "type":
                target_type,

            "non_missing":
                len(non_missing),

            "unique_values":
                unique_count,

            "missing_pct":
                series.isna().mean() * 100,

            "matched_terms":
                ", ".join(
                    matched_terms
                )
        }
    )


target_candidates_df = pd.DataFrame(
    target_candidates
)


print("\nPOSSIBLE TARGETS")
print("-" * 70)


if target_candidates_df.empty:

    print(
        "No strong target candidates "
        "detected."
    )

else:

    print(
        target_candidates_df
        .to_string(
            index=False
        )
    )


# ============================================================
# 11. METHOD FEASIBILITY
# ============================================================

method_feasibility = {}


# ------------------------------------------------------------
# Clustering
# ------------------------------------------------------------

method_feasibility[
    "clustering"
] = (
    len(model_numeric_features)
    >= 2
    and
    len(df) >= 10
)


# ------------------------------------------------------------
# PCA
# ------------------------------------------------------------

method_feasibility[
    "pca"
] = (
    len(model_numeric_features)
    >= 2
    and
    len(df) >= 10
)


# ------------------------------------------------------------
# Regression
# ------------------------------------------------------------

continuous_or_count_targets = []

if not target_candidates_df.empty:

    continuous_or_count_targets = (
        target_candidates_df[
            target_candidates_df[
                "type"
            ].isin(
                [
                    "continuous",
                    "count"
                ]
            )
        ]
    )


method_feasibility[
    "regression"
] = (
    len(
        continuous_or_count_targets
    ) > 0
    and
    len(model_numeric_features)
    >= 1
    and
    len(df) >= 30
)


# ------------------------------------------------------------
# Classification
# ------------------------------------------------------------

classification_targets = []

if not target_candidates_df.empty:

    classification_targets = (
        target_candidates_df[
            target_candidates_df[
                "type"
            ].isin(
                [
                    "binary",
                    "categorical"
                ]
            )
        ]
    )


method_feasibility[
    "classification"
] = (
    len(
        classification_targets
    ) > 0
    and
    len(model_numeric_features)
    >= 1
    and
    len(df) >= 30
)


# ------------------------------------------------------------
# Anomaly detection
# ------------------------------------------------------------

method_feasibility[
    "anomaly_detection"
] = (
    len(model_numeric_features)
    >= 2
    and
    len(df) >= 20
)


# ------------------------------------------------------------
# MCDA
# ------------------------------------------------------------
#
# MCDA requires business dimensions.
# It does not require a target variable.
# ------------------------------------------------------------

mcda_dimensions = [
    dimension
    for dimension, columns
    in dimension_columns.items()
    if (
        dimension in [
            "cost",
            "quality",
            "reliability",
            "risk",
            "sustainability"
        ]
        and len(columns) > 0
    )
]


method_feasibility[
    "mcda"
] = (
    len(mcda_dimensions)
    >= 2
    and
    len(df) >= 2
)


print("\nMETHOD FEASIBILITY")
print("-" * 70)


for method, feasible in (
    method_feasibility.items()
):

    symbol = (
        "✓"
        if feasible
        else "–"
    )


    print(
        f"{symbol} "
        f"{method.replace('_', ' ').title()}"
    )


# ============================================================
# 12. DATA QUALITY WARNINGS
# ============================================================

warnings_list = []


if duplicate_rows > 0:

    warnings_list.append(
        f"{duplicate_rows} exact "
        f"duplicate rows detected."
    )


if grain_duplicate_rows > 0:

    warnings_list.append(
        f"{grain_duplicate_rows} "
        f"duplicate analysis-grain "
        f"rows detected."
    )


if len(constant_features) > 0:

    warnings_list.append(
        f"{len(constant_features)} "
        f"constant numeric feature(s)."
    )


if len(
    near_constant_features
) > 0:

    warnings_list.append(
        f"{len(near_constant_features)} "
        f"near-constant numeric feature(s)."
    )


if (
    len(model_numeric_features)
    < 2
):

    warnings_list.append(
        "Fewer than 2 numeric features "
        "are available for multivariate "
        "analysis."
    )


if target_candidates_df.empty:

    warnings_list.append(
        "No strong predictive target "
        "was automatically identified."
    )


# ============================================================
# 13. CREATE CELL 19 CONFIGURATION
# ============================================================

cell19_config = {

    "input_file":
        BASE_PATH,

    "rows":
        int(df.shape[0]),

    "columns":
        int(df.shape[1]),

    "entity_column":
        "entity_id",

    "entity_name_column":
        (
            "entity_name"
            if "entity_name"
            in df.columns
            else None
        ),

    "grain_columns":
        grain_columns,

    "numeric_features":
        model_numeric_features,

    "categorical_features":
        model_categorical_features,

    "datetime_features":
        datetime_columns,

    "constant_features":
        constant_features,

    "near_constant_features":
        near_constant_features,

    "business_dimensions":
        dimension_columns,

    "possible_targets":
        (
            target_candidates_df
            .to_dict(
                orient="records"
            )
            if not target_candidates_df.empty
            else []
        ),

    "method_feasibility":
        method_feasibility,

    "mcda_dimensions":
        mcda_dimensions,

    "warnings":
        warnings_list
}


CONFIG_PATH = (
    V360_WORK + "/"
    "Vendor360_Cell18_Config.json"
)


with open(
    CONFIG_PATH,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        cell19_config,
        f,
        indent=2,
        default=str
    )


# ============================================================
# 14. FINAL STATUS
# ============================================================

validation = {

    "dataset_loaded":
        len(df) > 0,

    "entity_id_present":
        "entity_id" in df.columns,

    "entity_id_non_empty":
        df["entity_id"].notna().any(),

    "grain_valid":
        grain_duplicate_rows == 0,

    "numeric_features_available":
        len(model_numeric_features) >= 1,

    "business_dimensions_detected":
        any(
            len(v) > 0
            for v
            in dimension_columns.values()
        ),

    "configuration_created":
        os.path.exists(
            CONFIG_PATH
        )
}


validation[
    "overall_pass"
] = all(
    validation.values()
)


print("\n")
print("=" * 70)
print(
    "CELL 18 VALIDATION"
)
print("=" * 70)


for key, value in validation.items():

    symbol = (
        "✓"
        if value
        else "⚠"
    )

    print(
        f"{symbol} "
        f"{key.replace('_', ' ').title()}"
    )


print("\n" + "=" * 70)


if validation[
    "overall_pass"
]:

    print(
        "STATUS: PASS"
    )

    print(
        "Standardized dataset is ready "
        "for adaptive analysis in Cell 19."
    )

else:

    print(
        "STATUS: REVIEW REQUIRED"
    )


print("=" * 70)

# ================================================================


# ===== ORIGINAL NOTEBOOK CELL 38 =====

# FINAL REFINED VERSION
# ================================================================

import os
import json
import warnings
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split

from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture

from sklearn.metrics import (
    silhouette_score,
    calinski_harabasz_score,
    davies_bouldin_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

from sklearn.decomposition import PCA

from sklearn.ensemble import (
    IsolationForest,
    RandomForestRegressor,
    GradientBoostingRegressor,
    RandomForestClassifier,
    GradientBoostingClassifier
)

from sklearn.neighbors import LocalOutlierFactor

from sklearn.linear_model import (
    LinearRegression,
    PoissonRegressor,
    LogisticRegression
)

from sklearn.tree import DecisionTreeClassifier

warnings.filterwarnings("ignore")

# ================================================================
# 1. SETTINGS
# ================================================================

BASE_PATH = V360_WORK + "/Vendor360_Analysis_Base.csv"
OUTPUT_DIR = V360_WORK + "/Vendor360_Cell19"

RANDOM_STATE = 42
TEST_SIZE = 0.20

os.makedirs(OUTPUT_DIR, exist_ok=True)

if not os.path.exists(BASE_PATH):
    raise FileNotFoundError(
        f"Vendor360 analysis base not found: {BASE_PATH}"
    )

df = pd.read_csv(BASE_PATH)

print("=" * 70)
print("VENDOR360 ADAPTIVE METHOD TESTING & SELECTION")
print("=" * 70)

print("\nDATASET")
print("-" * 70)
print(f"Rows    : {df.shape[0]}")
print(f"Columns : {df.shape[1]}")


# ================================================================
# 2. HELPER FUNCTIONS
# ================================================================

def is_numeric(series):
    return pd.api.types.is_numeric_dtype(series)


def norm(col):
    return str(col).lower().strip()


def contains_any(text, terms):
    text = norm(text)
    return any(term in text for term in terms)


# ================================================================
# 3. ENTITY AND GRAIN
# ================================================================

entity_col = (
    "entity_id"
    if "entity_id" in df.columns
    else None
)

entity_name_col = (
    "entity_name"
    if "entity_name" in df.columns
    else None
)

context_cols = [
    c for c in df.columns
    if c.startswith("context__")
]

grain_cols = []

if entity_col:
    grain_cols.append(entity_col)

if context_cols:
    grain_cols.append(context_cols[0])

print("\nANALYSIS GRAIN")
print("-" * 70)

print(
    "Entity column :",
    entity_col if entity_col else "Not detected"
)

print(
    "Grain         :",
    " + ".join(grain_cols)
    if grain_cols
    else "Dataset row"
)


# ================================================================
# 4. BUSINESS DIMENSION DETECTION
# ================================================================

dimension_features = {
    "cost": [],
    "quality": [],
    "reliability": [],
    "risk": [],
    "sustainability": [],
    "capacity": [],
    "status": [],
    "outcome": []
}

for col in df.columns:

    c = norm(col)

    # ---------------- COST ----------------

    if (
        c.startswith("cost__")
        or contains_any(
            c,
            [
                "unit_price",
                "unit_cost",
                "purchase_price",
                "purchase_cost",
                "total_cost",
                "spend",
                "expense"
            ]
        )
    ):

        if is_numeric(df[col]):
            dimension_features["cost"].append(col)

    # ---------------- QUALITY ----------------

    elif (
        c.startswith("quality__")
        or contains_any(
            c,
            [
                "quality_score",
                "quality_rating",
                "defect_rate",
                "defect_pct",
                "rejection_rate"
            ]
        )
    ):

        if is_numeric(df[col]):
            dimension_features["quality"].append(col)

    # ---------------- RELIABILITY ----------------

    elif (
        c.startswith("reliability__")
        or contains_any(
            c,
            [
                "lead_time",
                "delivery_time",
                "delivery_days",
                "on_time",
                "ontime",
                "delivery_reliability",
                "late_delivery"
            ]
        )
    ):

        if is_numeric(df[col]):
            dimension_features["reliability"].append(col)

    # ---------------- RISK ----------------

    elif (
        c.startswith("risk__")
        or "risk_score" in c
        or "risk_rating" in c
    ):

        if is_numeric(df[col]):
            dimension_features["risk"].append(col)

    # ---------------- SUSTAINABILITY ----------------

    elif (
        c.startswith("sustainability__")
        or contains_any(
            c,
            [
                "esg_score",
                "sustainability_score",
                "sustainability_rating",
                "carbon_score",
                "environmental_score"
            ]
        )
    ):

        if is_numeric(df[col]):
            dimension_features["sustainability"].append(col)

    # ---------------- CAPACITY ----------------

    elif (
        c.startswith("capacity__")
        or contains_any(
            c,
            [
                "capacity_per",
                "production_capacity"
            ]
        )
    ):

        if is_numeric(df[col]):
            dimension_features["capacity"].append(col)

    # ---------------- STATUS ----------------

    elif (
        c.startswith("status__")
        or contains_any(
            c,
            [
                "preferred_supplier",
                "preferred_vendor",
                "restricted",
                "contract_status"
            ]
        )
    ):

        dimension_features["status"].append(col)

    # ---------------- OUTCOME ----------------

    elif c.startswith("outcome__"):

        dimension_features["outcome"].append(col)


# Remove duplicates
for dim in dimension_features:
    dimension_features[dim] = list(
        dict.fromkeys(
            dimension_features[dim]
        )
    )


# ================================================================
# 5. DISPLAY DIMENSIONS
# ================================================================

print("\nBUSINESS DIMENSION FEATURES")
print("-" * 70)

for dimension in [
    "cost",
    "quality",
    "reliability",
    "risk",
    "sustainability",
    "capacity",
    "status",
    "outcome"
]:

    print(f"\n{dimension.upper()}:")

    if dimension_features[dimension]:

        for col in dimension_features[dimension]:
            print(f" • {col}")

    else:
        print(" – None detected")


# ================================================================
# 6. NUMERIC MODEL FEATURES
# ================================================================

numeric_features = [
    c for c in df.columns
    if is_numeric(df[c])
]

numeric_features = [
    c for c in numeric_features
    if c != entity_col
    and not c.endswith("_id")
]

print("\nMODEL NUMERIC FEATURES")
print("-" * 70)

print(
    f"Usable numeric features: {len(numeric_features)}"
)

for col in numeric_features:
    print(f" • {col}")


# ================================================================
# 7. CORE BUSINESS FEATURE SET
# ================================================================
#
# IMPORTANT:
# extra__pricing_max_quantity remains available as an additional
# feature but is NOT included in the core Vendor360 business
# matrix because it is a pricing-volume constraint rather than
# supplier monthly capacity.
#
# ================================================================

core_dimensions = [
    "cost",
    "quality",
    "reliability",
    "risk",
    "sustainability",
    "capacity"
]

core_features = []

for dim in core_dimensions:

    for col in dimension_features[dim]:

        if col in numeric_features:
            core_features.append(col)

core_features = list(
    dict.fromkeys(core_features)
)

# Explicitly exclude metadata/data-volume variables
metadata_terms = [
    "record_count",
    "row_count",
    "missing",
    "frequency"
]

core_features = [
    c for c in core_features
    if not any(
        term in norm(c)
        for term in metadata_terms
    )
]

# Explicitly exclude pricing max quantity from the core matrix
core_features = [
    c for c in core_features
    if c != "extra__pricing_max_quantity"
]


print("\nCORE BUSINESS FEATURE SET")
print("-" * 70)

for col in core_features:
    print(f" • {col}")

print(
    f"Total core business features: "
    f"{len(core_features)}"
)

if len(core_features) < 2:

    raise ValueError(
        "Insufficient numeric business features "
        "for adaptive modeling."
    )


# ================================================================
# 8. BUSINESS FEATURE MATRIX
# ================================================================

X_business = df[core_features].copy()

business_imputer = SimpleImputer(
    strategy="median"
)

X_business_imputed = (
    business_imputer.fit_transform(
        X_business
    )
)

business_scaler = StandardScaler()

X_scaled = business_scaler.fit_transform(
    X_business_imputed
)

print("\nBUSINESS FEATURE MATRIX")
print("-" * 70)

print(
    f"Shape: {X_scaled.shape}"
)

print(
    "Missing values handled using median imputation."
)

print(
    "Features standardized using StandardScaler."
)


# ================================================================
# 9. CLUSTERING
# ================================================================

print("\n" + "=" * 70)
print("A. CLUSTERING METHOD TESTING")
print("=" * 70)

cluster_results = []

max_k = min(
    8,
    len(df) - 1
)

for k in range(2, max_k + 1):

    # ---------------- K-MEANS ----------------

    try:

        model = KMeans(
            n_clusters=k,
            random_state=RANDOM_STATE,
            n_init=20
        )

        labels = model.fit_predict(
            X_scaled
        )

        cluster_results.append({

            "method": "K-Means",
            "k": k,

            "silhouette":
                silhouette_score(
                    X_scaled,
                    labels
                ),

            "calinski_harabasz":
                calinski_harabasz_score(
                    X_scaled,
                    labels
                ),

            "davies_bouldin":
                davies_bouldin_score(
                    X_scaled,
                    labels
                )
        })

    except Exception:
        pass


    # ---------------- AGGLOMERATIVE ----------------

    try:

        model = AgglomerativeClustering(
            n_clusters=k
        )

        labels = model.fit_predict(
            X_scaled
        )

        cluster_results.append({

            "method": "Agglomerative",
            "k": k,

            "silhouette":
                silhouette_score(
                    X_scaled,
                    labels
                ),

            "calinski_harabasz":
                calinski_harabasz_score(
                    X_scaled,
                    labels
                ),

            "davies_bouldin":
                davies_bouldin_score(
                    X_scaled,
                    labels
                )
        })

    except Exception:
        pass


    # ---------------- GMM ----------------

    try:

        model = GaussianMixture(
            n_components=k,
            random_state=RANDOM_STATE
        )

        labels = model.fit_predict(
            X_scaled
        )

        if len(
            np.unique(labels)
        ) > 1:

            cluster_results.append({

                "method": "GMM",
                "k": k,

                "silhouette":
                    silhouette_score(
                        X_scaled,
                        labels
                    ),

                "calinski_harabasz":
                    calinski_harabasz_score(
                        X_scaled,
                        labels
                    ),

                "davies_bouldin":
                    davies_bouldin_score(
                        X_scaled,
                        labels
                    )
            })

    except Exception:
        pass


cluster_df = pd.DataFrame(
    cluster_results
)

if not cluster_df.empty:

    cluster_df["rank_silhouette"] = (
        cluster_df[
            "silhouette"
        ].rank(
            ascending=False,
            method="min"
        )
    )

    cluster_df["rank_calinski"] = (
        cluster_df[
            "calinski_harabasz"
        ].rank(
            ascending=False,
            method="min"
        )
    )

    cluster_df["rank_davies"] = (
        cluster_df[
            "davies_bouldin"
        ].rank(
            ascending=True,
            method="min"
        )
    )

    cluster_df["combined_rank"] = (
        cluster_df["rank_silhouette"]
        + cluster_df["rank_calinski"]
        + cluster_df["rank_davies"]
    )

    cluster_df = cluster_df.sort_values(
        [
            "combined_rank",
            "silhouette",
            "calinski_harabasz",
            "davies_bouldin"
        ],
        ascending=[
            True,
            False,
            False,
            True
        ]
    )

    print("\nCLUSTERING BENCHMARK")

    print(
        cluster_df[
            [
                "method",
                "k",
                "silhouette",
                "calinski_harabasz",
                "davies_bouldin"
            ]
        ].round(4).to_string(
            index=False
        )
    )

    selected_cluster = (
        cluster_df.iloc[0]
    )

    selected_clustering = {

        "method":
            selected_cluster["method"],

        "k":
            int(selected_cluster["k"]),

        "selection_basis":
            "Best combined rank across "
            "Silhouette, Calinski-Harabasz "
            "and Davies-Bouldin"
    }

else:

    selected_clustering = None


print(
    "\nSELECTED CLUSTERING CONFIGURATION"
)

print(
    selected_clustering
)


# ================================================================
# 10. PCA
# ================================================================

print("\n" + "=" * 70)
print("B. PCA ANALYSIS")
print("=" * 70)

pca = PCA()

X_pca = pca.fit_transform(
    X_scaled
)

explained = (
    pca.explained_variance_ratio_
)

cumulative = np.cumsum(
    explained
)

pca_df = pd.DataFrame({

    "component":
        [
            f"PC{i+1}"
            for i in range(
                len(explained)
            )
        ],

    "explained_variance_ratio":
        explained,

    "cumulative_variance":
        cumulative
})

print(
    pca_df.round(4).to_string(
        index=False
    )
)

components_80 = int(
    np.argmax(
        cumulative >= 0.80
    ) + 1
)

components_90 = int(
    np.argmax(
        cumulative >= 0.90
    ) + 1
)

print(
    f"\nComponents for 80% variance: "
    f"{components_80}"
)

print(
    f"Components for 90% variance: "
    f"{components_90}"
)


# ================================================================
# 11. ANOMALY DETECTION
# ================================================================

print("\n" + "=" * 70)
print("C. ANOMALY DETECTION")
print("=" * 70)

anomaly_results = {}

# Isolation Forest
iso = IsolationForest(
    contamination="auto",
    random_state=RANDOM_STATE
)

iso_labels = iso.fit_predict(
    X_scaled
)

iso_anomaly = (
    iso_labels == -1
)

anomaly_results[
    "Isolation Forest"
] = {

    "anomalies":
        int(
            iso_anomaly.sum()
        ),

    "anomaly_pct":
        float(
            iso_anomaly.mean() * 100
        )
}


# LOF
lof = LocalOutlierFactor(
    n_neighbors=min(
        20,
        len(df) - 1
    ),
    contamination="auto"
)

lof_labels = lof.fit_predict(
    X_scaled
)

lof_anomaly = (
    lof_labels == -1
)

anomaly_results[
    "Local Outlier Factor"
] = {

    "anomalies":
        int(
            lof_anomaly.sum()
        ),

    "anomaly_pct":
        float(
            lof_anomaly.mean() * 100
        )
}

anomaly_df = pd.DataFrame(
    anomaly_results
).T

print(
    anomaly_df.round(2).to_string()
)


# ================================================================
# 12. MEANINGFUL TARGET DETECTION
# ================================================================
#
# We do NOT automatically treat every numeric business feature
# as a predictive target.
#
# Predictive modeling is primarily applied to:
#   - explicitly binary status variables
#   - historical outcome variables
#
# This prevents meaningless tasks such as predicting the same
# supplier price simply because it is numeric.
# ================================================================

candidate_targets = []

# ---------------- STATUS TARGETS ----------------

for col in dimension_features["status"]:

    if col not in df.columns:
        continue

    series = df[col].dropna()

    if (
        len(series) >= 30
        and series.nunique() == 2
    ):

        counts = series.value_counts()

        # Require at least 5 examples per class
        if counts.min() >= 5:

            candidate_targets.append({

                "target": col,
                "type": "binary",
                "source": "status",
                "non_missing": len(series),
                "unique_values":
                    series.nunique(),
                "missing_pct":
                    df[col].isna().mean() * 100
            })


# ---------------- OUTCOME TARGETS ----------------

for col in dimension_features["outcome"]:

    if col not in df.columns:
        continue

    series = df[col].dropna()

    if len(series) < 30:
        continue

    unique_count = series.nunique()

    if unique_count < 2:
        continue

    if (
        pd.api.types.is_numeric_dtype(
            df[col]
        )
    ):

        # Count-like historical outcomes
        if (
            pd.api.types.is_integer_dtype(
                df[col]
            )
            and unique_count <= 15
            and series.min() >= 0
        ):

            target_type = "count"

        else:

            target_type = "continuous"

        candidate_targets.append({

            "target": col,
            "type": target_type,
            "source": "outcome",
            "non_missing": len(series),
            "unique_values":
                unique_count,
            "missing_pct":
                df[col].isna().mean() * 100
        })


target_df = pd.DataFrame(
    candidate_targets
)

print("\n" + "=" * 70)
print("D. PREDICTIVE TARGET SCREENING")
print("=" * 70)

if not target_df.empty:

    print(
        target_df.to_string(
            index=False
        )
    )

else:

    print(
        "No suitable predictive targets detected."
    )


# ================================================================
# 12b. VENDOR360 ENGINE (leakage-safe evaluation + direction-aware MCDA)
# ================================================================
import sys, os
for _p in (os.environ.get("VENDOR360_ENGINE_DIR"), os.getcwd(), V360_WORK,
           os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else None):
    if _p and os.path.isdir(os.path.join(_p, "vendor360_engine")) and _p not in sys.path:
        sys.path.insert(0, _p)
try:
    from vendor360_engine import safe_eval as _se
    from vendor360_engine import mcda as _mcda
except ImportError as _e:
    raise ImportError(
        "vendor360_engine/ package not found. Put the vendor360_engine folder next to the "
        "notebook (or set VENDOR360_ENGINE_DIR). Original error: " + str(_e))


# ================================================================
# 13. LEAKAGE-AWARE PREDICTORS
# ================================================================

LEAKAGE_LOG = []

def predictor_features_for_target(
    target,
    target_source
):

    predictors = [
        c for c in numeric_features
        if c != target
    ]

    # Remove identifier-like variables
    predictors = [
        c for c in predictors
        if c != entity_col
        and not c.endswith("_id")
    ]

    # Historical outcome target: do not use other outcome fields as predictors
    # (they may describe the same historical event).
    if target_source == "outcome":
        predictors = [
            c for c in predictors
            if not norm(c).startswith("outcome__")
        ]

    # NEW: remove predictors that are a restatement of the target
    # (e.g. target preferred_supplier vs outcome preferred_supplier_used).
    kept = []
    for c in predictors:
        if getattr(_se, "name_overlaps_target", lambda a,b: False)(c, target):
            LEAKAGE_LOG.append({"target": target, "predictor": c,
                                "reason": "name overlaps target"})
        else:
            kept.append(c)
    return kept



# ================================================================
# 14. REGRESSION BENCHMARK  (leakage-safe)
# ================================================================
# imputation + scaling happen INSIDE a pipeline fitted on training rows only;
# rows are split by entity (supplier) so one supplier never sits in both
# train and test; the model is chosen by cross-validation on training rows;
# a naive baseline is reported next to every result.

print("\n" + "=" * 70)
print("E. REGRESSION BENCHMARK")
print("=" * 70)

from sklearn.linear_model import PoissonRegressor as _Poisson

regression_results = []
regression_notes = []

if not target_df.empty:
    regression_targets = target_df[target_df["type"].isin(["continuous", "count"])]
    for _, row in regression_targets.iterrows():
        target = row["target"]
        target_source = row["source"]
        y = df[target]
        valid = y.notna()
        predictors = predictor_features_for_target(target, target_source)
        if len(predictors) < 2:
            continue
        if int(valid.sum()) < 30:
            continue
        models = _se.regression_models(RANDOM_STATE)
        models.pop("Decision Tree", None)                 # same model set as before
        if row["type"] == "count":
            models["Poisson Regression"] = _Poisson(max_iter=1000)
        groups = df.loc[valid, entity_col] if entity_col in df.columns else None
        res = _se.evaluate_regression(
            df.loc[valid, predictors], y.loc[valid], groups=groups,
            test_size=TEST_SIZE, seed=RANDOM_STATE, models=models, target_name=target)
        if res["status"] != "ok":
            regression_notes.append({"target": target, "note": res.get("reason")})
            continue
        for _, r in res["results"].iterrows():
            regression_results.append({
                "target": target, "model": r["model"], "test_rows": res["n_test"],
                "MAE": r["mae"], "RMSE": r["rmse"], "R2": r["r2"],
                "cv_mae_train": r.get("cv_mae_train", np.nan),
                "baseline_MAE": r["baseline_mae"],
                "selected_by_cv": r["model"] == res["selected_model"],
                "beats_baseline": res["beats_baseline"],
                "split": res["split"], "entity_overlap": res["group_overlap"],
            })
        for c, why in res["leaky_predictors"]:
            LEAKAGE_LOG.append({"target": target, "predictor": c, "reason": why})

regression_df = pd.DataFrame(regression_results)

if not regression_df.empty:
    print(regression_df.round(4).to_string(index=False))
else:
    print("No valid regression benchmark completed.")


# ================================================================
# 15. CLASSIFICATION BENCHMARK  (leakage-safe)
# ================================================================

print("\n" + "=" * 70)
print("F. CLASSIFICATION BENCHMARK")
print("=" * 70)

classification_results = []
classification_notes = []

if not target_df.empty:
    classification_targets = target_df[target_df["type"] == "binary"]
    for _, row in classification_targets.iterrows():
        target = row["target"]
        target_source = row["source"]
        y = df[target]
        valid = y.notna()
        predictors = predictor_features_for_target(target, target_source)
        if len(predictors) < 2:
            continue
        y_valid = y.loc[valid]
        class_counts = y_valid.value_counts()
        if len(class_counts) != 2:
            continue
        if class_counts.min() < 5:
            print(f"Skipping {target}: insufficient class representation.")
            continue
        groups = df.loc[valid, entity_col] if entity_col in df.columns else None
        res = _se.evaluate_classification(
            df.loc[valid, predictors], y_valid.astype(int), groups=groups,
            test_size=TEST_SIZE, seed=RANDOM_STATE, target_name=target)
        if res["status"] != "ok":
            classification_notes.append({"target": target, "note": res.get("reason")})
            continue
        for _, r in res["results"].iterrows():
            classification_results.append({
                "target": target, "model": r["model"], "test_rows": res["n_test"],
                "accuracy": r["accuracy"], "precision": r["precision"],
                "recall": r["recall"], "f1": r["f1"], "roc_auc": r["auc"],
                "baseline_accuracy": r["baseline_accuracy"],
                "grouped_cv_accuracy": r["grouped_cv_accuracy_all_rows"],
                "grouped_cv_accuracy_std": r["grouped_cv_accuracy_std"],
                "baseline_accuracy_cv": res["baseline_accuracy_all_rows"],
                "selected_by_cv": r["model"] == res["selected_model"],
                "beats_baseline": res["beats_baseline"],
                "split": res["split"], "entity_overlap": res["group_overlap"],
            })
        for c, why in res["leaky_predictors"]:
            LEAKAGE_LOG.append({"target": target, "predictor": c, "reason": why})
        if not res["beats_baseline"]:
            print(f"NOTE {target}: the CV-selected model does not clearly beat the "
                  f"majority-class baseline ({res['baseline_accuracy']:.1%}). "
                  "Do not present this as predictive evidence.")

classification_df = pd.DataFrame(classification_results)

if not classification_df.empty:
    print(classification_df.round(4).to_string(index=False))
else:
    print("No valid classification target detected.")

for _n in classification_notes + regression_notes:
    print(f"SKIPPED {_n['target']}: {_n['note']}")

if LEAKAGE_LOG:
    print("\nPredictors removed to prevent leakage:")
    print(pd.DataFrame(LEAKAGE_LOG).drop_duplicates().to_string(index=False))



# ================================================================
# 16. MCDA  (direction-aware, de-duplicated, no double-inversion)
# ================================================================
print("\n" + "=" * 70)
print("G. MULTI-CRITERIA DECISION ANALYSIS")
print("=" * 70)

mcda_dimensions = {}
for dim in ["cost", "quality", "reliability", "risk", "sustainability"]:
    usable = [c for c in dimension_features[dim] if c in df.columns and is_numeric(df[c])]
    if usable:
        mcda_dimensions[dim] = usable

print("MCDA dimensions available (before de-duplication):")
for dim, cols in mcda_dimensions.items():
    print(f"  {dim.upper()}: " + ", ".join(cols))

mcda_df = df.copy()
dimension_scores = {}
mcda_report = {}

if mcda_dimensions:
    _scored, mcda_report = _mcda.mcda_scores(df, mcda_dimensions)
    for _c in _scored.columns:
        if _c.startswith("mcda__"):
            mcda_df[_c] = _scored[_c]
    for dim in mcda_report:
        dimension_scores[dim] = mcda_df[f"mcda__{dim}_score"]
    print("\nPer-dimension columns actually used (direction per column):")
    for dim, info in mcda_report.items():
        used = ", ".join(f"{c} [{info['directions'][c]} is better]" for c in info["kept"])
        print(f"  {dim.upper()}: {used}")
        for c, why, dup in info["dropped"]:
            print(f"      dropped {c}: {why}" + (f" (duplicate of {dup})" if dup else ""))
    print("\nMCDA generated successfully.")
    print("Dimensions included: " + ", ".join(dimension_scores.keys()))
    print("Weights: equal across available dimensions.")
else:
    print("Insufficient dimensions for MCDA.")



# ================================================================
# 17. METHOD SELECTION SUMMARY
# ================================================================

print("\n" + "=" * 70)
print("METHOD SELECTION SUMMARY")
print("=" * 70)

method_summary = {}

if selected_clustering:

    method_summary[
        "CLUSTERING"
    ] = selected_clustering


method_summary["PCA"] = {

    "method": "PCA",

    "selection_basis":
        "Dimensionality and explained variance analysis"
}


method_summary[
    "ANOMALY_DETECTION"
] = {

    "methods_tested": [
        "Isolation Forest",
        "Local Outlier Factor"
    ],

    "selection_basis":
        "Comparative anomaly analysis; "
        "no universal winner assumed"
}


method_summary[
    "REGRESSION"
] = {

    "selection_basis":
        "Benchmark results retained by "
        "target and regression metrics"
}


method_summary[
    "CLASSIFICATION"
] = {

    "selection_basis":
        "Benchmark results retained by "
        "target and classification metrics"
}


method_summary["MCDA"] = {

    "method":
        "Equal-weight normalized MCDA",

    "selection_basis":
        "Transparent multi-criteria supplier evaluation"
}


for key, value in method_summary.items():

    print(
        f"{key}: {value}"
    )


# ================================================================
# 18. SAVE OUTPUTS
# ================================================================

if not cluster_df.empty:

    cluster_df.to_csv(
        f"{OUTPUT_DIR}/Clustering_Benchmark.csv",
        index=False
    )


pca_df.to_json(
    f"{OUTPUT_DIR}/PCA_Results.json",
    orient="records",
    indent=2
)


with open(
    f"{OUTPUT_DIR}/Anomaly_Results.json",
    "w"
) as f:

    json.dump(
        anomaly_results,
        f,
        indent=2
    )


if not regression_df.empty:

    regression_df.to_csv(
        f"{OUTPUT_DIR}/Regression_Benchmark.csv",
        index=False
    )


if not classification_df.empty:

    classification_df.to_csv(
        f"{OUTPUT_DIR}/Classification_Benchmark.csv",
        index=False
    )


if "mcda__overall_score" in mcda_df.columns:

    mcda_output_cols = []

    for c in [
        entity_col,
        entity_name_col
    ]:

        if (
            c
            and c in mcda_df.columns
        ):

            mcda_output_cols.append(c)

    mcda_output_cols += [
        c
        for c in mcda_df.columns
        if c.startswith("mcda__")
    ]

    mcda_df[
        mcda_output_cols
    ].to_csv(
        f"{OUTPUT_DIR}/MCDA_Results.csv",
        index=False
    )

    # Expose the same final MCDA output for downstream cells/UI.
    mcda_results_df = mcda_df[mcda_output_cols].copy()


# ================================================================
# 19. SAVE CONFIGURATION
# ================================================================

config = {

    "rows":
        int(df.shape[0]),

    "columns":
        int(df.shape[1]),

    "entity_column":
        entity_col,

    "grain_columns":
        grain_cols,

    "dimension_features":
        dimension_features,

    "numeric_features":
        numeric_features,

    "core_business_features":
        core_features,

    "candidate_targets":
        candidate_targets,

    "selected_clustering":
        selected_clustering,

    "pca_components_80":
        components_80,

    "pca_components_90":
        components_90,

    "method_summary":
        method_summary,

    "random_state":
        RANDOM_STATE,

    "test_size":
        TEST_SIZE
}

with open(
    f"{OUTPUT_DIR}/Vendor360_Cell19_Config.json",
    "w"
) as f:

    json.dump(
        config,
        f,
        indent=2,
        default=str
    )


# ================================================================
# 20. FINAL STATUS
# ================================================================

print("\n" + "=" * 70)
print("CELL 19 OUTPUT")
print("=" * 70)

print(
    f"Output directory: {OUTPUT_DIR}"
)

print("\nGenerated files:")

files_generated = [
    "Anomaly_Results.json",
    "Clustering_Benchmark.csv",
    "PCA_Results.json",
    "Vendor360_Cell19_Config.json"
]

if not regression_df.empty:

    files_generated.append(
        "Regression_Benchmark.csv"
    )

if not classification_df.empty:

    files_generated.append(
        "Classification_Benchmark.csv"
    )

if "mcda__overall_score" in mcda_df.columns:

    files_generated.append(
        "MCDA_Results.csv"
    )

for filename in files_generated:

    print(
        f"  ✓ {filename}"
    )


print("\nCELL 19 VALIDATION")
_c19 = {f"file exists and is non-empty: {_f}": (lambda _f=_f: v360_file_ok(os.path.join(OUTPUT_DIR, _f))) for _f in files_generated}
_c19["JSON outputs reload"] = lambda: all(v360_json_ok(os.path.join(OUTPUT_DIR, _f)) for _f in files_generated if _f.endswith(".json"))
_c19["MCDA table has rows and a score column"] = lambda: ("mcda__overall_score" in mcda_df.columns) and len(mcda_df) > 0 and mcda_df["mcda__overall_score"].notna().any()
v360_status("CELL 19", _c19)

print(
    "\nAdaptive method testing and benchmarking completed."
)

print(
    "Proceed to Cell 19.1 for the consolidated "
    "model performance and accuracy report."
)

# ================================================================
# VENDOR360 — CELL 19.1
# CONSOLIDATED MODEL PERFORMANCE & ACCURACY REPORT
# ================================================================

import os
import json
import pandas as pd
import numpy as np

CELL19_DIR = V360_WORK + "/Vendor360_Cell19"
OUTPUT_DIR = V360_WORK + "/Vendor360_Cell19"

os.makedirs(OUTPUT_DIR, exist_ok=True)

print("=" * 70)
print("VENDOR360 MODEL PERFORMANCE & ACCURACY REPORT")
print("=" * 70)


# ----------------------------------------------------------------
# 1. LOAD CELL 19 RESULTS
# ----------------------------------------------------------------

clustering_file = os.path.join(
    CELL19_DIR, "Clustering_Benchmark.csv"
)

regression_file = os.path.join(
    CELL19_DIR, "Regression_Benchmark.csv"
)

classification_file = os.path.join(
    CELL19_DIR, "Classification_Benchmark.csv"
)

clustering_df = (
    pd.read_csv(clustering_file)
    if os.path.exists(clustering_file)
    else pd.DataFrame()
)

regression_df = (
    pd.read_csv(regression_file)
    if os.path.exists(regression_file)
    else pd.DataFrame()
)

classification_df = (
    pd.read_csv(classification_file)
    if os.path.exists(classification_file)
    else pd.DataFrame()
)


# ----------------------------------------------------------------
# 2. CREATE CONSOLIDATED PERFORMANCE TABLE
# ----------------------------------------------------------------

performance_rows = []


# ================================================================
# CLUSTERING
# ================================================================

if not clustering_df.empty:

    for _, row in clustering_df.iterrows():

        performance_rows.append({
            "Task": "Clustering",
            "Target": "Business Feature Matrix",
            "Model": f"{row.get('method', 'Unknown')} (k={row.get('k', '')})",
            "Test_Rows": np.nan,
            "Accuracy": np.nan,
            "Precision": np.nan,
            "Recall": np.nan,
            "F1": np.nan,
            "ROC_AUC": np.nan,
            "MAE": np.nan,
            "RMSE": np.nan,
            "R2": np.nan,
            "Silhouette": row.get("silhouette", np.nan),
            "Calinski_Harabasz": row.get(
                "calinski_harabasz", np.nan
            ),
            "Davies_Bouldin": row.get(
                "davies_bouldin", np.nan
            ),
            "Notes": "Unsupervised clustering evaluation"
        })


# ================================================================
# REGRESSION
# ================================================================

if not regression_df.empty:

    for _, row in regression_df.iterrows():

        performance_rows.append({
            "Task": "Regression",
            "Target": row.get("target", "Unknown"),
            "Model": row.get("model", "Unknown"),
            "Test_Rows": row.get("test_rows", np.nan),
            "Accuracy": np.nan,
            "Precision": np.nan,
            "Recall": np.nan,
            "F1": np.nan,
            "ROC_AUC": np.nan,
            "MAE": row.get("MAE", np.nan),
            "RMSE": row.get("RMSE", np.nan),
            "R2": row.get("R2", np.nan),
            "Silhouette": np.nan,
            "Calinski_Harabasz": np.nan,
            "Davies_Bouldin": np.nan,
            "Notes": "Holdout regression evaluation"
        })


# ================================================================
# CLASSIFICATION
# ================================================================

if not classification_df.empty:

    for _, row in classification_df.iterrows():

        performance_rows.append({
            "Task": "Classification",
            "Target": row.get("target", "Unknown"),
            "Model": row.get("model", "Unknown"),
            "Test_Rows": row.get("test_rows", np.nan),
            "Accuracy": row.get("accuracy", np.nan),
            "Precision": row.get("precision", np.nan),
            "Recall": row.get("recall", np.nan),
            "F1": row.get("f1", np.nan),
            "ROC_AUC": row.get("roc_auc", np.nan),
            "MAE": np.nan,
            "RMSE": np.nan,
            "R2": np.nan,
            "Silhouette": np.nan,
            "Calinski_Harabasz": np.nan,
            "Davies_Bouldin": np.nan,
            "Notes": "Holdout binary classification evaluation"
        })


performance_df = pd.DataFrame(performance_rows)


# ----------------------------------------------------------------
# 3. FORMAT PERFORMANCE VALUES
# ----------------------------------------------------------------

metric_columns = [
    "Accuracy",
    "Precision",
    "Recall",
    "F1",
    "ROC_AUC",
    "MAE",
    "RMSE",
    "R2",
    "Silhouette",
    "Calinski_Harabasz",
    "Davies_Bouldin"
]

for col in metric_columns:
    if col in performance_df.columns:
        performance_df[col] = pd.to_numeric(
            performance_df[col],
            errors="coerce"
        )


# ----------------------------------------------------------------
# 4. PRINT CLASSIFICATION PERFORMANCE
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("A. CLASSIFICATION PERFORMANCE")
print("=" * 70)

classification_report = performance_df[
    performance_df["Task"] == "Classification"
].copy()

if not classification_report.empty:

    display(
        classification_report[
            [
                "Target",
                "Model",
                "Test_Rows",
                "Accuracy",
                "Precision",
                "Recall",
                "F1",
                "ROC_AUC"
            ]
        ].round(4)
    )

else:
    print("No classification models were evaluated.")


# ----------------------------------------------------------------
# 5. PRINT REGRESSION PERFORMANCE
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("B. REGRESSION PERFORMANCE")
print("=" * 70)

regression_report = performance_df[
    performance_df["Task"] == "Regression"
].copy()

if not regression_report.empty:

    display(
        regression_report[
            [
                "Target",
                "Model",
                "Test_Rows",
                "MAE",
                "RMSE",
                "R2"
            ]
        ].round(4)
    )

else:
    print("No regression models were evaluated.")


# ----------------------------------------------------------------
# 6. PRINT CLUSTERING PERFORMANCE
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("C. CLUSTERING PERFORMANCE")
print("=" * 70)

clustering_report = performance_df[
    performance_df["Task"] == "Clustering"
].copy()

if not clustering_report.empty:

    display(
        clustering_report[
            [
                "Model",
                "Silhouette",
                "Calinski_Harabasz",
                "Davies_Bouldin"
            ]
        ].round(4)
    )

else:
    print("No clustering models were evaluated.")


# ----------------------------------------------------------------
# 7. ANOMALY DETECTION SUMMARY
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("D. ANOMALY DETECTION PERFORMANCE")
print("=" * 70)

anomaly_file = os.path.join(
    CELL19_DIR,
    "Anomaly_Results.json"
)

anomaly_summary = {}

if os.path.exists(anomaly_file):

    with open(anomaly_file, "r") as f:
        anomaly_data = json.load(f)

    # Handle the expected dictionary structure
    if isinstance(anomaly_data, dict):

        for method, values in anomaly_data.items():

            if isinstance(values, dict):

                anomalies = values.get(
                    "anomalies",
                    values.get("anomaly_count", np.nan)
                )

                anomaly_pct = values.get(
                    "anomaly_pct",
                    np.nan
                )

                anomaly_summary[method] = {
                    "Anomalies": anomalies,
                    "Anomaly_Percentage": anomaly_pct
                }

    if anomaly_summary:

        anomaly_df = pd.DataFrame(
            anomaly_summary
        ).T.reset_index()

        anomaly_df.columns = [
            "Method",
            "Anomalies",
            "Anomaly_Percentage"
        ]

        display(anomaly_df.round(2))

    else:
        print("Anomaly results found but structure could not be parsed.")

else:
    print("Anomaly results file not found.")


# ----------------------------------------------------------------
# 8. PCA SUMMARY
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("E. PCA PERFORMANCE")
print("=" * 70)

pca_file = os.path.join(
    CELL19_DIR,
    "PCA_Results.json"
)

pca_summary = {}

if os.path.exists(pca_file):

    with open(pca_file, "r") as f:
        pca_data = json.load(f)

    # Search recursively for useful PCA information
    def find_pca_values(obj):

        result = {}

        if isinstance(obj, dict):

            for key, value in obj.items():

                key_lower = str(key).lower()

                if "80" in key_lower and isinstance(
                    value, (int, float)
                ):
                    result["Components_80pct"] = value

                if "90" in key_lower and isinstance(
                    value, (int, float)
                ):
                    result["Components_90pct"] = value

                if "cumulative" in key_lower:
                    result["Cumulative_Variance"] = value

                nested = find_pca_values(value)

                if nested:
                    result.update(nested)

        elif isinstance(obj, list):

            for item in obj:
                nested = find_pca_values(item)
                if nested:
                    result.update(nested)

        return result

    pca_summary = find_pca_values(pca_data)

    print(
        "PCA results loaded successfully."
    )

    if "Components_80pct" in pca_summary:
        print(
            f"Components for 80% variance : "
            f"{pca_summary['Components_80pct']}"
        )

    if "Components_90pct" in pca_summary:
        print(
            f"Components for 90% variance : "
            f"{pca_summary['Components_90pct']}"
        )

else:
    print("PCA results file not found.")


# ----------------------------------------------------------------
# 9. MCDA SUMMARY
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("F. MCDA SUMMARY")
print("=" * 70)

mcda_file = os.path.join(
    CELL19_DIR,
    "MCDA_Results.csv"
)

if os.path.exists(mcda_file):

    mcda_df = pd.read_csv(mcda_file)

    print(
        f"MCDA supplier-category records: "
        f"{len(mcda_df)}"
    )

    print(
        f"MCDA columns generated: "
        f"{len(mcda_df.columns)}"
    )

    print(
        "Available dimensions:"
    )

    for dimension in [
        "cost",
        "quality",
        "reliability",
        "risk",
        "sustainability"
    ]:
        print(f"  ✓ {dimension}")

else:
    print("MCDA results file not found.")


# ----------------------------------------------------------------
# 10. SAVE CONSOLIDATED REPORT
# ----------------------------------------------------------------

report_file = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Model_Performance_Report.csv"
)

performance_df.to_csv(
    report_file,
    index=False
)


# ----------------------------------------------------------------
# 11. SAVE JSON SUMMARY
# ----------------------------------------------------------------

json_summary = {
    "dataset": {
        "source": V360_WORK + "/Vendor360_Analysis_Base.csv"
    },
    "classification_models": len(classification_report),
    "regression_models": len(regression_report),
    "clustering_configurations": len(clustering_report),
    "anomaly_detection_available": bool(anomaly_summary),
    "pca_available": os.path.exists(pca_file),
    "mcda_available": os.path.exists(mcda_file),
    "report_file": report_file
}

json_file = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Model_Performance_Summary.json"
)

with open(json_file, "w") as f:
    json.dump(
        json_summary,
        f,
        indent=4,
        default=str
    )


# ----------------------------------------------------------------
# 12. FINAL STATUS
# ----------------------------------------------------------------

print("\n" + "=" * 70)
print("CELL 19.1 OUTPUT")
print("=" * 70)

print(f"✓ Consolidated report : {report_file}")
print(f"✓ JSON summary        : {json_file}")

print("\nModules included:")
print("✓ Classification metrics")
print("✓ Regression metrics")
print("✓ Clustering metrics")
print("✓ Anomaly detection")
print("✓ PCA")
print("✓ MCDA")

print("\nCELL 19.1 VALIDATION")
v360_status("CELL 19.1", {
    "consolidated report exists and is non-empty": lambda: v360_file_ok(report_file),
    "JSON summary exists and reloads": lambda: v360_json_ok(json_file),
})

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 40 =====

# ============================================================

import os
import json
import pandas as pd
import numpy as np

print("=" * 70)
print("VENDOR360 BUSINESS INTERPRETATION & SUPPLIER INSIGHTS")
print("=" * 70)

# ============================================================
# 1. PATHS
# ============================================================

BASE_PATH = V360_WORK + "/Vendor360_Analysis_Base.csv"
CELL19_DIR = V360_WORK + "/Vendor360_Cell19"
OUTPUT_DIR = V360_WORK + "/Vendor360_Cell20"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================
# 2. LOAD ANALYSIS BASE
# ============================================================

if not os.path.exists(BASE_PATH):
    raise FileNotFoundError(
        f"Analysis base not found: {BASE_PATH}"
    )

df = pd.read_csv(BASE_PATH)

print("\nDATASET")
print("-" * 70)
print(f"Rows          : {len(df)}")
print(f"Columns       : {len(df.columns)}")

# ============================================================
# 3. ENTITY DETECTION
# ============================================================

entity_col = None

preferred_entity_columns = [
    "entity_id",
    "supplier_id",
    "vendor_id",
    "company_id",
    "customer_id",
    "organization_id"
]

for col in preferred_entity_columns:
    if col in df.columns:
        entity_col = col
        break

if entity_col is None:

    entity_candidates = [
        c for c in df.columns
        if any(
            term in c.lower()
            for term in [
                "entity_id",
                "supplier_id",
                "vendor_id",
                "company_id"
            ]
        )
    ]

    if entity_candidates:
        entity_col = entity_candidates[0]

if entity_col is not None:

    entity_count = df[entity_col].nunique(
        dropna=True
    )

else:

    entity_count = len(df)

print(
    f"Entity column : "
    f"{entity_col if entity_col else 'Not detected'}"
)

print(f"Entity names  : {entity_count}")

# ============================================================
# 4. ANALYSIS GRAIN DETECTION
# ============================================================

context_columns = [
    c for c in df.columns
    if c.startswith("context__")
]

if entity_col and context_columns:

    context_name = context_columns[0].replace(
        "context__",
        ""
    )

    grain = f"Supplier + {context_name}"

elif entity_col:

    grain = "Entity"

else:

    grain = "Record"

print(f"Analysis grain: {grain}")

# ============================================================
# 5. BUSINESS DIMENSION DETECTION
# ============================================================

dimension_map = {

    "Cost": [
        "cost__"
    ],

    "Quality": [
        "quality__"
    ],

    "Reliability": [
        "reliability__"
    ],

    "Risk": [
        "risk__"
    ],

    "Sustainability": [
        "sustainability__"
    ],

    "Capacity": [
        "capacity__"
    ],

    "Status": [
        "status__"
    ],

    "Outcome": [
        "outcome__"
    ]
}

available_dimensions = {}

print("\nBUSINESS DIMENSIONS AVAILABLE")

for dimension, prefixes in dimension_map.items():

    matches = []

    for column in df.columns:

        column_lower = column.lower()

        if any(
            column_lower.startswith(
                prefix.lower()
            )
            for prefix in prefixes
        ):

            matches.append(column)

    # Reliability may also be represented by
    # historical lead-time data in the standardized base.
    if dimension == "Reliability":

        historical_lead_time_columns = [
            c for c in df.columns
            if (
                "historical_awards_lead_time"
                in c.lower()
            )
        ]

        for c in historical_lead_time_columns:

            if c not in matches:
                matches.append(c)

    available_dimensions[dimension] = matches

    if matches:

        print(f"✓ {dimension}")

    else:

        print(f"– {dimension}")

# ============================================================
# 6. CLUSTERING RESULTS
# ============================================================

print("\nCLUSTERING")

clustering_path = os.path.join(
    CELL19_DIR,
    "Clustering_Benchmark.csv"
)

selected_cluster = None
highest_silhouette = None

if os.path.exists(clustering_path):

    try:

        clustering_df = pd.read_csv(
            clustering_path
        )

        clustering_df.columns = [
            str(c).strip()
            for c in clustering_df.columns
        ]

        # Find silhouette column
        silhouette_col = next(
            (
                c for c in clustering_df.columns
                if "silhouette" in c.lower()
            ),
            None
        )

        # Find method / algorithm column
        method_col = next(
            (
                c for c in clustering_df.columns
                if c.lower() in [
                    "method",
                    "algorithm",
                    "model"
                ]
            ),
            None
        )

        # Find k column
        k_col = next(
            (
                c for c in clustering_df.columns
                if c.lower() in [
                    "k",
                    "n_clusters",
                    "clusters"
                ]
            ),
            None
        )

        if silhouette_col is not None:

            clustering_df[
                silhouette_col
            ] = pd.to_numeric(
                clustering_df[
                    silhouette_col
                ],
                errors="coerce"
            )

            valid = clustering_df.dropna(
                subset=[silhouette_col]
            )

            if len(valid) > 0:

                best_row = valid.loc[
                    valid[
                        silhouette_col
                    ].idxmax()
                ]

                highest_silhouette = float(
                    best_row[
                        silhouette_col
                    ]
                )

                method = (
                    str(
                        best_row[
                            method_col
                        ]
                    )
                    if method_col
                    else "Selected model"
                )

                if k_col:

                    k_value = str(
                        best_row[k_col]
                    )

                    selected_cluster = (
                        f"{method} k={k_value}"
                    )

                else:

                    selected_cluster = method

                print(
                    "Selected configuration: "
                    f"{selected_cluster}"
                )

                print(
                    "Highest individual Silhouette: "
                    f"{selected_cluster} = "
                    f"{highest_silhouette:.4f}"
                )

            else:

                print(
                    "No valid clustering benchmark "
                    "results found."
                )

        else:

            print(
                "Silhouette column not found."
            )

    except Exception as e:

        print(
            "Clustering results could not "
            f"be read: {e}"
        )

else:

    print(
        "Clustering results unavailable."
    )

# ============================================================
# 7. ANOMALY DETECTION
# ============================================================

print("\nANOMALY DETECTION")

anomaly_path = os.path.join(
    CELL19_DIR,
    "Anomaly_Results.json"
)

anomaly_available = False
anomaly_summary = []

if os.path.exists(anomaly_path):

    try:

        with open(
            anomaly_path,
            "r",
            encoding="utf-8"
        ) as f:

            anomaly_data = json.load(f)

        total_rows = len(df)

        # ----------------------------------------------------
        # Isolation Forest
        # ----------------------------------------------------

        isolation_forest = anomaly_data.get(
            "Isolation Forest"
        )

        if isinstance(
            isolation_forest,
            dict
        ):

            flagged = int(
                isolation_forest.get(
                    "anomalies",
                    0
                )
            )

            percentage = float(
                isolation_forest.get(
                    "anomaly_pct",
                    (
                        flagged / total_rows * 100
                        if total_rows
                        else 0
                    )
                )
            )

            print(
                "Isolation Forest: "
                f"{flagged}/{total_rows} flagged "
                f"({percentage:.2f}%)"
            )

            anomaly_summary.append({
                "method": "Isolation Forest",
                "flagged": flagged,
                "total": total_rows,
                "percentage": percentage
            })

            anomaly_available = True

        # ----------------------------------------------------
        # Local Outlier Factor
        # ----------------------------------------------------

        lof = anomaly_data.get(
            "Local Outlier Factor"
        )

        if isinstance(
            lof,
            dict
        ):

            flagged = int(
                lof.get(
                    "anomalies",
                    0
                )
            )

            percentage = float(
                lof.get(
                    "anomaly_pct",
                    (
                        flagged / total_rows * 100
                        if total_rows
                        else 0
                    )
                )
            )

            print(
                "Local Outlier Factor: "
                f"{flagged}/{total_rows} flagged "
                f"({percentage:.2f}%)"
            )

            anomaly_summary.append({
                "method": "Local Outlier Factor",
                "flagged": flagged,
                "total": total_rows,
                "percentage": percentage
            })

            anomaly_available = True

        if not anomaly_available:

            print(
                "Anomaly results file found, "
                "but no recognized anomaly metrics "
                "were detected."
            )

    except Exception as e:

        print(
            "Anomaly results could not "
            f"be read: {e}"
        )

else:

    print(
        "Anomaly detection unavailable."
    )

# ============================================================
# 8. PREDICTIVE ANALYSIS
# ============================================================

print("\nPREDICTIVE ANALYSIS")

regression_path = os.path.join(
    CELL19_DIR,
    "Regression_Benchmark.csv"
)

classification_path = os.path.join(
    CELL19_DIR,
    "Classification_Benchmark.csv"
)

predictive_available = False

# Regression
if os.path.exists(regression_path):

    try:

        regression_df = pd.read_csv(
            regression_path
        )

        if len(regression_df) > 0:

            predictive_available = True

    except Exception:
        pass

# Classification
if os.path.exists(
    classification_path
):

    try:

        classification_df = pd.read_csv(
            classification_path
        )

        if len(classification_df) > 0:

            predictive_available = True

    except Exception:
        pass

if predictive_available:

    print(
        "Predictive benchmarks available."
    )

else:

    print(
        "No valid predictive benchmarks available."
    )

# ============================================================
# 9. MCDA
# ============================================================

print("\nMCDA")

mcda_path = os.path.join(
    CELL19_DIR,
    "MCDA_Results.csv"
)

mcda_available = False
mcda_df = None

if os.path.exists(mcda_path):

    try:

        mcda_df = pd.read_csv(
            mcda_path
        )

        if len(mcda_df) > 0:

            mcda_available = True

            print(
                "✓ MCDA generated successfully"
            )

            print(
                "Dimensions: cost, quality, "
                "reliability, risk, sustainability"
            )

    except Exception as e:

        print(
            "MCDA results could not "
            f"be read: {e}"
        )

if not mcda_available:

    print(
        "– MCDA unavailable"
    )

# ============================================================
# 10. BUSINESS DIMENSION SUMMARY
# ============================================================

dimension_summary = []

for dimension, columns in (
    available_dimensions.items()
):

    for column in columns:

        numeric_values = pd.to_numeric(
            df[column],
            errors="coerce"
        )

        dimension_summary.append({

            "dimension": dimension,

            "feature": column,

            "available_values": int(
                numeric_values.notna().sum()
            ),

            "missing_values": int(
                numeric_values.isna().sum()
            ),

            "mean": (
                numeric_values.mean()
                if numeric_values.notna().any()
                else np.nan
            ),

            "median": (
                numeric_values.median()
                if numeric_values.notna().any()
                else np.nan
            )
        })

dimension_summary_df = pd.DataFrame(
    dimension_summary
)

dimension_summary_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Business_Dimension_Summary.csv"
)

dimension_summary_df.to_csv(
    dimension_summary_path,
    index=False
)

# ============================================================
# 11. BUSINESS INSIGHT FLAGS
# ============================================================

insight_flags = []

# ------------------------------------------------------------
# Anomaly insights
# ------------------------------------------------------------

for result in anomaly_summary:

    insight_flags.append({

        "insight_type":
            "Anomaly Detection",

        "method":
            result["method"],

        "description":
            (
                f'{result["flagged"]} of '
                f'{result["total"]} records flagged '
                f'as statistically unusual '
                f'({result["percentage"]:.2f}%). '
                "These should be treated as "
                "review candidates rather than "
                "confirmed supplier risks."
            )
    })

# ------------------------------------------------------------
# Clustering insight
# ------------------------------------------------------------

if selected_cluster is not None:

    insight_flags.append({

        "insight_type":
            "Segmentation",

        "method":
            selected_cluster,

        "description":
            (
                f"Selected clustering configuration: "
                f"{selected_cluster}, with highest "
                f"individual silhouette score of "
                f"{highest_silhouette:.4f}."
            )
    })

# ------------------------------------------------------------
# Predictive insight
# ------------------------------------------------------------

if predictive_available:

    insight_flags.append({

        "insight_type":
            "Predictive Analysis",

        "method":
            "Adaptive predictive modelling",

        "description":
            (
                "Predictive benchmark results are "
                "available for suitable targets "
                "detected in the dataset."
            )
    })

# ------------------------------------------------------------
# MCDA insight
# ------------------------------------------------------------

if mcda_available:

    insight_flags.append({

        "insight_type":
            "Decision Support",

        "method":
            "MCDA",

        "description":
            (
                "Multi-criteria supplier evaluation "
                "generated across cost, quality, "
                "reliability, risk and sustainability."
            )
    })

insight_flags_df = pd.DataFrame(
    insight_flags
)

insight_flags_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Business_Insight_Flags.csv"
)

insight_flags_df.to_csv(
    insight_flags_path,
    index=False
)

# ============================================================
# 12. BUSINESS INTERPRETATION SUMMARY
# ============================================================

interpretation_lines = []

interpretation_lines.append(
    "Vendor360 Business Interpretation Summary"
)

interpretation_lines.append(
    "=" * 55
)

interpretation_lines.append("")

interpretation_lines.append(
    f"Dataset contains {len(df)} analysis records "
    f"representing {entity_count} unique entities."
)

interpretation_lines.append(
    f"Analysis grain: {grain}."
)

interpretation_lines.append("")

# ------------------------------------------------------------
# Dimensions
# ------------------------------------------------------------

interpretation_lines.append(
    "Available business dimensions:"
)

for dimension, columns in (
    available_dimensions.items()
):

    if columns:

        interpretation_lines.append(
            f"- {dimension}: "
            f"{', '.join(columns)}"
        )

interpretation_lines.append("")

# ------------------------------------------------------------
# Clustering
# ------------------------------------------------------------

if selected_cluster:

    interpretation_lines.append(
        f"Clustering: {selected_cluster}; "
        f"highest individual silhouette = "
        f"{highest_silhouette:.4f}."
    )

else:

    interpretation_lines.append(
        "Clustering: benchmark results unavailable."
    )

interpretation_lines.append("")

# ------------------------------------------------------------
# Anomaly detection
# ------------------------------------------------------------

if anomaly_summary:

    interpretation_lines.append(
        "Anomaly detection:"
    )

    for result in anomaly_summary:

        interpretation_lines.append(
            f"- {result['method']}: "
            f"{result['flagged']}/"
            f"{result['total']} "
            f"({result['percentage']:.2f}%) "
            f"flagged as statistically unusual."
        )

    interpretation_lines.append(
        "Anomaly flags represent statistical "
        "review candidates and should not be "
        "treated as confirmed supplier risks."
    )

else:

    interpretation_lines.append(
        "Anomaly detection: unavailable."
    )

interpretation_lines.append("")

# ------------------------------------------------------------
# Predictive analysis
# ------------------------------------------------------------

if predictive_available:

    interpretation_lines.append(
        "Predictive analysis: benchmark "
        "results available."
    )

else:

    interpretation_lines.append(
        "Predictive analysis: no suitable "
        "predictive target/model available."
    )

interpretation_lines.append("")

# ------------------------------------------------------------
# MCDA
# ------------------------------------------------------------

if mcda_available:

    interpretation_lines.append(
        "MCDA: supplier decision-support analysis "
        "generated across five core dimensions."
    )

else:

    interpretation_lines.append(
        "MCDA: unavailable."
    )

interpretation_lines.append("")

# ------------------------------------------------------------
# Overall interpretation
# ------------------------------------------------------------

interpretation_lines.append(
    "Overall interpretation:"
)

interpretation_lines.append(
    "Vendor360 combines supplier segmentation, "
    "statistical review flags, predictive analysis "
    "where feasible, and multi-criteria decision "
    "support to assist supplier evaluation."
)

interpretation_lines.append(
    "The analytical outputs are intended to support "
    "human decision-making and should not be treated "
    "as autonomous purchasing decisions."
)

interpretation_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Business_Interpretation.txt"
)

with open(
    interpretation_path,
    "w",
    encoding="utf-8"
) as f:

    f.write(
        "\n".join(
            interpretation_lines
        )
    )

# ============================================================
# 13. FINAL OUTPUT
# ============================================================

print("\nOUTPUT FILES")
print("-" * 70)

print(
    "✓ Business dimension summary : "
    f"{dimension_summary_path}"
)

print(
    "✓ Business insight flags     : "
    f"{insight_flags_path}"
)

print(
    "✓ Interpretation summary     : "
    f"{interpretation_path}"
)

print("\nCELL 20 VALIDATION")
v360_status("CELL 20", {
    "dimension summary has rows": lambda: v360_csv_rows(dimension_summary_path) > 0,
    "insight flags file exists and is non-empty": lambda: v360_file_ok(insight_flags_path),
    "interpretation summary exists and is non-empty": lambda: v360_file_ok(interpretation_path),
})

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 42 =====

# ============================================================

import os
import json
import pandas as pd
import numpy as np

print("=" * 70)
print("VENDOR360 FINAL SOLUTION RECOMMENDATION & PROJECT REPORT")
print("=" * 70)

# ============================================================
# 1. PATHS
# ============================================================

BASE_PATH = V360_WORK + "/Vendor360_Analysis_Base.csv"
CELL19_DIR = V360_WORK + "/Vendor360_Cell19"
CELL20_DIR = V360_WORK + "/Vendor360_Cell20"
OUTPUT_DIR = V360_WORK + "/Vendor360_Cell21"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ============================================================
# 2. LOAD ANALYSIS BASE
# ============================================================

if not os.path.exists(BASE_PATH):
    raise FileNotFoundError(
        f"Analysis base not found: {BASE_PATH}"
    )

df = pd.read_csv(BASE_PATH)

# ============================================================
# 3. ENTITY DETECTION
# ============================================================

entity_col = None

preferred_entity_columns = [
    "entity_id",
    "supplier_id",
    "vendor_id",
    "company_id",
    "customer_id",
    "organization_id"
]

for col in preferred_entity_columns:
    if col in df.columns:
        entity_col = col
        break

if entity_col is None:

    entity_candidates = [
        c for c in df.columns
        if any(
            term in c.lower()
            for term in [
                "entity_id",
                "supplier_id",
                "vendor_id",
                "company_id"
            ]
        )
    ]

    if entity_candidates:
        entity_col = entity_candidates[0]

if entity_col is not None:
    unique_entities = df[
        entity_col
    ].nunique(dropna=True)
else:
    unique_entities = len(df)

# ============================================================
# 4. ANALYSIS GRAIN
# ============================================================

context_columns = [
    c for c in df.columns
    if c.startswith("context__")
]

if entity_col and context_columns:

    context_name = context_columns[0].replace(
        "context__",
        ""
    )

    analysis_grain = (
        f"Supplier + {context_name}"
    )

elif entity_col:

    analysis_grain = "Entity"

else:

    analysis_grain = "Record"

# ============================================================
# 5. BUSINESS DIMENSION DETECTION
# ============================================================

dimension_map = {
    "Cost": ["cost__"],
    "Quality": ["quality__"],
    "Reliability": ["reliability__"],
    "Risk": ["risk__"],
    "Sustainability": ["sustainability__"],
    "Capacity": ["capacity__"]
}

available_dimensions = {}

for dimension, prefixes in dimension_map.items():

    matches = []

    for column in df.columns:

        column_lower = column.lower()

        if any(
            column_lower.startswith(
                prefix.lower()
            )
            for prefix in prefixes
        ):
            matches.append(column)

    # Historical lead time can act as reliability
    if dimension == "Reliability":

        historical_lead_time = [
            c for c in df.columns
            if "historical_awards_lead_time"
            in c.lower()
        ]

        for c in historical_lead_time:

            if c not in matches:
                matches.append(c)

    available_dimensions[dimension] = matches

# ============================================================
# 6. CLUSTERING RESULTS
# ============================================================

clustering_path = os.path.join(
    CELL19_DIR,
    "Clustering_Benchmark.csv"
)

clustering_available = False
selected_cluster = None
highest_silhouette = None

if os.path.exists(clustering_path):

    try:

        clustering_df = pd.read_csv(
            clustering_path
        )

        clustering_df.columns = [
            str(c).strip()
            for c in clustering_df.columns
        ]

        silhouette_col = next(
            (
                c for c in clustering_df.columns
                if "silhouette" in c.lower()
            ),
            None
        )

        method_col = next(
            (
                c for c in clustering_df.columns
                if c.lower() in [
                    "method",
                    "algorithm",
                    "model"
                ]
            ),
            None
        )

        k_col = next(
            (
                c for c in clustering_df.columns
                if c.lower() in [
                    "k",
                    "n_clusters",
                    "clusters"
                ]
            ),
            None
        )

        if silhouette_col:

            clustering_df[
                silhouette_col
            ] = pd.to_numeric(
                clustering_df[
                    silhouette_col
                ],
                errors="coerce"
            )

            valid = clustering_df.dropna(
                subset=[silhouette_col]
            )

            if len(valid) > 0:

                best_row = valid.loc[
                    valid[
                        silhouette_col
                    ].idxmax()
                ]

                highest_silhouette = float(
                    best_row[
                        silhouette_col
                    ]
                )

                method = (
                    str(
                        best_row[
                            method_col
                        ]
                    )
                    if method_col
                    else "Selected model"
                )

                if k_col:

                    k_value = str(
                        best_row[k_col]
                    )

                    selected_cluster = (
                        f"{method} k={k_value}"
                    )

                else:

                    selected_cluster = method

                clustering_available = True

    except Exception as e:

        print(
            f"Warning: clustering results "
            f"could not be read: {e}"
        )

# ============================================================
# 7. ANOMALY DETECTION
# ============================================================

anomaly_path = os.path.join(
    CELL19_DIR,
    "Anomaly_Results.json"
)

anomaly_available = False
anomaly_results = []

if os.path.exists(anomaly_path):

    try:

        with open(
            anomaly_path,
            "r",
            encoding="utf-8"
        ) as f:

            anomaly_data = json.load(f)

        total_rows = len(df)

        # -------------------------------
        # Isolation Forest
        # -------------------------------

        isolation_data = anomaly_data.get(
            "Isolation Forest"
        )

        if isinstance(
            isolation_data,
            dict
        ):

            flagged = int(
                isolation_data.get(
                    "anomalies",
                    0
                )
            )

            percentage = float(
                isolation_data.get(
                    "anomaly_pct",
                    (
                        flagged / total_rows * 100
                        if total_rows
                        else 0
                    )
                )
            )

            anomaly_results.append({
                "method": "Isolation Forest",
                "flagged": flagged,
                "total": total_rows,
                "percentage": percentage
            })

            anomaly_available = True

        # -------------------------------
        # Local Outlier Factor
        # -------------------------------

        lof_data = anomaly_data.get(
            "Local Outlier Factor"
        )

        if isinstance(
            lof_data,
            dict
        ):

            flagged = int(
                lof_data.get(
                    "anomalies",
                    0
                )
            )

            percentage = float(
                lof_data.get(
                    "anomaly_pct",
                    (
                        flagged / total_rows * 100
                        if total_rows
                        else 0
                    )
                )
            )

            anomaly_results.append({
                "method": "Local Outlier Factor",
                "flagged": flagged,
                "total": total_rows,
                "percentage": percentage
            })

            anomaly_available = True

    except Exception as e:

        print(
            f"Warning: anomaly results "
            f"could not be read: {e}"
        )

# ============================================================
# 8. PREDICTIVE MODELLING
# ============================================================

regression_path = os.path.join(
    CELL19_DIR,
    "Regression_Benchmark.csv"
)

classification_path = os.path.join(
    CELL19_DIR,
    "Classification_Benchmark.csv"
)

regression_available = False
classification_available = False

if os.path.exists(regression_path):

    try:

        regression_df = pd.read_csv(
            regression_path
        )

        if len(regression_df) > 0:
            regression_available = True

    except Exception:
        regression_available = False

if os.path.exists(
    classification_path
):

    try:

        classification_df = pd.read_csv(
            classification_path
        )

        if len(classification_df) > 0:
            classification_available = True

    except Exception:
        classification_available = False

predictive_available = (
    regression_available
    or classification_available
)

# ============================================================
# 9. PCA
# ============================================================

pca_path = os.path.join(
    CELL19_DIR,
    "PCA_Results.json"
)

pca_available = os.path.exists(
    pca_path
)

# ============================================================
# 10. MCDA
# ============================================================

mcda_path = os.path.join(
    CELL19_DIR,
    "MCDA_Results.csv"
)

mcda_available = False

if os.path.exists(mcda_path):

    try:

        mcda_df = pd.read_csv(
            mcda_path
        )

        if len(mcda_df) > 0:
            mcda_available = True

    except Exception:
        mcda_available = False

# ============================================================
# 11. BUSINESS FINDINGS
# ============================================================

findings = []

findings.append({
    "category": "Dataset",
    "finding": (
        f"The standardized analysis base contains "
        f"{len(df)} records representing "
        f"{unique_entities} unique entities "
        f"at the {analysis_grain} grain."
    )
})

dimension_names = [
    dimension
    for dimension, columns
    in available_dimensions.items()
    if columns
]

findings.append({
    "category": "Business Dimensions",
    "finding": (
        "Available analytical dimensions: "
        + ", ".join(dimension_names)
        + "."
    )
})

if clustering_available:

    findings.append({
        "category": "Segmentation",
        "finding": (
            f"{selected_cluster} produced the "
            f"highest individual silhouette score "
            f"of {highest_silhouette:.4f} "
            f"among the benchmarked configurations."
        )
    })

if anomaly_available:

    for result in anomaly_results:

        findings.append({
            "category": "Anomaly Detection",
            "finding": (
                f'{result["method"]} flagged '
                f'{result["flagged"]} of '
                f'{result["total"]} records '
                f'({result["percentage"]:.2f}%) '
                f'as statistically unusual.'
            )
        })

if predictive_available:

    predictive_types = []

    if regression_available:
        predictive_types.append("regression")

    if classification_available:
        predictive_types.append("classification")

    findings.append({
        "category": "Predictive Modelling",
        "finding": (
            "Adaptive predictive benchmarking "
            "was available for "
            + " and ".join(
                predictive_types
            )
            + "."
        )
    })

if mcda_available:

    findings.append({
        "category": "Decision Support",
        "finding": (
            "MCDA generated supplier "
            "decision-support analysis across "
            "cost, quality, reliability, "
            "risk and sustainability."
        )
    })

# ============================================================
# 12. STAKEHOLDER ANALYSIS
# ============================================================

stakeholder_records = [

    {
        "stakeholder": "Procurement Management",
        "interest":
            "Supplier selection and procurement performance",
        "Vendor360_use":
            "MCDA, supplier segmentation and monitoring"
    },

    {
        "stakeholder": "Procurement Analysts",
        "interest":
            "Supplier comparison and analytical insights",
        "Vendor360_use":
            "Dashboards, benchmarks and supplier comparison"
    },

    {
        "stakeholder": "Supplier Management",
        "interest":
            "Supplier performance and relationship monitoring",
        "Vendor360_use":
            "Performance and anomaly review"
    },

    {
        "stakeholder": "Risk / Compliance Team",
        "interest":
            "Supplier risk and policy compliance",
        "Vendor360_use":
            "Risk indicators and anomaly review"
    },

    {
        "stakeholder": "Quality Management",
        "interest":
            "Quality performance and reliability",
        "Vendor360_use":
            "Quality and reliability indicators"
    },

    {
        "stakeholder": "Sustainability / ESG Team",
        "interest":
            "Sustainability performance",
        "Vendor360_use":
            "Sustainability indicators"
    },

    {
        "stakeholder": "Business Management",
        "interest":
            "Cross-functional supplier decision support",
        "Vendor360_use":
            "Integrated supplier decision support"
    }
]

stakeholders = pd.DataFrame(
    stakeholder_records
)

stakeholder_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Stakeholder_Analysis.csv"
)

stakeholders.to_csv(
    stakeholder_path,
    index=False
)

# ============================================================
# 13. REQUIREMENTS
# ============================================================

# List of dictionaries deliberately used here so every
# requirement is guaranteed to have the same structure.

requirement_records = [

    {
        "requirement_id": "REQ-01",
        "requirement":
            "Accept supplier data from one or multiple datasets",
        "priority": "High"
    },

    {
        "requirement_id": "REQ-02",
        "requirement":
            "Detect available supplier business dimensions",
        "priority": "High"
    },

    {
        "requirement_id": "REQ-03",
        "requirement":
            "Standardize supplier data into a common analysis base",
        "priority": "High"
    },

    {
        "requirement_id": "REQ-04",
        "requirement":
            "Validate data quality and analytical feasibility",
        "priority": "High"
    },

    {
        "requirement_id": "REQ-05",
        "requirement":
            "Segment suppliers using adaptive analytical methods",
        "priority": "Medium"
    },

    {
        "requirement_id": "REQ-06",
        "requirement":
            "Identify statistically unusual supplier records",
        "priority": "Medium"
    },

    {
        "requirement_id": "REQ-07",
        "requirement":
            "Evaluate suppliers using multiple decision criteria",
        "priority": "High"
    },

    {
        "requirement_id": "REQ-08",
        "requirement":
            "Provide transparent decision-support outputs",
        "priority": "High"
    }
]

requirements = pd.DataFrame(
    requirement_records
)

requirements_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Requirements.csv"
)

requirements.to_csv(
    requirements_path,
    index=False
)

# ============================================================
# 14. FINAL FINDINGS FILE
# ============================================================

findings_df = pd.DataFrame(
    findings
)

findings_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Final_Findings.csv"
)

findings_df.to_csv(
    findings_path,
    index=False
)

# ============================================================
# 15. FINAL RECOMMENDATION
# ============================================================

recommendation = {

    "project":
        "Vendor360",

    "purpose":
        (
            "Integrated framework for supplier "
            "risk, performance and sustainability "
            "analysis."
        ),

    "recommendation":
        (
            "Implement Vendor360 as a transparent "
            "supplier decision-support framework, "
            "not an autonomous purchasing system."
        ),

    "decision_support_scope": [
        "Supplier evaluation",
        "Supplier comparison",
        "Supplier segmentation",
        "Risk and unusual-pattern review",
        "Multi-criteria supplier assessment",
        "Performance monitoring"
    ],

    "analytical_modules": {

        "adaptive_standardization": True,

        "validation": True,

        "clustering":
            clustering_available,

        "pca":
            pca_available,

        "anomaly_detection":
            anomaly_available,

        "predictive_modelling":
            predictive_available,

        "mcda":
            mcda_available,

        "business_interpretation":
            True
    },

    "validation_context":
        (
            "The adaptive Vendor360 pipeline has "
            "been validated using both a single-"
            "dataset supplier input and the "
            "multi-dataset ChainIQ development "
            "input."
        ),

    "limitations": [

        (
            "Analytical results depend on the "
            "quality and availability of input data."
        ),

        (
            "Predictive modelling is only performed "
            "when a suitable target is detected."
        ),

        (
            "Anomaly flags identify statistically "
            "unusual observations and do not by "
            "themselves establish supplier risk."
        ),

        (
            "MCDA weights represent analytical "
            "assumptions and should be reviewed "
            "by business stakeholders."
        ),

        (
            "The framework supports human decision-"
            "making rather than autonomous purchasing."
        )
    ]
}

recommendation_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Recommendation.json"
)

with open(
    recommendation_path,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        recommendation,
        f,
        indent=2
    )

# ============================================================
# 16. FINAL TEXT REPORT
# ============================================================

report_lines = []

report_lines.append(
    "=" * 70
)

report_lines.append(
    "VENDOR360 FINAL SOLUTION RECOMMENDATION & PROJECT REPORT"
)

report_lines.append(
    "=" * 70
)

report_lines.append("")

report_lines.append("PROJECT")

report_lines.append(
    "Vendor360 — Integrated Framework for Supplier "
    "Risk, Performance and Sustainability Analysis"
)

report_lines.append("")

report_lines.append("DATASET")

report_lines.append(
    f"Rows                : {len(df)}"
)

report_lines.append(
    f"Columns             : {len(df.columns)}"
)

report_lines.append(
    f"Unique entities     : {unique_entities}"
)

report_lines.append(
    f"Analysis grain      : {analysis_grain}"
)

report_lines.append("")

# ------------------------------------------------------------
# Business dimensions
# ------------------------------------------------------------

report_lines.append(
    "BUSINESS DIMENSIONS"
)

for dimension in [
    "Cost",
    "Quality",
    "Reliability",
    "Risk",
    "Sustainability",
    "Capacity"
]:

    if available_dimensions.get(
        dimension
    ):

        report_lines.append(
            f"✓ {dimension}"
        )

    else:

        report_lines.append(
            f"– {dimension}"
        )

report_lines.append("")

# ------------------------------------------------------------
# Analytical modules
# ------------------------------------------------------------

report_lines.append(
    "ANALYTICAL MODULES"
)

report_lines.append(
    "✓ Adaptive data standardization"
)

report_lines.append(
    "✓ Data validation"
)

report_lines.append(
    "✓ Clustering / segmentation"
    if clustering_available
    else
    "– Clustering / segmentation unavailable"
)

report_lines.append(
    "✓ PCA"
    if pca_available
    else
    "– PCA unavailable"
)

report_lines.append(
    "✓ Anomaly detection"
    if anomaly_available
    else
    "– Anomaly detection unavailable"
)

report_lines.append(
    "✓ Adaptive predictive modelling"
    if predictive_available
    else
    "– Adaptive predictive modelling skipped "
    "(no suitable target)"
)

report_lines.append(
    "✓ MCDA decision support"
    if mcda_available
    else
    "– MCDA unavailable"
)

report_lines.append(
    "✓ Business interpretation"
)

report_lines.append("")

# ------------------------------------------------------------
# Key analytical results
# ------------------------------------------------------------

report_lines.append(
    "KEY ANALYTICAL RESULTS"
)

if clustering_available:

    report_lines.append(
        f"- Clustering: {selected_cluster}"
    )

    report_lines.append(
        f"- Highest individual silhouette: "
        f"{highest_silhouette:.4f}"
    )

if anomaly_available:

    for result in anomaly_results:

        report_lines.append(
            f"- {result['method']}: "
            f"{result['flagged']}/"
            f"{result['total']} flagged "
            f"({result['percentage']:.2f}%)"
        )

if predictive_available:

    report_lines.append(
        "- Predictive benchmarks available "
        "for suitable detected targets."
    )

else:

    report_lines.append(
        "- No suitable predictive target was "
        "available for this dataset."
    )

if mcda_available:

    report_lines.append(
        "- MCDA generated across cost, quality, "
        "reliability, risk and sustainability."
    )

report_lines.append("")

# ------------------------------------------------------------
# Recommendation
# ------------------------------------------------------------

report_lines.append(
    "FINAL RECOMMENDATION"
)

report_lines.append(
    "Implement Vendor360 as a transparent supplier "
    "decision-support framework, not an autonomous "
    "purchasing system."
)

report_lines.append("")

report_lines.append(
    "The framework is intended to support human "
    "decision-making by bringing together supplier "
    "information, business-dimension analysis, "
    "segmentation, statistical review flags, "
    "predictive analysis where feasible, and "
    "multi-criteria evaluation."
)

report_lines.append("")

# ------------------------------------------------------------
# Validation
# ------------------------------------------------------------

report_lines.append(
    "VALIDATION STATUS"
)

report_lines.append(
    "✓ Single-dataset supplier validation"
)

report_lines.append(
    "✓ Multi-dataset ChainIQ validation"
)

report_lines.append(
    "The adaptive pipeline adjusts its analytical "
    "modules according to the fields, dimensions "
    "and targets available in the supplied data."
)

report_lines.append("")

# ------------------------------------------------------------
# Limitations
# ------------------------------------------------------------

report_lines.append(
    "LIMITATIONS"
)

for limitation in recommendation[
    "limitations"
]:

    report_lines.append(
        f"- {limitation}"
    )

report_lines.append("")

report_lines.append(
    "=" * 70
)

report_text = "\n".join(
    report_lines
)

txt_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Final_Project_Report.txt"
)

with open(
    txt_path,
    "w",
    encoding="utf-8"
) as f:

    f.write(report_text)

# ============================================================
# 17. FINAL MARKDOWN REPORT
# ============================================================

markdown_lines = []

markdown_lines.append(
    "# Vendor360 Final Solution Recommendation & Project Report"
)

markdown_lines.append("")

markdown_lines.append(
    "## Project"
)

markdown_lines.append(
    "Vendor360 — Integrated Framework for Supplier "
    "Risk, Performance and Sustainability Analysis"
)

markdown_lines.append("")

markdown_lines.append(
    "## Dataset"
)

markdown_lines.append(
    f"- Rows: {len(df)}"
)

markdown_lines.append(
    f"- Columns: {len(df.columns)}"
)

markdown_lines.append(
    f"- Unique entities: {unique_entities}"
)

markdown_lines.append(
    f"- Analysis grain: {analysis_grain}"
)

markdown_lines.append("")

markdown_lines.append(
    "## Business Dimensions"
)

for dimension in [
    "Cost",
    "Quality",
    "Reliability",
    "Risk",
    "Sustainability",
    "Capacity"
]:

    if available_dimensions.get(
        dimension
    ):

        markdown_lines.append(
            f"- ✓ {dimension}"
        )

    else:

        markdown_lines.append(
            f"- – {dimension}"
        )

markdown_lines.append("")

markdown_lines.append(
    "## Analytical Modules"
)

markdown_lines.append(
    "- ✓ Adaptive data standardization"
)

markdown_lines.append(
    "- ✓ Data validation"
)

markdown_lines.append(
    (
        "- ✓ Clustering / segmentation"
        if clustering_available
        else
        "- – Clustering / segmentation unavailable"
    )
)

markdown_lines.append(
    (
        "- ✓ PCA"
        if pca_available
        else
        "- – PCA unavailable"
    )
)

markdown_lines.append(
    (
        "- ✓ Anomaly detection"
        if anomaly_available
        else
        "- – Anomaly detection unavailable"
    )
)

markdown_lines.append(
    (
        "- ✓ Adaptive predictive modelling"
        if predictive_available
        else
        "- – Adaptive predictive modelling "
        "skipped (no suitable target)"
    )
)

markdown_lines.append(
    (
        "- ✓ MCDA decision support"
        if mcda_available
        else
        "- – MCDA unavailable"
    )
)

markdown_lines.append(
    "- ✓ Business interpretation"
)

markdown_lines.append("")

markdown_lines.append(
    "## Key Analytical Results"
)

if clustering_available:

    markdown_lines.append(
        f"- **Clustering:** {selected_cluster}"
    )

    markdown_lines.append(
        f"- **Highest individual silhouette:** "
        f"{highest_silhouette:.4f}"
    )

if anomaly_available:

    for result in anomaly_results:

        markdown_lines.append(
            f"- **{result['method']}:** "
            f"{result['flagged']}/"
            f"{result['total']} flagged "
            f"({result['percentage']:.2f}%)"
        )

if predictive_available:

    markdown_lines.append(
        "- Predictive benchmarks available "
        "for suitable detected targets."
    )

else:

    markdown_lines.append(
        "- No suitable predictive target was "
        "available for this dataset."
    )

if mcda_available:

    markdown_lines.append(
        "- MCDA generated across cost, quality, "
        "reliability, risk and sustainability."
    )

markdown_lines.append("")

markdown_lines.append(
    "## Final Recommendation"
)

markdown_lines.append(
    "> Implement Vendor360 as a transparent "
    "supplier decision-support framework, "
    "not an autonomous purchasing system."
)

markdown_lines.append("")

markdown_lines.append(
    "The framework is intended to support human "
    "decision-making by bringing together supplier "
    "information, business-dimension analysis, "
    "segmentation, statistical review flags, "
    "predictive analysis where feasible, and "
    "multi-criteria evaluation."
)

markdown_lines.append("")

markdown_lines.append(
    "## Validation Status"
)

markdown_lines.append(
    "- ✓ Single-dataset supplier validation"
)

markdown_lines.append(
    "- ✓ Multi-dataset ChainIQ validation"
)

markdown_lines.append("")

markdown_lines.append(
    "## Limitations"
)

for limitation in recommendation[
    "limitations"
]:

    markdown_lines.append(
        f"- {limitation}"
    )

markdown_text = "\n".join(
    markdown_lines
)

md_path = os.path.join(
    OUTPUT_DIR,
    "Vendor360_Final_Project_Report.md"
)

with open(
    md_path,
    "w",
    encoding="utf-8"
) as f:

    f.write(markdown_text)

# ============================================================
# 18. FINAL CONSOLE OUTPUT
# ============================================================

print("\nDATASET")
print("-" * 70)

print(
    f"Rows                : {len(df)}"
)

print(
    f"Columns             : {len(df.columns)}"
)

print(
    f"Unique entities     : {unique_entities}"
)

print(
    f"Analysis grain      : {analysis_grain}"
)

print("\nBUSINESS DIMENSIONS")

for dimension in [
    "Cost",
    "Quality",
    "Reliability",
    "Risk",
    "Sustainability",
    "Capacity"
]:

    if available_dimensions.get(
        dimension
    ):

        print(
            f"✓ {dimension}"
        )

    else:

        print(
            f"– {dimension}"
        )

print("\nANALYTICAL MODULES")

print(
    "✓ Adaptive data standardization"
)

print(
    "✓ Data validation"
)

print(
    "✓ Clustering / segmentation"
    if clustering_available
    else
    "– Clustering / segmentation unavailable"
)

print(
    "✓ PCA"
    if pca_available
    else
    "– PCA unavailable"
)

print(
    "✓ Anomaly detection"
    if anomaly_available
    else
    "– Anomaly detection unavailable"
)

print(
    "✓ Adaptive predictive modelling"
    if predictive_available
    else
    "– Adaptive predictive modelling skipped "
    "(no suitable target)"
)

print(
    "✓ MCDA decision support"
    if mcda_available
    else
    "– MCDA unavailable"
)

print(
    "✓ Business interpretation"
)

# ============================================================
# ANOMALY RESULTS
# ============================================================

if anomaly_available:

    print("\nANOMALY RESULTS")

    for result in anomaly_results:

        print(
            f"{result['method']}: "
            f"{result['flagged']}/"
            f"{result['total']} "
            f"({result['percentage']:.2f}%)"
        )

# ============================================================
# FINAL OUTPUT FILES
# ============================================================

print("\nOUTPUT FILES")

print(
    f"✓ {txt_path}"
)

print(
    f"✓ {md_path}"
)

print(
    f"✓ {findings_path}"
)

print(
    f"✓ {recommendation_path}"
)

print(
    f"✓ {stakeholder_path}"
)

print(
    f"✓ {requirements_path}"
)

print("\nFINAL RECOMMENDATION")

print(
    "Implement Vendor360 as a transparent supplier "
    "decision-support framework, not an autonomous "
    "purchasing system."
)

print("\nCELL 21 VALIDATION (only checks that were actually executed are listed)")
v360_status("CELL 21", {
    "requirements table has rows": lambda: v360_csv_rows(requirements_path) > 0,
    "upstream MCDA results (Cell 19) exist": lambda: v360_file_ok(CELL19_DIR + "/MCDA_Results.csv"),
})

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 44 =====

# ============================================================

import os
import json
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime

print("=" * 70)
print("VENDOR360 AUTOMATED PROJECT / QUALITY AUDIT")
print("=" * 70)

# ------------------------------------------------------------
# 1. PATHS
# ------------------------------------------------------------

BASE_DIR = V360_WORK
CELL17_DIR = V360_WORK
CELL19_DIR = V360_WORK + "/Vendor360_Cell19"
CELL20_DIR = V360_WORK + "/Vendor360_Cell20"
CELL21_DIR = V360_WORK + "/Vendor360_Cell21"

AUDIT_DIR = V360_WORK + "/Vendor360_Cell22"
os.makedirs(AUDIT_DIR, exist_ok=True)

BASE_FILE = V360_WORK + "/Vendor360_Analysis_Base.csv"
DICT_FILE = V360_WORK + "/Vendor360_Data_Dictionary.csv"
META_FILE = V360_WORK + "/Vendor360_Metadata.json"

# ------------------------------------------------------------
# 2. EXPECTED OUTPUTS
# ------------------------------------------------------------

expected_files = {
    "Analysis Base": BASE_FILE,
    "Data Dictionary": DICT_FILE,
    "Metadata": META_FILE,

    # Cell 19
    "Anomaly Results": f"{CELL19_DIR}/Anomaly_Results.json",
    "Clustering Benchmark": f"{CELL19_DIR}/Clustering_Benchmark.csv",
    "PCA Results": f"{CELL19_DIR}/PCA_Results.json",
    "Regression Benchmark": f"{CELL19_DIR}/Regression_Benchmark.csv",
    "Classification Benchmark": f"{CELL19_DIR}/Classification_Benchmark.csv",
    "MCDA Results": f"{CELL19_DIR}/MCDA_Results.csv",

    # Cell 20
    "Business Dimension Summary":
        f"{CELL20_DIR}/Vendor360_Business_Dimension_Summary.csv",

    "Business Insight Flags":
        f"{CELL20_DIR}/Vendor360_Business_Insight_Flags.csv",

    "Interpretation Summary":
        f"{CELL20_DIR}/Vendor360_Business_Interpretation.txt",

    # Cell 21
    "Final Project Report":
        f"{CELL21_DIR}/Vendor360_Final_Project_Report.txt",

    "Final Findings":
        f"{CELL21_DIR}/Vendor360_Final_Findings.csv",

    "Recommendation":
        f"{CELL21_DIR}/Vendor360_Recommendation.json",

    "Stakeholder Analysis":
        f"{CELL21_DIR}/Vendor360_Stakeholder_Analysis.csv",

    "Requirements":
        f"{CELL21_DIR}/Vendor360_Requirements.csv",
}

# ------------------------------------------------------------
# 3. FILE EXISTENCE AUDIT
# ------------------------------------------------------------

print("\n[1] OUTPUT FILE AUDIT")
print("-" * 70)

file_audit = []

for name, path in expected_files.items():

    exists = os.path.exists(path)

    size_kb = (
        os.path.getsize(path) / 1024
        if exists else 0
    )

    file_audit.append({
        "output": name,
        "path": path,
        "exists": exists,
        "size_kb": round(size_kb, 2)
    })

    status = "✓ PASS" if exists else "✗ MISSING"

    print(f"{status:<10} {name}")

file_audit_df = pd.DataFrame(file_audit)

# ------------------------------------------------------------
# 4. LOAD ANALYSIS BASE
# ------------------------------------------------------------

print("\n[2] ANALYSIS BASE AUDIT")
print("-" * 70)

base_loaded = False

if os.path.exists(BASE_FILE):

    base_df = pd.read_csv(BASE_FILE)

    base_loaded = True

    rows, cols = base_df.shape

    print(f"Rows                 : {rows}")
    print(f"Columns              : {cols}")

else:

    base_df = pd.DataFrame()

    rows = 0
    cols = 0

    print("✗ Analysis base not found")

# ------------------------------------------------------------
# 5. ENTITY AUDIT
# ------------------------------------------------------------

entity_audit = {
    "entity_column": None,
    "unique_entities": None,
    "missing_entity_ids": None,
    "duplicate_rows": None
}

if base_loaded:

    possible_entity_columns = [
        "entity_id",
        "supplier_id",
        "Supplier ID",
        "vendor_id",
        "Vendor ID"
    ]

    entity_col = next(
        (
            c for c in possible_entity_columns
            if c in base_df.columns
        ),
        None
    )

    entity_audit["entity_column"] = entity_col

    if entity_col:

        entity_audit["unique_entities"] = int(
            base_df[entity_col].nunique()
        )

        entity_audit["missing_entity_ids"] = int(
            base_df[entity_col].isna().sum()
        )

    entity_audit["duplicate_rows"] = int(
        base_df.duplicated().sum()
    )

    print(
        f"Entity column        : "
        f"{entity_audit['entity_column']}"
    )

    print(
        f"Unique entities      : "
        f"{entity_audit['unique_entities']}"
    )

    print(
        f"Missing entity IDs   : "
        f"{entity_audit['missing_entity_ids']}"
    )

    print(
        f"Duplicate rows       : "
        f"{entity_audit['duplicate_rows']}"
    )

# ------------------------------------------------------------
# 6. MISSING VALUE AUDIT
# ------------------------------------------------------------

print("\n[3] MISSING VALUE AUDIT")
print("-" * 70)

missing_summary = []

if base_loaded:

    for col in base_df.columns:

        missing = int(base_df[col].isna().sum())

        pct = (
            missing / len(base_df) * 100
            if len(base_df) > 0
            else 0
        )

        missing_summary.append({
            "column": col,
            "missing_count": missing,
            "missing_pct": round(pct, 2)
        })

    missing_df = pd.DataFrame(missing_summary)

    total_missing_cells = int(
        missing_df["missing_count"].sum()
    )

    columns_with_missing = int(
        (missing_df["missing_count"] > 0).sum()
    )

    print(f"Total missing cells  : {total_missing_cells}")
    print(
        f"Columns with missing : "
        f"{columns_with_missing}"
    )

else:

    missing_df = pd.DataFrame()

# ------------------------------------------------------------
# 7. DATA TYPE AUDIT
# ------------------------------------------------------------

print("\n[4] DATA TYPE AUDIT")
print("-" * 70)

dtype_summary = []

if base_loaded:

    for col in base_df.columns:

        dtype_summary.append({
            "column": col,
            "dtype": str(base_df[col].dtype),
            "unique_values": int(
                base_df[col].nunique(dropna=True)
            )
        })

    dtype_df = pd.DataFrame(dtype_summary)

    print(
        f"Numeric columns     : "
        f"{base_df.select_dtypes(include=np.number).shape[1]}"
    )

    print(
        f"Categorical columns : "
        f"{base_df.select_dtypes(include=["object", "category"]).shape[1]}"
    )

else:

    dtype_df = pd.DataFrame()

# ------------------------------------------------------------
# 8. ANALYTICAL MODULE AUDIT
# ------------------------------------------------------------

print("\n[5] ANALYTICAL MODULE AUDIT")
print("-" * 70)

module_files = {
    "Clustering": [
        f"{CELL19_DIR}/Clustering_Benchmark.csv"
    ],

    "PCA": [
        f"{CELL19_DIR}/PCA_Results.json"
    ],

    "Anomaly Detection": [
        f"{CELL19_DIR}/Anomaly_Results.json"
    ],

    "Regression": [
        f"{CELL19_DIR}/Regression_Benchmark.csv"
    ],

    "Classification": [
        f"{CELL19_DIR}/Classification_Benchmark.csv"
    ],

    "MCDA": [
        f"{CELL19_DIR}/MCDA_Results.csv"
    ],

    "Business Interpretation": [
        f"{CELL20_DIR}/Vendor360_Business_Interpretation.txt"
    ],

    "Final Recommendation": [
        f"{CELL21_DIR}/Vendor360_Recommendation.json"
    ]
}

module_audit = []

for module, paths in module_files.items():

    available = any(
        os.path.exists(p)
        for p in paths
    )

    module_audit.append({
        "module": module,
        "available": available
    })

    print(
        f"{'✓ AVAILABLE' if available else '– NOT AVAILABLE':<18}"
        f"{module}"
    )

module_df = pd.DataFrame(module_audit)

# ------------------------------------------------------------
# 9. DIMENSION DETECTION
# ------------------------------------------------------------

print("\n[6] BUSINESS DIMENSION AUDIT")
print("-" * 70)

dimension_patterns = {

    "Cost": [
        "cost__",
        "price",
        "unit_cost",
        "cost_score"
    ],

    "Quality": [
        "quality",
        "quality__"
    ],

    "Reliability": [
        "reliability",
        "lead_time",
        "on_time",
        "delay"
    ],

    "Risk": [
        "risk",
        "risk__"
    ],

    "Sustainability": [
        "sustainability",
        "esg"
    ],

    "Capacity": [
        "capacity"
    ],

    "Status": [
        "preferred",
        "restricted",
        "contract_status"
    ],

    "Outcome": [
        "outcome__",
        "award",
        "savings",
        "historical"
    ]
}

dimension_audit = []

if base_loaded:

    columns_lower = {
        c: c.lower()
        for c in base_df.columns
    }

    for dimension, patterns in dimension_patterns.items():

        matched_columns = []

        for col, lower_col in columns_lower.items():

            if any(
                pattern.lower() in lower_col
                for pattern in patterns
            ):
                matched_columns.append(col)

        dimension_audit.append({
            "dimension": dimension,
            "available": len(matched_columns) > 0,
            "matched_columns": ", ".join(
                matched_columns
            )
        })

        print(
            f"{'✓' if matched_columns else '–'} "
            f"{dimension:<18} "
            f"{len(matched_columns)} feature(s)"
        )

else:

    dimension_audit = []

dimension_df = pd.DataFrame(dimension_audit)

# ------------------------------------------------------------
# 10. QUALITY CHECKS
# ------------------------------------------------------------

print("\n[7] QUALITY CHECKS")
print("-" * 70)

checks = []

def add_check(name, passed, details):

    checks.append({
        "check": name,
        "status": "PASS" if passed else "REVIEW",
        "details": details
    })

# Base exists
add_check(
    "Analysis base exists",
    os.path.exists(BASE_FILE),
    BASE_FILE
)

# Non-empty
add_check(
    "Analysis base non-empty",
    rows > 0,
    f"{rows} rows"
)

# No complete duplicate rows
duplicate_rows = (
    entity_audit["duplicate_rows"]
    if entity_audit["duplicate_rows"] is not None
    else 0
)

add_check(
    "No duplicate rows",
    duplicate_rows == 0,
    f"{duplicate_rows} duplicate rows"
)

# Entity IDs
missing_entities = (
    entity_audit["missing_entity_ids"]
    if entity_audit["missing_entity_ids"] is not None
    else 0
)

add_check(
    "Entity IDs complete",
    missing_entities == 0,
    f"{missing_entities} missing IDs"
)

# Core analytics
available_modules = {
    row["module"]
    for _, row in module_df.iterrows()
    if row["available"]
}

add_check(
    "Clustering output available",
    "Clustering" in available_modules,
    "Clustering benchmark detected"
)

add_check(
    "PCA output available",
    "PCA" in available_modules,
    "PCA results detected"
)

add_check(
    "Anomaly output available",
    "Anomaly Detection" in available_modules,
    "Anomaly results detected"
)

add_check(
    "MCDA output available",
    "MCDA" in available_modules,
    "MCDA results detected"
)

add_check(
    "Business interpretation available",
    "Business Interpretation" in available_modules,
    "Cell 20 interpretation detected"
)

add_check(
    "Recommendation output available",
    "Final Recommendation" in available_modules,
    "Cell 21 recommendation detected"
)

checks_df = pd.DataFrame(checks)

# ------------------------------------------------------------
# 11. PROJECT READINESS
# ------------------------------------------------------------

print("\n[8] PROJECT READINESS")
print("-" * 70)

total_checks = len(checks_df)

passed_checks = int(
    (checks_df["status"] == "PASS").sum()
)

readiness_pct = (
    passed_checks / total_checks * 100
    if total_checks
    else 0
)

if readiness_pct >= 90:
    readiness_status = "READY"
elif readiness_pct >= 75:
    readiness_status = "READY WITH REVIEW"
else:
    readiness_status = "NEEDS REVIEW"

print(
    f"Checks passed       : "
    f"{passed_checks}/{total_checks}"
)

print(
    f"Readiness           : "
    f"{readiness_pct:.2f}%"
)

print(
    f"Status              : "
    f"{readiness_status}"
)

# ------------------------------------------------------------
# 12. SAVE AUDIT OUTPUTS
# ------------------------------------------------------------

file_audit_df.to_csv(
    f"{AUDIT_DIR}/Vendor360_File_Audit.csv",
    index=False
)

missing_df.to_csv(
    f"{AUDIT_DIR}/Vendor360_Missing_Value_Audit.csv",
    index=False
)

dtype_df.to_csv(
    f"{AUDIT_DIR}/Vendor360_Data_Type_Audit.csv",
    index=False
)

module_df.to_csv(
    f"{AUDIT_DIR}/Vendor360_Module_Audit.csv",
    index=False
)

dimension_df.to_csv(
    f"{AUDIT_DIR}/Vendor360_Dimension_Audit.csv",
    index=False
)

checks_df.to_csv(
    f"{AUDIT_DIR}/Vendor360_Quality_Checks.csv",
    index=False
)

# ------------------------------------------------------------
# 13. JSON SUMMARY
# ------------------------------------------------------------

audit_summary = {

    "timestamp": datetime.now().isoformat(),

    "dataset": {
        "rows": rows,
        "columns": cols
    },

    "entity_audit": entity_audit,

    "quality": {
        "total_checks": total_checks,
        "passed_checks": passed_checks,
        "readiness_percentage": round(
            readiness_pct,
            2
        ),
        "status": readiness_status
    },

    "available_modules": sorted(
        list(available_modules)
    ),

    "business_dimensions": (
        dimension_df[
            dimension_df["available"] == True
        ]["dimension"].tolist()
        if not dimension_df.empty
        else []
    )
}

with open(
    f"{AUDIT_DIR}/Vendor360_Audit_Summary.json",
    "w"
) as f:

    json.dump(
        audit_summary,
        f,
        indent=4,
        default=str
    )

# ------------------------------------------------------------
# 14. FINAL REPORT
# ------------------------------------------------------------

report_lines = [

    "VENDOR360 AUTOMATED PROJECT / QUALITY AUDIT",
    "=" * 60,
    "",
    f"Rows: {rows}",
    f"Columns: {cols}",
    f"Entity column: {entity_audit['entity_column']}",
    f"Unique entities: {entity_audit['unique_entities']}",
    f"Duplicate rows: {entity_audit['duplicate_rows']}",
    f"Missing entity IDs: {entity_audit['missing_entity_ids']}",
    "",
    "PROJECT READINESS",
    "-" * 60,
    f"Checks passed: {passed_checks}/{total_checks}",
    f"Readiness: {readiness_pct:.2f}%",
    f"Status: {readiness_status}",
    "",
    "AVAILABLE ANALYTICAL MODULES",
    "-" * 60,
]

for module in sorted(available_modules):
    report_lines.append(f"✓ {module}")

report_lines.extend([
    "",
    "AVAILABLE BUSINESS DIMENSIONS",
    "-" * 60
])

if not dimension_df.empty:

    for _, row in dimension_df.iterrows():

        if row["available"]:
            report_lines.append(
                f"✓ {row['dimension']}"
            )
        else:
            report_lines.append(
                f"– {row['dimension']}"
            )

report_lines.extend([
    "",
    "AUDIT COMPLETE",
    "=" * 60
])

with open(
    f"{AUDIT_DIR}/Vendor360_Audit_Report.txt",
    "w"
) as f:

    f.write("\n".join(report_lines))

# ------------------------------------------------------------
# 15. FINAL OUTPUT
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("CELL 22 OUTPUTS")
print("=" * 70)

print(
    f"✓ {AUDIT_DIR}/Vendor360_File_Audit.csv"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Missing_Value_Audit.csv"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Data_Type_Audit.csv"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Module_Audit.csv"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Dimension_Audit.csv"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Quality_Checks.csv"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Audit_Summary.json"
)

print(
    f"✓ {AUDIT_DIR}/Vendor360_Audit_Report.txt"
)

print("\n" + "=" * 70)
print("CELL 22 STATUS:", readiness_status)
print("=" * 70)

# ============================================================
