# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 54 =====

# VENDOR360 — CELL 25
# SCENARIO-BASED SUPPLIER DECISION INTELLIGENCE ENGINE
# ============================================================

import os
import re
import json
import numpy as np
import pandas as pd
from datetime import datetime

from IPython.display import display, Markdown, clear_output


# ============================================================
# 1. PATHS
# ============================================================

BASE_PATH = V360_WORK + "/Vendor360_Analysis_Base.csv"
KPI_PATH = V360_WORK + "/Vendor360_Cell23/Vendor360_Supplier_KPI_Comparison.csv"
MCDA_PATH = V360_WORK + "/Vendor360_Cell19/MCDA_Results.csv"

OUT_DIR = V360_WORK + "/Vendor360_Cell25"
os.makedirs(OUT_DIR, exist_ok=True)

RANKING_PATH = os.path.join(
    OUT_DIR, "Vendor360_Scenario_Ranking.csv"
)

CONTRIBUTIONS_PATH = os.path.join(
    OUT_DIR, "Vendor360_Scenario_Contributions.csv"
)

EXPLANATION_PATH = os.path.join(
    OUT_DIR, "Vendor360_Scenario_Explanation.txt"
)

CONFIG_PATH = os.path.join(
    OUT_DIR, "Vendor360_Advisor_Config.json"
)

METADATA_PATH = os.path.join(
    OUT_DIR, "Vendor360_Scenario_Metadata.json"
)


# ============================================================
# 2. LOAD DATA
# ============================================================

print("=" * 70)
print("VENDOR360 — CELL 25")
print("SCENARIO-BASED SUPPLIER DECISION INTELLIGENCE ENGINE")
print("=" * 70)

if not os.path.exists(KPI_PATH):
    raise FileNotFoundError(
        f"Supplier KPI output not found:\n{KPI_PATH}\n"
        "Please run Cell 23 first."
    )

kpi_df = pd.read_csv(KPI_PATH)

base_df = (
    pd.read_csv(BASE_PATH)
    if os.path.exists(BASE_PATH)
    else pd.DataFrame()
)

mcda_df = (
    pd.read_csv(MCDA_PATH)
    if os.path.exists(MCDA_PATH)
    else pd.DataFrame()
)

print("\n[1] DATA LOADED")
print(f"Analysis Base : {base_df.shape}")
print(f"Supplier KPI  : {kpi_df.shape}")
print(f"MCDA Results  : {mcda_df.shape}")


# ============================================================
# 3. ADAPTIVE COLUMN DETECTION
# ============================================================

def find_column(df, candidates):

    if df is None or df.empty:
        return None

    columns = list(df.columns)

    normalized = {
        re.sub(r"[^a-z0-9]", "", str(c).lower()): c
        for c in columns
    }

    for candidate in candidates:

        key = re.sub(
            r"[^a-z0-9]",
            "",
            candidate.lower()
        )

        if key in normalized:
            return normalized[key]

    for candidate in candidates:

        key = re.sub(
            r"[^a-z0-9]",
            "",
            candidate.lower()
        )

        for norm_col, original_col in normalized.items():

            if (
                key in norm_col
                or norm_col in key
            ):
                return original_col

    return None


supplier_id_col = find_column(
    kpi_df,
    [
        "supplier_id",
        "supplierid",
        "vendor_id",
        "vendorid",
        "entity_id"
    ]
)

supplier_name_col = find_column(
    kpi_df,
    [
        "supplier_name",
        "suppliername",
        "vendor_name",
        "vendorname",
        "entity_name"
    ]
)

if supplier_id_col is None:

    supplier_id_col = "supplier_id"

    kpi_df[supplier_id_col] = [
        f"SUP-{i+1:04d}"
        for i in range(len(kpi_df))
    ]

if supplier_name_col is None:

    supplier_name_col = "supplier_name"

    kpi_df[supplier_name_col] = (
        kpi_df[supplier_id_col]
        .astype(str)
    )


print("\n[2] SUPPLIER IDENTIFICATION")
print(f"Supplier ID   : {supplier_id_col}")
print(f"Supplier Name : {supplier_name_col}")


# ============================================================
# 4. BUSINESS DIMENSION DETECTION
# ============================================================

dimension_patterns = {

    "Cost": [
        "cost_kpi",
        "unit_cost",
        "cost",
        "price",
        "unit_price",
        "pricing"
    ],

    "Quality": [
        "quality_kpi",
        "quality_score",
        "quality",
        "acceptance"
    ],

    "Reliability": [
        "reliability_kpi",
        "reliability",
        "on_time_delivery",
        "on_time",
        "lead_time",
        "delivery"
    ],

    "Risk": [
        "risk_kpi",
        "risk_score",
        "risk",
        "financial_health"
    ],

    "Sustainability": [
        "sustainability_kpi",
        "sustainability",
        "esg_score",
        "esg"
    ],

    "Capacity": [
        "capacity_kpi",
        "capacity",
        "capacity_per_month"
    ]
}

EXCLUDED_COLUMNS = {
    "supplier_record_count",
    "mcda_rank",
    "anomaly_flag",
    "risk_review_flag",
    "supplier_review_status",
    "kpi_completeness_pct"
}

dimension_columns = {}

for dimension, patterns in dimension_patterns.items():

    found = None

    for pattern in patterns:

        candidate = find_column(
            kpi_df,
            [pattern]
        )

        if candidate is not None:

            if candidate not in EXCLUDED_COLUMNS:
                found = candidate
                break

    if found is not None:
        dimension_columns[dimension] = found


print("\n[3] AVAILABLE BUSINESS DIMENSIONS")

for dimension in dimension_patterns:

    if dimension in dimension_columns:

        print(
            f"✓ {dimension:<18}: "
            f"{dimension_columns[dimension]}"
        )

    else:

        print(
            f"– {dimension:<18}: unavailable"
        )


# ============================================================
# 5. DIMENSION VOCABULARY
# ============================================================

DIMENSION_TERMS = {

    "Cost": [
        "cost",
        "price",
        "pricing"
    ],

    "Quality": [
        "quality"
    ],

    "Reliability": [
        "reliability",
        "reliable",
        "dependability",
        "dependable"
    ],

    "Risk": [
        "risk",
        "safety",
        "safe"
    ],

    "Sustainability": [
        "sustainability",
        "sustainable",
        "esg"
    ],

    "Capacity": [
        "capacity"
    ]
}


def normalize_dimension_name(value):

    text = str(value).strip().lower()

    aliases = {

        "cost": "Cost",
        "price": "Cost",
        "pricing": "Cost",

        "quality": "Quality",

        "reliability": "Reliability",
        "reliable": "Reliability",
        "dependability": "Reliability",
        "dependable": "Reliability",

        "risk": "Risk",
        "safety": "Risk",
        "safe": "Risk",

        "sustainability": "Sustainability",
        "sustainable": "Sustainability",
        "esg": "Sustainability",

        "capacity": "Capacity"
    }

    return aliases.get(text)


# ============================================================
# 6. DEFAULT BUSINESS DIRECTIONS
# ============================================================

DEFAULT_DIRECTION = {

    "Cost": "lower",

    "Quality": "higher",

    "Reliability": "higher",

    "Risk": "lower",

    "Sustainability": "higher",

    "Capacity": "higher"
}


# ============================================================
# 7-13. SCENARIO ENGINE  (single source of truth)
# ============================================================
# The parser, weighting and scoring that used to live here (and a second copy in
# the Streamlit app) are now ONE module: vendor360_engine/scenario_engine.py.
# Cell 25 and the Streamlit What-If page both call it, so a scenario can no
# longer produce two different rankings.
import sys as _sys, os as _os, json as _json
for _p in (_os.environ.get("VENDOR360_ENGINE_DIR"), _os.getcwd(), V360_WORK):
    if _p and _os.path.isdir(_os.path.join(_p, "vendor360_engine")) and _p not in _sys.path:
        _sys.path.insert(0, _p)
from vendor360_engine import scenario_engine as _scn

# Direction of each KPI column, written by Cell 23 from the SOURCE columns.
KPI_DIRECTIONS = {}
_kpi_cfg_path = _os.path.join(_os.path.dirname(KPI_PATH), "Vendor360_KPI_Config.json")
if _os.path.exists(_kpi_cfg_path):
    with open(_kpi_cfg_path) as _f:
        KPI_DIRECTIONS = {d: v for d, v in _json.load(_f).get("kpi_directions", {}).items()
                          if d in dimension_columns}
# D6: never silently fall back to a hard-coded Reliability direction.
# Infer it from the actual source KPI semantics when Cell 23 config is absent.
if not KPI_DIRECTIONS:
    def _infer_dim_direction(dim, cols):
        names = " ".join(str(c).lower() for c in cols)
        if dim == "Reliability":
            if any(x in names for x in [
                "lead_time", "leadtime", "delay_days",
                "delivery_days", "days"
            ]):
                return "lower"
            return "higher"
        if dim == "Cost":
            return "lower"
        if dim == "Risk":
            return "lower"
        return "higher"

    KPI_DIRECTIONS = {
        d: _infer_dim_direction(d, dimension_columns.get(d, []))
        for d in dimension_columns
    }

print("KPI directions from Cell 23:", KPI_DIRECTIONS or "none found")


def interpret_scenario_local(text):
    interpretation = _scn.interpret_scenario(text, list(dimension_columns))
    # The business meaning ("better reliability") is mapped onto the KPI's real orientation.
    for dim, direction in KPI_DIRECTIONS.items():
        if dim in interpretation:
            interpretation[dim]["direction"] = direction
    return interpretation


def build_weights(interpretation):
    return _scn.build_weights(interpretation, list(interpretation))


def score_suppliers(df, interpretation, weights):
    return _scn.score_suppliers(
        df, interpretation, weights, dimension_columns,
        supplier_id_col, supplier_name_col,
        column_direction_override=KPI_DIRECTIONS or None)



# ============================================================
# 14. LOCAL EXPLANATION
# ============================================================

def build_local_explanation(
    scenario,
    interpretation,
    weights,
    ranking_df
):

    if ranking_df.empty:

        return (
            "No eligible suppliers were available."
        )

    top = ranking_df.iloc[0]

    lines = [

        "VENDOR360 SCENARIO DECISION EXPLANATION",

        "=" * 55,

        f"Scenario:\n{scenario}",

        "",

        f"Recommended Supplier: "
        f"{top[supplier_name_col]}",

        f"Scenario Decision Score: "
        f"{float(top['scenario__decision_score']):.3f}",

        "",

        "INTERPRETED BUSINESS PRIORITIES",

        "-" * 40
    ]

    for dimension in weights:

        info = interpretation[
            dimension
        ]

        lines.append(
            f"{dimension}: "
            f"{info['priority']} | "
            f"{info['direction']} | "
            f"weight={weights[dimension]:.3f}"
        )

    lines.extend([
        "",
        "TOP SUPPLIER CONTRIBUTIONS",
        "-" * 40
    ])

    for dimension in weights:

        score_col = (
            f"scenario__"
            f"{dimension.lower()}_score"
        )

        contribution_col = (
            f"scenario__"
            f"{dimension.lower()}_contribution"
        )

        if (
            score_col not in top
            or
            contribution_col not in top
        ):
            continue

        lines.append(
            f"{dimension}: "
            f"score="
            f"{float(top[score_col]):.3f}, "
            f"contribution="
            f"{float(top[contribution_col]):.3f}"
        )

    lines.extend([
        "",
        "TOP SUPPLIER RANKING",
        "-" * 40
    ])

    for _, row in ranking_df.head(10).iterrows():

        lines.append(
            f"{int(row['scenario__rank'])}. "
            f"{row[supplier_name_col]} — "
            f"{float(row['scenario__decision_score']):.3f}"
        )

    lines.extend([

        "",

        "DECISION NOTE",

        "-" * 40,

        "The recommendation is "
        "scenario-dependent. Changing "
        "business priorities can change "
        "the supplier ranking.",

        "Vendor360 is a decision-support "
        "framework and does not autonomously "
        "execute purchasing decisions."
    ])

    return "\n".join(lines)


# ============================================================
# 15. GEMINI CONTEXT
# ============================================================

def build_gemini_supplier_context(
    ranking_df,
    max_suppliers=15
):

    records = []

    for _, row in ranking_df.head(
        max_suppliers
    ).iterrows():

        record = {

            "supplier_id":
                str(
                    row[supplier_id_col]
                ),

            "supplier_name":
                str(
                    row[supplier_name_col]
                ),

            "scenario_score":
                round(
                    float(
                        row[
                            "scenario__decision_score"
                        ]
                    ),
                    4
                ),

            "scenario_rank":
                int(
                    row[
                        "scenario__rank"
                    ]
                )
        }

        for dimension in dimension_columns:

            column = (
                f"scenario__"
                f"{dimension.lower()}_score"
            )

            if column in row:

                record[
                    f"{dimension.lower()}_score"
                ] = round(
                    float(
                        row[column]
                    ),
                    4
                )

        records.append(record)

    return records


# ============================================================
# 16. OPTIONAL GEMINI
# ============================================================

def call_gemini_worker(
    scenario,
    interpretation,
    weights,
    ranking_df
):

    try:

        from google import genai

    except Exception as e:

        return None, (
            "Gemini package unavailable: "
            + str(e)
        )

    api_key = os.environ.get(
        "GEMINI_API_KEY"
    )

    if not api_key:

        return None, (
            "Gemini API key not configured."
        )

    try:

        # 30 s request timeout (milliseconds in the google-genai SDK) so a slow Gemini call cannot hang the app;
        # on timeout the except block below returns the local explanation instead.
        client = genai.Client(
            api_key=api_key,
            http_options={"timeout": int(os.environ.get("GEMINI_TIMEOUT_SECONDS", "30")) * 1000}
        )

        supplier_context = (
            build_gemini_supplier_context(
                ranking_df
            )
        )

        prompt = f"""
You are the AI interpretation layer
for Vendor360 supplier decision support.

Use ONLY the verified data below.

Do not invent supplier metrics.
Do not predict future failures.
Do not override the Python ranking with
unsupported information.

BUSINESS SCENARIO:
{scenario}

INTERPRETED PRIORITIES:
{json.dumps(interpretation, indent=2)}

WEIGHTS:
{json.dumps(weights, indent=2)}

VERIFIED SUPPLIER DATA:
{json.dumps(supplier_context, indent=2)}

Return JSON with:

{{
  "recommended_supplier": "...",
  "reason": "...",
  "tradeoffs": ["...", "..."],
  "management_action": "...",
  "confidence_note": "..."
}}
"""

        response = client.models.generate_content(
            model=os.environ.get("GEMINI_MODEL", "gemini-3.8-flash"),
            contents=prompt
        )

        text = getattr(
            response,
            "text",
            None
        )

        if not text:

            return None, (
                "Gemini returned no text."
            )

        text = text.strip()

        text = re.sub(
            r"^```json\s*",
            "",
            text,
            flags=re.IGNORECASE
        )

        text = re.sub(
            r"\s*```$",
            "",
            text
        )

        return json.loads(text), None

    except Exception as e:

        return None, str(e)


# ============================================================
# 17. GEMINI VALIDATION
# ============================================================

def validate_gemini_decision(
    result,
    ranking_df
):

    if not isinstance(
        result,
        dict
    ):
        return False

    required = [
        "recommended_supplier",
        "reason",
        "tradeoffs",
        "management_action",
        "confidence_note"
    ]

    if not all(
        key in result
        for key in required
    ):
        return False

    names = (
        ranking_df[
            supplier_name_col
        ]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    recommended = str(
        result[
            "recommended_supplier"
        ]
    ).strip().lower()

    return recommended in set(names)


# ============================================================
# 18. MAIN ADVISOR
# ============================================================

def run_advisor(
    scenario,
    engine="Local Deterministic"
):

    scenario = str(
        scenario
    ).strip()

    if not scenario:

        raise ValueError(
            "Please enter a business scenario."
        )

    print("\n" + "=" * 70)
    print("SCENARIO DECISION ENGINE")
    print("=" * 70)

    print(
        f"\nScenario:\n{scenario}"
    )

    # --------------------------------------------------------
    # Interpretation
    # --------------------------------------------------------

    interpretation = (
        interpret_scenario_local(
            scenario
        )
    )

    weights = build_weights(
        interpretation
    )

    print("\n[LOCAL INTERPRETATION]")

    for dimension in dimension_columns:

        info = interpretation[
            dimension
        ]

        print(
            f"{dimension:<18} "
            f"Priority: "
            f"{info['priority']:<18} "
            f"Direction: "
            f"{info['direction']:<7} "
            f"Weight: "
            f"{weights.get(dimension, 0):.3f}"
        )

    # --------------------------------------------------------
    # Deterministic scoring
    # --------------------------------------------------------

    ranking_df, contributions_df = (
        score_suppliers(
            kpi_df,
            interpretation,
            weights
        )
    )

    print(
        f"\nEligible suppliers: "
        f"{len(ranking_df)}"
    )

    print("\nTOP SUPPLIERS")

    display(
        ranking_df[
            [
                supplier_id_col,
                supplier_name_col,
                "scenario__decision_score",
                "scenario__rank",
                "advisor__decision_status"
            ]
        ].head(10)
    )

    final_engine = (
        "Local Deterministic"
    )

    gemini_result = None
    gemini_error = None

    # --------------------------------------------------------
    # Optional Gemini
    # --------------------------------------------------------

    if engine == "Gemini AI Worker":

        print(
            "\n[GEMINI AI WORKER]"
        )

        print(
            "Calling Gemini..."
        )

        gemini_result, gemini_error = (
            call_gemini_worker(
                scenario,
                interpretation,
                weights,
                ranking_df
            )
        )

        if (
            gemini_result is not None
            and
            validate_gemini_decision(
                gemini_result,
                ranking_df
            )
        ):

            final_engine = (
                "Gemini AI Worker"
            )

            print(
                "✓ Gemini decision validated."
            )

        else:

            print(
                "⚠ Gemini unavailable or "
                "failed validation."
            )

            if gemini_error:

                print(
                    f"Reason: {gemini_error}"
                )

            print(
                "✓ Local deterministic "
                "fallback used."
            )

    else:

        print(
            "\n✓ Local Deterministic Engine selected"
        )

    # --------------------------------------------------------
    # Recommendation
    # --------------------------------------------------------

    top_supplier = ranking_df.iloc[0][
        supplier_name_col
    ]

    top_score = float(
        ranking_df.iloc[0][
            "scenario__decision_score"
        ]
    )

    if (
        final_engine == "Gemini AI Worker"
        and
        gemini_result is not None
    ):

        recommended = str(
            gemini_result[
                "recommended_supplier"
            ]
        ).strip().lower()

        matched = ranking_df[
            ranking_df[
                supplier_name_col
            ]
            .astype(str)
            .str.strip()
            .str.lower()
            == recommended
        ]

        if not matched.empty:

            top_supplier = matched.iloc[0][
                supplier_name_col
            ]

            top_score = float(
                matched.iloc[0][
                    "scenario__decision_score"
                ]
            )

    # --------------------------------------------------------
    # Explanation
    # --------------------------------------------------------

    explanation = build_local_explanation(
        scenario,
        interpretation,
        weights,
        ranking_df
    )

    if (
        final_engine == "Gemini AI Worker"
        and
        gemini_result is not None
    ):

        explanation += (

            "\n\n"
            "GEMINI MANAGEMENT INTERPRETATION"
            "\n"
            + "-" * 40
            + "\n"
            + str(
                gemini_result[
                    "reason"
                ]
            )
            + "\n\nTrade-offs:\n"
            + "\n".join(
                "- " + str(x)
                for x in gemini_result[
                    "tradeoffs"
                ]
            )
            + "\n\nManagement Action:\n"
            + str(
                gemini_result[
                    "management_action"
                ]
            )
            + "\n\nConfidence Note:\n"
            + str(
                gemini_result[
                    "confidence_note"
                ]
            )
        )

    # --------------------------------------------------------
    # Save ranking
    # --------------------------------------------------------

    ranking_df.to_csv(
        RANKING_PATH,
        index=False
    )

    contributions_df.to_csv(
        CONTRIBUTIONS_PATH,
        index=False
    )

    with open(
        EXPLANATION_PATH,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            explanation
        )

    config = {

        "scenario":
            scenario,

        "engine_requested":
            engine,

        "engine_used":
            final_engine,

        "supplier_id_column":
            supplier_id_col,

        "supplier_name_column":
            supplier_name_col,

        "available_dimensions":
            list(
                dimension_columns.keys()
            ),

        "interpretation":
            interpretation,

        "weights":
            weights,

        "recommended_supplier":
            str(top_supplier),

        "scenario_score":
            round(
                top_score,
                6
            ),

        "gemini_used":
            final_engine
            == "Gemini AI Worker",

        "category_level_mcda_rank_used":
            False,

        "timestamp":
            datetime.now().isoformat()
    }

    with open(
        CONFIG_PATH,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            config,
            f,
            indent=2
        )

    metadata = {

        "rows":
            int(len(ranking_df)),

        "dimensions":
            list(
                dimension_columns.keys()
            ),

        "scenario":
            scenario,

        "recommended_supplier":
            str(top_supplier),

        "scenario_score":
            round(
                top_score,
                6
            ),

        "engine":
            final_engine,

        "directionality":
            DEFAULT_DIRECTION,

        "category_level_mcda_rank_used":
            False,

        "supplier_level_decision_score":
            True,

        "timestamp":
            datetime.now().isoformat()
    }

    with open(
        METADATA_PATH,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            metadata,
            f,
            indent=2
        )

    # --------------------------------------------------------
    # Final output
    # --------------------------------------------------------

    print("\n" + "=" * 70)
    print("SCENARIO DECISION COMPLETE")
    print("=" * 70)

    print(
        f"Recommended supplier: "
        f"{top_supplier}"
    )

    print(
        f"Scenario score: "
        f"{top_score:.3f}"
    )

    print(
        f"Engine: "
        f"{final_engine}"
    )

    print(
        "\nThe recommendation is "
        "scenario-dependent. Changing "
        "business priorities can change "
        "the ranking."
    )

    print("\nOUTPUTS")

    print(f"✓ {RANKING_PATH}")
    print(f"✓ {CONTRIBUTIONS_PATH}")
    print(f"✓ {EXPLANATION_PATH}")
    print(f"✓ {CONFIG_PATH}")
    print(f"✓ {METADATA_PATH}")

    return {

        "ranking":
            ranking_df,

        "contributions":
            contributions_df,

        "interpretation":
            interpretation,

        "weights":
            weights,

        "recommendation":
            top_supplier,

        "score":
            top_score,

        "engine":
            final_engine,

        "gemini":
            gemini_result
    }


# ============================================================


# Interactive notebook widgets intentionally excluded from production backend.
