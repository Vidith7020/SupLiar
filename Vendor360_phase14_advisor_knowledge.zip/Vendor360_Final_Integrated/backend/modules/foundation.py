# AUTO-EXTRACTED FROM VENDOR360_FINAL_notebook.ipynb
"""Notebook-derived backend phase. Source order preserved; Streamlit UI excluded."""


# ===== ORIGINAL NOTEBOOK CELL 2 =====

# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import io
import os
import re
import hashlib
import warnings

from google.colab import files

# --- Vendor360 path settings (set by backend/pipeline.py; env fallback for standalone use) ---
# V360_WORK  : where generated outputs (Vendor360_Cell*/ folders, analysis base, ...) are written.
# V360_INPUT : where the source datasets are read from. Defaults to V360_WORK (Colab /content layout).
V360_WORK = globals().get("V360_WORK") or os.environ.get("VENDOR360_WORKDIR", "/content")
V360_INPUT = globals().get("V360_INPUT") or os.environ.get("VENDOR360_INPUT_DIR") or V360_WORK

warnings.filterwarnings("ignore")

pd.set_option("display.max_columns", None)
pd.set_option("display.width", 160)


# ------------------------------------------------------------
# Supported file types
# ------------------------------------------------------------

SUPPORTED_EXTENSIONS = [".csv", ".xlsx", ".xls"]


# ------------------------------------------------------------
# Find datasets already present in Colab
# ------------------------------------------------------------

available_files = [
    f for f in os.listdir(V360_INPUT)
    if os.path.isfile(os.path.join(V360_INPUT, f))
    and not f.startswith("Vendor360_")  # never re-ingest files this system generated
    and os.path.splitext(f)[1].lower() in SUPPORTED_EXTENSIONS
]


# ------------------------------------------------------------
# Ask for upload if no datasets are present
# ------------------------------------------------------------

if not available_files:

    print("No dataset files found.")
    print("Upload one or more CSV, XLS, or XLSX files.\n")

    uploaded = files.upload()

    if not uploaded:
        raise ValueError("No files uploaded.")

    available_files = list(uploaded.keys())


# ------------------------------------------------------------
# Remove exact duplicate files
# ------------------------------------------------------------

def file_hash(path):
    """Generate a hash to identify identical files."""
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


datasets = {}
file_hashes = {}
duplicate_files = []


# ------------------------------------------------------------
# Load every unique dataset
# ------------------------------------------------------------

for file_name in available_files:

    file_path = os.path.join(V360_INPUT, file_name)

    try:
        current_hash = file_hash(file_path)

        # Skip exact duplicate copies
        if current_hash in file_hashes:

            duplicate_files.append(
                (file_name, file_hashes[current_hash])
            )

            continue

        ext = os.path.splitext(file_name)[1].lower()

        if ext == ".csv":

            try:
                data = pd.read_csv(file_path)

            except UnicodeDecodeError:

                data = pd.read_csv(
                    file_path,
                    encoding="latin1"
                )

        elif ext in [".xlsx", ".xls"]:

            data = pd.read_excel(file_path)

        else:
            continue

        datasets[file_name] = data
        file_hashes[current_hash] = file_name

    except Exception as e:

        print(f"⚠ Could not load {file_name}: {e}")


if not datasets:
    raise ValueError("No valid datasets could be loaded.")

# ------------------------------------------------------------
# PHASE 2 PREPARATION (INR conversion, capacity placeholder, like-for-like price)
# ------------------------------------------------------------
# Defined once here and called by BOTH foundation.py and analytics.py (analytics reloads the
# CSVs from disk, so the same preparation must be applied to that copy too).
# Everything it does is recorded in VENDOR360_PREP_LOG (shown on the Data Quality page).
import json as _json
from pathlib import Path as _Path

def _find_fx_file():
    cands = []
    _env = os.environ.get("VENDOR360_CONFIG_DIR")
    if _env:
        cands.append(_Path(_env) / "fx_rates.json")
    _f = globals().get("__file__")
    if _f:
        cands.append(_Path(_f).resolve().parent.parent / "config" / "fx_rates.json")
    cands += [_Path(V360_WORK + "/config/fx_rates.json"), _Path("config/fx_rates.json")]
    for c in cands:
        if c.exists():
            return c
    return None

def vendor360_prepare(datasets):
    global VENDOR360_PREP_LOG, VENDOR360_ONBOARDING_PRICE
    VENDOR360_PREP_LOG = {"fx": {}, "capacity": {}, "price_normalisation": {}}
    _fx_path = _find_fx_file()
    _FX = _json.loads(_fx_path.read_text(encoding="utf-8")) if _fx_path else None

    def _to_inr(frame, value_cols):
        cur = frame["currency"].astype(str).str.upper().str.strip()
        rates = _FX["rates"]
        unknown = sorted(set(cur.unique()) - set(rates))
        if unknown:
            raise ValueError(f"No FX rate in fx_rates.json for currencies: {unknown}")
        factor = cur.map(rates).astype(float)
        for vc in value_cols:
            if vc in frame.columns:
                frame[vc] = pd.to_numeric(frame[vc], errors="coerce") * factor
        frame["fx_rate_to_inr"] = factor
        frame["currency"] = "INR"
        return frame

    if _FX is not None:
        VENDOR360_PREP_LOG["fx"] = {
            "applied": True, "base": "INR", "rates": _FX["rates"], "as_of": _FX.get("as_of"),
            "source": _FX.get("source"), "indicative": bool(_FX.get("indicative", False)), "files": {}
        }
        for _name, _df in list(datasets.items()):
            _cols = {c.lower(): c for c in _df.columns}
            if "currency" not in _cols:
                continue
            if "unit_price" in _cols:
                _before = _df["currency"].astype(str).value_counts().to_dict()
                datasets[_name] = _to_inr(_df.copy().rename(columns={_cols["currency"]: "currency"}),
                                          [_cols["unit_price"], _cols.get("expedited_unit_price", "expedited_unit_price")])
                VENDOR360_PREP_LOG["fx"]["files"][_name] = {"converted": ["unit_price", "expedited_unit_price"], "rows_by_source_currency": _before}
            elif "total_value" in _cols:
                _before = _df["currency"].astype(str).value_counts().to_dict()
                datasets[_name] = _to_inr(_df.copy().rename(columns={_cols["currency"]: "currency"}), [_cols["total_value"]])
                VENDOR360_PREP_LOG["fx"]["files"][_name] = {"converted": ["total_value"], "rows_by_source_currency": _before}
    else:
        VENDOR360_PREP_LOG["fx"] = {"applied": False, "reason": "config/fx_rates.json not found"}

    # Capacity: 999999 is a placeholder, not a measurement. Replace it with the median of the
    # real values in the same level-1 category and mark the row as estimated.
    for _name, _df in list(datasets.items()):
        if "capacity_per_month" in _df.columns and "supplier_id" in _df.columns:
            _d = _df.copy()
            _cap = pd.to_numeric(_d["capacity_per_month"], errors="coerce")
            _ph = _cap >= 999999
            if _ph.any():
                _grp = _d["category_l1"] if "category_l1" in _d.columns else pd.Series("all", index=_d.index)
                _real = _cap.where(~_ph)
                _med = _real.groupby(_grp).transform("median").fillna(_real.median())
                _d["capacity_per_month"] = _cap.where(~_ph, _med)
                _d["placeholder_imputed"] = _ph.astype(int)
                datasets[_name] = _d
                VENDOR360_PREP_LOG["capacity"] = {
                    "placeholder_value": 999999, "rows_replaced": int(_ph.sum()),
                    "suppliers_affected": sorted(_d.loc[_ph, "supplier_id"].astype(str).unique().tolist()),
                    "method": "median of non-placeholder capacity in the same category_l1 (estimated, not measured)"
                }

    # Onboarding reference price (separate from the bounded cost KPI; MCDA cost scoring is NOT affected).
    # Real INR unit price per supplier = median of INR unit prices over per-unit pricing models only.
    # Lump-sum models (fixed, performance, subscription) are not unit prices and are left out; a supplier
    # with only those models has no value here.
    VENDOR360_PER_UNIT_MODELS = ["tiered", "day_rate", "usage", "blended_rate"]
    VENDOR360_ONBOARDING_PRICE = pd.DataFrame(columns=["supplier_id", "unit_price_inr", "price_rows"])
    for _name, _df in list(datasets.items()):
        if {"unit_price", "pricing_model", "supplier_id", "currency"}.issubset(_df.columns) and str(_df["currency"].iloc[0]).upper() == "INR":
            _u = _df[_df["pricing_model"].astype(str).str.lower().isin(VENDOR360_PER_UNIT_MODELS)].copy()
            _u["unit_price"] = pd.to_numeric(_u["unit_price"], errors="coerce")
            _u = _u.dropna(subset=["unit_price"])
            VENDOR360_ONBOARDING_PRICE = (_u.groupby("supplier_id")["unit_price"].agg(unit_price_inr="median", price_rows="size").reset_index())
            VENDOR360_PREP_LOG["onboarding_price"] = {
                "applied": True, "currency": "INR", "models_used": VENDOR360_PER_UNIT_MODELS,
                "suppliers_with_price": int(len(VENDOR360_ONBOARDING_PRICE)),
                "method": "median INR unit price per supplier over per-unit pricing models (tiered, day_rate, usage, blended_rate); lump-sum models (fixed, performance, subscription) are excluded"}
            break

    # Price normalisation: unit prices mix pricing models and scales (0.03 .. 195,000), so raw
    # prices are not comparable across suppliers. After INR conversion each price is expressed
    # relative to the median price of its peer group (same pricing_model + category_l2).
    for _name, _df in list(datasets.items()):
        if {"unit_price", "pricing_model", "category_l2"}.issubset(_df.columns):
            _d = _df.copy()
            for _vc in ("unit_price", "expedited_unit_price"):
                if _vc in _d.columns:
                    _v = pd.to_numeric(_d[_vc], errors="coerce")
                    # Percentile within the peer group (0 = cheapest, 1 = most expensive). A ratio to the
                    # median explodes where a group mixes units (e.g. per-GB vs per-TB storage prices);
                    # the percentile stays bounded and still ranks suppliers within like-for-like peers.
                    _d[_vc] = _v.groupby([_d["pricing_model"], _d["category_l2"]]).rank(pct=True, method="average")
            datasets[_name] = _d
            VENDOR360_PREP_LOG["price_normalisation"] = {
                "applied": True, "file": _name,
                "method": "price percentile within the same pricing_model and category_l2 after INR conversion (0 = cheapest in peer group, 1 = most expensive; lower is better). Peer groups can still mix units, e.g. cloud storage per-GB vs per-TB, so this is a relative position, not a price."
            }

    return datasets

vendor360_prepare(datasets)



# ------------------------------------------------------------
# Display ingestion results
# ------------------------------------------------------------

print("=" * 75)
print("VENDOR360 DATA INGESTION")
print("=" * 75)

print(f"\nUnique datasets loaded: {len(datasets)}")

for file_name, data in datasets.items():

    print(
        f"✓ {file_name:<35} "
        f"{len(data):>6,} rows × {len(data.columns):>3} columns"
    )


if duplicate_files:

    print("\nDuplicate files skipped:")

    for duplicate, original in duplicate_files:

        print(
            f"  ↳ {duplicate} "
            f"(duplicate of {original})"
        )


print("\nDataset objects created:")
print("  datasets = {filename: dataframe}")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 4 =====

# ============================================================

dataset_summary = []


for file_name, data in datasets.items():

    numeric_columns = data.select_dtypes(
        include=np.number
    ).columns

    categorical_columns = data.select_dtypes(
        include=["object", "category", "bool"]
    ).columns

    total_cells = len(data) * len(data.columns)

    missing_cells = data.isna().sum().sum()

    missing_rate = (
        missing_cells / total_cells * 100
        if total_cells > 0 else 0
    )

    duplicate_rate = (
        data.duplicated().mean() * 100
        if len(data) > 0 else 0
    )

    dataset_summary.append({

        "Dataset": file_name,

        "Rows": len(data),

        "Columns": len(data.columns),

        "Duplicate_Rows": data.duplicated().sum(),

        "Duplicate_%": round(
            duplicate_rate, 2
        ),

        "Missing_Cells": missing_cells,

        "Missing_%": round(
            missing_rate, 2
        ),

        "Numeric_Columns": len(
            numeric_columns
        ),

        "Categorical_Columns": len(
            categorical_columns
        ),

        "Memory_MB": round(
            data.memory_usage(
                deep=True
            ).sum() / 1024**2,
            2
        )
    })


dataset_summary_df = pd.DataFrame(
    dataset_summary
)


print("=" * 75)
print("DATASET SUMMARY")
print("=" * 75)

display(dataset_summary_df)


# ------------------------------------------------------------
# Individual previews
# ------------------------------------------------------------

for file_name, data in datasets.items():

    print("\n" + "-" * 75)
    print(f"{file_name} — PREVIEW")
    print("-" * 75)

    display(data.head(3))

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 6 =====

# ============================================================

def normalize_column(col):

    col = str(col).lower().strip()

    col = re.sub(
        r"[^a-z0-9]+",
        "_",
        col
    )

    return re.sub(
        r"_+",
        "_",
        col
    ).strip("_")


# ------------------------------------------------------------
# Vendor360 business field keywords
# ------------------------------------------------------------

KEYWORDS = {

    "Supplier": [
        "supplier", "vendor", "seller",
        "provider", "supplier_id",
        "vendor_id", "supplier_name",
        "vendor_name"
    ],

    "Cost": [
        "cost", "price", "unit_price",
        "unit_cost", "spend", "amount",
        "value", "total_cost",
        "total_value"
    ],

    "Quality": [
        "quality", "defect", "defects",
        "rejection", "reject", "return",
        "failure", "rating"
    ],

    "Reliability": [
        "reliability", "delivery",
        "lead_time", "leadtime",
        "on_time", "ontime",
        "delay", "delays", "late"
    ],

    "Risk": [
        "risk", "risk_score",
        "risk_level", "disruption",
        "dependency", "exposure"
    ],

    "Sustainability": [
        "esg", "sustainability",
        "environmental", "social",
        "governance", "carbon",
        "emission", "ethical"
    ],

    "Performance": [
        "performance", "kpi",
        "sla", "compliance",
        "score"
    ],

    "Outcome": [
        "award", "awarded",
        "selected", "winner",
        "rank", "saving",
        "decision", "outcome"
    ],

    "Quantity": [
        "quantity", "qty", "volume",
        "units", "capacity",
        "moq", "minimum_order"
    ]
}


# ------------------------------------------------------------
# Detection function
# ------------------------------------------------------------

def detect_fields(data):

    detected = {}

    date_columns = []


    # Date detection
    for col in data.columns:

        if pd.api.types.is_datetime64_any_dtype(
            data[col]
        ):

            date_columns.append(col)
            continue


        if data[col].dtype == "object":

            values = data[col].dropna()

            if len(values) > 0:

                parsed = pd.to_datetime(
                    values,
                    errors="coerce"
                )

                if (
                    parsed.notna().mean()
                    >= 0.70
                ):

                    date_columns.append(col)


    # Business field detection
    for category, keywords in KEYWORDS.items():

        matches = []

        for col in data.columns:

            normalized = normalize_column(col)

            if any(
                keyword in normalized
                for keyword in keywords
            ):

                matches.append(col)

        detected[category] = matches


    return detected, date_columns


# ------------------------------------------------------------
# Run detection on every dataset
# ------------------------------------------------------------

detected_by_dataset = {}

date_columns_by_dataset = {}


for file_name, data in datasets.items():

    detected_fields, dates = detect_fields(data)

    detected_by_dataset[file_name] = detected_fields

    date_columns_by_dataset[file_name] = dates


# ------------------------------------------------------------
# Display results
# ------------------------------------------------------------

for file_name, data in datasets.items():

    print("\n" + "=" * 75)
    print(f"DATASET: {file_name}")
    print("=" * 75)


    # Column information
    column_info = pd.DataFrame({

        "Column": data.columns,

        "Normalized_Name": [
            normalize_column(col)
            for col in data.columns
        ],

        "Data_Type":
            data.dtypes.astype(str),

        "Missing":
            data.isna().sum(),

        "Missing_%":
            (data.isna().mean() * 100).round(2),

        "Unique":
            data.nunique()
    })

    display(column_info)


    # Business fields
    print("-" * 75)
    print("VENDOR360 FIELD DETECTION")
    print("-" * 75)

    for category, columns in (
        detected_by_dataset[file_name].items()
    ):

        print(f"\n{category}:")

        if columns:

            for col in columns:
                print(f"  ✓ {col}")

        else:
            print("  ✗ Not detected")


    # Dates
    print("\nDate columns:")

    dates = date_columns_by_dataset[file_name]

    if dates:

        for col in dates:
            print(f"  ✓ {col}")

    else:

        print("  ✗ None detected")


# ------------------------------------------------------------
# Primary dataset compatibility
# ------------------------------------------------------------

primary_file = next(iter(datasets))

df = datasets[primary_file]

detected = detected_by_dataset[primary_file]

date_columns = date_columns_by_dataset[primary_file]

print("\n" + "=" * 75)
print("PRIMARY DATASET")
print("=" * 75)

print(primary_file)

print("\nAvailable detection objects:")
print("  detected_by_dataset")
print("  date_columns_by_dataset")

print("\nPrimary dataset shortcuts:")
print("  df")
print("  detected")
print("  date_columns")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 8 =====

# ============================================================

dimensions = [
    "Cost",
    "Reliability",
    "Quality",
    "Risk",
    "Sustainability"
]


capability_results = []


for file_name, data in datasets.items():

    detected = detected_by_dataset[file_name]

    numeric_columns = data.select_dtypes(
        include=np.number
    ).columns

    supplier_available = bool(
        detected["Supplier"]
    )


    modules = {

        "Supplier Profiling":
            supplier_available,

        "Cost Analysis":
            supplier_available
            and bool(detected["Cost"]),

        "Quality Analysis":
            supplier_available
            and bool(detected["Quality"]),

        "Reliability Analysis":
            supplier_available
            and bool(detected["Reliability"]),

        "Risk Analysis":
            supplier_available
            and bool(detected["Risk"]),

        "Sustainability Analysis":
            supplier_available
            and bool(detected["Sustainability"]),

        "Clustering":
            len(numeric_columns) >= 2,

        "Anomaly Detection":
            len(numeric_columns) >= 2,

        "PCA":
            len(numeric_columns) >= 2
    }


    capability_results.append({

        "Dataset": file_name,

        **{
            module: "YES"
            if available
            else "NO"

            for module, available
            in modules.items()
        }
    })


capability_df = pd.DataFrame(
    capability_results
)


print("=" * 75)
print("VENDOR360 ANALYSIS CAPABILITY")
print("=" * 75)

display(capability_df)


# ------------------------------------------------------------
# Dimension availability
# ------------------------------------------------------------

for file_name in datasets:

    detected = detected_by_dataset[file_name]

    print("\n" + "-" * 75)
    print(f"{file_name} — DIMENSIONS")
    print("-" * 75)

    for dimension in dimensions:

        columns = detected[dimension]

        if columns:

            print(
                f"✓ {dimension:<16} "
                f"{', '.join(columns)}"
            )

        else:

            print(
                f"✗ {dimension:<16} Not available"
            )

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 10 =====

# ============================================================

for file_name, data in datasets.items():

    print("\n" + "=" * 75)
    print(f"STATISTICAL PROFILE: {file_name}")
    print("=" * 75)


    # --------------------------------------------------------
    # Numerical variables
    # --------------------------------------------------------

    numeric_columns = data.select_dtypes(
        include=np.number
    ).columns.tolist()

    print("\nNUMERICAL VARIABLES")
    print("-" * 50)

    if numeric_columns:

        display(
            data[numeric_columns]
            .describe()
            .T
            .round(3)
        )

    else:

        print("No numerical variables detected.")


    # --------------------------------------------------------
    # Categorical variables
    # --------------------------------------------------------

    categorical_columns = data.select_dtypes(
        include=["object", "category", "bool"]
    ).columns.tolist()

    print("\nCATEGORICAL VARIABLES")
    print("-" * 50)

    if categorical_columns:

        for col in categorical_columns:

            print(
                f"\n{col} "
                f"({data[col].nunique(dropna=True)} unique values)"
            )

            display(
                data[col]
                .value_counts(
                    dropna=False
                )
                .head(10)
                .to_frame("Count")
            )

    else:

        print("No categorical variables detected.")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 12 =====

# ============================================================

for file_name, data in datasets.items():

    numeric_columns = data.select_dtypes(
        include=np.number
    ).columns.tolist()


    print("\n" + "=" * 75)
    print(f"OUTLIER ANALYSIS: {file_name}")
    print("=" * 75)


    # --------------------------------------------------------
    # IQR outlier detection
    # --------------------------------------------------------

    outlier_results = []


    for col in numeric_columns:

        series = data[col].dropna()

        if len(series) < 5:
            continue

        Q1 = series.quantile(0.25)
        Q3 = series.quantile(0.75)

        IQR = Q3 - Q1

        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR

        count = (
            (series < lower)
            | (series > upper)
        ).sum()


        outlier_results.append({

            "Column": col,

            "Potential_Outliers": count,

            "Outlier_%": round(
                count / len(series) * 100,
                2
            )
        })


    if outlier_results:

        outlier_df = pd.DataFrame(
            outlier_results
        )

        display(
            outlier_df.sort_values(
                "Potential_Outliers",
                ascending=False
            )
        )

    else:

        print("No numerical variables suitable for outlier analysis.")


    # --------------------------------------------------------
    # Correlation
    # --------------------------------------------------------

    if len(numeric_columns) >= 2:

        print("\nNUMERICAL CORRELATION")

        correlation = (
            data[numeric_columns]
            .corr()
        )

        display(
            correlation.round(2)
        )


        plt.figure(
            figsize=(10, 7)
        )

        sns.heatmap(
            correlation,
            cmap="coolwarm",
            center=0,
            annot=False
        )

        plt.title(
            f"Numerical Correlation — {file_name}"
        )

        plt.tight_layout()
        plt.show()

    else:

        print(
            "\nCorrelation analysis requires "
            "at least two numerical variables."
        )

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 14 =====

# ============================================================

TARGET_KEYWORDS = [

    "target",
    "label",
    "class",
    "outcome",
    "risk",
    "rating",
    "score",
    "awarded",
    "selected",
    "winner",
    "failure",
    "performance",
    "default",
    "decision",
    "rank",
    "saving"
]


target_candidates_by_dataset = {}


for file_name, data in datasets.items():

    candidates = []


    for col in data.columns:

        normalized = normalize_column(col)

        keyword_matches = [
            keyword
            for keyword in TARGET_KEYWORDS
            if keyword in normalized
        ]


        if keyword_matches:

            candidates.append({

                "Column": col,

                "Data_Type":
                    str(data[col].dtype),

                "Unique_Values":
                    data[col].nunique(
                        dropna=True
                    ),

                "Missing_%":
                    round(
                        data[col].isna().mean()
                        * 100,
                        2
                    ),

                "Possible_Target":
                    ", ".join(
                        keyword_matches
                    )
            })


    target_candidates_by_dataset[
        file_name
    ] = candidates


# ------------------------------------------------------------
# Display candidates
# ------------------------------------------------------------

print("=" * 75)
print("POTENTIAL MACHINE LEARNING TARGETS")
print("=" * 75)

for file_name, candidates in (
    target_candidates_by_dataset.items()
):

    print(
        f"\n{file_name}"
    )

    if candidates:

        display(
            pd.DataFrame(candidates)
        )

    else:

        print(
            "No obvious target column detected."
        )


print("\n" + "=" * 75)

print("""
IMPORTANT
---------
Detected columns are only TARGET CANDIDATES.

A target will NOT be selected automatically.

Final model targets will be determined after:
• Data cleaning
• Feature engineering
• EDA
• Business relevance assessment
• Target distribution analysis
• Leakage checking
• Historical outcome validation

Different datasets may require different ML approaches.
""")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 16 =====

# ============================================================

print("\n" + "=" * 75)
print("VENDOR360 DATASET PROFILING REPORT")
print("=" * 75)


print(
    f"\nTOTAL UNIQUE DATASETS : {len(datasets)}"
)


# ------------------------------------------------------------
# Dataset-level reports
# ------------------------------------------------------------

for file_name, data in datasets.items():

    detected = detected_by_dataset[file_name]

    total_cells = (
        len(data)
        * len(data.columns)
    )

    missing_rate = (
        data.isna().sum().sum()
        / total_cells
        if total_cells > 0
        else 0
    )

    duplicate_rate = (
        data.duplicated().mean()
        if len(data) > 0
        else 0
    )


    numeric_count = len(
        data.select_dtypes(
            include=np.number
        ).columns
    )

    categorical_count = len(
        data.select_dtypes(
            include=[
                "object",
                "category",
                "bool"
            ]
        ).columns
    )


    print("\n" + "-" * 75)
    print(f"DATASET: {file_name}")
    print("-" * 75)

    print(f"""
SIZE
----
Rows              : {len(data):,}
Columns           : {len(data.columns):,}

DATA QUALITY
------------
Missing data      : {missing_rate * 100:.2f}%
Duplicate rows    : {duplicate_rate * 100:.2f}%

DATA TYPES
----------
Numeric columns   : {numeric_count}
Categorical cols  : {categorical_count}
Date columns      : {len(date_columns_by_dataset[file_name])}

VENDOR360 DIMENSIONS
--------------------
Supplier          : {"✓" if detected["Supplier"] else "✗"}
Cost              : {"✓" if detected["Cost"] else "✗"}
Reliability       : {"✓" if detected["Reliability"] else "✗"}
Quality           : {"✓" if detected["Quality"] else "✗"}
Risk              : {"✓" if detected["Risk"] else "✗"}
Sustainability    : {"✓" if detected["Sustainability"] else "✗"}
""")


# ------------------------------------------------------------
# Final conclusion
# ------------------------------------------------------------

print("\n" + "=" * 75)
print("PROFILING CONCLUSION")
print("=" * 75)

print("""
The uploaded datasets have been successfully profiled.

Vendor360 will NOT assume that every dataset contains
all supplier evaluation dimensions.

Available fields will be detected automatically and only
supported analysis modules will be executed.

The original datasets remain separate and are not merged
during ingestion.

NEXT STEP
---------
Proceed to:

02_Data_Cleaning_Standardization.ipynb

The next notebook will clean and standardize the detected
datasets while preserving the original source data.
""")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 18 =====

# ============================================================

# Preserve original source tables
raw_datasets = {
    name: data.copy(deep=True)
    for name, data in datasets.items()
}

print("=" * 75)
print("VENDOR360 — DATA CLEANING & STANDARDIZATION")
print("=" * 75)

print(f"\nDatasets received: {len(datasets)}")

for name, data in datasets.items():

    print(
        f"✓ {name:<35} "
        f"{len(data):>6,} rows × {len(data.columns):>3} columns"
    )

print("\n✓ Original datasets preserved in: raw_datasets")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 20 =====

# ============================================================

def standardize_column_name(column):

    column = str(column).strip().lower()

    column = re.sub(
        r"[^a-z0-9]+",
        "_",
        column
    )

    column = re.sub(
        r"_+",
        "_",
        column
    ).strip("_")

    return column


cleaned_datasets = {}


for name, data in raw_datasets.items():

    df_clean = data.copy()

    original_columns = list(
        df_clean.columns
    )

    new_columns = [
        standardize_column_name(col)
        for col in df_clean.columns
    ]


    # Prevent duplicate column names
    seen = {}
    final_columns = []

    for col in new_columns:

        if col not in seen:

            seen[col] = 0
            final_columns.append(col)

        else:

            seen[col] += 1

            final_columns.append(
                f"{col}_{seen[col]}"
            )


    df_clean.columns = final_columns

    cleaned_datasets[name] = df_clean


    print(f"\n{name}")

    for old, new in zip(
        original_columns,
        final_columns
    ):

        if str(old) != str(new):

            print(
                f"  {old} → {new}"
            )


print("\n✓ Column names standardized.")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 22 =====

# ============================================================

missing_tokens = [
    "",
    " ",
    "na",
    "n/a",
    "null",
    "none",
    "nan",
    "-",
    "--",
    "unknown",
    "not available"
]


cleaning_report = []


for name, data in cleaned_datasets.items():

    df_clean = data.copy()


    # --------------------------------------------------------
    # Clean text columns
    # --------------------------------------------------------

    text_columns = df_clean.select_dtypes(
        include=["object", "category"]
    ).columns


    for col in text_columns:

        df_clean[col] = (
            df_clean[col]
            .astype("string")
            .str.strip()
        )

        df_clean[col] = (
            df_clean[col]
            .replace(
                missing_tokens,
                np.nan,
                regex=False
            )
        )


    # --------------------------------------------------------
    # Convert numeric-looking columns
    # --------------------------------------------------------

    converted_columns = []


    for col in df_clean.columns:

        if df_clean[col].dtype == "object":

            converted = pd.to_numeric(
                df_clean[col],
                errors="coerce"
            )

            original_non_null = (
                df_clean[col].notna().sum()
            )

            converted_non_null = (
                converted.notna().sum()
            )


            if (
                original_non_null > 0
                and converted_non_null
                / original_non_null >= 0.95
            ):

                df_clean[col] = converted

                converted_columns.append(col)


    cleaned_datasets[name] = df_clean


    cleaning_report.append({

        "Dataset": name,

        "Rows": len(df_clean),

        "Columns": len(df_clean.columns),

        "Numeric_Conversions":
            len(converted_columns),

        "Remaining_Missing_Cells":
            df_clean.isna().sum().sum()
    })


cleaning_report_df = pd.DataFrame(
    cleaning_report
)


display(cleaning_report_df)

print(
    "\n✓ Values and data types standardized."
)

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 24 =====

# ============================================================

duplicate_report = []


for name, data in cleaned_datasets.items():

    duplicate_count = data.duplicated(
        keep=False
    ).sum()


    duplicate_report.append({

        "Dataset": name,

        "Rows": len(data),

        "Exact_Duplicate_Rows":
            duplicate_count,

        "Duplicate_%":
            round(
                duplicate_count / len(data) * 100,
                2
            )
            if len(data) > 0
            else 0
    })


duplicate_report_df = pd.DataFrame(
    duplicate_report
)


print("=" * 75)
print("DUPLICATE ANALYSIS")
print("=" * 75)

display(duplicate_report_df)


print("""
NOTE
----
Duplicates are reported rather than automatically deleted.

This is important because repeated records can be legitimate
in transactional datasets such as pricing or historical awards.
""")

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 26 =====

# ============================================================

def key_score(series):

    values = series.dropna()

    if len(values) == 0:
        return 0

    return values.nunique() / len(values)


key_candidates = {}


for name, data in cleaned_datasets.items():

    candidates = []

    for col in data.columns:

        uniqueness = key_score(data[col])

        name_hint = any(
            word in col
            for word in [
                "id",
                "code",
                "key",
                "number",
                "no"
            ]
        )

        if (
            name_hint
            or uniqueness >= 0.98
        ):

            candidates.append({

                "Column": col,

                "Unique_Ratio":
                    round(uniqueness, 3),

                "Unique_Values":
                    data[col].nunique(
                        dropna=True
                    ),

                "Missing_%":
                    round(
                        data[col].isna().mean() * 100,
                        2
                    )
            })


    key_candidates[name] = pd.DataFrame(
        candidates
    )


print("=" * 75)
print("KEY CANDIDATES")
print("=" * 75)


for name, candidates in key_candidates.items():

    print(f"\n{name}")

    if len(candidates):

        display(candidates)

    else:

        print(
            "No obvious identifier columns detected."
        )


# ------------------------------------------------------------
# Cross-dataset relationship detection
# ------------------------------------------------------------

relationships = []

dataset_names = list(
    cleaned_datasets.keys()
)


for i in range(len(dataset_names)):

    for j in range(i + 1, len(dataset_names)):

        name_a = dataset_names[i]
        name_b = dataset_names[j]

        df_a = cleaned_datasets[name_a]
        df_b = cleaned_datasets[name_b]


        for col_a in df_a.columns:

            values_a = set(
                df_a[col_a]
                .dropna()
                .astype(str)
            )

            if not values_a:
                continue


            for col_b in df_b.columns:

                values_b = set(
                    df_b[col_b]
                    .dropna()
                    .astype(str)
                )

                if not values_b:
                    continue


                overlap = (
                    len(values_a & values_b)
                    / min(
                        len(values_a),
                        len(values_b)
                    )
                )


                if overlap >= 0.70:

                    relationships.append({

                        "Dataset_A": name_a,

                        "Column_A": col_a,

                        "Dataset_B": name_b,

                        "Column_B": col_b,

                        "Value_Overlap_%":
                            round(
                                overlap * 100,
                                2
                            )
                    })


relationship_df = pd.DataFrame(
    relationships
)


print("\n" + "=" * 75)
print("DETECTED CROSS-DATASET RELATIONSHIPS")
print("=" * 75)


if len(relationship_df):

    display(
        relationship_df.sort_values(
            "Value_Overlap_%",
            ascending=False
        )
    )

else:

    print(
        "No strong cross-dataset relationships detected."
    )

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 28 =====

# ============================================================

table_roles = []


for name, data in cleaned_datasets.items():

    identifier_count = sum(
        any(
            word in col
            for word in [
                "id",
                "code",
                "key"
            ]
        )
        for col in data.columns
    )


    date_count = sum(
        pd.api.types.is_datetime64_any_dtype(
            data[col]
        )
        for col in data.columns
    )


    table_roles.append({

        "Dataset": name,

        "Rows": len(data),

        "Columns": len(data.columns),

        "Identifier_Columns":
            identifier_count,

        "Date_Columns":
            date_count,

        "Likely_Table_Type":
            (
                "Reference/Master"
                if len(data) < 500
                and identifier_count >= 1
                else
                "Transactional/Operational"
            )
    })


table_roles_df = pd.DataFrame(
    table_roles
)


print("=" * 75)
print("TABLE ROLE ANALYSIS")
print("=" * 75)

display(table_roles_df)

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 30 =====

# ============================================================

supplier_profile = None

supplier_table_candidates = []


# ------------------------------------------------------------
# Identify supplier-level tables
# ------------------------------------------------------------

for name, data in cleaned_datasets.items():

    supplier_id_columns = [
        col
        for col in data.columns
        if (
            "supplier_id" in col
            or "vendor_id" in col
        )
    ]


    if not supplier_id_columns:
        continue


    supplier_key = supplier_id_columns[0]

    supplier_count = (
        data[supplier_key]
        .nunique(dropna=True)
    )


    rows = len(data)


    # A supplier master table should normally have
    # approximately one row per supplier.
    row_supplier_ratio = (
        rows / supplier_count
        if supplier_count > 0
        else np.inf
    )


    supplier_table_candidates.append({

        "Dataset": name,

        "Supplier_Key": supplier_key,

        "Rows": rows,

        "Unique_Suppliers":
            supplier_count,

        "Rows_Per_Supplier":
            round(
                row_supplier_ratio,
                2
            ),

        "Supplier_Name":
            "supplier_name"
            if "supplier_name" in data.columns
            else None
    })


supplier_table_candidates_df = pd.DataFrame(
    supplier_table_candidates
)


print("=" * 75)
print("SUPPLIER TABLE CANDIDATES")
print("=" * 75)


if len(supplier_table_candidates_df):

    display(
        supplier_table_candidates_df
    )

else:

    print(
        "No supplier-level table detected."
    )


# ------------------------------------------------------------
# Select supplier master table
# ------------------------------------------------------------

if len(supplier_table_candidates_df):

    # Prefer a table where:
    # rows ≈ unique suppliers
    #
    # This prevents pricing or transaction tables
    # from being incorrectly selected.

    candidates = (
        supplier_table_candidates_df
        .copy()
    )


    candidates["Master_Table_Score"] = (
        abs(
            candidates["Rows_Per_Supplier"] - 1
        )
    )


    selected = candidates.sort_values(
        "Master_Table_Score"
    ).iloc[0]


    selected_table = selected[
        "Dataset"
    ]

    supplier_key = selected[
        "Supplier_Key"
    ]


    supplier_profile = (
        cleaned_datasets[
            selected_table
        ].copy()
    )


    print("\n" + "=" * 75)
    print("SELECTED SUPPLIER MASTER TABLE")
    print("=" * 75)

    print(
        f"\nSource table : {selected_table}"
    )

    print(
        f"Supplier key: {supplier_key}"
    )

    print(
        f"Suppliers   : "
        f"{supplier_profile[supplier_key].nunique():,}"
    )

    print(
        f"Rows        : "
        f"{len(supplier_profile):,}"
    )


else:

    print(
        "\nNo reliable supplier master table "
        "could be identified."
    )


# ------------------------------------------------------------
# Store analysis-ready objects
# ------------------------------------------------------------

analysis_ready = {}


if supplier_profile is not None:

    analysis_ready[
        "supplier_profile"
    ] = supplier_profile


print("\n✓ Analysis-ready objects:")

for name, data in analysis_ready.items():

    print(
        f"  {name}: "
        f"{len(data):,} rows × "
        f"{len(data.columns):,} columns"
    )

# ============================================================


# ===== ORIGINAL NOTEBOOK CELL 32 =====

# ============================================================

print("=" * 75)
print("VENDOR360 — DATA GRAIN & RELATIONSHIP VALIDATION")
print("=" * 75)

# ------------------------------------------------------------
# 1. Identify likely identifier columns
# ------------------------------------------------------------

id_columns_by_dataset = {}

for name, data in cleaned_datasets.items():

    id_cols = []

    for col in data.columns:

        col_lower = col.lower()

        if (
            col_lower.endswith("_id")
            or col_lower.endswith("_code")
            or col_lower in [
                "id",
                "code",
                "key"
            ]
        ):
            id_cols.append(col)

    id_columns_by_dataset[name] = id_cols


# ------------------------------------------------------------
# 2. Check uniqueness of identifier columns
# ------------------------------------------------------------

print("\n" + "=" * 75)
print("IDENTIFIER CARDINALITY")
print("=" * 75)

for name, data in cleaned_datasets.items():

    print(f"\n{name}")

    id_cols = id_columns_by_dataset[name]

    if not id_cols:

        print("  No obvious identifier columns.")

        continue

    for col in id_cols:

        total = data[col].notna().sum()
        unique = data[col].nunique(dropna=True)

        ratio = (
            unique / total
            if total > 0
            else 0
        )

        print(
            f"  {col:<30} "
            f"unique={unique:>5,} | "
            f"non-null={total:>5,} | "
            f"uniqueness={ratio:.1%}"
        )


# ------------------------------------------------------------
# 3. Detect likely composite grains
# ------------------------------------------------------------

print("\n" + "=" * 75)
print("LIKELY DATA GRAIN")
print("=" * 75)

grain_candidates = {}

for name, data in cleaned_datasets.items():

    candidates = []

    # Single-column identifiers
    for col in id_columns_by_dataset[name]:

        unique_ratio = (
            data[col].nunique(dropna=True)
            / data[col].notna().sum()
            if data[col].notna().sum() > 0
            else 0
        )

        if unique_ratio >= 0.95:

            candidates.append([col])

    # Common business dimensions
    possible_dimensions = [
        col for col in [
            "supplier_id",
            "vendor_id",
            "category_l1",
            "category_l2",
            "country",
            "region",
            "business_unit"
        ]
        if col in data.columns
    ]

    # Test useful two-column combinations
    for i in range(len(possible_dimensions)):

        for j in range(i + 1, len(possible_dimensions)):

            cols = [
                possible_dimensions[i],
                possible_dimensions[j]
            ]

            unique_rows = (
                data[cols]
                .drop_duplicates()
                .shape[0]
            )

            ratio = (
                unique_rows / len(data)
                if len(data) > 0
                else 0
            )

            if ratio >= 0.95:

                candidates.append(cols)

    # Remove duplicate candidates
    unique_candidates = []

    for candidate in candidates:

        if candidate not in unique_candidates:
            unique_candidates.append(candidate)

    grain_candidates[name] = unique_candidates

    print(f"\n{name}")

    if unique_candidates:

        for candidate in unique_candidates[:10]:

            print(
                "  ✓ "
                + " + ".join(candidate)
            )

    else:

        print(
            "  No near-unique grain detected."
        )


# ------------------------------------------------------------
# 4. Validate supplier-category grain
# ------------------------------------------------------------

print("\n" + "=" * 75)
print("SUPPLIER-CATEGORY GRAIN CHECK")
print("=" * 75)

for name, data in cleaned_datasets.items():

    required = [
        "supplier_id",
        "category_l1",
        "category_l2"
    ]

    if all(col in data.columns for col in required):

        unique_combinations = (
            data[
                required
            ]
            .drop_duplicates()
            .shape[0]
        )

        duplicate_combinations = (
            len(data)
            - unique_combinations
        )

        print(f"\n{name}")

        print(
            f"  Rows: "
            f"{len(data):,}"
        )

        print(
            f"  Unique supplier-category combinations: "
            f"{unique_combinations:,}"
        )

        print(
            f"  Repeated combinations: "
            f"{duplicate_combinations:,}"
        )

        if duplicate_combinations == 0:

            print(
                "  ✓ Supplier + category combination "
                "is unique."
            )

        else:

            print(
                "  ℹ Multiple records exist for some "
                "supplier-category combinations."
            )


# ------------------------------------------------------------
# 5. Store structural metadata
# ------------------------------------------------------------

dataset_structure = {
    "id_columns": id_columns_by_dataset,
    "grain_candidates": grain_candidates
}

print("\n" + "=" * 75)
print("STRUCTURAL ANALYSIS COMPLETE")
print("=" * 75)

print(
    "\n✓ Identifier information stored in:"
    " id_columns_by_dataset"
)

print(
    "✓ Grain candidates stored in:"
    " grain_candidates"
)

print(
    "✓ Combined structural metadata stored in:"
    " dataset_structure"
)

# ============================================================


# ------------------------------------------------------------
# Shared status helper (Phase 4 / P5): a banner says PASS only when every check actually ran and passed.
#   PASS            all checks ran and passed
#   PARTIAL         nothing failed, but at least one check could not run (value None)
#   CHECK REQUIRED  at least one check ran and failed (or the check itself raised)
# ------------------------------------------------------------
VENDOR360_STATUS = {}

def v360_file_ok(path):
    try:
        return os.path.isfile(path) and os.path.getsize(path) > 0
    except Exception:
        return False

def v360_json_ok(path):
    try:
        import json as _j
        with open(path, encoding="utf-8") as _fh:
            _j.load(_fh)
        return True
    except Exception:
        return False

def v360_csv_rows(path):
    try:
        return int(len(pd.read_csv(path)))
    except Exception:
        return 0

def v360_status(cell, checks):
    """checks: {name: True | False | None | callable}. Callables are executed; an exception counts as a failure."""
    results = {}
    for name, chk in checks.items():
        try:
            val = chk() if callable(chk) else chk
        except Exception as exc:
            print(f"  (check '{name}' raised {type(exc).__name__}: {exc})")
            val = False
        results[name] = None if val is None else bool(val)
    for name, val in results.items():
        print(f"  {'✓' if val else ('–' if val is None else '✗')} {name}" + ("  (could not run)" if val is None else ""))
    if any(v is False for v in results.values()):
        status = "CHECK REQUIRED"
    elif any(v is None for v in results.values()):
        status = "PARTIAL"
    else:
        status = "PASS"
    n_ok = sum(v is True for v in results.values())
    VENDOR360_STATUS[cell] = {"status": status, "passed": n_ok, "total": len(results), "checks": results}
    print("\n" + "=" * 70)
    print(f"{cell} STATUS: {status} ({n_ok}/{len(results)} checks passed)")
    print("=" * 70)
    return status
