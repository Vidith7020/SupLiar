"""
Deterministic answers for the Vendor360 AI Advisor.

DATA -> ANALYSIS -> DECISION SUPPORT -> AI EXPLANATION
Everything returned here is computed from verified tables; nothing is generated.
If a question is not recognised the function returns None, and the caller may
hand the VERIFIED context to Gemini for explanation. Gemini never supplies numbers.

answer_question(question, suppliers, risk, n_entities, scenario_runner)
    suppliers : DataFrame with 'Supplier ID','Supplier Name','Overall Decision Score','Supplier Rank'
    risk      : Risk Radar DataFrame (entity_id/entity_name/risk_radar_* columns) or empty
    scenario_runner(text) -> engine result dict (scenario_engine.run_scenario output) or None
"""

from __future__ import annotations

import re
from typing import Callable, Optional

import pandas as pd

_DIM_WORDS = {
    "cost": r"\b(?:cost|price|cheap|cheapest|afford\w*|budget)\b",
    "quality": r"\bquality\b",
    "reliability": r"\b(?:reliab\w*|deliver\w*|lead[- ]time|on[- ]time)\b",
    "risk": r"\brisk\w*\b",
    "sustainability": r"\b(?:sustainab\w*|esg|green|environment\w*)\b",
    "capacity": r"\b(?:capacity|volume|scale)\b",
}
_NOTE = " This is decision support, not an automatic purchasing decision."


def _has(q: str, pattern: str) -> bool:
    return re.search(pattern, q) is not None


def _col(df: pd.DataFrame, *names):
    for n in names:
        if n in df.columns:
            return n
    return None


def _mentioned_dims(q: str):
    return [d for d, p in _DIM_WORDS.items() if _has(q, p)]


def _find_supplier(q: str, suppliers: pd.DataFrame):
    """Supplier whose name or id appears in the question (longest name wins)."""
    best = None
    for _, r in suppliers.iterrows():
        name = str(r["Supplier Name"]).lower()
        sid = str(r["Supplier ID"]).lower()
        if (name and name in q) or (sid and sid in q):
            if best is None or len(name) > len(str(best["Supplier Name"])):
                best = r
    return best


def _risk_rows(risk: pd.DataFrame):
    band = _col(risk, "risk_radar_band", "risk_band", "risk_level")
    action = _col(risk, "risk_radar_action", "management_action")
    rank = _col(risk, "risk_radar_rank")
    name = _col(risk, "entity_name", "supplier_name")
    sid = _col(risk, "entity_id", "supplier_id")
    score = _col(risk, "risk_radar_score")
    sig = _col(risk, "risk_radar_signal_count")
    flags = _col(risk, "risk_radar_flags")
    return dict(band=band, action=action, rank=rank, name=name, sid=sid, score=score, sig=sig, flags=flags)


def answer_question(question: str, suppliers: pd.DataFrame, risk: Optional[pd.DataFrame],
                    n_entities: int,
                    scenario_runner: Optional[Callable[[str], Optional[dict]]] = None) -> Optional[str]:
    q = str(question or "").lower().strip()
    if not q:
        return None
    risk = risk if risk is not None else pd.DataFrame()
    has_suppliers = suppliers is not None and not suppliers.empty
    dims = _mentioned_dims(q)

    # 1) counts -----------------------------------------------------------
    if _has(q, r"\bhow many (?:suppliers|vendors|entities)\b|\bnumber of (?:suppliers|vendors|entities)\b"):
        return f"The analysis evaluates **{int(n_entities)} suppliers**."

    rr = _risk_rows(risk) if not risk.empty else None

    # 2) risk distribution ---------------------------------------------------
    if "risk" in dims and rr and rr["band"] and _has(q, r"\b(?:distribution|breakdown|split|bands?|levels?|how many|count)\b"):
        counts = risk[rr["band"]].astype(str).str.upper().value_counts()
        parts = [f"{int(counts.get(b, 0))} {b}" for b in ("HIGH", "MEDIUM", "LOW")]
        msg = "Risk Radar band distribution: " + ", ".join(parts) + "."
        if rr["action"]:
            ac = risk[rr["action"]].astype(str).str.upper().value_counts()
            msg += (" Management actions are a separate signal: "
                    + ", ".join(f"{int(ac.get(a, 0))} {a}" for a in ("ESCALATE", "REVIEW", "MONITOR")) + ".")
        return msg + " The Risk Radar is an early-warning tool, not proof that a supplier will fail."

    # 3) major risks / most risky suppliers ----------------------------------
    if "risk" in dims and rr and rr["rank"] and _has(q, r"\b(?:major|top|main|biggest|highest|key|worst|most|which)\b"):
        top = risk.sort_values(rr["rank"]).head(5)
        lines = []
        for _, r in top.iterrows():
            bit = f"{r[rr['name']]} ({r[rr['sid']]})"
            if rr["band"] and rr["action"]:
                bit += f": band {r[rr['band']]}, action {r[rr['action']]}"
            if rr["sig"] is not None:
                bit += f", {int(r[rr['sig']])} warning signals"
            lines.append(bit)
        return ("Highest-ranked suppliers on the Risk Radar:\n- " + "\n- ".join(lines)
                + "\n\nBand and management action are different: a LOW band can still carry ESCALATE when several "
                  "warning signals are present." + _NOTE)

    # 4) a named supplier -------------------------------------------------
    if has_suppliers:
        sup = _find_supplier(q, suppliers)
        if sup is not None:
            txt = (f"**{sup['Supplier Name']}** ({sup['Supplier ID']}): supplier-level decision score "
                   f"{sup['Overall Decision Score']:.3f}, rank {int(sup['Supplier Rank'])} of {len(suppliers)}.")
            if rr and rr["sid"]:
                m = risk[risk[rr["sid"]].astype(str) == str(sup["Supplier ID"])]
                if not m.empty:
                    m = m.iloc[0]
                    txt += f" Risk Radar: rank {int(m[rr['rank']])}" if rr["rank"] else " Risk Radar:"
                    if rr["band"]:
                        txt += f", band {m[rr['band']]}"
                    if rr["action"]:
                        txt += f", action {m[rr['action']]}"
                    if rr["flags"] and pd.notna(m[rr["flags"]]) and str(m[rr["flags"]]).strip():
                        txt += f". Signals: {m[rr['flags']]}"
                    txt += "."
            return txt

    # 5) best / recommend -------------------------------------------------------
    if has_suppliers and _has(q, r"\b(?:best|top|recommend\w*|ideal|should (?:we|i) (?:choose|pick|select)|which supplier)\b"):
        # criteria in the question -> use the SAME scenario engine as Cell 25 / What-If
        if dims and scenario_runner is not None:
            res = scenario_runner(question)
            if res and res.get("explanation", {}).get("recommendation"):
                rec = res["explanation"]["recommendation"]
                w = res["weights"]
                wt = ", ".join(f"{d} {v:.0%}" for d, v in sorted(w.items(), key=lambda kv: -kv[1]) if v >= 0.05)
                msg = (f"For that priority mix ({wt}), the scenario engine ranks **{rec['supplier_name']}** first "
                       f"(score {rec['score']:.3f}).")
                for t in res["explanation"].get("trade_offs", [])[:2]:
                    msg += f" Trade-off: {t['note']}"
                return msg + _NOTE
        best = suppliers.sort_values("Supplier Rank").iloc[0]
        return (f"The current top supplier on the supplier-level decision score is **{best['Supplier Name']}** "
                f"(score {best['Overall Decision Score']:.3f}, equal weights across available dimensions)." + _NOTE)

    return None
