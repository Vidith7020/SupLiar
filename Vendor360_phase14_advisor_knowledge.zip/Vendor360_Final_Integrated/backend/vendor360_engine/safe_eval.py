"""
Leakage-safe model evaluation (replacement for the classification and
regression blocks of Cell 19).

What was wrong
--------------
* SimpleImputer(median) was fit on ALL rows, then the data was split, so the
  test rows influenced the imputation values (preprocessing leakage).
* If several rows belong to one supplier (supplier x category), a random split
  puts the same supplier in train and test (entity leakage).
* The "best" model was chosen by looking at test-set metrics, so the reported
  test score is optimistically biased (selection leakage).
* Predictors that are (near) copies of the target were not screened.
* Accuracy was reported without the majority-class baseline, which makes
  83-87% on an imbalanced 151-row target look better than it may be.

What this does
--------------
* imputer + scaler + model live in ONE sklearn Pipeline; they are fit on
  training data only (inside CV folds too).
* Splits are grouped by entity id when one is supplied.
* Models are chosen by cross-validation on the training portion; the test set
  is scored once, afterwards, for reporting.
* Every result carries a baseline and an honest reliability note.
"""

from __future__ import annotations

import warnings
import re
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import (GradientBoostingClassifier, GradientBoostingRegressor,
                              RandomForestClassifier, RandomForestRegressor)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, mean_absolute_error,
                             mean_squared_error, precision_score, r2_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import (GroupKFold, GroupShuffleSplit, KFold,
                                     StratifiedKFold, cross_val_score,
                                     train_test_split)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor


def screen_leaky_predictors(X: pd.DataFrame, y: pd.Series, threshold: float = 0.98):
    """Drop predictors that duplicate the target. Returns (clean_X, report)."""
    report = []
    keep = []
    yn = pd.to_numeric(y, errors="coerce")
    for c in X.columns:
        xn = pd.to_numeric(X[c], errors="coerce")
        pair = pd.concat([xn, yn], axis=1).dropna()
        if len(pair) >= 8 and pair.iloc[:, 0].nunique() > 1 and pair.iloc[:, 1].nunique() > 1:
            rho = pair.iloc[:, 0].corr(pair.iloc[:, 1], method="spearman")
            if pd.notna(rho) and abs(rho) >= threshold:
                report.append((c, f"|Spearman| with target = {abs(rho):.3f}"))
                continue
        keep.append(c)
    return X[keep], report


def name_overlaps_target(name: str, target_name: str) -> bool:
    """Compatibility helper used by newer Cell 19 versions.
    Returns True when a predictor name is essentially restating the target.
    """
    def _norm(s):
        return re.sub(r"[^a-z0-9]+", "", str(s).lower())
    a, b = _norm(name), _norm(target_name)
    return bool(a and b and (a == b or a in b or b in a))


def _pipe(model):
    return Pipeline([("impute", SimpleImputer(strategy="median")),
                     ("scale", StandardScaler()),
                     ("model", model)])


def _split(X, y, groups, test_size, seed, stratify):
    if groups is not None and pd.Series(groups).nunique() >= 10:
        gss = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
        tr, te = next(gss.split(X, y, groups))
        return tr, te, "grouped by entity"
    idx = np.arange(len(X))
    tr, te = train_test_split(idx, test_size=test_size, random_state=seed,
                              stratify=y if stratify else None)
    return tr, te, "random" + (" stratified" if stratify else "")


def _cv(y_train, groups_train, stratified, k, seed):
    if groups_train is not None and pd.Series(groups_train).nunique() >= k:
        return GroupKFold(n_splits=k)
    if stratified:
        k = max(2, min(k, int(pd.Series(y_train).value_counts().min())))
        return StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    return KFold(n_splits=k, shuffle=True, random_state=seed)


def classification_models(seed=42) -> Dict[str, object]:
    return {
        "Logistic Regression": LogisticRegression(max_iter=2000),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=seed),
        "Random Forest": RandomForestClassifier(n_estimators=200, random_state=seed),
        "Gradient Boosting": GradientBoostingClassifier(random_state=seed),
    }


def regression_models(seed=42) -> Dict[str, object]:
    return {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=5, random_state=seed),
        "Random Forest": RandomForestRegressor(n_estimators=200, random_state=seed),
        "Gradient Boosting": GradientBoostingRegressor(random_state=seed),
    }


def _overlap(groups, tr, te):
    """Number of entities present in both train and test (must be 0 when grouped)."""
    if groups is None:
        return None
    return int(len(set(groups.iloc[tr]) & set(groups.iloc[te])))


def _note(n_test, extra=None):
    notes = []
    if n_test < 30:
        notes.append(f"only {n_test} test rows: metric is unstable")
    if extra:
        notes.append(extra)
    return "; ".join(notes) or "ok"


def evaluate_classification(X: pd.DataFrame, y: pd.Series, groups=None, test_size=0.25,
                            seed=42, cv_splits=5, models=None, target_name=None) -> dict:
    X = X.reset_index(drop=True)
    y = pd.Series(y).reset_index(drop=True)
    g = None if groups is None else pd.Series(groups).reset_index(drop=True)
    X, leaks = screen_leaky_predictors(X, y)
    if X.shape[1] < 2:
        return {"status": "skipped", "reason": "fewer than 2 usable predictors after leakage screening", "leaky_predictors": leaks}
    tr, te, how = _split(X, y, g, test_size, seed, stratify=True)
    Xtr, Xte, ytr, yte = X.iloc[tr], X.iloc[te], y.iloc[tr], y.iloc[te]
    if ytr.nunique() < 2 or yte.nunique() < 2:
        return {"status": "skipped", "reason": "a split lost one class", "split": how, "leaky_predictors": leaks}
    gtr = None if g is None else g.iloc[tr]
    cv = _cv(ytr, gtr, True, cv_splits, seed)

    rows, cv_scores = [], {}
    base = DummyClassifier(strategy="most_frequent").fit(Xtr, ytr)
    base_acc = accuracy_score(yte, base.predict(Xte))
    for name, model in (models if models is not None else classification_models(seed)).items():
        pipe = _pipe(model)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cvs = cross_val_score(pipe, Xtr, ytr, cv=cv, groups=gtr, scoring="f1_macro")
        cv_scores[name] = float(np.mean(cvs))
        pipe.fit(Xtr, ytr)
        pred = pipe.predict(Xte)
        try:
            auc = roc_auc_score(yte, pipe.predict_proba(Xte)[:, 1])
        except Exception:
            auc = np.nan
        rows.append({"model": name, "cv_f1_macro_train": cv_scores[name],
                     "accuracy": accuracy_score(yte, pred),
                     "precision": precision_score(yte, pred, zero_division=0),
                     "recall": recall_score(yte, pred, zero_division=0),
                     "f1": f1_score(yte, pred, zero_division=0),
                     "auc": auc, "baseline_accuracy": base_acc})
    selected = max(cv_scores, key=cv_scores.get)           # chosen WITHOUT the test set
    res = pd.DataFrame(rows)
    sel_acc = float(res.loc[res.model == selected, "accuracy"].iloc[0])
    return {
        "status": "ok", "split": how, "n_train": len(tr), "n_test": len(te),
        "group_overlap": _overlap(g, tr, te),
        "selected_model": selected, "selection_basis": "cross-validated macro-F1 on training rows only",
        "results": res, "baseline_accuracy": float(base_acc), "leaky_predictors": leaks,
        "beats_baseline": bool(sel_acc > base_acc + 0.02),
        "note": _note(len(te), None if sel_acc > base_acc + 0.02 else
                      "selected model does not clearly beat the majority-class baseline"),
    }


def evaluate_regression(X: pd.DataFrame, y: pd.Series, groups=None, test_size=0.25,
                        seed=42, cv_splits=5, models=None, target_name=None) -> dict:
    X = X.reset_index(drop=True)
    y = pd.to_numeric(pd.Series(y).reset_index(drop=True), errors="coerce")
    g = None if groups is None else pd.Series(groups).reset_index(drop=True)
    X, leaks = screen_leaky_predictors(X, y)
    if X.shape[1] < 2:
        return {"status": "skipped", "reason": "fewer than 2 usable predictors after leakage screening", "leaky_predictors": leaks}
    tr, te, how = _split(X, y, g, test_size, seed, stratify=False)
    Xtr, Xte, ytr, yte = X.iloc[tr], X.iloc[te], y.iloc[tr], y.iloc[te]
    gtr = None if g is None else g.iloc[tr]
    cv = _cv(ytr, gtr, False, cv_splits, seed)
    rows, cv_scores = [], {}
    base = DummyRegressor(strategy="mean").fit(Xtr, ytr)
    base_mae = mean_absolute_error(yte, base.predict(Xte))
    for name, model in (models if models is not None else regression_models(seed)).items():
        pipe = _pipe(model)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cvs = cross_val_score(pipe, Xtr, ytr, cv=cv, groups=gtr, scoring="neg_mean_absolute_error")
        cv_scores[name] = float(np.mean(cvs))
        pipe.fit(Xtr, ytr)
        pred = pipe.predict(Xte)
        rows.append({"model": name, "cv_mae_train": -cv_scores[name],
                     "mae": mean_absolute_error(yte, pred),
                     "rmse": float(np.sqrt(mean_squared_error(yte, pred))),
                     "r2": r2_score(yte, pred), "baseline_mae": base_mae})
    selected = max(cv_scores, key=cv_scores.get)
    res = pd.DataFrame(rows)
    sel = res.loc[res.model == selected].iloc[0]
    better = bool(sel["mae"] < base_mae * 0.95)
    return {
        "status": "ok", "split": how, "n_train": len(tr), "n_test": len(te),
        "group_overlap": _overlap(g, tr, te),
        "selected_model": selected, "selection_basis": "cross-validated MAE on training rows only",
        "results": res, "baseline_mae": float(base_mae), "leaky_predictors": leaks,
        "beats_baseline": better,
        "note": _note(len(te), None if better else "selected model does not clearly beat predicting the mean"),
    }
