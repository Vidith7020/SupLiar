"""
Vendor360 MCDA helpers (drop-in replacement for the MCDA block of Cell 19,
and the shared way Cell 23 should build dimension KPIs).

Problems this fixes in the original implementation
--------------------------------------------------
1. A dimension was the plain mean of its RAW columns. Columns on different
   scales (price in thousands, a 1-5 rating, a percentage) let the largest
   scale dominate, and columns with opposite meaning (lead_time: lower is
   better; on_time_rate: higher is better) were averaged together and then
   inverted as a whole. Each column is now oriented and rescaled to a 0-1
   "goodness" BEFORE averaging.
2. Semantically duplicated columns (x, x_norm, x_scaled, or two columns with
   |Spearman| >= 0.95) counted several times inside one dimension. They are
   now collapsed to one representative and reported.
3. Missing values: composites average the columns that exist for a row and
   report how many were available; they are never silently filled.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

_LOWER_HINTS = [
    "lead_time", "leadtime", "delivery_time", "delivery_days", "days_to", "delay", "late",
    "defect", "reject", "return", "failure", "complaint", "incident",
    "cost", "price", "spend", "risk", "emission", "carbon", "volatility", "dependency",
]
_HIGHER_HINTS = [
    "on_time", "ontime", "reliab", "quality", "score", "rating", "esg", "sustain",
    "capacity", "compliance", "certif", "yield", "acceptance",
]
_STEM_SUFFIX = re.compile(r"(?:_norm(?:alized|alised)?|_scaled|_std|_z|_zscore|_pct|_percent|_index|_normalized)$")

# Dimensions whose *default* direction is lower-is-better when the name is ambiguous.
DIMENSION_DEFAULT = {
    "cost": "lower", "risk": "lower",
    "quality": "higher", "reliability": "higher", "sustainability": "higher", "capacity": "higher",
}


def infer_column_direction(column: str, dimension: str) -> str:
    """'lower' or 'higher' for ONE column, from its own name first, then from
    the dimension default. 'late_delivery_rate' -> lower even inside Reliability."""
    name = re.sub(r"[^a-z0-9]+", "_", str(column).lower()).strip("_")
    # explicit "higher is better" patterns win over the generic lower hints
    # (e.g. 'on_time_delivery' contains 'delivery' but is higher-is-better)
    if re.search(r"on_?time|reliab|quality_score|esg|compliance", name) and not re.search(r"late|delay|defect", name):
        return "higher"
    if any(h in name for h in _LOWER_HINTS):
        # 'cost_score' / 'risk_score' are still costs/risks -> lower
        return "lower"
    if any(h in name for h in _HIGHER_HINTS):
        return "higher"
    return DIMENSION_DEFAULT.get(str(dimension).lower(), "higher")


def _stem(column: str) -> str:
    n = re.sub(r"[^a-z0-9]+", "_", str(column).lower()).strip("_")
    n = re.sub(r"^[a-z]+__", "", n)           # strip 'cost__' style prefixes
    return _STEM_SUFFIX.sub("", n)


def drop_redundant_columns(df: pd.DataFrame, columns: Iterable[str], corr_threshold: float = 0.95):
    """Keep one column per group of duplicates. Returns (kept, dropped) where
    dropped is a list of (column, reason, kept_equivalent)."""
    cols = [c for c in columns if c in df.columns]
    kept: List[str] = []
    dropped = []
    num = df[cols].apply(pd.to_numeric, errors="coerce")
    for c in cols:
        if num[c].notna().sum() == 0 or num[c].nunique(dropna=True) <= 1:
            dropped.append((c, "empty or constant", None))
            continue
        dup_of = None
        for k in kept:
            if _stem(c) == _stem(k):
                dup_of, reason = k, "same name stem"
                break
            pair = num[[c, k]].dropna()
            if len(pair) >= 8 and pair[c].nunique() > 1 and pair[k].nunique() > 1:
                rho = pair[c].corr(pair[k], method="spearman")
                if pd.notna(rho) and abs(rho) >= corr_threshold:
                    dup_of, reason = k, f"|Spearman|={abs(rho):.2f}"
                    break
        if dup_of is None:
            kept.append(c)
        else:
            dropped.append((c, reason, dup_of))
    return kept, dropped


def goodness(series: pd.Series, direction: str, winsor: float = 0.0) -> pd.Series:
    """0-1 where 1 is best. NaN stays NaN."""
    v = pd.to_numeric(series, errors="coerce")
    if v.notna().sum() == 0:
        return pd.Series(np.nan, index=series.index)
    if winsor and v.notna().sum() >= 20:
        lo, hi = v.quantile(winsor), v.quantile(1 - winsor)
        v = v.clip(lo, hi)
    lo, hi = v.min(), v.max()
    if np.isclose(lo, hi):
        return pd.Series(0.5, index=series.index).where(v.notna())
    g = (v - lo) / (hi - lo)
    return (1 - g) if direction == "lower" else g


def dimension_composite(df: pd.DataFrame, columns: Iterable[str], dimension: str,
                        corr_threshold: float = 0.95, winsor: float = 0.0,
                        direction_overrides: Optional[Dict[str, str]] = None):
    """Return (composite 0-1 goodness Series, info dict)."""
    kept, dropped = drop_redundant_columns(df, columns, corr_threshold)
    overrides = direction_overrides or {}
    parts, directions = {}, {}
    for c in kept:
        d = overrides.get(c) or infer_column_direction(c, dimension)
        directions[c] = d
        parts[c] = goodness(df[c], d, winsor)
    if not parts:
        return pd.Series(np.nan, index=df.index), {"kept": [], "dropped": dropped, "directions": {}, "n_available": pd.Series(0, index=df.index)}
    P = pd.DataFrame(parts)
    comp = P.mean(axis=1, skipna=True)
    return comp, {"kept": kept, "dropped": dropped, "directions": directions, "n_available": P.notna().sum(axis=1)}


def mcda_scores(df: pd.DataFrame, dimension_features: Dict[str, List[str]],
                weights: Optional[Dict[str, float]] = None, **kw):
    """Equal-weight MCDA by default (weights renormalised over available
    dimensions). Every dimension composite is already 'higher is better',
    so there is no second inversion step.

    Returns (scored_df, report). scored_df gains mcda__<dim>_score,
    mcda__overall_score, mcda__rank (method='min' so ties share a rank)."""
    out = df.copy()
    report = {}
    comps = {}
    for dim, cols in dimension_features.items():
        usable = [c for c in cols if c in df.columns]
        comp, info = dimension_composite(df, usable, dim, **kw)
        if info["kept"]:
            comps[dim] = comp
            out[f"mcda__{dim}_score"] = comp
            report[dim] = info
    if not comps:
        out["mcda__overall_score"] = np.nan
        out["mcda__rank"] = np.nan
        return out, report
    w = pd.Series({d: (weights or {}).get(d, 1.0) for d in comps}, dtype=float)
    w = w / w.sum()
    C = pd.DataFrame(comps)
    avail = C.notna().mul(w, axis=1).sum(axis=1)
    overall = C.fillna(0).mul(w, axis=1).sum(axis=1) / avail.where(avail > 0)
    out["mcda__overall_score"] = overall
    out["mcda__rank"] = overall.rank(ascending=False, method="min")
    out["mcda__dimensions_used"] = len(comps)
    return out, report
