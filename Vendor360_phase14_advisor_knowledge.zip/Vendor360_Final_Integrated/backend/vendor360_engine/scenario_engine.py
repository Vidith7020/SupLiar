"""
Vendor360 scenario decision engine  (official implementation of Cell 25).

DATA -> ANALYSIS -> DECISION SUPPORT -> AI EXPLANATION
This module is the DECISION SUPPORT layer for scenarios. It is pure:
no file I/O, no Colab, no Streamlit, no Gemini. Cell 25 and the Streamlit
What-If page both import from here, so there is exactly one set of rankings.

Public API
----------
interpret_scenario(text, dimensions)        -> interpretation dict
build_weights(interpretation, dimensions)   -> {dimension: weight}
score_suppliers(df, interpretation, weights, dimension_columns, id_col, name_col)
                                            -> (ranking_df, contributions_df)
explain_ranking(...)                        -> deterministic explanation dict
run_scenario(...)                           -> everything above in one call
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

DIMENSIONS = ["Cost", "Quality", "Reliability", "Risk", "Sustainability", "Capacity"]

DEFAULT_DIRECTION = {
    "Cost": "lower",
    "Quality": "higher",
    "Reliability": "higher",
    "Risk": "lower",
    "Sustainability": "higher",
    "Capacity": "higher",
}

# "mild" is new: it is what a hedged requirement or a partly-tolerated
# dimension maps to ("reasonably low risk, but we can accept some more").
PRIORITY_MULTIPLIERS = {
    "neutral": 0.10,
    "mild": 0.40,
    "positive": 1.00,
    "strong_positive": 2.50,
}
_LEVELS = ["neutral", "mild", "positive", "strong_positive"]

# Words that identify a dimension in free text (plural / variant aware).
DIMENSION_TERMS = {
    "Cost": [r"costs?", r"pric(?:e|es|ing)", r"budgets?", r"cheap(?:er|est)?",
             r"afford(?:able|ability)", r"expensive"],
    "Quality": [r"quality", r"defects?"],
    "Reliability": [r"reliability", r"reliable", r"dependab(?:ility|le)",
                    r"on[- ]time", r"deliver(?:y|ies)", r"lead[- ]times?"],
    "Risk": [r"risks?", r"risky", r"disruptions?", r"safety", r"safe"],
    "Sustainability": [r"sustainability", r"sustainable", r"esg", r"green",
                       r"environmental(?:ly)?"],
    "Capacity": [r"capacity", r"capacities", r"volumes?", r"monthly orders",
                 r"large orders"],
}
_DIM_RE = {d: re.compile(r"\b(?:" + "|".join(t) + r")\b") for d, t in DIMENSION_TERMS.items()}

# --------------------------------------------------------------------------
# Cue vocabularies. Order of checks matters; see _clause_signal().
# --------------------------------------------------------------------------
DEPRIORITIZE_CUES = [
    r"not (?:a |an |the )?(?:very |that |really )?(?:major |big |key |main |primary |high |top )?priorit(?:y|ies)",
    r"not (?:very |that |really |particularly |so )?(?:important|critical|essential|crucial|necessary|significant)",
    r"not (?:a |an )?(?:major |big |key |main |primary )?(?:concern|issue|problem|constraint|factor|focus|consideration)",
    r"(?:low|lower|lowest|little) priority",
    r"(?:low|lower)[- ]priority",
    r"secondary(?: consideration| concern| factor| priority)?",
    r"less important", r"least important", r"of little importance",
    r"nice[- ]to[- ]have", r"optional", r"minor(?: factor| concern| consideration)?",
    r"does(?: not|n't) matter", r"do(?: not|n't) matter", r"irrelevant",
    r"no(?: real)? (?:issue|problem|concern|constraint)",
    r"unimportant", r"not a deal[- ]?breaker",
]
TOLERANCE_CUES = [
    r"(?:willing|prepared|ready|happy|able|open) to (?:accept|tolerate|take)",
    r"(?:can|could|may|will|would|do|are|is) (?:also )?(?:accept|tolerate|live with)",
    r"(?:we )?accept(?:s|ed)?\b",
    r"tolerate", r"(?:comfortable|ok(?:ay)?|fine) with",
    r"flexible (?:on|about|with)", r"room (?:for|to accept)",
]
STRONG_CUES = [
    r"most important", r"top priority", r"highest priority", r"key priority",
    r"main priority", r"primary (?:priority|concern|factor|focus)",
    r"(?:very|extremely|critically|highly) important", r"critical(?:ly)?",
    r"crucial(?:ly)?", r"essential", r"must[- ]have", r"mission[- ]critical",
    r"matters? (?:the )?most", r"paramount", r"non[- ]negotiable",
]
POSITIVE_CUES = [
    r"important", r"priority", r"prefer(?:red|s|ence)?", r"strong", r"significant",
    r"reasonabl[ey]", r"acceptable", r"adequate", r"decent", r"good", r"better",
    r"need(?:s|ed)?", r"require[ds]?", r"should", r"want", r"seek", r"matters?", r"key",
    r"high(?:er)?", r"low(?:er)?", r"dependable", r"reliable",
]
# Adjectives that attach to the dimension word itself and imply "strong".
_SUPERLATIVE_BEFORE = r"(?:highest|best|lowest|least|minimum|minimal|strongest|top|smallest|greatest)"

_CLAUSE_SPLIT = re.compile(
    r"[.!?;\n]+|,\s*(?:but|however|though|although|while|whereas|yet)\b|"
    r"\s+(?:but|however|although|though|whereas|while|yet)\s+|"
    r"\s+(?:if|provided|as long as|unless|because|since|so that)\s+",
    flags=re.I,
)
_COMMA_SPLIT = re.compile(r",")


def _norm_text(text: str) -> str:
    t = str(text).lower().replace("\u2019", "'")
    t = re.sub(r"\s+", " ", t)
    return t.strip()


def _any(patterns: Iterable[str], text: str) -> bool:
    return any(re.search(r"\b" + p + r"\b", text) for p in patterns)


def _dims_in(clause: str, dimensions: Iterable[str]) -> List[Tuple[str, int]]:
    """(dimension, first character position) for each dimension mentioned."""
    found = []
    for d in dimensions:
        m = _DIM_RE[d].search(clause)
        if m:
            found.append((d, m.start()))
    return sorted(found, key=lambda x: x[1])


def _is_bare_list(text: str) -> bool:
    """True for 'quality, reliability' (only dimension words, commas and filler). Such a list is the subject of the
    next piece ('... and sustainability are major needs'), so it must not be cut off from it."""
    rest = text
    for d in DIMENSIONS:
        rest = _DIM_RE[d].sub(" ", rest)
    rest = re.sub(r"\b(?:and|or|the|our|high|higher|good|strong|best|low|lower|highest|lowest)\b|[,&]", " ", rest)
    return not rest.strip()


def _split_clauses(text: str) -> List[str]:
    """Sentence -> clause segmentation. Commas split only when the right-hand
    side begins a new predicate about another dimension, so lists such as
    'quality, reliability and cost are critical' stay together."""
    raw = [c.strip() for c in _CLAUSE_SPLIT.split(text) if c and c.strip()]
    out: List[str] = []
    for c in raw:
        parts = _COMMA_SPLIT.split(c)
        buf = parts[0]
        for p in parts[1:]:
            p = p.strip()
            # new clause if it has its own predicate and its own dimension
            if _dims_in(p, DIMENSIONS) and re.search(
                r"\b(?:is|are|should|must|can|could|will|would|matters?|need|needs|prefer|want)\b", p
            ) and _dims_in(buf, DIMENSIONS) and not _is_bare_list(buf):
                out.append(buf.strip())
                buf = p
            else:
                buf = buf + ", " + p
        out.append(buf.strip())
    # split independent predicates joined by "and":  "X is ... and Y is ..."
    # (but NOT "quality and reliability are critical": the left side has no
    # predicate of its own, so the pair stays together for the compound rule)
    final: List[str] = []
    dim_alt = "|".join(t for ts in DIMENSION_TERMS.values() for t in ts)
    pat = re.compile(
        r"\s+and\s+(?=(?:the\s+)?(?:" + dim_alt + r")\b\s+(?:is|are|should|must|can|could|matters?|isn't|aren't|doesn't)\b)"
    )
    predicate = re.compile(r"\b(?:is|are|should|must|can|could|matters?|isn't|aren't|doesn't|need|needs|prefer|want|keep|kept)\b")
    for c in out:
        start = 0
        for m in pat.finditer(c):
            left = c[start:m.start()]
            if predicate.search(left):
                final.append(left.strip())
                start = m.end()
        tail = c[start:].strip()
        if tail:
            final.append(tail)
    return final


def _comparative_pass(low: str, level: Dict[str, str], evidence: Dict[str, List[str]], dims: List[str]) -> None:
    """'reliability becomes more important than cost' raises reliability and LOWERS cost. Before this pass both
    dimensions inherited 'important' from the same clause."""
    alt = "|".join(t for d in dims for t in DIMENSION_TERMS[d])
    pats = [
        (r"(?P<a>" + alt + r")\b[^.;,]{0,40}?\b(?:much |far |a lot |way |even )?more (?:important|critical|crucial|essential) "
         r"(?:than|compared (?:to|with)|over)\s+(?:the\s+|our\s+)?(?P<b>" + alt + r")\b"),
        (r"(?P<b>" + alt + r")\b[^.;,]{0,40}?\b(?:much |far |a lot |way |even )?less (?:important|critical)\s+"
         r"(?:than|compared (?:to|with))\s+(?:the\s+|our\s+)?(?P<a>" + alt + r")\b"),
        (r"prioriti[sz]e\s+(?:the\s+|our\s+)?(?P<a>" + alt + r")\s+(?:over|above|before|ahead of)\s+(?:the\s+|our\s+)?(?P<b>" + alt + r")\b"),
        (r"(?P<a>" + alt + r")\s+(?:takes?|should take)\s+precedence over\s+(?:the\s+|our\s+)?(?P<b>" + alt + r")\b"),
    ]

    def which(word: str) -> Optional[str]:
        for d in dims:
            if _DIM_RE[d].fullmatch(word):
                return d
        return None

    for pat in pats:
        for m in re.finditer(pat, low):
            a, b = which(m.group("a")), which(m.group("b"))
            if not a or not b or a == b:
                continue
            level[a] = max(level[a], "positive", key=_LEVELS.index)
            if _LEVELS.index(level[b]) > _LEVELS.index("mild"):
                level[b] = "mild"
            evidence[a].append(f"comparative: '{m.group(0).strip()}'")
            evidence[b].append(f"comparative (ranked below {a.lower()}): '{m.group(0).strip()}'")


def _bump(level: str, steps: int) -> str:
    i = max(0, min(len(_LEVELS) - 1, _LEVELS.index(level) + steps))
    return _LEVELS[i]


def _clause_signal(clause: str, dimension: str) -> Optional[Tuple[str, str]]:
    """Return (kind, level) for how this clause treats `dimension`, or None.
    kind in {"deprioritize","tolerance","explicit","mention"}"""
    m = _DIM_RE[dimension].search(clause)
    if not m:
        return None

    after = clause[m.start():]
    # Tolerance applies to the dimension that FOLLOWS the cue: "accept some risk".
    tol = None
    for p in TOLERANCE_CUES:
        t = re.search(p, clause)
        if t and t.start() <= m.start():
            # "cannot accept high risk" / "won't tolerate delays" is the
            # opposite of tolerance: the dimension is a hard requirement.
            before = clause[max(0, t.start() - 25):t.start()]
            if re.search(r"\b(?:cannot|can't|can not|couldn't|won't|will not|do not|don't|never|not|unwilling|unable)\b", before):
                return ("explicit", "strong_positive")
            tol = t
            break
    if tol is not None and not _dims_in(clause[:tol.start()], [d for d in DIMENSIONS if d != dimension]) :
        return ("tolerance", "neutral")

    # De-prioritisation beats everything else inside the same clause.
    if _any(DEPRIORITIZE_CUES, clause):
        return ("deprioritize", "neutral")

    # superlative directly attached:  "highest quality", "lowest risk"
    for term in DIMENSION_TERMS[dimension]:
        if re.search(r"\b" + _SUPERLATIVE_BEFORE + r"\s+(?:possible\s+)?" + term + r"\b", clause):
            return ("explicit", "strong_positive")

    # superlative AFTER the dimension:  "risk should be the lowest possible", "cost as low as possible"
    for term in DIMENSION_TERMS[dimension]:
        if re.search(r"\b" + term + r"\s+(?:should be|must be|needs? to be|has to be|to be|is)\s+(?:the\s+)?"
                     r"(?:lowest|highest|minimal|minimum|best|smallest|strongest)\b", clause):
            return ("explicit", "strong_positive")
        if re.search(r"\b" + term + r"\b.{0,40}\bas (?:low|high|good|strong) as (?:possible|we can get|we can)\b", clause):
            return ("explicit", "strong_positive")

    if _any(STRONG_CUES, clause):
        return ("explicit", "strong_positive")
    if _any(POSITIVE_CUES, clause):
        return ("explicit", "positive")
    return ("mention", "mild")


def _compound_pass(clause: str, level_by_dim: Dict[str, str], dims: List[str]) -> None:
    """'highest reliability and quality' / 'quality and reliability are critical':
    the modifier applies to BOTH named dimensions. Direction is not copied."""
    alt = "|".join(t for d in dims for t in DIMENSION_TERMS[d])
    pair = re.compile(
        r"\b(?:" + _SUPERLATIVE_BEFORE + r"|good|better|strong|high|low)\s+(?:possible\s+)?"
        r"(" + alt + r")\s*(?:,|and|&)\s*(?:the\s+)?(" + alt + r")\b"
    )
    rev = re.compile(
        r"\b(" + alt + r")\s*(?:,|and|&)\s*(?:the\s+)?(" + alt + r")\s+(?:are|is|must be|should be)\s+"
        r"(very |extremely )?(critical|crucial|essential|important|a priority|key)\b"
    )

    def which(word):
        for d in dims:
            if _DIM_RE[d].fullmatch(word):
                return d
        return None

    # lists of 2-4 dimensions with a shared predicate: "quality, reliability and sustainability are major needs"
    lst = re.compile(
        r"((?:" + alt + r")(?:\s*,\s*(?:and\s+|or\s+)?|\s+and\s+|\s*&\s*)){1,3}(?:the\s+)?(?:" + alt + r")\s+"
        r"(?:are|is|must be|should be)\s+(?:(?:very|extremely|really|all|all of them)\s+)?"
        r"(critical|crucial|essential|important|a priority|key|priorities|"
        r"major (?:needs?|requirements?|priorit(?:y|ies))|big (?:needs?|priorit(?:y|ies))|top (?:needs?|priorit(?:y|ies))|"
        r"(?:hard )?requirements?|musts?|non[- ]negotiable)\b"
    )
    for m in lst.finditer(clause):
        strong = re.search(r"critical|crucial|essential|major|top|non[- ]negotiable|must|very|extremely", m.group(0)[len(m.group(0)) - 40:])
        lvl = "strong_positive" if strong else "positive"
        for d in dims:
            if _DIM_RE[d].search(m.group(0)):
                level_by_dim[d] = max(level_by_dim.get(d, "neutral"), lvl, key=_LEVELS.index)

    for m in pair.finditer(clause):
        lvl = "strong_positive" if re.match(r"\b" + _SUPERLATIVE_BEFORE, m.group(0)) else "positive"
        for g in (m.group(1), m.group(2)):
            d = which(g)
            if d:
                level_by_dim[d] = max(level_by_dim.get(d, "neutral"), lvl, key=_LEVELS.index)
    for m in rev.finditer(clause):
        lvl = "strong_positive" if m.group(4) in ("critical", "crucial", "essential") or m.group(3) else "positive"
        for g in (m.group(1), m.group(2)):
            d = which(g)
            if d:
                level_by_dim[d] = max(level_by_dim.get(d, "neutral"), lvl, key=_LEVELS.index)


# --------------------------------------------------------------------------
# Direction
# --------------------------------------------------------------------------
def detect_direction(text: str, dimension: str) -> str:
    """Direction comes from the phrase describing THIS dimension only.
    Guard: 'high risk' / 'high cost' describe something to avoid, so a
    lower-is-better dimension is never flipped by 'high ...'."""
    t = _norm_text(text)
    default = DEFAULT_DIRECTION.get(dimension, "higher")
    for term in DIMENSION_TERMS[dimension]:
        hi = [rf"\b(?:highest|best|strongest|strong|excellent|good|better|maximi[sz]e|improve|increase)\s+(?:possible\s+)?{term}\b"]
        if default == "higher":
            hi.append(rf"\b(?:high|higher)\s+{term}\b")
        lo = [rf"\b(?:lowest|least|minimum|minimal|smallest|low|lower|minimi[sz]e|reduce|decrease)\s+(?:possible\s+)?{term}\b"]
        if default == "lower":
            lo.append(rf"\b{term}\s+(?:is|are|should be|must be)\s+(?:low|lowest|minimal|minimum)\b")
        if any(re.search(p, t) for p in hi) and default == "higher":
            return "higher"
        if any(re.search(p, t) for p in lo) and default == "lower":
            return "lower"
        # explicit reversal of the default (rare but legitimate)
        if default == "higher" and any(re.search(p, t) for p in lo[:1]):
            return "lower"
        if default == "lower" and any(re.search(p, t) for p in hi[:1]) and "cost" not in term and "risk" not in term:
            return "higher"
    return default


# --------------------------------------------------------------------------
# Interpretation
# --------------------------------------------------------------------------
_HEALTH = [r"hospital", r"healthcare", r"health care", r"medical", r"clinic", r"patient",
           r"pharmaceutical", r"pharma"]
_MISSION = [r"mission[- ]critical", r"business[- ]critical", r"critical operations?",
            r"cannot afford (?:a )?failure", r"failure is unacceptable"]
_COST_FLEX = [r"cost is no (?:issue|problem|object)", r"cost is not (?:an issue|a problem|a constraint)",
              r"(?:cost|price) does(?:n't| not) matter", r"price is no (?:issue|object)",
              r"price is not an issue", r"budget(?: is)? flexible", r"flexible budget",
              r"(?:willing|happy|able|prepared) to pay (?:more|a premium)", r"can pay more",
              r"money is no object", r"no budget constraints?"]
_COST_TIGHT = [r"cost[- ]conscious", r"price[- ]sensitive", r"(?:tight|limited|strict|small) budget",
               r"budget is (?:tight|limited|small|constrained)", r"budget constraints?"]


def interpret_scenario(text: str, dimensions: Iterable[str] = DIMENSIONS) -> Dict[str, dict]:
    """Return {dimension: {"priority", "direction", "evidence"}} for every
    dimension in `dimensions` (the ones available in the data)."""
    text = str(text or "").strip()
    if not text:
        raise ValueError("Scenario cannot be empty.")
    dims = [d for d in dimensions if d in DIMENSION_TERMS]
    low = _norm_text(text)

    level: Dict[str, str] = {d: "neutral" for d in dims}
    evidence: Dict[str, List[str]] = {d: [] for d in dims}

    explicit_seen: Dict[str, bool] = {d: False for d in dims}
    for clause in _split_clauses(low):
        mentioned = [d for d, _ in _dims_in(clause, dims)]
        if not mentioned:
            continue
        clause_level: Dict[str, str] = {}
        _compound_pass(clause, clause_level, dims)
        for d in mentioned:
            sig = _clause_signal(clause, d)
            if sig is None:
                continue
            kind, lvl = sig
            if d in clause_level and kind in ("explicit", "mention"):
                lvl = clause_level[d]  # compound rule already set it
                kind = "explicit"
            if kind == "tolerance":
                # one step down from whatever was said before; if nothing was
                # said before, tolerance alone means "do not weight it highly"
                level[d] = _bump(level[d], -1) if explicit_seen[d] else "neutral"
                evidence[d].append(f"tolerance: '{clause.strip()}'")
            elif kind == "deprioritize":
                level[d] = "neutral"
                explicit_seen[d] = True
                evidence[d].append(f"de-prioritised: '{clause.strip()}'")
            elif kind == "explicit":
                # stronger statements win over weaker ones unless a later
                # clause explicitly de-prioritises (handled above)
                level[d] = max(level[d], lvl, key=_LEVELS.index) if explicit_seen[d] else lvl
                explicit_seen[d] = True
                evidence[d].append(f"{lvl}: '{clause.strip()}'")
            else:  # bare mention
                if not explicit_seen[d]:
                    level[d] = max(level[d], "mild", key=_LEVELS.index)
                    evidence[d].append(f"mentioned: '{clause.strip()}'")

    _comparative_pass(low, level, evidence, dims)

    # ---- business context ------------------------------------------------
    def has(patterns):
        return any(re.search(p, low) for p in patterns)

    if has(_COST_TIGHT) and "Cost" in level:
        level["Cost"] = max(level["Cost"], "positive", key=_LEVELS.index)
        evidence["Cost"].append("context: cost-conscious / tight budget")
    if has(_HEALTH):
        for d in ("Quality", "Reliability", "Risk"):
            if d in level and level[d] in ("neutral", "mild"):
                level[d] = "positive"
                evidence[d].append("context: healthcare setting")
    if has(_MISSION) and not re.search(r"\bnot\s+(?:a\s+)?(?:mission|business)[- ]critical", low):
        for d in ("Reliability", "Risk"):
            if d in level:
                level[d] = "strong_positive"
                evidence[d].append("context: mission-critical")
    if has(_COST_FLEX) and "Cost" in level:
        level["Cost"] = "neutral"
        evidence["Cost"].append("context: budget flexible / willing to pay more")

    return {
        d: {"priority": level[d], "direction": detect_direction(low, d), "evidence": evidence[d]}
        for d in dims
    }


def build_weights(interpretation: Dict[str, dict], dimensions: Optional[Iterable[str]] = None) -> Dict[str, float]:
    dims = list(dimensions) if dimensions is not None else list(interpretation)
    raw = {d: PRIORITY_MULTIPLIERS.get(interpretation[d]["priority"], 0.10) for d in dims if d in interpretation}
    total = sum(raw.values()) or 1.0
    return {d: v / total for d, v in raw.items()}


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------
def minmax(series: pd.Series, direction: str) -> pd.Series:
    """0-1 goodness. Missing stays NaN (never silently imputed)."""
    v = pd.to_numeric(series, errors="coerce")
    lo, hi = v.min(), v.max()
    if v.notna().sum() == 0:
        return pd.Series(np.nan, index=series.index)
    if np.isclose(lo, hi):
        out = pd.Series(0.5, index=series.index).where(v.notna())
    else:
        out = (v - lo) / (hi - lo)
    if direction == "lower":
        out = 1 - out
    return out.clip(0, 1)


def _status(score: float) -> str:
    if pd.isna(score):
        return "Insufficient data"
    if score >= 0.75:
        return "Strong Candidate"
    if score >= 0.60:
        return "Good Candidate"
    if score >= 0.45:
        return "Review"
    return "Lower Fit"


def score_suppliers(
    df: pd.DataFrame,
    interpretation: Dict[str, dict],
    weights: Dict[str, float],
    dimension_columns: Dict[str, str],
    id_col: str,
    name_col: Optional[str] = None,
    column_direction_override: Optional[Dict[str, str]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Supplier-level scenario scoring.

    * One row per supplier is REQUIRED; duplicated ids are averaged first and
      the number of collapsed rows is reported in `n_source_rows`.
    * Missing dimension values are not imputed. Each supplier's score is
      renormalised over the weight it actually has data for, and
      `data_completeness` reports that share, so contributions sum to the score.
    * Ties share a rank (method="min"); order within a tie is by supplier id so
      the output is deterministic.
    """
    name_col = name_col or id_col
    work = df.copy()
    dims = [d for d in weights if d in dimension_columns and dimension_columns[d] in work.columns]
    num_cols = [dimension_columns[d] for d in dims]

    counts = work.groupby(id_col, dropna=False).size().rename("n_source_rows")
    if counts.max() > 1:
        agg = {c: "mean" for c in num_cols}
        if name_col != id_col:
            agg[name_col] = "first"
        for c in num_cols:
            work[c] = pd.to_numeric(work[c], errors="coerce")
        work = work.groupby(id_col, dropna=False, as_index=False).agg(agg)
    work = work.merge(counts.reset_index(), on=id_col, how="left")
    work = work.reset_index(drop=True)

    norm = {}
    for d in dims:
        direction = (column_direction_override or {}).get(d, interpretation[d]["direction"])
        norm[d] = minmax(work[dimension_columns[d]], direction)

    w = pd.Series({d: weights[d] for d in dims})
    N = pd.DataFrame(norm)
    avail = N.notna().mul(w, axis=1)
    avail_w = avail.sum(axis=1)
    weighted = N.fillna(0).mul(w, axis=1)
    score = weighted.sum(axis=1) / avail_w.where(avail_w > 0)
    contrib = weighted.div(avail_w.where(avail_w > 0), axis=0)  # sums to score

    result = work.copy()
    result["scenario__decision_score"] = score
    result["data_completeness"] = (avail_w / w.sum()).round(4) if len(dims) else np.nan
    for d in dims:
        result[f"scenario__{d.lower()}_score"] = N[d]
        result[f"scenario__{d.lower()}_contribution"] = contrib[d]

    result["_k"] = result[id_col].astype(str)
    result = result.sort_values(["scenario__decision_score", "_k"], ascending=[False, True], na_position="last")
    result["scenario__rank"] = result["scenario__decision_score"].rank(ascending=False, method="min")
    result["advisor__decision_status"] = result["scenario__decision_score"].map(_status)
    result = result.drop(columns="_k").reset_index(drop=True)

    rows = []
    for d in dims:
        rows.append(pd.DataFrame({
            "supplier_id": result[id_col].astype(str),
            "supplier_name": result[name_col].astype(str),
            "dimension": d,
            "source_column": dimension_columns[d],
            "direction": (column_direction_override or {}).get(d, interpretation[d]["direction"]),
            "priority": interpretation[d]["priority"],
            "weight": weights[d],
            "normalized_dimension_score": result[f"scenario__{d.lower()}_score"],
            "weighted_contribution": result[f"scenario__{d.lower()}_contribution"],
        }))
    contributions = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    return result, contributions


# --------------------------------------------------------------------------
# Deterministic explanation / trade-offs (what Gemini may later PARAPHRASE)
# --------------------------------------------------------------------------
def explain_ranking(
    ranking: pd.DataFrame,
    interpretation: Dict[str, dict],
    weights: Dict[str, float],
    id_col: str,
    name_col: Optional[str] = None,
    top_n: int = 3,
    near_tie_gap: float = 0.02,
) -> dict:
    name_col = name_col or id_col
    scored = ranking[ranking["scenario__decision_score"].notna()]
    if scored.empty:
        return {"recommendation": None, "caveats": ["No supplier had data for any weighted dimension."]}

    dims = [d for d in weights if f"scenario__{d.lower()}_score" in ranking.columns]
    top = scored.iloc[0]
    out = {
        "recommendation": {
            "supplier_id": str(top[id_col]),
            "supplier_name": str(top[name_col]),
            "score": float(top["scenario__decision_score"]),
            "status": top["advisor__decision_status"],
        },
        "weights": {d: round(float(weights[d]), 4) for d in dims},
        "priority_summary": {d: interpretation[d]["priority"] for d in dims},
        "why": [], "trade_offs": [], "caveats": [], "runners_up": [],
    }

    contribs = {d: float(top[f"scenario__{d.lower()}_contribution"]) for d in dims
                if pd.notna(top[f"scenario__{d.lower()}_contribution"])}
    for d, c in sorted(contribs.items(), key=lambda kv: kv[1], reverse=True)[:3]:
        out["why"].append({
            "dimension": d, "weight": round(float(weights[d]), 3),
            "normalized_score": round(float(top[f"scenario__{d.lower()}_score"]), 3),
            "contribution": round(c, 3),
        })

    for d in dims:
        s = top[f"scenario__{d.lower()}_score"]
        if pd.isna(s):
            out["caveats"].append(f"No {d} data for {top[name_col]}; its score was renormalised over the remaining dimensions.")
            continue
        peer = scored[f"scenario__{d.lower()}_score"].dropna()
        if len(peer) >= 4 and s <= peer.quantile(0.35):
            low_weight = weights[d] < 0.05
            out["trade_offs"].append({
                "dimension": d, "supplier_score": round(float(s), 3),
                "peer_median": round(float(peer.median()), 3), "weight": round(float(weights[d]), 3),
                "deprioritised": bool(low_weight),
                "note": (f"{top[name_col]} is weak on {d}, which this scenario deliberately de-prioritised; "
                         "management should confirm that concession is acceptable."
                         if low_weight else
                         f"{top[name_col]} is below the median on {d}; this is a real concession in this scenario."),
            })

    for _, r in scored.iloc[1:top_n].iterrows():
        gaps = {d: float(r[f"scenario__{d.lower()}_score"] - top[f"scenario__{d.lower()}_score"])
                for d in dims if pd.notna(r[f"scenario__{d.lower()}_score"]) and pd.notna(top[f"scenario__{d.lower()}_score"])}
        better = [d for d, g in gaps.items() if g > 0.05]
        out["runners_up"].append({
            "supplier_id": str(r[id_col]), "supplier_name": str(r[name_col]),
            "score": float(r["scenario__decision_score"]),
            "gap_to_top": float(top["scenario__decision_score"] - r["scenario__decision_score"]),
            "stronger_on": better,
        })
    if out["runners_up"] and out["runners_up"][0]["gap_to_top"] < near_tie_gap:
        out["caveats"].append(
            f"Near tie: the top two suppliers differ by {out['runners_up'][0]['gap_to_top']:.3f}; "
            "treat the order as indicative, not decisive."
        )
    if "data_completeness" in top and top["data_completeness"] < 0.999:
        out["caveats"].append(f"Data completeness for the top supplier is {top['data_completeness']:.0%}.")
    out["caveats"].append("Decision-support ranking from the scenario weights; not an automatic purchasing decision.")
    return out


def run_scenario(
    df: pd.DataFrame,
    scenario_text: str,
    dimension_columns: Dict[str, str],
    id_col: str,
    name_col: Optional[str] = None,
    column_direction_override: Optional[Dict[str, str]] = None,
) -> dict:
    """The one entry point used by Cell 25 and by the Streamlit What-If page."""
    dims = [d for d in DIMENSIONS if d in dimension_columns]
    interpretation = interpret_scenario(scenario_text, dims)
    weights = build_weights(interpretation, dims)
    ranking, contributions = score_suppliers(
        df, interpretation, weights, dimension_columns, id_col, name_col, column_direction_override)
    explanation = explain_ranking(ranking, interpretation, weights, id_col, name_col)
    return {"interpretation": interpretation, "weights": weights, "ranking": ranking,
            "contributions": contributions, "explanation": explanation}
