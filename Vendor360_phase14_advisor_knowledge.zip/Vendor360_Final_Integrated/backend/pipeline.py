from __future__ import annotations
import os, sys, runpy, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODULES = ROOT / "modules"

def _compat():
    # Colab-compatible shims for non-interactive backend execution.
    import builtins
    if not hasattr(builtins, "display"):
        builtins.display = lambda *args, **kwargs: None
    try:
        import google.colab.files as files  # type: ignore
    except Exception:
        class _Files:
            @staticmethod
            def upload(): return {}
        sys.modules.setdefault("google", type(sys)("google"))
        sys.modules.setdefault("google.colab", type(sys)("google.colab"))
        sys.modules.setdefault("google.colab.files", type(sys)("google.colab.files"))
        sys.modules["google.colab.files"].upload = _Files.upload

def run_backend(work_dir: str | None = None, execute_ai: bool = False, input_dir: str | None = None) -> dict:
    """Run the notebook-derived backend without the Streamlit cells.

    The exact notebook cell source is preserved in phase modules and executed
    in one shared namespace because the original model intentionally shares
    intermediate DataFrames/configuration across cells.
    """
    _compat()
    # work_dir: generated outputs. input_dir: source datasets (defaults to work_dir, the Colab /content layout).
    work = work_dir or os.environ.get("VENDOR360_WORKDIR", "/content")
    inp = input_dir or os.environ.get("VENDOR360_INPUT_DIR") or work
    root = Path(work)
    os.makedirs(root, exist_ok=True)
    os.chdir(root)
    # NOTE: modules are exec'd into ONE shared namespace (they share DataFrames/config across cells),
    # which also means os.chdir and sys.path changes here are process-wide side effects.
    ns = {"__name__":"__vendor360_backend__", "__file__":str(ROOT / "pipeline.py"),
          "V360_WORK": str(root), "V360_INPUT": str(Path(inp))}
    # Engine files are already included; make them importable.
    engine = ROOT / "engine"
    sys.path.insert(0, str(ROOT))
    order = ["foundation.py","analytics.py","supplier_decision.py"]
    if execute_ai: order += ["ai.py"]
    order += ["scenario.py","risk_radar.py","decision_intelligence.py"]
    results=[]
    for name in order:
        path = MODULES / name
        code = path.read_text(encoding="utf-8")
        try:
            exec(compile(code, str(path), "exec"), ns, ns)
            results.append({"module":name,"ok":True})
        except Exception as exc:
            results.append({"module":name,"ok":False,"error":f"{type(exc).__name__}: {exc}"})
            raise RuntimeError(f"Vendor360 backend failed in {name}: {exc}") from exc
    return {"ok":True,"results":results,"namespace":ns}
