"""Local knowledge layer for the Vendor360 advisor.

Answers the questions the engine rows cannot: "what should a big business look for in a supplier?", "why is dual sourcing
used?", "how do I negotiate?", "should we consolidate?", "what do you suggest?". No model and no network: a hand-written
procurement knowledge base (advisor_kb_a/b/c) is searched with a small BM25-style ranker, and the answer is composed for the
kind of question (why / how / list / should / compare / pitfalls / example) and tailored to the buyer (large business, SME,
startup, public sector) and the sector (IT, logistics, manufacturing, services, facilities).

General guidance is never presented as data. Where an entry has a `hook`, a short paragraph is computed from the live
supplier rows ("In your portfolio: ...") using only engine values; hooks never invent numbers.

Pure python. advisor_core is imported lazily to avoid a circular import (advisor_core routes to this module).
"""
from __future__ import annotations

import math
import re
from collections import Counter
from typing import Any, Optional

from .advisor_kb_a import ENTRIES as _A
from .advisor_kb_b import ENTRIES as _B
from .advisor_kb_c import ENTRIES as _C

ENTRIES: list[dict] = [*_A, *_B, *_C]
BY_ID: dict[str, dict] = {e["id"]: e for e in ENTRIES}

STRONG = 1.2    # confidence needed to answer a general question from the knowledge base
WEAK = 0.7      # enough to answer when nothing else in the router matched

AUDIENCE_LABEL = {"enterprise": "a large business", "sme": "a small or mid-sized business", "startup": "a startup", "public": "a public-sector buyer"}
SECTOR_LABEL = {"it": "IT and cloud suppliers", "logistics": "logistics suppliers", "manufacturing": "manufacturing suppliers",
                "services": "consulting and services suppliers", "facilities": "facilities suppliers"}
SECTOR_ENTRY = {"it": "sector_it", "logistics": "sector_logistics", "manufacturing": "sector_manufacturing", "services": "sector_services", "facilities": "sector_facilities"}


def _ac():
    from . import advisor_core
    return advisor_core


# ------------------------------------------------------------------------------------------- text ----
_STOP = set("""a an the and or but of to in on for with at by from as is are was were be been being it its this that these those i we you our my your me us
do does did can could would will shall may might must what which who whom whose when where there their they them he she his her about into than then so if any some such
very also just please tell give let got yes no how why should keep make get use like show""".split())
_SYN = {"vendor": "supplier", "provider": "supplier", "seller": "supplier", "contractor": "supplier", "subcontractor": "supplier", "vendors": "supplier",
        "big": "enterprise", "large": "enterprise", "corporate": "enterprise", "multinational": "enterprise", "corporation": "enterprise", "mnc": "enterprise",
        "small": "sme", "smb": "sme", "mid": "sme", "medium": "sme",
        "seek": "criteria", "feature": "criteria", "quality": "quality", "attribute": "criteria", "characteristic": "criteria", "trait": "criteria", "factor": "criteria",
        "requirement": "criteria",
        "choose": "select", "pick": "select", "shortlist": "select", "vet": "select", "assess": "evaluate", "screen": "evaluate",
        "cheap": "cost", "cheapest": "cost", "expensive": "cost", "saving": "save",
        "danger": "risk", "risky": "risk", "threat": "risk", "exposure": "risk",
        "fail": "failure", "bankrupt": "failure", "insolvency": "failure", "collapse": "failure",
        "buy": "purchase", "purchasing": "purchase", "procurement": "purchase", "sourcing": "source",
        "late": "delay", "slow": "delay",
        "green": "sustainability", "esg": "esg", "eco": "sustainability", "environmental": "sustainability", "sustainable": "sustainability",
        "bargain": "negotiate", "haggle": "negotiate",
        "outsource": "outsourcing", "insource": "insourcing", "choos": "select", "chose": "select", "chosen": "select"}


def _stem(w: str) -> str:
    """Crude suffix stripping, applied identically to questions and knowledge-base text (plural first, then -ing / -ed / -ly)."""
    if len(w) > 4 and w.endswith("ies"):
        w = w[:-3] + "y"
    elif len(w) > 5 and w.endswith("sses"):
        w = w[:-2]
    elif len(w) > 4 and w.endswith("es") and w[-3] in "sxz" or len(w) > 5 and w.endswith(("ches", "shes")):
        w = w[:-2]
    elif len(w) > 3 and w.endswith("s") and not w.endswith(("ss", "us", "is")):
        w = w[:-1]
    if len(w) > 5 and w.endswith("ing"):
        w = w[:-3]
    elif len(w) > 4 and w.endswith("ed"):
        w = w[:-2]
    if len(w) > 4 and w.endswith("ly"):
        w = w[:-2]
    return w


def tokens(text: str) -> list[str]:
    out: list[str] = []
    for raw in re.findall(r"[a-z0-9]+(?:[-'][a-z0-9]+)*", str(text).lower()):
        parts = [raw.replace("'", "")] if "'" in raw else raw.split("-")
        if "-" in raw:
            parts = [raw.replace("-", "")] + parts   # "lock-in" -> "lockin", "lock", "in"
        for p in parts:
            if not p or p in _STOP or len(p) < 2 and not p.isdigit():
                continue
            p = _SYN.get(p, p)
            p = _SYN.get(_stem(p), _stem(p))
            if p not in _STOP:
                out.append(p)
    return out


# ------------------------------------------------------------------------------------------ index ----
_IDX: dict[str, Any] = {}


def _build() -> dict:
    docs = []
    df: Counter = Counter()
    for e in ENTRIES:
        w: Counter = Counter()
        for t in tokens(e["title"]):
            w[t] += 3.0
        phrases = []
        for k in e["keywords"]:
            ts = tokens(k)
            phrases.append(ts)
            for t in ts:
                w[t] += 2.5
        for qn in e.get("questions", []):
            for t in tokens(qn):
                w[t] += 1.5
        for t in tokens(e["summary"]):
            w[t] += 0.8
        for lab, txt in e["points"]:
            for t in tokens(lab):
                w[t] += 0.8
            for t in tokens(txt):
                w[t] += 0.25
        for t in tokens(e.get("why", "")):
            w[t] += 0.4
        docs.append({"id": e["id"], "w": w, "phrases": [p for p in phrases if p]})
        for t in w:
            df[t] += 1
    n = len(docs)
    idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}
    return {"docs": docs, "idf": idf}


def _index() -> dict:
    if not _IDX:
        _IDX.update(_build())
    return _IDX


def retrieve(question: str, k: int = 3) -> list[tuple[dict, float]]:
    """[(entry, confidence)] best first. Confidence is the share of the query's informative terms the entry explains (0..~1.5)."""
    ix = _index()
    qt = tokens(question)
    qset = list(dict.fromkeys(qt))
    known = [t for t in qset if t in ix["idf"]]
    if not known:
        return []
    norm = sum(ix["idf"][t] for t in known) or 1.0
    scored = []
    for d in ix["docs"]:
        s = 0.0
        for t in known:
            tf = d["w"].get(t, 0.0)
            if tf:
                s += ix["idf"][t] * (tf / (tf + 1.2)) * 2.0
        for ph in d["phrases"]:
            if len(ph) >= 2 and all(t in qset for t in ph):
                contiguous = any(qt[i:i + len(ph)] == ph for i in range(len(qt) - len(ph) + 1))
                s += sum(ix["idf"].get(t, 0) for t in ph) * (2.0 if contiguous else 0.8)
            elif len(ph) == 1 and ph[0] in qset and ix["idf"].get(ph[0], 0) > 1.8:
                s += ix["idf"][ph[0]] * 1.0
        scored.append((s / norm, d["id"]))
    scored.sort(reverse=True)
    return [(BY_ID[i], round(c, 3)) for c, i in scored[:k] if c > 0]


# --------------------------------------------------------------------------------- question reading ----
STYLE_RX = [
    ("pitfalls", r"\b(mistakes?|pitfalls?|go wrong|avoid|red flags?|warning signs?|downsides?|dangers?|watch out)\b"),
    ("example", r"\b(examples?|for instance|sample|illustrate|case study)\b"),
    ("compare", r"\b(difference|differences|versus|vs\.?|compare|compared to|better than|pros and cons|advantages|disadvantages|benefits and)\b"),
    ("should", r"^(should|is it (better|worth|wise|good|ok|okay)|do we need|would it be (better|wise)|ought|is it a good idea)|\bshould (we|i|a|an|the|our)\b.*\b(or|choose|use|go|switch|consolidate|outsource|keep|replace|pay|buy)\b|\bworth\b"),
    ("why", r"^(why|how come)\b|\bwhy\b|\bwhat makes\b|\bthe reason\b"),
    ("how", r"^(how (do|can|could|would|should|to|might|does)|what (steps|is the process|is the best way)|steps|ways to|guide|process (for|to))\b|\bhow (to|do i|do we|can i|can we|should i|should we)\b|\bsteps\b"),
    ("define", r"^(what is|what's|what are|what does|what do you mean|define|meaning of|explain|tell me about|describe)\b"),
    ("list", r"\b(key|main|top|important)\s+(features?|criteria|qualities|factors|things|attributes|characteristics|requirements|kpis?|metrics|clauses|checks|signs)\b|\b(look for|looking for|seek|consider|check|ask for|include)\b|\bwhat (should|must|do)\b.*\b(have|include|look|consider|check|ask|seek)\b|\bwhat makes\b"),
    ("advice", r"\b(suggest\w*|advice|advise|recommend\w*|tips?|best practices?|strategy|approach|ideas?|improve|guidelines?|checklist|playbook)\b"),
]


def detect_style(q: str) -> str:
    ql = q.lower().strip()
    for name, rx in STYLE_RX:
        if re.search(rx, ql):
            return name
    return "overview"


def detect_audience(q: str) -> Optional[str]:
    ql = q.lower()
    if re.search(r"\b(public[- ]sector|government|municipal\w*|public authorit\w+|ministry|council|public procurement|public buyer)\b", ql):
        return "public"
    if re.search(r"\b(start-?ups?|early[- ]stage|scale-?ups?)\b", ql):
        return "startup"
    if re.search(r"\b(big|large|enterprise|corporate|multinational|global|major)\b[ -]*(sized |scale )?(business|businesses|company|companies|firm|organi[sz]ations?|buyers?|enterprise|corporations?|manufacturers?|retailers?)\b|\b(enterprises?|multinationals?|mncs?|fortune \d+)\b|\blarge-?scale (buyer|procurement|organi[sz]ation)", ql):
        return "enterprise"
    if re.search(r"\b(small|medium|mid-?sized|midsize|family|local)\b[ -]*(sized |scale )?(business|businesses|company|companies|firm|organi[sz]ations?|buyers?|enterprise|manufacturers?|retailers?|shop)\b|\b(smes?|smbs?)\b", ql):
        return "sme"
    return None


def detect_sector(q: str, rows: Optional[list] = None) -> Optional[str]:
    ql = q.lower()
    rx = [("it", r"\b(cloud|software|saas|hosting|data ?cent(?:er|re)s?|cyber\w*|it services|it suppliers?|it vendors?|technology (?:supplier|vendor|provider)s?|managed it|it procurement)\b"),
          ("logistics", r"\b(logistics?|freight|shipping|transport\w*|carriers?|warehous\w+|3pl|courier|haulier)\b"),
          ("manufacturing", r"\b(manufactur\w+|factory|factories|components?|raw materials?|production suppliers?|oem|machining|parts suppliers?)\b"),
          ("services", r"\b(consult\w+|agency|agencies|marketing|advisory|professional services|law firms?|legal|freelanc\w+)\b"),
          ("facilities", r"\b(facilit\w+|cleaning|catering|maintenance|janitorial|security guards?)\b")]
    for name, p in rx:
        if re.search(p, ql):
            return name
    if re.search(r"\bIT\b", q) and re.search(r"\bIT\s+(supplier|vendor|provider|categor|procurement|service|purchas)", q):
        return "it"
    if rows:
        cat = _ac().find_category(q, rows)
        if cat:
            c = cat.lower()
            for name, p in (("it", r"\bit\b|tech|software|cloud|digital"), ("logistics", r"logist|transport|freight|shipping"), ("manufacturing", r"manufactur|material|component|production"),
                            ("services", r"service|consult|market|advis|legal|profession"), ("facilities", r"facilit|clean|maint")):
                if re.search(p, c):
                    return name
    return None


_DATA_RX = re.compile(r"\b(our|my|we have|do we|are we|are there|how many|current(?:ly)?|right now|today|in the data|this portfolio|in our)\b", re.I)
_ADVISORY_RX = re.compile(r"\b(should|why|how (?:do|can|could|would|to|might)|what (?:do|can) (?:we|i)|suggest\w*|advice|advise|recommend\w*|tips?|strategy|best practice|ought|improve|reduce|mitigate|avoid|protect|handle|deal with|manage)\b", re.I)
_REQUIREMENT_RX = re.compile(r"^(i|we)\s+(need|want|require|am looking|are looking|would like|prefer)\b|^looking for\b|^find me\b|^(give|show) me (the |a )?(top|best|safest|cheapest)\b|\b(cost|price|budget) is (no|not) (an )?(issue|object|concern|problem)\b|\b(as|is) (low|high) as possible\b", re.I)
_SUGGEST_RX = re.compile(r"(what|which|where).{0,30}(should|do|can) (we|i).{0,25}(do|focus|prioriti[sz]e|improve|fix|act|address|start|work on|tackle|change)|\b(suggest|recommend|advise)\w*\b.{0,50}(portfolio|supplier base|supply base|suppliers|our|us|me)|\bnext steps?\b|\baction plan\b|\bwhat (actions|steps)\b|improve (our|the|my) (\w+ ){0,2}(portfolio|supply base|suppliers|procurement)|what (are|is) (the )?(biggest|main|top|key) (issues?|problems?|concerns?|weakness\w*|risks?|gaps?|challenges?)|where should we focus|\btop priorit\w+|\bquick wins?\b|\bwhat do you (suggest|recommend|think we should)|\bany (suggestions?|recommendations?|advice)\b|what('s| is) (the )?(biggest|main) (issue|problem|concern|weakness)", re.I)
_DOMAIN = set(tokens("supplier procurement sourcing contract purchase cost price quality risk delivery lead time vendor negotiate negotiation category spend tender bid rfp rfq rfi "
                     "sustainability esg compliance audit capacity portfolio supply base weakness issue improve improvement scorecard fraud invoice quote quotes partner supply price prices pricing business company buyer buying sla kpi onboard onboarding payment inventory logistics resilience continuity "
                     "dependency concentration diversif strategy savings consolidat outsourc manufactur procure financial stability ranking score mcda scenario weight"))


def in_domain(question: str) -> bool:
    return any(t in _DOMAIN for t in tokens(question))


_DATA_LISTING_RX = re.compile(r"^(which|who)\b.*\b(supplier|suppliers|vendor|vendors|is|are|has|have)\b|^who\b|^what('s| is| are) the (cheapest|best(?! (practice|way|approach|strategy|method))|worst|safest|average|highest|lowest|top|riskiest|fastest|strongest|weakest)\b|^how many\b(?!.*\b(should|ought|ideal|optimal|recommended|need)\b)|^how (is|are)\b.*\b(doing|performing)\b|^show\b|^list\b|^(is|are) (the )?(data|there)\b|^which\b", re.I)
_BACKREF_RX = re.compile(r"\b(the first one|the second one|the third one|them|those|that one|this one|it|these)\b", re.I)


def route(question: str, rows: list, named_count: int = 0) -> Optional[dict]:
    """Decide whether the question should be answered from the knowledge base. Returns the retrieval summary or None.
    The caller (advisor_core.classify) has already handled greetings, named-supplier questions and what-if wording."""
    q = question.strip()
    ql = q.lower()
    if _REQUIREMENT_RX.search(ql):
        return None
    hits = retrieve(q, 3)
    if not hits:
        return None
    top, conf = hits[0]
    data_q = bool(_DATA_RX.search(ql))
    advisory = bool(_ADVISORY_RX.search(ql))
    if _DATA_LISTING_RX.search(ql):
        return None                      # "which suppliers need attention?", "who is the cheapest?": the engine answers from the rows
    if rows and not advisory and _ac().find_category(q, rows) and conf < 4.0:
        return None                      # "how is IT doing?", "what is the risk in Facilities": category summary
    if _BACKREF_RX.search(ql) and conf < 2.5 and len(ql.split()) <= 12:
        return None                      # pronoun follow-ups are resolved against the previous answer
    asks = bool(re.match(r"^(what|why|how|which|when|where|who|is|are|should|do|does|can|could|would|will|explain|tell me|define|describe|any|help me|give me|suggest|advise|i('d| would) like to (know|understand))\b", ql)) or "?" in ql or advisory \
        or bool(re.search(r"\b(tips|advice|best practices?|strategy|guidelines?|checklist|approach|ideas)\b", ql))
    if not asks:
        return None
    if not in_domain(q) and conf < 2.5:
        return None                      # a stray rare word ("capital") must not pull in an unrelated topic
    if data_q and not advisory and conf < 2.5:
        return None                      # "how concentrated are our awards?" is a data question, answered by the engine
    if named_count and not advisory:
        return None
    if conf >= STRONG:
        return {"hits": hits, "conf": conf, "strong": True}
    return {"hits": hits, "conf": conf, "strong": False}


def wants_suggestions(question: str) -> bool:
    ql = question.lower()
    if re.search(r"\b(if|when|whenever|in case|suppose|assuming)\b", ql) and not re.search(r"\b(suggest|recommend)", ql):
        return False                      # "what do I do if a key supplier goes bankrupt?" is a how-to, not a portfolio review
    return bool(_SUGGEST_RX.search(question))


# ------------------------------------------------------------------------------------ follow-ups ----
_FOLLOW = [
    ("more", r"\b(tell me more|more (detail|details|info|information)|go deeper|deeper|elaborate|expand|continue|go on|in more detail|dig (in|deeper)|what else)\b"),
    ("example", r"\b(example|for instance|sample|illustrate)\b"),
    ("pitfalls", r"\b(mistakes?|pitfalls?|go wrong|avoid|watch out|risks of (that|this|it)|downsides?)\b"),
    ("how", r"\b(how (do|can|should|would) (i|we) (do|start|implement|apply|put)|steps|how to (do|start|implement)|implement|get started|where (do|should) (i|we) start)\b"),
    ("brief", r"\b(simpl\w+|summar\w+|short(er)?|tl;?dr|eli5|in a nutshell|in one sentence|briefly)\b"),
    ("why", r"^(why|why is that|why does (that|this) matter|but why|why\?)"),
]


def followup(question: str, topic_ids: list[str]) -> Optional[dict]:
    """\"tell me more\", \"give an example\", \"what about for a small business?\" about the previous knowledge answer."""
    if not topic_ids or topic_ids[0] not in BY_ID:
        return None
    ql = question.lower().strip()
    words = ql.split()
    if len(words) > 12:
        return None
    aud, sec = detect_audience(question), detect_sector(question)
    mode = None
    for m, rx in _FOLLOW:
        if re.search(rx, ql):
            mode = m
            break
    retarget = bool((aud or sec) and re.match(r"^(and |but |what about|how about|what if|now |also |for |in )", ql) or (aud or sec) and len(words) <= 7)
    if not mode and not retarget:
        return None
    return {"topic_ids": topic_ids, "mode": mode or "overview", "audience": aud, "sector": sec}


# ------------------------------------------------------------------------------------ data hooks ----
def _refs(rs: list[dict]) -> list[dict]:
    ac = _ac()
    return [ac.ref(r) for r in rs]


def _names(rs: list[dict], n: int = 3) -> str:
    ac = _ac()
    return ac._join([ac._b(r) for r in rs[:n]])


def hook_selection_fit(rows, extras) -> Optional[dict]:
    ac = _ac()
    gaps: Counter = Counter()
    ok = []
    for r in rows:
        miss = []
        if ac._status(r) != "Stable":
            miss.append("risk")
        e = ac.num(r.get("sustainability_kpi"))
        if e is None or e < ac.ESG_LINE:
            miss.append("ESG")
        for d in ("quality", "reliability"):
            g = ac.goodness(r, d)
            if g is None or g < 60:
                miss.append(d)
        if miss:
            gaps.update(miss)
        else:
            ok.append(r)
    ok.sort(key=ac._rank)
    n = len(rows)
    bar = f"Stable on the Risk Radar, ESG of {ac.ESG_LINE} or more, and quality and reliability percentiles of 60 or more"
    if ok:
        txt = (f"As an illustration, {len(ok)} of your {n} suppliers clear a demanding bar ({bar}). The best ranked are {_names(ok)}.")
    else:
        txt = f"As an illustration, none of your {n} suppliers clears a demanding bar ({bar})."
    if gaps and len(ok) < n:
        top = gaps.most_common(2)
        txt += " The most common shortfalls among the rest are " + ac._join([f"{k} ({v} suppliers)" for k, v in top]) + "."
    return {"text": txt, "suppliers": ok[:3]}


def hook_cost_trap(rows, extras) -> Optional[dict]:
    ac = _ac()
    cheap = [r for r in rows if (ac.goodness(r, "cost") or 0) >= 75]
    if not cheap:
        return None
    bad = []
    for r in cheap:
        weak = [d for d in ("quality", "reliability") if (ac.goodness(r, d) if ac.goodness(r, d) is not None else 100) < 40]
        if ac._flagged(r) or weak:
            bad.append(r)
    if bad:
        txt = (f"{len(bad)} of the {len(cheap)} cheapest suppliers (the cheapest quarter on price) are flagged on the Risk Radar or weak on quality or reliability: "
               f"{_names(bad)}. Their low price may be paid for elsewhere.")
    else:
        txt = f"The {len(cheap)} cheapest suppliers are not flagged and are not weak on quality or reliability, so in this data the low price is not obviously hiding a problem."
    return {"text": txt, "suppliers": bad[:3] or cheap[:3]}


def hook_risk_exposure(rows, extras) -> Optional[dict]:
    ac = _ac()
    crit = [r for r in rows if ac._status(r) == "Critical"]
    emer = [r for r in rows if ac._status(r) == "Emerging Risk"]
    watch = [r for r in rows if ac._status(r) == "Watch"]
    flags: Counter = Counter()
    for r in rows:
        if ac._flagged(r):
            for f in re.split(r"[;,]", str(r.get("risk_radar_flags") or "")):
                f = f.strip()
                if f:
                    flags[f] += 1
    parts = [f"{len(crit)} supplier{'s' if len(crit) != 1 else ''} Critical, {len(emer)} Emerging Risk and {len(watch)} on Watch out of {len(rows)}."]
    if flags:
        parts.append("The most frequent risk signals are " + ac._join([f"{k} ({v})" for k, v in flags.most_common(3)]) + ".")
    top10 = [r for r in rows if ac._rank(r) <= 10]
    fl10 = [r for r in top10 if ac._flagged(r)]
    if top10 and fl10:
        parts.append(f"{len(fl10)} of the top {len(top10)} ranked suppliers carry a warning ({_names(fl10)}).")
    worst = sorted([r for r in rows if ac._flagged(r)], key=lambda r: -(ac._risk(r) or 0))
    return {"text": " ".join(parts), "suppliers": worst[:3]}


def hook_critical_list(rows, extras) -> Optional[dict]:
    ac = _ac()
    need = sorted([r for r in rows if ac._at_risk(r)], key=lambda r: -(ac._risk(r) or 0))
    if not need:
        watch = sorted([r for r in rows if ac._status(r) == "Watch"], key=lambda r: -(ac._risk(r) or 0))
        if watch:
            return {"text": f"Nobody is Critical or Emerging Risk right now. On Watch: {_names(watch, 4)}.", "suppliers": watch[:3]}
        return {"text": "No supplier is currently flagged on the Risk Radar.", "suppliers": []}
    lines = []
    for r in need[:3]:
        why = str(r.get("risk_explanation") or r.get("risk_radar_flags") or "").strip().rstrip(".")
        lines.append(f"- {ac._b(r)}: {ac._status(r)}, risk {ac.f1(ac._risk(r))}" + (f". {why}." if why else "."))
    return {"text": f"{len(need)} supplier{'s are' if len(need) != 1 else ' is'} at Critical or Emerging Risk:\n" + "\n".join(lines), "suppliers": need[:3]}


def hook_esg_gap(rows, extras) -> Optional[dict]:
    ac = _ac()
    pool = [r for r in rows if ac.num(r.get("sustainability_kpi")) is not None]
    if not pool:
        return None
    below = [r for r in pool if ac.num(r["sustainability_kpi"]) < ac.ESG_LINE]
    avg = sum(ac.num(r["sustainability_kpi"]) for r in pool) / len(pool)
    low = sorted(pool, key=lambda r: ac.num(r["sustainability_kpi"]))[:3]
    top10 = [r for r in below if ac._rank(r) <= 10]
    txt = f"Average ESG is {avg:.1f}; {len(below)} of {len(pool)} suppliers score below {ac.ESG_LINE}. Lowest: " + ac._named(low, lambda r: ac.f1(r["sustainability_kpi"])) + "."
    if top10:
        txt += f" {len(top10)} of those sit in the top 10 by MCDA, so sustainability is a trade-off there."
    return {"text": txt, "suppliers": low}


def hook_data_gaps(rows, extras) -> Optional[dict]:
    ac = _ac()
    inc = sorted([r for r in rows if (ac.num(r.get("kpi_completeness_pct")) or 100) < 100], key=lambda r: ac.num(r.get("kpi_completeness_pct")) or 0)
    est = [r for r in rows if r.get("capacity_estimated")]
    if not inc and not est:
        return {"text": "Every supplier has complete KPI data and no capacity is estimated.", "suppliers": []}
    txt = f"{len(inc)} of {len(rows)} suppliers have incomplete KPI data" + (f" (lowest: {ac._join([ac._name(r) + ' ' + ac.f0(r.get('kpi_completeness_pct')) + '%' for r in inc[:3]])})" if inc else "") + \
          f", and {len(est)} use an estimated capacity."
    return {"text": txt, "suppliers": inc[:3]}


def hook_single_source_cats(rows, extras) -> Optional[dict]:
    ac = _ac()
    parts = []
    cats: dict[str, list[dict]] = {}
    for r in rows:
        cats.setdefault(str(r.get("category") or "Unclassified"), []).append(r)
    thin = [(c, [x for x in rs if ac._status(x) == "Stable"]) for c, rs in cats.items()]
    thin = [(c, st) for c, st in thin if len(st) < 2]
    if thin:
        parts.append("Categories with fewer than two Stable suppliers, so little real backup: " + ac._join([f"{c} ({len(st)} Stable of {len(cats[c])})" for c, st in thin[:4]]) + ".")
    dep = ac._lazy(extras or {}, "dependency")
    ss = (dep or {}).get("single_source_categories") or [] if dep and dep.get("available") else []
    if ss:
        parts.append("Single-source sub-categories in the award history: " + ac._join(list(ss)[:4]) + ".")
    if not parts:
        return {"text": "Every category has at least two Stable suppliers and no single-source sub-category shows in the award history.", "suppliers": []}
    return {"text": " ".join(parts), "suppliers": []}


def hook_concentration(rows, extras) -> Optional[dict]:
    ac = _ac()
    dep = ac._lazy(extras or {}, "dependency")
    if not dep or not dep.get("available"):
        return None
    cats = sorted(dep.get("categories", []), key=lambda c: -c["hhi"])
    top = dep.get("top_suppliers", [])
    parts = []
    if cats:
        c = cats[0]
        band = "high" if c["hhi"] >= 2500 else "moderate" if c["hhi"] >= 1500 else "low"
        parts.append(f"The most concentrated category is {c['category']} (HHI {c['hhi']}, {band}); {c['top_supplier']} wins {c['top_share_pct']}% of its awards.")
    if len(top) >= 3:
        parts.append(f"The top three suppliers hold {sum(s['share_pct'] for s in top[:3]):.1f}% of all awards.")
    by_id = {str(r.get("supplier_id")): r for r in rows}
    exp = [by_id[str(s["supplier_id"])] for s in top if str(s.get("supplier_id")) in by_id and ac._flagged(by_id[str(s["supplier_id"])])]
    if exp:
        parts.append(f"Heavily used and flagged: {_names(exp)}.")
    return {"text": " ".join(parts), "suppliers": exp[:3]} if parts else None


def hook_capacity_view(rows, extras) -> Optional[dict]:
    ac = _ac()
    pool = sorted([r for r in rows if ac.num(r.get("capacity_kpi")) is not None], key=lambda r: -ac.num(r["capacity_kpi"]))
    if not pool:
        return None
    est = [r for r in rows if r.get("capacity_estimated")]
    txt = "Largest stated capacity: " + ac._named(pool[:3], lambda r: ac.f0(r["capacity_kpi"]) + " units/month") + "."
    if est:
        txt += f" {len(est)} supplier{'s use' if len(est) != 1 else ' uses'} an estimated capacity, so treat that dimension with care."
    return {"text": txt, "suppliers": pool[:3]}


def hook_lead_time_view(rows, extras) -> Optional[dict]:
    ac = _ac()
    pool = sorted([r for r in rows if ac.num(r.get("reliability_kpi")) is not None], key=lambda r: ac.num(r["reliability_kpi"]))
    if len(pool) < 2:
        return None
    fast, slow = pool[:3], pool[::-1][:3]
    return {"text": "Shortest lead times: " + ac._named(fast, lambda r: ac.f1(r["reliability_kpi"]) + " days") + ". Longest: " + ac._named(slow, lambda r: ac.f1(r["reliability_kpi"]) + " days") + ".",
            "suppliers": fast}


def hook_category_depth(rows, extras) -> Optional[dict]:
    ac = _ac()
    cats: dict[str, list[dict]] = {}
    for r in rows:
        cats.setdefault(str(r.get("category") or "Unclassified"), []).append(r)
    if not cats:
        return None
    parts = ac._join([f"{c} ({len(rs)}, {sum(1 for x in rs if ac._status(x) == 'Stable')} Stable)" for c, rs in sorted(cats.items(), key=lambda kv: -len(kv[1]))[:6]])
    thin = [c for c, rs in cats.items() if len(rs) <= 2]
    txt = f"Suppliers per category: {parts}."
    if thin:
        txt += f" {ac._join(thin[:3])} {'has' if len(thin) == 1 else 'have'} two or fewer suppliers, which limits competition and backup."
    return {"text": txt, "suppliers": []}


def hook_country_mix(rows, extras) -> Optional[dict]:
    ac = _ac()
    by: dict[str, list[dict]] = {}
    for r in rows:
        c = str(r.get("country_hq") or "").strip()
        if c:
            by.setdefault(c, []).append(r)
    if not by:
        return None
    ordered = sorted(by.items(), key=lambda kv: -len(kv[1]))
    n = sum(len(v) for v in by.values())
    c0, rs0 = ordered[0]
    txt = f"Your suppliers are headquartered in {len(by)} countries; the largest group is {c0} with {len(rs0)} of {n} ({len(rs0) / n * 100:.0f}%)."
    fl = sum(1 for r in rs0 if ac._flagged(r))
    if fl:
        txt += f" {fl} of them {'is' if fl == 1 else 'are'} flagged on the Risk Radar."
    return {"text": txt, "suppliers": []}


def hook_rank_vs_risk(rows, extras) -> Optional[dict]:
    ac = _ac()
    fl = sorted([r for r in rows if ac._rank(r) <= 10 and ac._flagged(r)], key=ac._rank)
    if not fl:
        return {"text": "None of your top-10 ranked suppliers carries a Risk Radar warning right now.", "suppliers": []}
    return {"text": "In your data: " + ac._join([f"{ac._b(r)} is ranked #{r['rank']} but {ac._status(r)} (risk {ac.f1(ac._risk(r))})" for r in fl[:3]]) + ".", "suppliers": fl[:3]}


HOOKS = {"selection_fit": hook_selection_fit, "cost_trap": hook_cost_trap, "risk_exposure": hook_risk_exposure, "critical_list": hook_critical_list, "esg_gap": hook_esg_gap,
         "data_gaps": hook_data_gaps, "single_source_cats": hook_single_source_cats, "concentration": hook_concentration, "capacity_view": hook_capacity_view,
         "lead_time_view": hook_lead_time_view, "category_depth": hook_category_depth, "country_mix": hook_country_mix, "rank_vs_risk": hook_rank_vs_risk}


def run_hook(name: Optional[str], rows: list, extras: Optional[dict]) -> Optional[dict]:
    fn = HOOKS.get(name or "")
    if not fn or not rows:
        return None
    try:
        return fn(rows, extras)
    except Exception:       # a hook must never break a general answer
        return None


# -------------------------------------------------------------------------------------- rendering ----
def _bul(items: list[tuple[str, str]], n: Optional[int] = None) -> str:
    return "\n".join(f"- **{a}**: {b}" for a, b in (items[:n] if n else items))


def _plain(items: list[str], n: Optional[int] = None) -> str:
    return "\n".join(f"- {x}" for x in (items[:n] if n else items))


def _steps(items: list[str]) -> str:
    return "\n".join(f"- **Step {i}.** {x}" for i, x in enumerate(items, 1))


def _app_line(e: dict) -> str:
    ia = e.get("in_app") or []
    if not ia:
        return ""
    return "In Vendor360: " + _ac()._join([f"**{p}** ({w})" for p, w in ia[:2]]) + "."


def render(e: dict, style: str, *, audience: Optional[str] = None, sector: Optional[str] = None, mode: str = "overview",
           rows: Optional[list] = None, extras: Optional[dict] = None) -> dict:
    """Compose the reply for one entry. Returns reply text plus hook suppliers."""
    blocks: list[str] = []
    shown_all = False
    summary = e["summary"]
    if mode == "brief":
        blocks.append(summary)
        hk = None
    elif mode == "more":
        shown_all = True
        blocks.append(f"More on **{e['title'].lower()}**:")
        if e.get("how"):
            blocks.append("**How to do it**\n" + _steps(e["how"]))
        if e.get("decide"):
            d = e["decide"]
            blocks.append("**When it fits**\n" + _plain(d.get("favour", [])) + ("\n**When it does not**\n" + _plain(d.get("against", [])) if d.get("against") else "") + (f"\nRule of thumb: {d['rule']}" if d.get("rule") else ""))
        if e.get("pros") or e.get("cons"):
            blocks.append("**Pros**\n" + _plain(e.get("pros", [])) + "\n**Cons**\n" + _plain(e.get("cons", [])))
        if e.get("pitfalls"):
            blocks.append("**Common mistakes**\n" + _plain(e["pitfalls"]))
        if e.get("example"):
            blocks.append("**Example**\n" + e["example"])
        for a, pts in (e.get("audience") or {}).items():
            blocks.append(f"**For {AUDIENCE_LABEL[a]}**\n" + _bul(pts))
        for s, pts in (e.get("sector") or {}).items():
            blocks.append(f"**For {SECTOR_LABEL.get(s, s)}**\n" + _bul(pts))
        if len(blocks) == 1:   # nothing extra to say: show the full list of points instead
            blocks.append(_bul(e["points"]))
    elif style == "why":
        blocks.append(e.get("why") or summary)
        blocks.append("**What drives it**\n" + _bul(e["points"], 4))
    elif style == "how":
        blocks.append(summary if not e.get("how") else summary.split(". ")[0].rstrip(".") + ".")
        blocks.append("**Steps**\n" + _steps(e["how"]) if e.get("how") else "**How to approach it**\n" + _bul(e["points"], 6))
        if e.get("pitfalls"):
            blocks.append("**Watch out for**\n" + _plain(e["pitfalls"], 2))
    elif style == "define":
        blocks.append(summary)
        if e.get("why"):
            blocks.append(e["why"])
        if e.get("example"):
            blocks.append("**Example**\n" + e["example"])
        else:
            blocks.append(_bul(e["points"], 4))
    elif style == "should" and e.get("decide"):
        d = e["decide"]
        blocks.append("It depends on your situation. " + (d.get("rule") or ""))
        blocks.append("**It makes sense when**\n" + _plain(d["favour"]) + ("\n**Be careful when**\n" + _plain(d["against"]) if d.get("against") else ""))
        if e.get("pros") or e.get("cons"):
            blocks.append("**Pros**\n" + _plain(e.get("pros", []), 3) + "\n**Cons**\n" + _plain(e.get("cons", []), 3))
    elif style == "compare" and (e.get("pros") or e.get("cons") or e.get("decide")):
        blocks.append(summary)
        if e.get("pros") or e.get("cons"):
            blocks.append("**Pros**\n" + _plain(e.get("pros", [])) + "\n**Cons**\n" + _plain(e.get("cons", [])))
        if e.get("decide"):
            blocks.append("**Choose it when**\n" + _plain(e["decide"]["favour"]))
    elif style == "pitfalls" and e.get("pitfalls"):
        blocks.append(f"The usual mistakes with {e['title'].lower()}:")
        blocks.append(_plain(e["pitfalls"]))
        blocks.append(summary)
    elif style == "example" and e.get("example"):
        blocks.append(summary)
        blocks.append("**Example**\n" + e["example"])
    else:
        blocks.append(summary)
        blocks.append(_bul(e["points"], 7))
        if e.get("decide") and style in ("advice", "overview") and e.get("decide", {}).get("rule"):
            blocks.append("Rule of thumb: " + e["decide"]["rule"])
    # tailoring
    if mode != "more" and mode != "brief":
        aud_pts = (e.get("audience") or {}).get(audience or "")
        if aud_pts:
            blocks.append(f"**For {AUDIENCE_LABEL[audience]}, also weigh**\n" + _bul(aud_pts, 4))
        sec_pts = (e.get("sector") or {}).get(sector or "")
        if sec_pts:
            blocks.append(f"**For {SECTOR_LABEL.get(sector, sector)}**\n" + _bul(sec_pts, 3))
    hook_res = None
    if mode != "brief" and e.get("hook") and rows:
        hook_res = run_hook(e["hook"], rows, extras)
        if hook_res and hook_res.get("text"):
            blocks.append("**In your portfolio**\n" + hook_res["text"])
    if mode not in ("brief",):
        app = _app_line(e)
        if app and mode != "more":
            blocks.append(app)
    for k in ("note", "disclaimer"):
        if e.get(k) and mode in ("overview", "more"):
            blocks.append(e[k])
    return {"reply": "\n\n".join(b for b in blocks if b and b.strip()), "hook": hook_res, "shown_all": shown_all}


def _follow_ups(e: dict, audience: Optional[str], sector: Optional[str], mode: str) -> list[str]:
    fu: list[str] = []
    if mode != "more":
        fu.append("Tell me more")
    if audience is None and e.get("audience"):
        fu.append("What about for a small business?" if "sme" in e["audience"] else "What about for a large business?")
    if sector and SECTOR_ENTRY.get(sector) and SECTOR_ENTRY[sector] != e["id"]:
        fu.append(f"What should I look for in {SECTOR_LABEL[sector]}?")
    if e.get("example") and mode != "more":
        fu.append("Give me an example")
    elif e.get("pitfalls") and mode != "more":
        fu.append("What mistakes should I avoid?")
    for f in e.get("follow_ups", []):
        if f not in fu:
            fu.append(f)
    return fu[:4]


def _understood(audience: Optional[str], sector: Optional[str]) -> str:
    bits = []
    if audience:
        bits.append(f"advice for **{AUDIENCE_LABEL[audience]}**")
    if sector:
        bits.append(f"with a focus on **{SECTOR_LABEL[sector]}**")
    return " ".join(bits)


NOTE_GENERAL = "General procurement guidance, not read from your data. The 'In your portfolio' paragraph (when shown) is computed from the engine."


def answer_topic(question: str, rows: list, *, entries: list[tuple[dict, float]], extras: Optional[dict] = None, style: Optional[str] = None,
                 mode: str = "overview", audience: Optional[str] = None, sector: Optional[str] = None) -> dict:
    """Fields for the advisor answer (the caller wraps them with advisor_core._answer)."""
    style = style or detect_style(question)
    audience = audience or detect_audience(question)
    sector = sector or detect_sector(question, rows)
    top, conf = entries[0]
    second = entries[1] if len(entries) > 1 else None
    # two concepts side by side ("dual vs single sourcing", "RFP or RFQ")
    if style == "compare" and mode == "overview" and second and second[1] >= 0.6 * conf and second[1] >= WEAK:
        a, b = top, second[0]
        reply = (f"**{a['title']}**\n{a['summary']}\n\n" + (("Pros:\n" + _plain(a.get("pros", []), 3) + "\nCons:\n" + _plain(a.get("cons", []), 3) + "\n\n") if a.get("pros") else "") +
                 f"**{b['title']}**\n{b['summary']}\n\n" + (("Pros:\n" + _plain(b.get("pros", []), 3) + "\nCons:\n" + _plain(b.get("cons", []), 3) + "\n\n") if b.get("pros") else "") +
                 "Which one fits depends on how critical the category is, how many credible suppliers exist and how costly a failure would be.")
        hooks = [h for h in (run_hook(a.get("hook"), rows, extras),) if h]
        if hooks:
            reply += "\n\n**In your portfolio**\n" + hooks[0]["text"]
        fu = [f"Tell me more about {a['title'].lower()}", f"Tell me more about {b['title'].lower()}"] + [f for f in a.get("follow_ups", [])][:2]
        return {"title": f"{a['title']} vs {b['title']}", "reply": reply, "why": a["summary"], "evidence": [NOTE_GENERAL], "follow_ups": fu[:4],
                "topic_ids": [a["id"], b["id"]], "suppliers": hooks[0]["suppliers"] if hooks else [], "next_step": "", "actions": [], "understood": "", "entry": a}
    r = render(top, style, audience=audience, sector=sector, mode=mode, rows=rows, extras=extras)
    actions = [{"label": f"Open {p}", "page": p} for p, _ in (top.get("in_app") or [])[:2]]
    title = top["title"] if mode in ("overview", "brief") else f"{top['title']}: more detail"
    return {"title": title, "reply": r["reply"], "why": top["summary"], "evidence": [NOTE_GENERAL] + [f"Related topic: {BY_ID[i]['title']}" for i in top.get("related", [])[:3] if i in BY_ID],
            "follow_ups": _follow_ups(top, audience, sector, mode), "topic_ids": [top["id"]] + [x for x in top.get("related", []) if x in BY_ID][:2],
            "suppliers": (r["hook"] or {}).get("suppliers", []) if r["hook"] else [], "next_step": "", "actions": actions, "understood": _understood(audience, sector), "entry": top}


# ------------------------------------------------------------------------- portfolio suggestions ----
def suggestions(rows: list, extras: Optional[dict] = None) -> dict:
    """Prioritised actions computed from the portfolio. Each item states the evidence it rests on."""
    ac = _ac()
    items: list[tuple[str, str, list[dict], Optional[dict]]] = []   # (headline, detail, suppliers, action)
    need = sorted([r for r in rows if ac._at_risk(r)], key=lambda r: -(ac._risk(r) or 0))
    if need:
        crit = sum(1 for r in need if ac._status(r) == "Critical")
        items.append((f"Deal with the {len(need)} supplier{'s' if len(need) != 1 else ''} at Critical or Emerging Risk",
                      f"{ac._join([ac._b(r) for r in need[:3]])} {'is' if len(need) == 1 else 'are'} the highest ({crit} Critical). Find the drivers, ask for a recovery plan and prepare a backup before awarding more volume.",
                      need[:3], {"label": "Open Risk Monitoring", "page": "Risk Monitoring"}))
    top10 = sorted([r for r in rows if ac._rank(r) <= 10 and ac._flagged(r) and r not in need], key=ac._rank)
    if top10:
        items.append((f"Check the {len(top10)} high-ranked supplier{'s' if len(top10) != 1 else ''} that carry a warning",
                      f"{ac._join([ac._b(r) + ' (#' + str(r['rank']) + ', ' + ac._status(r) + ')' for r in top10[:3]])}. A good score does not offset a flag without a mitigation plan.",
                      top10[:3], {"label": "Open Risk Monitoring", "page": "Risk Monitoring"}))
    cats: dict[str, list[dict]] = {}
    for r in rows:
        cats.setdefault(str(r.get("category") or "Unclassified"), []).append(r)
    thin = [(c, [x for x in rs if ac._status(x) == "Stable"]) for c, rs in cats.items()]
    thin = [(c, s) for c, s in thin if len(s) < 2]
    if thin:
        items.append((f"Build backup options in {ac._join([c for c, _ in thin[:3]])}",
                      "Each has fewer than two Stable suppliers, so a failure has nowhere to go. Qualify a second source for the critical items.", [], {"label": "Open Supplier Onboarding", "page": "Supplier Onboarding"}))
    dep = ac._lazy(extras or {}, "dependency")
    if dep and dep.get("available"):
        cs = sorted(dep.get("categories", []), key=lambda c: -c["hhi"])
        by_id = {str(r.get("supplier_id")): r for r in rows}
        exp = [by_id[str(s["supplier_id"])] for s in dep.get("top_suppliers", []) if str(s.get("supplier_id")) in by_id and ac._flagged(by_id[str(s["supplier_id"])])]
        if cs and cs[0]["hhi"] >= 2500:
            items.append((f"Reduce concentration in {cs[0]['category']}", f"HHI {cs[0]['hhi']} (high): {cs[0]['top_supplier']} wins {cs[0]['top_share_pct']}% of awards. Shift some volume to a qualified alternative.",
                          [], {"label": "Open Dependency Analysis", "page": "Dependency Analysis"}))
        elif exp:
            items.append(("Review heavy use of flagged suppliers", f"{ac._join([ac._b(r) for r in exp[:3]])} {'is' if len(exp) == 1 else 'are'} among the most-awarded and flagged.", exp[:3], {"label": "Open Dependency Analysis", "page": "Dependency Analysis"}))
    esg = [r for r in rows if ac.num(r.get("sustainability_kpi")) is not None and ac.num(r["sustainability_kpi"]) < ac.ESG_LINE and ac._rank(r) <= 10]
    if esg:
        items.append((f"Address ESG gaps among top-ranked suppliers", f"{ac._join([ac._b(r) for r in esg[:3]])} score below {ac.ESG_LINE} on ESG yet rank in the top 10. Ask for improvement targets.", esg[:3], {"label": "Open Sustainability", "page": "Sustainability"}))
    inc = [r for r in rows if (ac.num(r.get("kpi_completeness_pct")) or 100) < 100]
    if inc:
        items.append((f"Close data gaps for {len(inc)} supplier{'s' if len(inc) != 1 else ''}", "Their scores rest on fewer inputs. Ask for the missing KPIs before relying on a close ranking.", inc[:3], {"label": "Open Data Quality", "page": "Data Quality & Decisions"}))
    ct = hook_cost_trap(rows, extras)
    if ct and "flagged on the Risk Radar or weak" in ct["text"]:
        items.append(("Do not take the cheapest price at face value", ct["text"], ct["suppliers"], {"label": "Open Supplier Comparison", "page": "Supplier Comparison"}))
    items = items[:5]
    if not items:
        best = sorted([r for r in rows if ac._status(r) == "Stable"], key=ac._rank)[:3]
        reply = ("Nothing urgent stands out. No supplier is flagged, every category has backup, and the data is complete. "
                 "Good next moves: negotiate with the top suppliers using performance data, review contracts approaching renewal, and run a what-if scenario to test how robust your ranking is.")
        return {"title": "Portfolio suggestions", "reply": reply, "why": "No urgent issue found in the risk, backup, concentration, ESG or data checks.", "evidence": [NOTE_GENERAL],
                "follow_ups": ["How do I negotiate with a supplier?", "How do I reduce supplier costs without hurting quality?"], "topic_ids": [], "suppliers": best, "next_step": "", "actions": [], "understood": ""}
    lines = [f"- **{i}. {h}.** {d}" for i, (h, d, _, _) in enumerate(items, 1)]
    reply = "Here is what I would do first, in priority order:\n\n" + "\n".join(lines) + "\n\nI ordered these by exposure: risk first, then backup and concentration, then sustainability and data quality."
    seen, sup = set(), []
    for _, _, rs, _ in items:
        for r in rs:
            if r.get("supplier_id") not in seen:
                seen.add(r.get("supplier_id"))
                sup.append(r)
    return {"title": "What I would focus on", "reply": reply, "why": items[0][1], "evidence": [f"{h}: {d}" for h, d, _, _ in items], "suppliers": sup[:5], "topic_ids": ["risk_mitigation"],
            "follow_ups": ["How do I reduce supplier risk?", "What should I do about a supplier flagged Critical?", "When should I use dual sourcing?"], "next_step": "Start with item 1; each item says where in Vendor360 to dig in.",
            "actions": list({a["label"]: a for _, _, _, a in items if a}.values())[:3], "understood": ""}


# --------------------------------------------------------------------------------------- fallbacks ----
def framework(question: str, rows: list) -> dict:
    """The question is about suppliers or procurement but matches no topic. Give a way of thinking rather than a dead end."""
    style = detect_style(question)
    ac = _ac()
    if style == "why":
        head = "I don't have a specific explanation for that, but this is how I would find the cause:"
        pts = [("Define what changed or what looks odd", "Name the metric, the supplier or category, and the period."),
               ("Check the usual drivers", "Price, quality, lead time and its variability, capacity, risk signals, concentration and data completeness."),
               ("Separate cause from correlation", "Compare against similar suppliers or an earlier period before concluding."),
               ("Check the data", "Missing or estimated values can explain odd results.")]
    elif style in ("should", "compare"):
        head = "I don't have a ready-made rule for that, but here is a way to decide:"
        pts = [("State the objective", "Cost, resilience, quality, speed or sustainability. They pull in different directions."),
               ("Set must-haves", "Anything that would rule an option out (compliance, security, capacity)."),
               ("Compare the options on total cost and risk", "Include switching effort and the cost of a failure, not only price."),
               ("Test the choice", "Ask what would have to be true for the other option to win.")]
    elif style == "how":
        head = "I don't have a specific playbook for that, but a sound approach looks like this:"
        pts = [("Clarify the goal and the constraint", "What must be achieved, by when, with what limits?"),
               ("Gather the facts", "Spend, performance, risk and market alternatives."),
               ("Pick the lever", "Competition, partnership, risk reduction, specification change or contract terms."),
               ("Pilot, measure, adjust", "Start small, track the result against a baseline.")]
    else:
        head = "I don't have a specific topic for that, but these are the factors that usually matter in a supplier decision:"
        pts = [("Cost over the whole life", "Price plus logistics, quality and risk cost."), ("Quality and delivery", "Consistency and predictability."),
               ("Risk and resilience", "Single points of failure, financial and geopolitical exposure."), ("Sustainability and compliance", "Evidence, not claims."),
               ("Capacity and fit", "Can they scale with you and work well with you?")]
    reply = head + "\n\n" + _bul(pts) + "\n\nTell me the situation in a sentence (what you buy, what matters most) and I can be more specific, or I can run your priorities through the scenario engine."
    return {"title": "How I would think about it", "reply": reply, "why": head, "evidence": [NOTE_GENERAL],
            "follow_ups": ["What key features should a big business look for in a supplier?", "I need high quality and the lowest risk", "What do you suggest I focus on?", "What can you do?"],
            "topic_ids": [], "suppliers": [], "next_step": "", "actions": [], "understood": ""}


def out_of_scope() -> dict:
    reply = ("That's outside what I can help with. I'm built for supplier and procurement decisions, so I can talk about your supplier data (scores, risk, ESG, concentration, trends) "
             "and about general practice such as choosing suppliers, negotiating, contracts, risk, sustainability and sourcing strategy.")
    return {"title": "Outside my scope", "reply": reply, "why": reply, "evidence": [], "topic_ids": [], "suppliers": [], "next_step": "", "actions": [], "understood": "",
            "follow_ups": ["What key features should a big business look for in a supplier?", "How do I reduce supplier risk?", "What do you suggest I focus on?", "What can you do?"]}
