"""Supplier Onboarding Readiness: deterministic portfolio-fit assessment.

Ported from the original Streamlit module (Vendor360 notebook, Supplier Onboarding page) so that the
React UI only collects input and renders this module's structured result. No AI is involved.

Rules (unchanged from the original):
  * better-than % : higher-is-better -> share of peers strictly BELOW the entered value;
                    lower-is-better  -> share of peers strictly ABOVE it.
  * position      : >=75 Strong, >=50 Above average, >=25 Watch, else Weak
  * Portfolio Fit : mean of the (1-decimal) better-than % over the available dimensions
  * assessment    : any Weak -> REVIEW REQUIRED; else any Watch -> MANAGEMENT REVIEW; else READY FOR MANAGEMENT REVIEW
  * a prospective supplier is NOT added to the portfolio; nothing is saved (session-only).

One deliberate difference from the bounded cost KPI: Cost here is a REAL INR unit price (supplier-level median over
per-unit pricing models: tiered, day_rate, usage, blended_rate; lump-sum models are not unit prices). It is kept separate
from the bounded cost KPI used by MCDA, which is unchanged. Allowed range = 0 .. 2x the highest peer price.
"""
from __future__ import annotations
import math
import re
from typing import Any
import numpy as np
import pandas as pd

DIMENSIONS = ["Cost", "Quality", "Reliability", "Risk", "Sustainability", "Capacity"]
DEFAULT_DIRECTION = {"Cost": "lower", "Quality": "higher", "Reliability": "lower",
                     "Risk": "lower", "Sustainability": "higher", "Capacity": "higher"}
MEANING = {
    "Cost": "Median unit price in INR (per-unit pricing models)",
    "Quality": "Quality score",
    "Reliability": "Lead time in days",
    "Risk": "Risk score",
    "Sustainability": "Sustainability score",
    "Capacity": "Capacity per month",
}
STEP = {"Cost": 1.0, "Quality": 1.0, "Reliability": 0.5, "Risk": 1.0, "Sustainability": 1.0, "Capacity": 1.0}


class OnboardingInputError(ValueError):
    """Raised for invalid user input (missing / non-numeric / out-of-range values)."""


COST_COL = "unit_price_inr"   # merged into the KPI frame by with_unit_price(); cost_kpi itself is never used here


def _col(dim: str) -> str:
    return COST_COL if dim == "Cost" else f"{dim.lower()}_kpi"


def with_unit_price(kpi: pd.DataFrame, price: pd.DataFrame | None) -> pd.DataFrame:
    """Return a copy of the supplier KPI frame with the real INR unit price (supplier level) attached."""
    out = kpi.copy()
    if price is not None and len(price) and {"supplier_id", COST_COL}.issubset(price.columns):
        m = price[["supplier_id", COST_COL]].copy()
        m["supplier_id"] = m["supplier_id"].astype(str)
        out["supplier_id"] = out["supplier_id"].astype(str)
        out = out.drop(columns=[COST_COL], errors="ignore").merge(m, on="supplier_id", how="left")
    return out


def parse_list(value: Any) -> list[str]:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return []
    return [x.strip() for x in re.split(r"[,;|]", str(value)) if x.strip() and x.strip().lower() != "nan"]


def available_dimensions(kpi: pd.DataFrame) -> list[str]:
    return [d for d in DIMENSIONS if _col(d) in kpi.columns and pd.to_numeric(kpi[_col(d)], errors="coerce").notna().any()]


def peers(kpi: pd.DataFrame, dim: str) -> pd.Series:
    return pd.to_numeric(kpi[_col(dim)], errors="coerce").dropna() if _col(dim) in kpi.columns else pd.Series(dtype=float)


def input_range(kpi: pd.DataFrame, dim: str) -> tuple[float, float]:
    if dim in ("Quality", "Risk", "Sustainability"):
        return 0.0, 100.0
    p = peers(kpi, dim)
    if p.empty:
        return 0.0, 100.0
    mx = float(p.max())
    upper = max(mx * 2.0, mx + 1.0)
    upper = float(np.ceil(upper)) if dim in ("Reliability", "Capacity", "Cost") else float(round(upper, 2))
    return 0.0, upper


def _directions(directions: dict | None) -> dict:
    d = dict(DEFAULT_DIRECTION)
    for k, v in (directions or {}).items():
        name = str(k).capitalize()
        if name in d and str(v).lower() in ("higher", "lower"):
            d[name] = str(v).lower()
    return d


def config(kpi: pd.DataFrame, directions: dict | None = None) -> dict:
    dirs = _directions(directions)
    dims = available_dimensions(kpi)
    rows = []
    for d in dims:
        lo, hi = input_range(kpi, d)
        p = peers(kpi, d)
        rows.append({"dimension": d, "min": lo, "max": hi, "step": STEP[d], "direction": dirs[d],
                     "meaning": MEANING[d], "median": round(float(p.median()), 4) if not p.empty else lo})
    cats: set[str] = set()
    if "category_l2_list" in kpi.columns:
        for v in kpi["category_l2_list"].dropna().astype(str):
            cats.update(parse_list(v))
    suppliers = []
    for _, r in kpi.sort_values("supplier_name").iterrows():
        vals = {d: (None if pd.isna(pd.to_numeric(r.get(_col(d)), errors="coerce")) else round(float(r[_col(d)]), 4)) for d in dims}
        c = parse_list(r.get("category_l2_list"))
        suppliers.append({"supplier_id": str(r["supplier_id"]), "supplier_name": str(r["supplier_name"]),
                          "category": c[0] if c else "", "values": vals})
    return {"dimensions": rows, "categories": sorted(cats), "suppliers": suppliers, "peer_count": int(len(kpi)),
            "cost_note": ("Cost is the supplier's median unit price in INR across per-unit pricing models (tiered, day rate, usage, "
                          "blended rate). Lump-sum contracts (fixed, performance, subscription) are not unit prices and are excluded, so "
                          "suppliers that only use those models have no Cost value and start at the portfolio median."),
            "notice": "This is a readiness assessment only. It does not automatically approve, reject, create, "
                      "or permanently save a supplier."}


def _position(pct: float) -> str:
    if pct >= 75:
        return "Strong"
    if pct >= 50:
        return "Above average"
    if pct >= 25:
        return "Watch"
    return "Weak"


def assess(kpi: pd.DataFrame, payload: dict, directions: dict | None = None) -> dict:
    """payload: {supplier_name, supplier_id, category, values: {Dimension: number|None}, preview?: bool}"""
    dirs = _directions(directions)
    dims = available_dimensions(kpi)
    name = str(payload.get("supplier_name") or "").strip()
    sid = str(payload.get("supplier_id") or "").strip()
    cat = str(payload.get("category") or "").strip()
    raw_values = payload.get("values") or {}

    values: dict[str, float | None] = {}
    for d in dims:
        v = raw_values.get(d)
        if v is None or (isinstance(v, str) and not v.strip()):
            values[d] = None
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            raise OnboardingInputError(f"{d} must be a number.")
        if math.isnan(f) or math.isinf(f):
            raise OnboardingInputError(f"{d} must be a finite number.")
        lo, hi = input_range(kpi, d)
        if f < lo or f > hi:
            raise OnboardingInputError(f"{d} must be between {lo:g} and {hi:g} (got {f:g}).")
        values[d] = f

    filled = int(bool(name)) + int(bool(sid)) + int(bool(cat) and cat != "Select category") + sum(v is not None for v in values.values())
    total = 3 + len(dims)
    completeness = {"filled": filled, "total": total, "pct": round(filled / total * 100) if total else 0}
    out: dict[str, Any] = {"completeness": completeness, "completeness_pct": completeness["pct"]}
    if payload.get("preview"):
        return {**out, "preview": True}

    missing = [label for label, ok in (("Supplier name", bool(name)), ("Supplier ID", bool(sid)),
                                       ("Primary category", bool(cat) and cat != "Select category")) if not ok]
    missing += [f"{d} value" for d in dims if values[d] is None]
    if missing:
        return {**out, "status": "needs_information", "missing": missing,
                "message": "Needs information — complete: " + ", ".join(missing) + "."}

    rows = []
    for d in dims:
        p = peers(kpi, d)
        if p.empty:
            continue
        entered = float(values[d])  # type: ignore[arg-type]
        pct = float((p < entered).mean() * 100) if dirs[d] == "higher" else float((p > entered).mean() * 100)
        pct = round(pct, 1)
        rows.append({"dimension": d, "entered": round(entered, 2), "portfolio_median": round(float(p.median()), 2),
                     "direction": dirs[d], "better_than_pct": pct, "position": _position(pct)})
    fit = round(float(np.mean([r["better_than_pct"] for r in rows])), 1) if rows else 0.0
    strong = [r["dimension"] for r in rows if r["better_than_pct"] >= 75]
    watch = [r["dimension"] for r in rows if 25 <= r["better_than_pct"] <= 49.9999]
    weak = [r["dimension"] for r in rows if r["better_than_pct"] < 25]
    pct_of = {r["dimension"]: r["better_than_pct"] for r in rows}

    if weak:
        label, tone = "REVIEW REQUIRED", "danger"
        message = "Weak portfolio positions detected on: " + ", ".join(weak) + "."
        recommendation = ("Conduct additional commercial and operational due diligence before progressing this supplier. "
                          "Priority dimensions: " + ", ".join(weak) + ".")
    elif watch:
        label, tone = "MANAGEMENT REVIEW", "warning"
        message = "The supplier is broadly acceptable, but some dimensions require attention."
        recommendation = "The supplier can proceed to management review, with particular attention to: " + ", ".join(watch) + "."
    else:
        label, tone = "READY FOR MANAGEMENT REVIEW", "stable"
        message = "No major weak dimension was detected against the current portfolio."
        recommendation = "The supplier can proceed to management review. No major portfolio weakness was detected."

    strengths = [f"{d} — stronger than {pct_of[d]:.1f}% of current suppliers." for d in strong]
    if weak:
        attention = [f"{d} — stronger than only {pct_of[d]:.1f}% of current suppliers." for d in weak]
    else:
        attention = [f"{d} — better than {pct_of[d]:.1f}% of current suppliers." for d in watch]
    interpretation = []
    if strong:
        interpretation.append("Strong portfolio positions: " + ", ".join(strong) + ".")
    if watch:
        interpretation.append("Watch dimensions: " + ", ".join(watch) + ".")
    if weak:
        interpretation.append("Priority investigation areas: " + ", ".join(weak) + ".")

    return {**out, "status": "assessed", "supplier": {"name": name, "id": sid, "category": cat},
            "fit_index": fit, "assessment": label, "tone": tone, "message": message, "benchmark": rows,
            "strengths": strengths, "strengths_empty": "No dimension currently falls in the strongest portfolio quartile." if not strengths else None,
            "attention": attention, "attention_empty": "No major benchmark weakness detected." if not attention else None,
            "recommendation": recommendation, "interpretation": interpretation,
            "caption": "Readiness compares the entered supplier profile against the current Vendor360 supplier portfolio. "
                       "It is not an automatic supplier approval, rejection, or purchasing decision. "
                       "New supplier entries are session-only and are not added to the dataset.",
            "peer_count": int(len(kpi))}
