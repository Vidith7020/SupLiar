from __future__ import annotations
import json, os, io, re, threading, contextlib
from pathlib import Path
from contextlib import asynccontextmanager
from typing import Any
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from . import advisor_context, advisor_core, gemini_client

ROOT = Path(__file__).resolve().parent.parent
# WORK  : generated outputs (Vendor360_Cell*/ folders etc.). Default /content so Colab works unchanged.
# INPUT : the source datasets (suppliers/pricing/categories/historical_awards). Defaults to WORK.
WORK = Path(os.getenv("VENDOR360_WORKDIR", "/content"))
INPUT = Path(os.getenv("VENDOR360_INPUT_DIR") or WORK)
NS: dict[str, Any] = {}
BOOT_ERROR: str | None = None
# starting -> ready | error. Endpoints that need engine output answer 503 until "ready".
STATE = "starting"


def _records(df: pd.DataFrame | None):
    if df is None or df.empty:
        return []
    return json.loads(df.where(pd.notna(df), None).to_json(orient="records"))


def _read(path: str) -> pd.DataFrame:
    """Read a GENERATED output (under WORK)."""
    p = WORK / path
    return pd.read_csv(p) if p.exists() else pd.DataFrame()


def _require_ready():
    if STATE == "starting":
        raise HTTPException(503, "Vendor360 backend is still starting; retry shortly (see /api/health).")
    if STATE == "error":
        raise HTTPException(503, f"Vendor360 backend failed to start: {BOOT_ERROR}")


def _id_col(df):
    for c in ("supplier_id", "entity_id", "vendor_id"):
        if c in df.columns:
            return c
    return None


def _name_col(df):
    for c in ("supplier_name", "entity_name", "vendor_name"):
        if c in df.columns:
            return c
    return None


def _clear_generated():
    """Remove only files/folders this system generated (names starting with 'Vendor360_') from WORK.

    Source datasets never start with that prefix, so they are never touched. Ingestion also ignores
    such names, which keeps repeated starts idempotent.
    """
    import shutil
    if not WORK.exists():
        return
    for p in WORK.iterdir():
        if p.name.startswith("Vendor360_"):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                p.unlink(missing_ok=True)


def _boot():
    global NS, BOOT_ERROR, STATE
    try:
        WORK.mkdir(parents=True, exist_ok=True)
        _clear_generated()
        from .pipeline import run_backend
        result = run_backend(str(WORK), execute_ai=False, input_dir=str(INPUT))
        NS = result["namespace"]
        BOOT_ERROR = None
        STATE = "ready"
    except Exception as exc:
        BOOT_ERROR = f"{type(exc).__name__}: {exc}"
        NS = {}
        STATE = "error"


# ---------------------------------------------------------------------------
# Portfolio assembly (Phase 1): one slim, documented schema.
# All scores come from the deterministic engine outputs; this layer only
# merges tables and derives a *display* scale (percentile, direction-aware).
# ---------------------------------------------------------------------------
DIMENSIONS = ["cost", "quality", "reliability", "risk", "sustainability", "capacity"]
DIRECTIONS = {"cost": "lower", "quality": "higher", "reliability": "lower",
              "risk": "lower", "sustainability": "higher", "capacity": "higher"}
RUN_LOCK = threading.Lock()


def _directions() -> dict:
    p = WORK / "Vendor360_Cell23" / "Vendor360_KPI_Config.json"
    try:
        raw = json.loads(p.read_text())
        return {k.lower(): str(v).lower() for k, v in raw.items() if k.lower() in DIMENSIONS} or DIRECTIONS
    except Exception:
        return DIRECTIONS


def _clean(v):
    if v is None:
        return None
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    if hasattr(v, "item"):
        v = v.item()
    return v


def _source(name: str) -> pd.DataFrame:
    """Read a SOURCE dataset (under INPUT)."""
    p = INPUT / name
    return pd.read_csv(p) if p.exists() else pd.DataFrame()


def _kpi_df():
    kpi = NS.get("supplier_kpi_df", pd.DataFrame()).copy()
    return kpi if not kpi.empty else _read("Vendor360_Cell23/Vendor360_Supplier_KPI_Comparison.csv")


def _portfolio_rows() -> list[dict]:
    di = NS.get("decision_intelligence_df", pd.DataFrame()).copy()
    if di.empty:
        di = _read("Vendor360_Cell26B/Vendor360_Decision_Intelligence.csv")
    risk = NS.get("risk_radar_df", pd.DataFrame()).copy()
    if risk.empty:
        risk = _read("Vendor360_Cell26/Vendor360_Risk_Radar.csv")
    kpi = _kpi_df()
    if kpi.empty:
        return []
    kpi["supplier_id"] = kpi["supplier_id"].astype(str)
    out = kpi[["supplier_id", "supplier_name", "supplier_record_count", "category_l2_list", "mcda_score",
               "supplier_mcda_rank", "kpi_completeness_pct"] + [f"{d}_kpi" for d in DIMENSIONS]].copy()
    if not di.empty:
        di["supplier_id"] = di["supplier_id"].astype(str)
        keep = ["supplier_id", "risk_radar_score", "risk_radar_status", "risk_radar_action", "positive_contributors",
                "negative_contributors", "risk_explanation", "decision_position", "decision_explanation",
                "recommended_action"]
        out = out.merge(di[[c for c in keep if c in di.columns]], on="supplier_id", how="left")
    if not risk.empty:
        rid = _id_col(risk)
        r2 = risk.rename(columns={rid: "supplier_id"})
        r2["supplier_id"] = r2["supplier_id"].astype(str)
        keep = [c for c in ("supplier_id", "risk_radar_band", "risk_radar_signal_count", "risk_radar_flags") if c in r2.columns]
        out = out.merge(r2[keep].drop_duplicates("supplier_id"), on="supplier_id", how="left")
    # category_l1 + country from the source file (first/most common per supplier)
    sup = _source("suppliers.csv")
    if not sup.empty and "supplier_id" in sup.columns:
        sup["supplier_id"] = sup["supplier_id"].astype(str)
        meta = sup.groupby("supplier_id").agg(
            category=("category_l1", lambda x: x.mode().iat[0] if len(x.mode()) else None),
            country_hq=("country_hq", "first")).reset_index()
        out = out.merge(meta, on="supplier_id", how="left")
    else:
        out["category"] = None
        out["country_hq"] = None
    # Display scale: direction-aware percentile 0-100 (100 = best). Display only.
    dirs = _directions()
    for d in DIMENSIONS:
        col = out[f"{d}_kpi"].astype(float)
        pct = col.rank(pct=True, method="average") * 100
        out[f"{d}_score"] = (100 - pct + (100 / max(col.notna().sum(), 1))) if dirs.get(d) == "lower" else pct
        out.loc[col.isna(), f"{d}_score"] = None
        out[f"{d}_score"] = out[f"{d}_score"].clip(0, 100).round(1)
    _est = set(((NS.get("VENDOR360_PREP_LOG") or {}).get("capacity") or {}).get("suppliers_affected", []))
    out["capacity_estimated"] = out["supplier_id"].astype(str).isin(_est)
    out["score"] = (out["mcda_score"].astype(float) * 100).round(1)
    out["rank"] = out["supplier_mcda_rank"].astype(float).astype("Int64")
    out = out.sort_values("rank")
    rows = []
    for rec in out.to_dict(orient="records"):
        rows.append({k: _clean(v) for k, v in rec.items()})
    return rows


def _schema_note() -> dict:
    return {
        "score": "MCDA recommendation score x100 (engine output; display scale only)",
        "rank": "supplier-level MCDA rank (1 = best)",
        "<dimension>_kpi": "raw engine KPI in its native unit (cost: price percentile within pricing model + category after INR conversion, reliability: lead-time days, capacity: units/month; estimated where the source held a placeholder)",
        "<dimension>_score": "direction-aware percentile within this portfolio, 0-100, 100 = best (display only)",
        "risk_radar_score": "operational risk 0-100, lower is better (separate from the MCDA score)",
        "directions": _directions(),
        "risk_thresholds": NS.get("RISK_THRESHOLDS"),
    }


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Run the ~15 s pipeline in the background so the server answers /api/health immediately.
    # (Skipped if a previous lifespan already finished booting, e.g. repeated TestClient sessions.)
    if STATE != "ready":
        threading.Thread(target=_boot, name="vendor360-boot", daemon=True).start()
    yield


app = FastAPI(title="Vendor360 API", version="1.2.0", lifespan=lifespan)
# CORS: the UI normally calls /api through the Vite proxy (same origin), so no cross-origin access is
# needed. Default to local dev origins only; override with a comma-separated VENDOR360_CORS_ORIGINS.
_CORS = [o.strip() for o in os.getenv(
    "VENDOR360_CORS_ORIGINS",
    "http://localhost:5173,http://127.0.0.1:5173,http://localhost:8000,http://127.0.0.1:8000").split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=_CORS, allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"])


@app.get("/api/health")
def health():
    return {"status": STATE, "ok": STATE == "ready", "backend_ready": STATE == "ready", "error": BOOT_ERROR,
            "workdir": str(WORK), "input_dir": str(INPUT)}


@app.get("/api/portfolio")
def get_portfolio():
    _require_ready()
    rows = _portfolio_rows()
    if not rows:
        raise HTTPException(503, BOOT_ERROR or "Vendor360 outputs are not available.")
    return {"count": len(rows), "schema": _schema_note(), "suppliers": rows}


@app.get("/api/risk")
def get_risk():
    _require_ready()
    df = NS.get("risk_radar_df", pd.DataFrame())
    if df.empty:
        df = _read("Vendor360_Cell26/Vendor360_Risk_Radar.csv")
    if df.empty:
        raise HTTPException(503, "Risk Radar output is not available.")
    return {"count": len(df), "columns": list(df.columns), "records": _records(df)}


@app.get("/api/supplier/{supplier_id}")
def get_supplier(supplier_id: str):
    _require_ready()
    rows = _portfolio_rows()
    m = [r for r in rows if str(r["supplier_id"]) == str(supplier_id)]
    if not m:
        raise HTTPException(404, "Supplier not found")
    return m[0]


# ---------------------------------------------------------------- trends ----
@app.get("/api/trends")
def get_trends():
    _require_ready()
    df = _source("historical_awards.csv")
    if df.empty or "award_date" not in df.columns:
        return {"available": False, "records": [], "reason": "historical_awards.csv with award_date not found"}
    df["award_date"] = pd.to_datetime(df["award_date"], errors="coerce")
    df = df.dropna(subset=["award_date"]).copy()
    if "awarded" in df.columns:
        df = df[df["awarded"].astype(str).str.lower().isin(["true", "1", "yes"])]
    if df.empty:
        return {"available": False, "records": [], "reason": "no awarded rows"}
    df["period"] = df["award_date"].dt.to_period("M").astype(str)
    prep = NS.get("VENDOR360_PREP_LOG", {}) or {}
    fx = prep.get("fx") if prep.get("fx", {}).get("applied") else None
    if fx and "currency" in df.columns and not set(df["currency"].astype(str).str.upper()).issubset(fx["rates"]):
        return {"available": False, "records": [], "reason": "award currencies missing from fx_rates.json"}
    recs = []
    for period, g in df.groupby("period"):
        rec = {"period": period, "awards": int(len(g))}
        for src, name in (("lead_time_days", "avg_lead_time"), ("risk_score_at_award", "avg_risk"), ("savings_pct", "avg_savings")):
            rec[name] = round(float(g[src].mean()), 2) if src in g.columns and g[src].notna().any() else None
        # Value converted to INR with the pipeline's FX table (config/fx_rates.json) BEFORE summing.
        if "total_value" in g.columns and fx:
            gv = g["total_value"].astype(float)
            if "currency" in g.columns:
                gv = gv * g["currency"].astype(str).str.upper().map(fx["rates"]).astype(float)
            rec["award_value_inr"] = round(float(gv.sum()), 2) if gv.notna().any() else None
        recs.append(rec)
    return {"available": True, "basis": "awarded rows only", "currency": "INR" if fx else None,
            "fx": ({"rates": fx["rates"], "as_of": fx.get("as_of"), "source": fx.get("source"), "indicative": fx.get("indicative")} if fx else None),
            "records": recs}


# ------------------------------------------------------------ dependency ----
@app.get("/api/dependency")
def get_dependency():
    _require_ready()
    aw = _source("historical_awards.csv")
    sup = _source("suppliers.csv")
    if aw.empty or "supplier_id" not in aw.columns:
        return {"available": False}
    if "awarded" in aw.columns:
        aw = aw[aw["awarded"].astype(str).str.lower().isin(["true", "1", "yes"])]
    total = len(aw)
    cats = []
    for cat, g in aw.groupby("category_l1"):
        shares = g["supplier_id"].value_counts(normalize=True)
        top_id = shares.index[0]
        name = g.loc[g["supplier_id"] == top_id, "supplier_name"].iloc[0] if "supplier_name" in g.columns else top_id
        cats.append({"category": cat, "awards": int(len(g)), "suppliers_used": int(shares.size),
                     "top_supplier": name, "top_share_pct": round(float(shares.iloc[0]) * 100, 1),
                     "hhi": round(float((shares ** 2).sum() * 10000))})
    cats.sort(key=lambda r: -r["top_share_pct"])
    sup_counts = aw.groupby(["supplier_id"]).agg(awards=("award_id", "count"),
                                                 name=("supplier_name", "first"),
                                                 categories=("category_l1", "nunique")).reset_index()
    sup_counts["share_pct"] = (sup_counts["awards"] / max(total, 1) * 100).round(1)
    sup_counts = sup_counts.sort_values("awards", ascending=False).head(10)
    single = []
    if not sup.empty and {"category_l2", "supplier_id"} <= set(sup.columns):
        n = sup.groupby("category_l2")["supplier_id"].nunique()
        single = sorted(n[n == 1].index.tolist())
    return {"available": True, "basis": "awarded rows (counts, not currency values)", "total_awards": int(total),
            "categories": cats, "top_suppliers": _records(sup_counts), "single_source_categories": single}


# --------------------------------------------------------------- quality ----
@app.get("/api/quality")
def get_quality():
    _require_ready()
    rows = _portfolio_rows()
    if not rows:
        raise HTTPException(503, "Outputs not available.")
    src = {}
    for n in ("suppliers.csv", "pricing.csv", "historical_awards.csv", "categories.csv"):
        d = _source(n)
        src[n] = {"rows": int(len(d)), "columns": int(d.shape[1])}
    dim = _read("Vendor360_Cell23/Vendor360_KPI_Dimension_Summary.csv")
    kpi = pd.DataFrame(rows)
    missing = {d: int(kpi[f"{d}_kpi"].isna().sum()) for d in DIMENSIONS}
    sentinel = int((kpi["capacity_kpi"].astype(float) >= 999999).sum())
    pr = _source("pricing.csv")
    return {
        "sources": src, "suppliers": int(len(kpi)), "supplier_records": int(kpi["supplier_record_count"].sum()),
        "dimension_availability": _records(dim[[c for c in ("dimension", "available", "supplier_kpi_column") if c in dim.columns]]) if not dim.empty else [],
        "missing_kpi_by_dimension": missing,
        "completeness_below_100": int((kpi["kpi_completeness_pct"].astype(float) < 100).sum()),
        "capacity_placeholder_999999": sentinel,
        "preparation": NS.get("VENDOR360_PREP_LOG", {}),
        "pricing_currencies": pr["currency"].value_counts().to_dict() if "currency" in pr else {},
        "pricing_models": pr["pricing_model"].value_counts().to_dict() if "pricing_model" in pr else {},
        "decision_positions": pd.Series([r.get("decision_position") for r in rows]).value_counts().to_dict(),
        "notes": [
            "Scores are produced only by the deterministic engine; this page reports data health.",
            "Prices are converted to INR with the rates in config/fx_rates.json before any aggregation (see preparation.fx).",
            "Cost KPI = price percentile within the same pricing model and category (0 = cheapest, 1 = most expensive); see preparation.price_normalisation.",
            "Capacity: the source placeholder value 999999 was replaced by a category median estimate for the affected suppliers (see preparation.capacity).",
        ],
    }


# ---------------------------------------------------------------- export ----
EXPORTS = {
    "portfolio": "Vendor360_Portfolio.csv",
    "risk": "Vendor360_Cell26/Vendor360_Risk_Radar.csv",
    "decision": "Vendor360_Cell26B/Vendor360_Decision_Intelligence.csv",
    "kpi": "Vendor360_Cell23/Vendor360_Supplier_KPI_Comparison.csv",
}


@app.get("/api/export/{name}")
def export(name: str):
    _require_ready()
    if name not in EXPORTS:
        raise HTTPException(404, "Unknown export")
    if name == "portfolio":
        df = pd.DataFrame(_portfolio_rows())
    else:
        df = _read(EXPORTS[name])
    if df.empty:
        raise HTTPException(503, "Export not available.")
    return Response(df.to_csv(index=False), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{Path(EXPORTS[name]).name}"'})


# ---------------------------------------------------- onboarding readiness ----
class OnboardingRequest(BaseModel):
    supplier_name: str = ""
    supplier_id: str = ""
    category: str = ""
    values: dict[str, float | None] = {}
    preview: bool = False


def _onb_kpi():
    """Supplier KPI frame + real INR unit price (for onboarding only; the engine's cost KPI is untouched)."""
    from . import onboarding
    return onboarding.with_unit_price(NS["supplier_kpi_df"], NS.get("VENDOR360_ONBOARDING_PRICE"))


@app.get("/api/onboarding/config")
def onboarding_config():
    _require_ready()
    from . import onboarding
    return onboarding.config(_onb_kpi(), _directions())


@app.post("/api/onboarding/assess")
def onboarding_assess(req: OnboardingRequest):
    _require_ready()
    from . import onboarding
    try:
        return onboarding.assess(_onb_kpi(), req.model_dump(), _directions())
    except onboarding.OnboardingInputError as exc:
        raise HTTPException(422, str(exc))


# -------------------------------------------------------------- scenario ----
class ScenarioRequest(BaseModel):
    scenario_text: str


class AdvisorRequest(BaseModel):
    question: str
    use_gemini: bool = False  # on-demand: only true when the user switches Gemini on
    # Recent turns [{role, content, supplier_ids?, intent?, scenario_text?}] so the advisor can follow up ("compare them", "why?").
    history: list[dict[str, Any]] = []


def _run_engine(text: str) -> dict:
    fn = NS.get("run_advisor")
    if fn is None:
        raise HTTPException(503, "Scenario engine is not available.")
    # The scenario engine writes its CSV/JSON into this folder; _boot() deletes it on every start.
    (WORK / "Vendor360_Cell25").mkdir(parents=True, exist_ok=True)
    with RUN_LOCK, contextlib.redirect_stdout(io.StringIO()):
        return fn(text, engine="Local Deterministic")


def _scenario_payload(text: str) -> dict:
    result = _run_engine(text)
    ranking = result.get("ranking")
    base = {str(r["supplier_id"]): r for r in _portfolio_rows()}
    rows = []
    if ranking is not None and not ranking.empty:
        for rec in ranking.to_dict(orient="records"):
            sid = str(rec.get("supplier_id"))
            b = base.get(sid, {})
            new_rank = _clean(rec.get("scenario__rank"))
            base_rank = b.get("rank")
            rows.append({"supplier_id": sid, "supplier_name": rec.get("supplier_name"),
                         "scenario_rank": None if new_rank is None else int(new_rank),
                         "scenario_score": None if _clean(rec.get("scenario__decision_score")) is None else round(float(rec["scenario__decision_score"]) * 100, 1),
                         "baseline_rank": base_rank, "baseline_score": b.get("score"),
                         "rank_change": None if (new_rank is None or base_rank is None) else int(base_rank) - int(new_rank)})
    rows.sort(key=lambda r: (r["scenario_rank"] is None, r["scenario_rank"]))
    weights = {k: round(float(v), 3) for k, v in (result.get("weights") or {}).items()}
    interp = result.get("interpretation") or {}
    emphasised = [k for k, v in interp.items() if isinstance(v, dict) and v.get("priority") not in (None, "neutral")]
    movers = [r for r in rows if r["rank_change"]]
    movers.sort(key=lambda r: -abs(r["rank_change"]))
    if emphasised and movers:
        m = movers[0]
        verb = "up" if m["rank_change"] > 0 else "down"
        expl = (f"Emphasis on {', '.join(emphasised)} changes the weights; {m['supplier_name']} moves {verb} "
                f"{abs(m['rank_change'])} place(s) (#{m['baseline_rank']} to #{m['scenario_rank']}).")
    elif emphasised:
        expl = f"Emphasis on {', '.join(emphasised)} changes the weights, but the top ranking order is unchanged."
    else:
        expl = "No dimension priority was detected in the text, so weights stay equal (baseline-like)."
    return {"engine": result.get("engine"), "interpretation": interp, "weights": weights, "emphasised": emphasised,
            "explanation": expl, "recommendation": result.get("recommendation"), "ranking": rows}


@app.post("/api/scenario")
def scenario(req: ScenarioRequest):
    _require_ready()
    try:
        return _scenario_payload(req.scenario_text)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, f"Scenario evaluation failed: {exc}") from exc


def _safe(fn):
    """Optional payloads (trends, concentration) must never break the chat."""
    try:
        return fn()
    except Exception:
        return None


def _advisor_answer(question: str, history: list | None = None) -> dict:
    """Conversational, deterministic advisor over engine outputs (see advisor_core). No Gemini, no invented numbers."""
    _require_ready()
    try:
        rows = _portfolio_rows()
        if not rows:
            raise HTTPException(503, "Advisor data not available.")
        return advisor_core.answer(question, rows, scenario_fn=_scenario_payload, history=history,
                                   extras={"dependency": get_dependency, "trends": get_trends})
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, f"Advisor evaluation failed: {exc}") from exc


# ---------------------------------------------------------------- gemini (on demand) ----
GEMINI_LOCK = threading.Lock()


def _gemini_context(rows: list[dict], focus_ids=()) -> dict:
    """Verified facts Gemini may talk about: every supplier with all dimensions, category / leader / concentration / trend
    summaries and a glossary (see advisor_context). All values come from the engine."""
    return advisor_context.build_context(rows, dependency=_safe(get_dependency), trends=_safe(get_trends), focus_ids=focus_ids)


@app.get("/api/gemini/status")
def gemini_status():
    """Tells the UI whether the on-demand Gemini buttons can work. Never returns the key."""
    return {"configured": gemini_client.is_configured(), "model": gemini_client.model_name(),
            "sdk_installed": gemini_client.sdk_installed()}


@app.post("/api/insights/gemini")
def gemini_insights():
    """On-demand executive insights written by Gemini from verified engine outputs."""
    _require_ready()
    rows = _portfolio_rows()
    if not rows:
        raise HTTPException(503, "Portfolio data not available.")
    ctx = _gemini_context(rows)
    with GEMINI_LOCK:
        res = gemini_client.generate(gemini_client.build_insights_prompt(ctx), ctx)
    return {"engine": "Gemini (grounded in engine outputs)" if res["success"] else "Gemini unavailable",
            "insights": gemini_client.clean_insights(res["data"]) if res["success"] else None,
            "gemini": gemini_client.public_meta(res),
            "supplier_count": len(rows)}


@app.post("/api/advisor")
def advisor(req: AdvisorRequest):
    history = advisor_core.clean_history(req.history)
    answer = _advisor_answer(req.question, history)
    if not req.use_gemini:
        return answer
    rows = _portfolio_rows()
    ctx = _gemini_context(rows, focus_ids=[s.get("supplier_id") for s in answer.get("suppliers", [])])
    # What Gemini sees of the engine answer; the same object is used to verify numbers it quotes from it.
    engine_view = {k: answer.get(k) for k in ("intent", "title", "reply", "understood", "evidence", "next_step")}
    engine_view["suppliers"] = [{"name": s.get("supplier_name"), "rank": s.get("rank"), "score": s.get("score")} for s in answer.get("suppliers", [])]
    engine_view["weights"] = answer.get("weights")
    with GEMINI_LOCK:
        res = gemini_client.generate(gemini_client.build_advisor_prompt(req.question, engine_view, ctx, history), {"context": ctx, "engine_answer": engine_view})
    answer = dict(answer)
    answer["gemini"] = gemini_client.public_meta(res)
    if res["success"]:
        answer["ai"] = gemini_client.clean_advisor(res["data"])
        answer["engine"] = "Gemini (grounded in engine outputs)"
    else:
        answer["ai"] = None  # the deterministic answer above is still complete
    return answer
