"""Conversational advisor core for Vendor360.

Pure python (no FastAPI, no pandas) so it can be unit-tested without the engine running.

Design
------
* Deterministic: every figure in a reply is read from the engine rows (or from the scenario engine's output).
  Gemini, when switched on, only explains / extends this answer and never supplies scores.
* Intent first, keywords second. The old router fired on single words ("risk", "problem"), so "the risk should be
  the lowest possible" was answered with a list of the *riskiest* suppliers. Here a question that states
  requirements (several dimensions, or one dimension plus a need word) goes to the scenario engine and comes
  back as a recommendation.
* Conversation memory: the caller passes the recent history; "them", "the first one", "why?", "and what about
  Dell?" and "also I need high capacity" are resolved against the previous answer.
* Every answer keeps the old fields (title, why, evidence, next_step, suppliers, engine) and adds `reply`
  (conversational text), `follow_ups`, `actions`, `intent`, `understood` and `scenario_text`.
"""
from __future__ import annotations

import math
import re
from typing import Any, Callable, Optional

from . import advisor_knowledge as knowledge

DIMS = ["cost", "quality", "reliability", "risk", "sustainability", "capacity"]
LABEL = {"cost": "Cost", "quality": "Quality", "reliability": "Reliability", "risk": "Risk",
         "sustainability": "Sustainability", "capacity": "Capacity"}
ESG_LINE = 70
_NOTE = "This is decision support, not an automatic purchasing decision."

DIM_PATTERNS = {
    "cost": r"\b(?:costs?|prices?|pricing|cheap\w*|afford\w*|budget|expensive|spend)\b",
    "quality": r"\bquality\b",
    "reliability": r"\b(?:reliab\w*|deliver\w*|lead[- ]?times?|on[- ]time|punctual|fast\w*|quick\w*)\b",
    "risk": r"\b(?:risks?|risky|safe\w*|low[- ]risk)\b",
    "sustainability": r"\b(?:sustainab\w*|esg|green|environment\w*|eco[- ]?friendly)\b",
    "capacity": r"\b(?:capacity|volume|scal(?:e|able|ability))\b",
}
NEED_CUES = (r"\b(?:need\w*|must|should|important|priorit\w*|want\w*|require\w*|looking for|care about|essential|"
             r"critical|crucial|matters?|major|focus|key|top concern|no problem|don'?t mind|do not mind|willing|"
             r"can afford|fine with|okay with|ok with|tolerate\w*|lowest possible|as low as possible|"
             r"as high as possible|highest possible|prefer\w*|ideal(?:ly)?)\b")
WHATIF_CUES = r"\b(?:what if|more important|matters? most|instead of|if we|if i|suppose|assuming|imagine)\b|priorit"
_NUMWORDS = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
_GENERIC_FIRST_WORDS = {"global", "international", "enterprise", "business", "digital", "technology", "consulting",
                        "services", "solutions", "systems", "group", "premier", "swiss", "european", "americas"}

Rows = list[dict[str, Any]]


# ----------------------------------------------------------------------------------------- helpers ----
def num(v: Any) -> Optional[float]:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) or math.isinf(x) else x


def f1(v: Any) -> str:
    x = num(v)
    return "n/a" if x is None else f"{x:.1f}"


def f0(v: Any) -> str:
    x = num(v)
    return "n/a" if x is None else f"{x:,.0f}"


def _name(r: dict) -> str:
    return str(r.get("supplier_name") or r.get("supplier_id") or "?")


def _b(r: dict) -> str:
    return f"**{_name(r)}**"


def _rank(r: dict) -> int:
    x = num(r.get("rank"))
    return int(x) if x is not None else 10_000


def _status(r: dict) -> str:
    return str(r.get("risk_radar_status") or "Unrated")


def _risk(r: dict) -> Optional[float]:
    return num(r.get("risk_radar_score"))


def _flagged(r: dict) -> bool:
    return _status(r) in ("Critical", "Emerging Risk", "Watch")


def _at_risk(r: dict) -> bool:
    return _status(r) in ("Critical", "Emerging Risk")


def goodness(r: dict, dim: str) -> Optional[float]:
    """0-100, higher is always better. Risk is inverted from the Risk Radar score; the rest are the portfolio
    percentiles the API already provides (direction-aware)."""
    if dim == "risk":
        x = _risk(r)
        return None if x is None else 100 - x
    return num(r.get(f"{dim}_score"))


def raw_text(r: dict, dim: str) -> str:
    v = num(r.get(f"{dim}_kpi"))
    if dim == "risk":
        v = _risk(r)
    if v is None:
        return "n/a"
    if dim == "cost":
        return f"price percentile {v:.0f} (0 = cheapest)"
    if dim == "quality":
        return f"quality score {v:.1f}"
    if dim == "reliability":
        return f"lead time {v:.1f} days"
    if dim == "risk":
        return f"risk {v:.1f} (lower is better)"
    if dim == "sustainability":
        return f"ESG {v:.1f}"
    return f"{v:,.0f} units/month" + (" (estimated)" if r.get("capacity_estimated") else "")


def ref(r: dict) -> dict:
    return {"supplier_id": r.get("supplier_id"), "supplier_name": r.get("supplier_name"), "rank": r.get("rank"),
            "score": r.get("score"), "risk_status": r.get("risk_radar_status"), "risk_score": r.get("risk_radar_score")}


def _join(items: list[str]) -> str:
    items = [i for i in items if i]
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    return ", ".join(items[:-1]) + " and " + items[-1]


def _plural(n: int, one: str, many: Optional[str] = None) -> str:
    return f"{n} {one if n == 1 else (many or one + 's')}"


def _named(rs: list, fmt) -> str:
    """"**A** (x), **B** (y) and **C** (z)" without nested f-string quotes (Python < 3.12 safe)."""
    return _join([_b(r) + " (" + fmt(r) + ")" for r in rs])


def _snap(r: dict, dims: list[str]) -> str:
    bits = []
    for d in dims:
        if d == "risk":
            bits.append(f"Risk {f1(_risk(r))} (lower is better)")
        else:
            g = goodness(r, d)
            bits.append(f"{LABEL[d]} {'n/a' if g is None else f'{g:.0f}'}")
    return " · ".join(bits)


def _weakest(r: dict) -> Optional[tuple[str, float]]:
    vals = [(d, goodness(r, d)) for d in ("cost", "quality", "reliability", "sustainability", "capacity")]
    vals = [(d, v) for d, v in vals if v is not None]
    return min(vals, key=lambda x: x[1]) if vals else None


def _risk_sentence(r: dict) -> str:
    st, sc = _status(r), _risk(r)
    if st == "Stable":
        return f"{_b(r)} is rated Stable on the Risk Radar (risk {f1(sc)})."
    if st == "Unrated":
        return f"{_b(r)} could not be rated on the Risk Radar."
    return f"{_b(r)} is rated {st} on the Risk Radar (risk {f1(sc)}), so check the drivers before awarding."


def _answer(intent: str, title: str, reply: str, *, why: str = "", evidence: Optional[list[str]] = None,
            next_step: str = "", suppliers: Optional[list[dict]] = None, follow_ups: Optional[list[str]] = None,
            actions: Optional[list[dict]] = None, understood: str = "", scenario_text: str = "",
            engine: str = "Deterministic engine outputs", extra: Optional[dict] = None) -> dict:
    out = {"engine": engine, "intent": intent, "title": title, "reply": reply.strip(), "why": why or reply.split("\n")[0],
           "evidence": evidence or [], "next_step": next_step, "suppliers": suppliers or [],
           "follow_ups": (follow_ups or [])[:4], "actions": actions or [], "understood": understood,
           "scenario_text": scenario_text}
    if extra:
        out.update(extra)
    return out


# --------------------------------------------------------------------------------------- name lookup ----
def find_suppliers(q: str, rows: Rows) -> list[dict]:
    """Suppliers named in the question, in order of appearance. Full name or ID; a unique distinctive first word
    (4+ letters) also counts ("Dentsu", "Azure"), unless it is a generic corporate word."""
    ql = q.lower()
    hits: list[tuple[int, dict]] = []
    seen = set()
    first_words: dict[str, list[dict]] = {}
    for r in rows:
        w = _name(r).lower().split()[0]
        first_words.setdefault(w, []).append(r)
    for r in rows:
        name, sid = _name(r).lower(), str(r.get("supplier_id") or "").lower()
        m = re.search(rf"(?<![\w]){re.escape(name)}(?![\w])", ql) or (sid and re.search(rf"(?<![\w]){re.escape(sid)}(?![\w])", ql))
        if not m:
            w = name.split()[0]
            if len(w) >= 4 and w not in _GENERIC_FIRST_WORDS and len(first_words[w]) == 1:
                m = re.search(rf"\b{re.escape(w)}\b", ql)
        if m and r.get("supplier_id") not in seen:
            seen.add(r.get("supplier_id"))
            hits.append((m.start(), r))
    # typo tolerance ("Computacentre", "Accentur"): a token that is one close, distinctive first word
    for pos, r in _fuzzy_hits(ql, rows, first_words):
        if r.get("supplier_id") not in seen:
            seen.add(r.get("supplier_id"))
            hits.append((pos, r))
    return [r for _, r in sorted(hits, key=lambda x: x[0])]


def _fuzzy_hits(ql: str, rows: Rows, first_words: dict) -> list[tuple[int, dict]]:
    import difflib
    candidates = [w for w, rs in first_words.items() if len(w) >= 6 and w not in _GENERIC_FIRST_WORDS and len(rs) == 1]
    out: list[tuple[int, dict]] = []
    for m in re.finditer(r"[a-z][a-z0-9&'-]{5,}", ql):
        tok = m.group(0)
        if tok in first_words or any(re.search(p, tok) for p in DIM_PATTERNS.values()):
            continue
        close = difflib.get_close_matches(tok, candidates, n=2, cutoff=0.86)
        if len(close) == 1 or (len(close) == 2 and difflib.SequenceMatcher(None, tok, close[0]).ratio() - difflib.SequenceMatcher(None, tok, close[1]).ratio() > 0.08):
            r = first_words[close[0]][0]
            if all(r is not h for _, h in out):
                out.append((m.start(), r))
    return out


def mentioned_dims(q: str) -> list[str]:
    ql = q.lower()
    return [d for d, p in DIM_PATTERNS.items() if re.search(p, ql)]


def find_category(question: str, rows: Rows) -> Optional[str]:
    cats = sorted({str(r.get("category") or "") for r in rows if r.get("category")}, key=len, reverse=True)
    for c in cats:
        if len(c) <= 3:  # "IT": only the capitalised token, never the pronoun "it"
            if re.search(rf"\b{re.escape(c)}\b", question):
                return c
        elif re.search(rf"\b{re.escape(c.lower())}\b", question.lower()):
            return c
    return None


def _top_n(q: str, default: int = 3) -> int:
    m = re.search(r"\btop\s+(\d+|" + "|".join(_NUMWORDS) + r")\b", q.lower())
    if not m:
        return default
    t = m.group(1)
    return max(2, min(int(t) if t.isdigit() else _NUMWORDS[t], 6))


# --------------------------------------------------------------------------------------- conversation ----
def clean_history(history: Any) -> list[dict]:
    """Defensive copy of the client-supplied history (never trust size or types)."""
    out = []
    for m in (history if isinstance(history, list) else [])[-8:]:
        if not isinstance(m, dict) or m.get("role") not in ("user", "assistant"):
            continue
        ids = m.get("supplier_ids")
        out.append({"role": m["role"], "content": str(m.get("content") or "")[:600],
                    "supplier_ids": [str(i)[:40] for i in ids[:12]] if isinstance(ids, list) else [],
                    "intent": str(m.get("intent") or "")[:40], "scenario_text": str(m.get("scenario_text") or "")[:500],
                    "topic_ids": [str(i)[:60] for i in m.get("topic_ids")[:4]] if isinstance(m.get("topic_ids"), list) else []})
    return out


def _state(history: list[dict]) -> dict:
    st = {"ids": [], "intent": "", "scenario_text": "", "topics": []}
    for m in reversed(history):
        if m["role"] == "assistant":
            st.update(ids=m.get("supplier_ids") or [], intent=m.get("intent") or "", scenario_text=m.get("scenario_text") or "", topics=m.get("topic_ids") or [])
            break
    return st


_ORD = {"first": 0, "1st": 0, "top one": 0, "second": 1, "2nd": 1, "third": 2, "3rd": 2}


def _pronoun_targets(q: str, state: dict, rows: Rows) -> list[dict]:
    by_id = {str(r.get("supplier_id")): r for r in rows}
    last = [by_id[i] for i in state["ids"] if i in by_id]
    if not last:
        return []
    for word, idx in _ORD.items():
        if re.search(rf"\b(?:the )?{word}(?: one| supplier)?\b", q) and idx < len(last):
            return [last[idx]]
    if re.search(r"\b(?:them|they|those|these|both|all of them|each)\b", q):
        return last
    if re.search(r"\b(?:it|that one|this one|that supplier|him|her|he|she|its)\b", q):
        return last[:1]
    return []


# ------------------------------------------------------------------------------------------- builders ----
def _help(rows: Rows) -> dict:
    reply = ("I'm the Vendor360 advisor. I answer from the engine's scores, so every figure is traceable. You can talk to me normally:\n"
             "- Tell me what you need: \"quality and reliability matter most, cost is no issue, risk as low as possible\"\n"
             "- Ask about one supplier: \"Why is Dentsu ranked where it is?\"\n"
             "- Compare: \"Compare Azure Enterprise and Swiss Sovereign Cloud\" or \"compare the top three\"\n"
             "- Find alternatives: \"What is a safer alternative to Alibaba Cloud?\"\n"
             "- Look at the portfolio: risk, sustainability, concentration of awards, trends, data quality, a category\n"
             "- Ask for advice: \"What should a big business look for in a supplier?\", \"How do I negotiate?\", \"Should we consolidate suppliers?\", \"What do you suggest we focus on?\"\n"
             "- Ask why or how: \"Why does dual sourcing matter?\", \"How does the Risk Radar work?\", \"Why can a top-ranked supplier be high risk?\"\n"
             "I remember the conversation, so you can follow up with \"why?\", \"compare them\" or \"and what if cost mattered more?\".")
    return _answer("help", "What I can help with", reply, follow_ups=["What do you suggest we focus on?", "What key features should a big business look for in a supplier?", "Compare the top three suppliers", "Which suppliers need attention?"])


def _greeting(rows: Rows) -> dict:
    attn = [r for r in rows if _at_risk(r)]
    top = sorted(rows, key=_rank)[0] if rows else None
    reply = f"Hi! I'm the Vendor360 advisor. I'm looking at {len(rows)} suppliers right now."
    if top:
        reply += f" {_b(top)} is ranked first, and {_plural(len(attn), 'supplier')} {'is' if len(attn) == 1 else 'are'} Critical or Emerging Risk."
    reply += " Tell me what matters to you, or ask about a supplier, and I'll take it from there."
    return _answer("greeting", "Hello", reply, follow_ups=["What do you suggest we focus on?", "I need high quality and reliability with the lowest risk", "What should a big business look for in a supplier?"])


def _thanks() -> dict:
    return _answer("thanks", "You're welcome", "Happy to help. Ask a follow-up any time, for example to compare the suppliers we just looked at.", follow_ups=["Compare them", "Which suppliers need attention?"])


def _portfolio_summary(rows: Rows) -> dict:
    n = len(rows)
    cats: dict[str, int] = {}
    for r in rows:
        cats[str(r.get("category") or "Unclassified")] = cats.get(str(r.get("category") or "Unclassified"), 0) + 1
    st: dict[str, int] = {}
    for r in rows:
        st[_status(r)] = st.get(_status(r), 0) + 1
    top = sorted(rows, key=_rank)[:3]
    avg = sum(num(r.get("score")) or 0 for r in rows) / max(n, 1)
    reply = (f"The portfolio has **{n} suppliers** across {_join([f'{k} ({v})' for k, v in sorted(cats.items(), key=lambda x: -x[1])])}. "
             f"Average MCDA score is {avg:.1f}. Risk Radar: " + ", ".join(f"{v} {k}" for k, v in sorted(st.items(), key=lambda x: -x[1])) + ".\n\n"
             "Top three by MCDA: " + _named(top, lambda r: f1(r.get("score"))) + ".")
    return _answer("portfolio", f"Portfolio summary: {n} suppliers", reply, suppliers=[ref(r) for r in top],
                   follow_ups=["Which suppliers need attention?", "Compare the top three suppliers", "Who is best on sustainability?"],
                   next_step="Ask about a supplier, a category, or tell me your priorities for a recommendation.")


def _top_list(rows: Rows, n: int = 3) -> dict:
    top = sorted(rows, key=_rank)[:n]
    lines = [f"#{r['rank']} {_name(r)}: {f1(r.get('score'))} - {r.get('positive_contributors') or 'no standout strengths recorded'}" for r in top]
    reply = (f"By the engine's default (equal-weight) MCDA ranking, the top {n} are " + _join([f"{_b(r)} ({f1(r.get('score'))})" for r in top]) +
             ". " + " ".join(_risk_sentence(r) for r in top if _flagged(r)) +
             "\n\nIf you tell me what matters most (cost, quality, reliability, risk, sustainability, capacity) I can re-rank for your situation.")
    return _answer("top", f"Top {n} suppliers by MCDA score", reply.strip(), why="Ranked by the supplier-level MCDA recommendation score.", evidence=lines,
                   suppliers=[ref(r) for r in top], next_step="Use Supplier Comparison to see the dimensions side by side.",
                   follow_ups=[f"Compare the top {n} suppliers", "I need quality and reliability above all, risk as low as possible", f"Why is {_name(top[0])} ranked first?"] if top else [],
                   actions=[{"label": "Open Supplier Comparison", "page": "Supplier Comparison"}])


def _risk_list(rows: Rows, question: str) -> dict:
    ordered = sorted(rows, key=lambda r: -(_risk(r) or 0))
    crit = [r for r in ordered if _status(r) == "Critical"]
    emer = [r for r in ordered if _status(r) == "Emerging Risk"]
    watch = [r for r in ordered if _status(r) == "Watch"]
    need = crit + emer
    if need:
        title = f"{_plural(len(need), 'supplier')} need action on the Risk Radar"
        reply = (f"{_plural(len(crit), 'supplier')} {'is' if len(crit) == 1 else 'are'} Critical and {len(emer)} Emerging Risk, with {len(watch)} more on Watch.\n\n" +
                 "\n".join(f"- {_b(r)}: risk {f1(_risk(r))} ({_status(r)}). {r.get('risk_explanation') or ''}".rstrip() for r in need[:4]))
    elif watch:
        title = "No supplier needs immediate action"
        reply = f"Nobody is Critical or Emerging Risk, but {len(watch)} on Watch are worth monitoring: " + _join([f"{_b(r)} ({f1(_risk(r))})" for r in watch[:4]]) + "."
    else:
        title = "Portfolio is stable on the Risk Radar"
        reply = "No supplier is flagged on the Risk Radar."
    reply += "\n\nRisk is operational exposure and is separate from the MCDA recommendation score."
    ev = [f"{_name(r)}: risk {f1(_risk(r))} ({_status(r)}) · flags: {r.get('risk_radar_flags') or 'none'}" for r in ordered[:5]]
    first = ordered[0] if ordered else None
    return _answer("risk_list", title, reply, why="Ordered by operational risk score; this is separate from the MCDA recommendation score.", evidence=ev,
                   suppliers=[ref(r) for r in ordered[:5]], next_step="Review the highest-risk suppliers first and validate the flagged drivers.",
                   follow_ups=([f"Why is {_name(first)} high risk?", f"Find a safer alternative to {_name(first)}"] if first and _flagged(first) else []) + ["Who has the lowest risk?"],
                   actions=[{"label": "Open Risk Monitoring", "page": "Risk Monitoring"}])


def _leaders(rows: Rows, dim: str, worst: bool, n: int = 5) -> dict:
    pool = [r for r in rows if goodness(r, dim) is not None]
    pool.sort(key=lambda r: goodness(r, dim), reverse=not worst)  # type: ignore[arg-type,return-value]
    pick = pool[:n]
    if not pick:
        return _answer("leaders", f"No {LABEL[dim].lower()} data", f"None of the suppliers has {LABEL[dim].lower()} data, so I can't rank them.")
    word = "weakest" if worst else "strongest"
    lines = [f"#{r['rank']} {_name(r)}: {raw_text(r, dim)}" for r in pick]
    top = pick[0]
    weak = _weakest(top) if not worst else None
    reply = (f"The {word} suppliers on **{LABEL[dim].lower()}** are " + _join([f"{_b(r)} ({raw_text(r, dim)})" for r in pick[:3]]) + ".")
    if not worst:
        reply += f" {_b(top)} sits at MCDA rank #{top['rank']}"
        reply += f" and its weakest dimension is {LABEL[weak[0]].lower()} (percentile {weak[1]:.0f})." if weak and weak[1] < 50 else "."
        flagged = [r for r in pick[:3] if _flagged(r)]
        if flagged:
            reply += " Note: " + _join([_b(r) for r in flagged]) + f" {'carries' if len(flagged) == 1 else 'carry'} a Risk Radar warning."
    return _answer("leaders", f"{'Weakest' if worst else 'Top'} suppliers on {LABEL[dim].lower()}", reply, evidence=lines, suppliers=[ref(r) for r in pick],
                   follow_ups=[f"Compare these top {min(3, len(pick))}", f"Which of them is lowest risk?", f"Why is {_name(top)} ranked #{top['rank']} overall?"],
                   next_step=f"Check the profile of {_name(top)} for the full picture.")


def _lowest_risk(rows: Rows, n: int = 5) -> dict:
    pool = sorted([r for r in rows if _risk(r) is not None], key=lambda r: (_risk(r), _rank(r)))
    stable = [r for r in pool if _status(r) == "Stable"][:n]
    pick = stable or pool[:n]
    best_ranked = sorted(stable, key=_rank)[:1]
    reply = "The lowest-risk suppliers are " + _join([f"{_b(r)} (risk {f1(_risk(r))}, MCDA #{r['rank']})" for r in pick[:3]]) + "."
    if best_ranked and best_ranked[0] is not pick[0]:
        reply += f" If you want low risk without giving up overall performance, {_b(best_ranked[0])} is the best-ranked Stable supplier (#{best_ranked[0]['rank']})."
    reply += "\n\nTell me what else matters (quality, reliability, sustainability…) and I'll find the best low-risk fit."
    return _answer("lowest_risk", "Lowest-risk suppliers", reply, evidence=[f"{_name(r)}: risk {f1(_risk(r))} ({_status(r)}), MCDA #{r['rank']}" for r in pick],
                   suppliers=[ref(r) for r in pick], follow_ups=["I need quality and reliability too, with the lowest risk", f"Compare these top {min(3, len(pick))}"] if pick else [],
                   next_step="Combine low risk with your other priorities to get a shortlist.")


def _profile(r: dict, question: str, rows: Rows) -> dict:
    q = question.lower()
    risk_focus = bool(re.search(r"\b(risk\w*|critical|watch|flag\w*|warning|danger)\b", q))
    why_focus = bool(re.search(r"\b(why|how come|explain|reason)\b", q))
    parts = [f"{_b(r)} is ranked **#{r.get('rank')} of {len(rows)}** with an MCDA score of {f1(r.get('score'))}, and is {_status(r)} on the Risk Radar (risk {f1(_risk(r))})."]
    if risk_focus and r.get("risk_explanation"):
        parts.append(str(r["risk_explanation"]))
    elif r.get("decision_explanation"):
        parts.append(str(r["decision_explanation"]))
    strengths = [x.strip() for x in str(r.get("positive_contributors") or "").split(";") if x.strip()]
    weak = [x.strip() for x in str(r.get("negative_contributors") or "").split(";") if x.strip()]
    if strengths:
        parts.append("Strengths: " + "; ".join(strengths[:3]) + ".")
    if weak:
        parts.append("Concerns: " + "; ".join(weak[:3]) + ".")
    if r.get("risk_radar_flags"):
        parts.append("Risk signals: " + str(r["risk_radar_flags"]) + ".")
    parts.append("Dimension snapshot (percentiles, 100 = best): " + _snap(r, DIMS) + ".")
    ev = [f"{LABEL[d]}: {raw_text(r, d)}" for d in DIMS]
    fu = [f"Compare {_name(r)} with the top supplier", f"What is an alternative to {_name(r)}?"]
    if _flagged(r):
        fu[1] = f"Find a safer alternative to {_name(r)}"
    return _answer("profile", f"{_name(r)}: rank #{r.get('rank')}, {_status(r)}", "\n\n".join(parts),
                   why=(r.get("risk_explanation") if risk_focus and r.get("risk_explanation") else r.get("decision_explanation")) or "", evidence=ev,
                   next_step=r.get("recommended_action") or "", suppliers=[ref(r)], follow_ups=fu + ([f"Why is {_name(r)} ranked #{r.get('rank')}?"] if not why_focus else []),
                   actions=[{"label": f"Open {_name(r)}", "page": "Supplier Profile", "supplier_id": r.get("supplier_id")}])


def _compare(rs: list[dict], rows: Rows, title: Optional[str] = None, from_scenario: bool = False) -> dict:
    """`from_scenario`: rs is a shortlist from a previous recommendation, already in scenario order, so the first one leads."""
    rs = rs[:4]
    wins = {r["supplier_id"]: [] for r in rs}
    margins = {}
    for d in DIMS:
        sc = sorted([(goodness(r, d), r) for r in rs if goodness(r, d) is not None], key=lambda x: -x[0])  # type: ignore[operator]
        if len(sc) >= 2 and sc[0][0] != sc[1][0]:
            wins[sc[0][1]["supplier_id"]].append(d)
            margins[d] = sc[0][0] - sc[1][0]  # type: ignore[operator]
    leader = rs[0] if from_scenario else sorted(rs, key=_rank)[0]
    others = [r for r in rs if r is not leader]
    intro = (f"{_b(leader)} placed first for your stated priorities (default MCDA #{leader['rank']}, score {f1(leader.get('score'))}), and it is best on " if from_scenario
             else f"{_b(leader)} is the stronger overall choice (MCDA #{leader['rank']}, score {f1(leader.get('score'))}), and it is best on ")
    parts = [intro +
             f"{len(wins[leader['supplier_id']])} of 6 dimensions" + (f" ({_join([LABEL[d].lower() for d in wins[leader['supplier_id']]])})." if wins[leader["supplier_id"]] else ".")]
    for o in others:
        ahead = [d for d in wins[o["supplier_id"]]]
        behind = [d for d in DIMS if d in wins[leader["supplier_id"]] and goodness(o, d) is not None]
        if ahead:
            parts.append(f"{_b(o)} (#{o['rank']}) beats it on {_join([f'{LABEL[d].lower()} (by {margins[d]:.0f} points)' for d in ahead])}" +
                         (f" but trails on {_join([LABEL[d].lower() for d in behind[:3]])}." if behind else "."))
        else:
            parts.append(f"{_b(o)} (#{o['rank']}) is not the best on any dimension.")
    flagged = [r for r in rs if _flagged(r)]
    parts.append(("Risk differs: " + "; ".join(f"{_name(r)} is {_status(r)} (risk {f1(_risk(r))})" for r in rs) + ". A better score does not offset a warning without a mitigation plan.")
                 if flagged else "All of them are Stable on the Risk Radar, so the call rests on the trade-offs above.")
    cats = {str(r.get("category")) for r in rs}
    if len(cats) > 1:
        parts.append("They are in different categories, so this compares relative standing across the portfolio, not like-for-like offers.")
    ev = [f"{_name(r)}: " + _snap(r, DIMS) for r in rs]
    return _answer("compare", title or "Comparison: " + " vs ".join(_name(r) for r in rs), "\n\n".join(parts), evidence=ev, suppliers=[ref(r) for r in rs],
                   follow_ups=[f"Find a safer alternative to {_name(flagged[0])}"] if flagged else [f"Why is {_name(leader)} ranked #{leader['rank']}?", "I need quality above all, what changes?"],
                   next_step="Open Supplier Comparison for the full side-by-side table.", actions=[{"label": "Open Supplier Comparison", "page": "Supplier Comparison"}],
                   why=parts[0])


def _alternatives(r: dict, rows: Rows) -> dict:
    pool = [x for x in rows if x is not r and x.get("category") == r.get("category")]
    safer = sorted([x for x in pool if _status(x) == "Stable"], key=_rank)[:3]
    if not safer:
        reply = f"There is no Stable supplier in {r.get('category')} to switch {_b(r)} to. The other {_plural(len(pool), 'supplier')} in the category {'is' if len(pool) == 1 else 'are'} also flagged, so mitigation or onboarding someone new may be needed."
        return _answer("alternatives", f"No Stable alternative to {_name(r)}", reply, suppliers=[ref(r)], actions=[{"label": "Open Supplier Onboarding", "page": "Supplier Onboarding"}],
                       follow_ups=[f"Why is {_name(r)} flagged?"])
    parts = [f"In {r.get('category')}, the best-ranked Stable alternatives to {_b(r)} (#{r['rank']}, {_status(r)}, risk {f1(_risk(r))}) are:"]
    for x in safer:
        dscore = (num(x.get("score")) or 0) - (num(r.get("score")) or 0)
        drisk = (_risk(r) or 0) - (_risk(x) or 0)
        parts.append(f"- {_b(x)} (#{x['rank']}): score {f1(x.get('score'))} ({'+' if dscore >= 0 else '−'}{abs(dscore):.1f} vs {_name(r)}), risk {f1(_risk(x))} ({abs(drisk):.1f} points {'lower' if drisk >= 0 else 'higher'}).")
    return _answer("alternatives", f"Alternatives to {_name(r)}", "\n".join(parts), evidence=[f"{_name(x)}: " + _snap(x, DIMS) for x in safer],
                   suppliers=[ref(x) for x in safer], next_step="Compare the shortlisted suppliers before switching.",
                   follow_ups=[f"Compare {_name(r)} with {_name(safer[0])}", f"Compare {_name(safer[0])} and {_name(safer[-1])}"] if len(safer) > 1 else [f"Compare {_name(r)} with {_name(safer[0])}"],
                   actions=[{"label": "Open Supplier Comparison", "page": "Supplier Comparison"}])


def _category(cat: str, rows: Rows) -> dict:
    pool = sorted([r for r in rows if r.get("category") == cat], key=_rank)
    if not pool:
        return _answer("category", f"No suppliers in {cat}", f"I don't see any suppliers in {cat}.")
    avg = sum(num(r.get("score")) or 0 for r in pool) / len(pool)
    flagged = [r for r in pool if _flagged(r)]
    esg = [num(r.get("sustainability_kpi")) for r in pool if num(r.get("sustainability_kpi")) is not None]
    reply = (f"**{cat}** has {len(pool)} suppliers with an average MCDA score of {avg:.1f}. The best is {_b(pool[0])} (#{pool[0]['rank']}, {f1(pool[0].get('score'))}), "
             f"followed by {_join([_b(r) for r in pool[1:3]])}. {_plural(len(flagged), 'supplier')} here {'is' if len(flagged) == 1 else 'are'} flagged on the Risk Radar" +
             (f" ({_join([_name(r) for r in flagged[:3]])})" if flagged else "") + ".")
    if esg:
        reply += f" Average ESG is {sum(esg) / len(esg):.1f}."
    return _answer("category", f"{cat}: {len(pool)} suppliers", reply, evidence=[f"#{r['rank']} {_name(r)}: {f1(r.get('score'))}, {_status(r)}" for r in pool[:5]],
                   suppliers=[ref(r) for r in pool[:5]], follow_ups=[f"I need high quality and low risk in {cat}", f"Compare the top three in {cat}"],
                   next_step=f"Use the Supplier Directory category filter for {cat}.")


def _sustainability(rows: Rows) -> dict:
    pool = [r for r in rows if num(r.get("sustainability_kpi")) is not None]
    if not pool:
        return _answer("sustainability", "No ESG data", "No supplier has an ESG score, so I can't assess sustainability.")
    vals = [num(r["sustainability_kpi"]) for r in pool]
    avg = sum(vals) / len(vals)  # type: ignore[arg-type]
    below = [r for r in pool if num(r["sustainability_kpi"]) < ESG_LINE]  # type: ignore[operator]
    ordered = sorted(pool, key=lambda r: -num(r["sustainability_kpi"]))  # type: ignore[arg-type]
    topten_below = [r for r in below if _rank(r) <= 10]
    compounded = [r for r in below if _flagged(r)]
    reply = (f"Portfolio ESG averages **{avg:.1f}**; {len(below)} of {len(pool)} suppliers score below {ESG_LINE}. Strongest: " +
             _named(ordered[:3], lambda r: f1(r["sustainability_kpi"])) + ". Weakest: " + _named(ordered[::-1][:3], lambda r: f1(r["sustainability_kpi"])) + ".")
    if topten_below:
        reply += f" {_plural(len(topten_below), 'top-10 supplier')} sit below {ESG_LINE} ({_join([_name(r) for r in topten_below[:3]])}), so sustainability is a trade-off there."
    if compounded:
        reply += f" {_join([_b(r) for r in compounded[:3]])} combine low ESG with a risk warning."
    return _answer("sustainability", "Sustainability overview", reply, evidence=[f"{_name(r)}: ESG {f1(r['sustainability_kpi'])}, MCDA #{r['rank']}" for r in ordered[:3] + ordered[::-1][:3]],
                   suppliers=[ref(r) for r in ordered[:3]], follow_ups=["Who is best on sustainability?", "I need strong sustainability and low risk"],
                   actions=[{"label": "Open Sustainability", "page": "Sustainability"}], next_step="Open the Sustainability page for the distribution and category view.")


def _data_quality(rows: Rows) -> dict:
    inc = sorted([r for r in rows if (num(r.get("kpi_completeness_pct")) or 100) < 100], key=lambda r: num(r.get("kpi_completeness_pct")) or 0)
    est = [r for r in rows if r.get("capacity_estimated")]
    reply = (f"{_plural(len(inc), 'supplier')} {'has' if len(inc) == 1 else 'have'} incomplete KPI data" + (" (" + _join([_name(r) + " " + f0(r.get("kpi_completeness_pct")) + "%" for r in inc[:3]]) + ")" if inc else "") +
             f", and {len(est)} {'uses' if len(est) == 1 else 'use'} an estimated capacity. Scores for those suppliers rest on fewer or estimated inputs, so treat them with more caution.")
    return _answer("data_quality", "Data completeness", reply, follow_ups=["Which suppliers need attention?", "Compare the top three suppliers"], suppliers=[ref(r) for r in inc[:5]], actions=[{"label": "Open Data Quality", "page": "Data Quality & Decisions"}],
                   next_step="Open Data Quality & Decisions for the full audit.")


def _dependency(rows: Rows, dep: Optional[dict]) -> dict:
    if not dep or not dep.get("available"):
        return _answer("dependency", "Concentration data unavailable", "I don't have award-concentration data for this dataset.")
    cats = sorted(dep.get("categories", []), key=lambda c: -c["hhi"])
    top = dep.get("top_suppliers", [])
    by_id = {str(r.get("supplier_id")): r for r in rows}
    parts = []
    if cats:
        c = cats[0]
        band = "high" if c["hhi"] >= 2500 else "moderate" if c["hhi"] >= 1500 else "low"
        parts.append(f"**{c['category']}** is the most concentrated category (HHI {c['hhi']}, {band}): {c['top_supplier']} wins {c['top_share_pct']}% of its {c['awards']} awards.")
    if len(top) >= 3:
        s3 = sum(s["share_pct"] for s in top[:3])
        parts.append(f"The top three suppliers hold {s3:.1f}% of all {dep.get('total_awards')} awarded contracts.")
    exposed = [(s, by_id.get(str(s["supplier_id"]))) for s in top]
    exposed = [(s, r) for s, r in exposed if r is not None and _flagged(r)]
    if exposed:
        parts.append("Heavily used and flagged: " + "; ".join(f"{s['name']} ({s['share_pct']}% of awards, {_status(r)})" for s, r in exposed[:3]) + ".")
    ss = dep.get("single_source_categories") or []
    parts.append(f"Single-source sub-categories: {_join(ss)}." if ss else "No sub-category depends on a single supplier.")
    return _answer("dependency", "Award concentration", "\n\n".join(parts), suppliers=[ref(r) for _, r in exposed[:4]],
                   evidence=[f"{c['category']}: HHI {c['hhi']}, top share {c['top_share_pct']}%, {c['suppliers_used']} suppliers" for c in cats[:4]],
                   actions=[{"label": "Open Dependency Analysis", "page": "Dependency Analysis"}], next_step="Open Dependency Analysis for the per-category tables.",
                   follow_ups=["Which of the most-used suppliers are risky?", "Which suppliers need attention?"])


def _trends(tr: Optional[dict]) -> dict:
    if not tr or not tr.get("available") or not tr.get("records"):
        return _answer("trends", "Trend data unavailable", "I don't have award-history trends for this dataset.")
    recs = tr["records"]
    counts = sorted(r["awards"] for r in recs)
    med = (counts[len(counts) // 2] if len(counts) % 2 else (counts[len(counts) // 2 - 1] + counts[len(counts) // 2]) / 2)
    partial = {r["period"] for r in ([recs[0], recs[-1]] if len(recs) >= 3 else []) if r["awards"] < 0.5 * med}
    full = [r for r in recs if r["period"] not in partial]
    parts = []
    if partial:
        parts.append(f"{_join(sorted(partial))} look incomplete ({', '.join(str(next(r['awards'] for r in recs if r['period'] == p)) for p in sorted(partial))} awards vs a typical {med:.0f}), so I leave them out of the direction checks.")
    for key, label, better in (("avg_lead_time", "Lead time", "lower"), ("avg_risk", "Risk at award", "lower"), ("avg_savings", "Savings", "higher")):
        pts = [(r["period"], r.get(key)) for r in full if r.get(key) is not None]
        if len(pts) >= 2:
            (p0, a), (p1, b) = pts[0], pts[-1]
            d = b - a
            pct = abs(d / a * 100) if a else 0
            verdict = "essentially flat" if pct < 3 else ("improved" if (d < 0) == (better == "lower") else "got worse")
            parts.append(f"{label} went from {a:.1f} to {b:.1f} between {p0} and {p1} ({verdict}).")
    if len(full) < 4:
        parts.append(f"With only {len(full)} complete months, treat these directions as indicative, not as a firm trend.")
    return _answer("trends", "Performance trends", "\n\n".join(parts), follow_ups=["Which suppliers need attention?", "How concentrated are our awards?"], evidence=[f"{r['period']}: {r['awards']} awards, lead {r.get('avg_lead_time')}, risk {r.get('avg_risk')}, savings {r.get('avg_savings')}%" for r in recs],
                   actions=[{"label": "Open Performance Trends", "page": "Performance Trends"}], next_step="Open Performance Trends for the monthly table.")


def _recommend(question: str, rows: Rows, scenario_fn: Optional[Callable[[str], dict]], *, whatif: bool = False,
               category: Optional[str] = None, scenario_text: Optional[str] = None) -> dict:
    text = scenario_text or question
    payload = None
    if scenario_fn is not None:
        try:
            payload = scenario_fn(text)
        except Exception:  # engine problem: degrade to the default ranking instead of failing the chat
            payload = None
    if not payload or not payload.get("ranking"):
        ans = _top_list(rows, 3)
        ans["reply"] = "I couldn't run the scenario engine for that, so here is the default ranking instead.\n\n" + ans["reply"]
        return ans
    by_id = {str(r.get("supplier_id")): r for r in rows}
    ranking = [x for x in payload["ranking"] if str(x.get("supplier_id")) in by_id and x.get("scenario_rank") is not None]
    if category:
        ranking = [x for x in ranking if by_id[str(x["supplier_id"])].get("category") == category]
    if not ranking:
        return _top_list(rows, 3)
    weights = {str(k).lower(): float(v) for k, v in (payload.get("weights") or {}).items()}
    emph, mild, relaxed = [], [], []
    for k, v in (payload.get("interpretation") or {}).items():
        if not isinstance(v, dict):
            continue
        d, lvl = str(k).lower(), v.get("priority")
        if lvl in ("positive", "strong_positive"):
            emph.append(d)
        elif lvl == "mild":
            mild.append(d)
        elif v.get("evidence"):
            relaxed.append(d)
    emph.sort(key=lambda d: -weights.get(d, 0))
    bits = []
    if emph:
        bits.append(_join([f"**{LABEL[d]}**" for d in emph]) + (" matter most" if len(emph) > 1 else " matters most"))
    if mild:
        bits.append(_join([LABEL[d].lower() for d in mild]) + " also count")
    if relaxed:
        bits.append(_join([LABEL[d].lower() for d in relaxed]) + " can be relaxed")
    understood = "; ".join(bits)
    top3 = ranking[:3]
    topr = by_id[str(top3[0]["supplier_id"])]
    movement = ""
    if top3[0].get("baseline_rank") is not None and top3[0].get("baseline_rank") != top3[0].get("scenario_rank"):
        movement = f", up from #{top3[0]['baseline_rank']} in the default ranking" if (top3[0]["baseline_rank"] or 0) > (top3[0]["scenario_rank"] or 0) else f", down from #{top3[0]['baseline_rank']} in the default ranking"
    lead = "If that's the case, " if whatif else "Under those priorities, "
    parts = []
    if understood:
        parts.append(("Here's how I read " + ("that scenario" if whatif else "your priorities") + f": {understood}."))
    else:
        parts.append("I didn't detect any specific priority, so the weights stay equal.")
    parts.append(f"{lead}{_b(topr)} comes out on top (score {f1(top3[0].get('scenario_score'))}{movement}). " +
                 ("Next are " + _join([_b(by_id[str(x["supplier_id"])]) + " (" + f1(x.get("scenario_score")) + ")" for x in top3[1:]]) + "." if len(top3) > 1 else ""))
    risk_wanted = "risk" in emph
    sentence = _risk_sentence(topr)
    if risk_wanted:
        stable = [x for x in ranking if _status(by_id[str(x["supplier_id"])]) == "Stable"]
        if stable and str(stable[0]["supplier_id"]) != str(top3[0]["supplier_id"]):
            alt = by_id[str(stable[0]["supplier_id"])]
            sentence += f" Since low risk matters to you, the best-ranked **Stable** option is {_b(alt)} (scenario #{stable[0]['scenario_rank']}, score {f1(stable[0].get('scenario_score'))})."
    parts.append(sentence)
    wk = _weakest(topr)
    if wk and wk[1] < 50:
        parts.append(f"Trade-off: {_name(topr)}'s weakest dimension is {LABEL[wk[0]].lower()} (percentile {wk[1]:.0f}).")
    weight_lines = [f"{LABEL[d]}: {w * 100:.0f}% weight" for d, w in sorted(weights.items(), key=lambda kv: -kv[1]) if d in LABEL]
    snap_dims = emph or ["quality", "reliability", "risk"]
    ev = weight_lines + [f"{_name(by_id[str(x['supplier_id'])])}: " + _snap(by_id[str(x['supplier_id'])], snap_dims) for x in top3]
    sup = [{**ref(by_id[str(x["supplier_id"])]), "rank": x.get("scenario_rank"), "score": x.get("scenario_score")} for x in ranking[:5]]
    return _answer("whatif" if whatif else "recommendation", ("Scenario result: " if whatif else "Best fit for your priorities: ") + _name(topr), "\n\n".join(parts),
                   why=payload.get("explanation") or parts[0], evidence=ev, suppliers=sup, understood=understood, scenario_text=text,
                   next_step=f"Review {_name(topr)}'s profile and risk drivers before awarding. " + _NOTE,
                   follow_ups=[f"Compare these top {min(3, len(top3))}", f"Why is {_name(topr)} first?", "What if cost mattered more?" if "cost" not in emph else "What if risk mattered more?"],
                   actions=[{"label": "Open What-If Scenarios", "page": "What-If Scenarios"}, {"label": f"Open {_name(topr)}", "page": "Supplier Profile", "supplier_id": topr.get("supplier_id")}],
                   engine="Deterministic scenario engine", extra={"weights": weights})


def _from_knowledge(intent: str, k: dict, **extra) -> dict:
    """Wrap a knowledge-layer result in the standard answer shape."""
    ex = {"topic_ids": k.get("topic_ids", [])}
    ex.update(extra.pop("extra", {}) or {})
    return _answer(intent, k["title"], k["reply"], why=k.get("why", ""), evidence=k.get("evidence"), next_step=k.get("next_step", ""),
                   suppliers=[ref(r) for r in k.get("suppliers", [])], follow_ups=k.get("follow_ups"), actions=k.get("actions"), understood=k.get("understood", ""),
                   engine="Local knowledge base + engine data" if intent == "knowledge" else "Deterministic engine outputs", extra=ex)


def _supplier_note(r: dict) -> str:
    wk = _weakest(r)
    txt = f"**About {_name(r)} in your data:** ranked #{r.get('rank')} with MCDA {f1(r.get('score'))}, {_status(r)} on the Risk Radar (risk {f1(_risk(r))})."
    if wk and wk[1] < 50:
        txt += f" Its weakest dimension is {LABEL[wk[0]].lower()} (percentile {wk[1]:.0f})."
    return txt


def _fallback(question: str, rows: Rows) -> dict:
    """Nothing in the router matched. Try the knowledge base loosely, then a way-of-thinking answer, then say what is out of scope."""
    words = question.split()
    if not knowledge.in_domain(question) and len(words) >= 3 and not re.search(r"\b(data|complete|compare|rank\w*|best|top|worst|cheap\w*|safe\w*|them|it|that|those|this|these|score\w*|zzz)\b", question.lower()):
        return _from_knowledge("out_of_scope", knowledge.out_of_scope())
    if knowledge.in_domain(question):
        hits = [h for h in knowledge.retrieve(question, 3) if h[1] >= knowledge.WEAK]
        if hits:
            return _from_knowledge("knowledge", knowledge.answer_topic(question, rows, entries=hits))
        return _from_knowledge("framework", knowledge.framework(question, rows))
    reply = ("I couldn't map that to a specific analysis. I work best with questions about suppliers, risk, sustainability, concentration, trends, data quality, general procurement advice, or with a description of what you need "
             "(for example \"quality and reliability matter most, cost is no issue, risk as low as possible\").")
    return _answer("unknown", "I need a bit more to go on", reply, follow_ups=["Which suppliers need attention?", "I need high quality and the lowest risk", "Compare the top three suppliers", "What can you do?"])


# ------------------------------------------------------------------------------------------- routing ----
def classify(question: str, rows: Rows, state: dict) -> dict:
    """Returns {"intent": ..., plus parameters}. Order matters and is documented inline."""
    q = question.lower().strip()
    words = q.split()
    dims = mentioned_dims(q)
    named = find_suppliers(question, rows)
    cat = find_category(question, rows)

    if re.match(r"^(hi|hello|hey|hiya|good (morning|afternoon|evening)|yo)\b[\s!.,?]*$", q):
        return {"intent": "greeting"}
    if len(words) <= 5 and re.match(r"^(thanks|thank you|thx|ty|great|ok|okay|cool|perfect|nice|awesome)\b", q):
        return {"intent": "thanks"}
    if re.search(r"\b(who are you|what are you|are you (an? )?(ai|bot|human|gemini|chatgpt|robot)|your name|who made you|who built you)\b", q):
        return {"intent": "about"}
    if re.search(r"\b(what can you do|what do you do|how do you work|what do you know|your capabilit\w+)\b", q) or (len(words) <= 3 and re.match(r"^(help|help me|\?)$", q)):
        return {"intent": "help"}

    # ---- general knowledge: advice, whys, hows, definitions, "what should a big business look for", portfolio suggestions ----
    if state.get("topics") and state["intent"] == "knowledge":
        kf = knowledge.followup(question, state["topics"])
        if kf:
            return {"intent": "knowledge_follow", **kf}
    kb = knowledge.route(question, rows, len(named))
    scenario_cue = re.search(r"\b(what if|suppose|assuming|imagine|if we|if i|instead of)\b", q)
    if knowledge.wants_suggestions(question) and not named and (kb is None or kb["conf"] < 3.5):
        return {"intent": "suggestions"}
    if kb and kb["strong"] and not (scenario_cue and dims) and (not named or kb["conf"] >= 2.5):
        return {"intent": "knowledge", "hits": kb["hits"], "named": named[:1]}

    pron = _pronoun_targets(q, state, rows) if len(words) <= 12 and not named else []
    # explicit scenario wording ("what if…") is always the scenario engine, optionally continuing the previous scenario
    if re.search(WHATIF_CUES, q) and (dims or state["scenario_text"]):
        text = question
        if state["scenario_text"] and re.match(r"^(and|also|but|now|then|actually|what about)\b", q) or (state["scenario_text"] and len(words) <= 8 and dims and re.search(r"\b(more|less|also|too)\b", q)):
            text = state["scenario_text"].rstrip(". ") + ". " + question
        return {"intent": "whatif", "text": text, "category": cat}

    if re.search(r"\b(alternatives?|replace\w*|switch(?:ing)? (?:from|away)|substitute|safer option|instead of)\b", q) and (named or pron):
        return {"intent": "alternatives", "target": (named or pron)[0]}
    if len(named) >= 2 or (re.search(r"\b(compare|versus|vs\.?|difference between|which is better|head to head)\b", q) and (named or pron)):
        rs = named if len(named) >= 2 else (pron if len(pron) >= 2 else named + [r for r in pron if r not in named])
        if not named and re.search(r"\btop\b", q) and len(pron) >= 2:  # "compare these top 3" = the first 3 of the previous answer
            rs = pron[:_top_n(q, len(pron))]
        if len(rs) >= 2:
            return {"intent": "compare", "targets": rs, "from_scenario": not named and state["intent"] in ("recommendation", "whatif")}
    if re.search(r"\bcompare\b", q) and re.search(r"\btop\b", q):
        return {"intent": "compare_top", "n": _top_n(q)}
    if re.search(r"\bcompare\b", q) and cat:
        return {"intent": "compare_category", "category": cat, "n": _top_n(q)}
    if len(named) == 1:
        return {"intent": "profile", "target": named[0]}
    if pron and re.search(r"\b(why|explain|tell me more|details?|more about|how|what about|risk\w*|strengths?|weakness\w*)\b", q):
        return {"intent": "profile", "target": pron[0]}
    if pron and len(pron) >= 2 and re.search(r"\b(compare|difference|better|best|which)\b", q):
        return {"intent": "compare", "targets": pron}

    # requirements / preferences => recommendation (this is what the old router got wrong)
    need = re.search(NEED_CUES, q) is not None
    superlative = re.search(r"\b(best|top|most|highest|lowest|cheapest|safest|fastest|strongest|weakest|worst|biggest|least|leading)\b", q) is not None
    asks_list = re.search(r"\b(which|who|list|show|name|any|are there)\b", q) is not None
    state_only_risk = dims == ["risk"] or not dims
    if len(dims) >= 2 and not (superlative and asks_list and not need):
        return {"intent": "recommend", "text": question, "category": cat}
    if len(dims) == 1 and need and not (state_only_risk and re.search(r"\b(attention|critical|watch|flagged|at risk|risky)\b", q)) and not asks_list:
        return {"intent": "recommend", "text": question, "category": cat}

    if re.search(r"\b(attention|critical|watch|flagged|at risk|risky|concern\w*|warning|problem suppliers?|early warning|worst risk|highest risk|most risk\w*)\b", q) and "risk" in (dims or ["risk"]):
        return {"intent": "risk_list"}
    if re.search(r"\b(lowest|least|safest|minimal|minimum|smallest)\b.*\brisk\w*\b|\b(safest|low[- ]risk)\b", q):
        return {"intent": "lowest_risk"}
    if len(dims) == 1 and superlative:
        worst = re.search(r"\b(worst|weakest|lowest|least|poorest|bottom)\b", q) is not None and dims[0] != "cost" and dims[0] != "risk"
        if dims[0] == "cost" and re.search(r"\b(cheap\w*|lowest|least|best)\b", q):
            worst = False
        if dims[0] == "cost" and re.search(r"\b(expensive|highest|most|priciest)\b", q):
            worst = True
        if dims[0] == "risk":
            return {"intent": "risk_list" if re.search(r"\b(highest|most|worst|biggest)\b", q) else "lowest_risk"}
        return {"intent": "leaders", "dim": dims[0], "worst": worst}

    if re.search(r"\b(esg|sustainab\w*|green)\b", q):
        return {"intent": "sustainability"}
    if re.search(r"\b(concentrat\w*|dependen\w*|single[- ]source|hhi|over-?reliant|award share|market share|diversif\w*)\b", q):
        return {"intent": "dependency"}
    if re.search(r"\b(trend\w*|over time|monthly|savings|history|historical|award history|getting better|getting worse)\b", q):
        return {"intent": "trends"}
    if re.search(r"\b(data quality|completeness|missing data|incomplete|data gaps?|estimated)\b", q):
        return {"intent": "data_quality"}
    if kb and not named and kb["conf"] >= knowledge.WEAK and knowledge.detect_style(question) in ("why", "how", "define", "should", "pitfalls", "compare", "advice"):
        return {"intent": "knowledge", "hits": kb["hits"], "named": []}
    if cat and not re.search(r"\b(compare)\b", q):
        return {"intent": "category", "category": cat}
    if re.search(r"\b(how many|number of|count of)\b.*\b(suppliers?|vendors?)\b", q) or re.search(r"\b(portfolio|overview|summary|summari[sz]e|snapshot)\b", q):
        return {"intent": "portfolio"}
    if re.search(r"\b(best|top|recommend\w*|ideal|should (?:we|i) (?:choose|pick|select|use)|which supplier|who should)\b", q):
        return {"intent": "top", "n": _top_n(q)}
    if len(dims) == 1:
        return {"intent": "leaders", "dim": dims[0], "worst": False} if dims[0] != "risk" else {"intent": "risk_list"}
    return {"intent": "unknown"}


def _lazy(extras: dict, key: str) -> Optional[dict]:
    """extras values may be callables so the (CSV-reading) dependency / trends payloads are only built when needed."""
    v = extras.get(key)
    if callable(v):
        try:
            return v()
        except Exception:
            return None
    return v


def answer(question: str, rows: Rows, *, scenario_fn: Optional[Callable[[str], dict]] = None, history: Any = None,
           extras: Optional[dict] = None) -> dict:
    """Main entry point. `rows` are the /api/portfolio supplier dicts, `scenario_fn(text)` returns the scenario payload."""
    question = str(question or "").strip()[:600]
    extras = extras or {}
    hist = clean_history(history)
    state = _state(hist)
    if not question:
        return _help(rows)
    if not rows:
        kb = knowledge.route(question, [], 0)
        if kb and kb["strong"]:   # general guidance does not need the supplier data
            return _from_knowledge("knowledge", knowledge.answer_topic(question, [], entries=kb["hits"]))
        return _answer("unknown", "No data", "The supplier data isn't available yet.")
    r = classify(question, rows, state)
    it = r["intent"]
    if it == "knowledge":
        k = knowledge.answer_topic(question, rows, entries=r["hits"], extras=extras)
        if r.get("named"):
            k["reply"] += "\n\n" + _supplier_note(r["named"][0])
            k["suppliers"] = [r["named"][0]] + [x for x in k.get("suppliers", []) if x is not r["named"][0]]
        return _from_knowledge("knowledge", k)
    if it == "knowledge_follow":
        entries = [(knowledge.BY_ID[i], 1.0) for i in r["topic_ids"] if i in knowledge.BY_ID]
        return _from_knowledge("knowledge", knowledge.answer_topic(question, rows, entries=entries, extras=extras, mode=r["mode"],
                                                                   style=knowledge.detect_style(question) if r["mode"] == "overview" else None,
                                                                   audience=r.get("audience"), sector=r.get("sector")))
    if it == "suggestions":
        return _from_knowledge("suggestions", knowledge.suggestions(rows, extras))
    if it == "greeting":
        return _greeting(rows)
    if it == "thanks":
        return _thanks()
    if it == "about":
        return _answer("about", "About the advisor", "I'm the Vendor360 advisor. I answer from your supplier data (scores, risk, ESG, concentration, trends) and from a built-in procurement knowledge base, "
                       "so I can also give general advice such as what to look for in a supplier, how to negotiate or why dual sourcing matters. "
                       "I run locally and don't need an external model; Gemini is an optional extra for longer written analysis.",
                       follow_ups=["What can you do?", "What do you suggest we focus on?", "What should a big business look for in a supplier?"])
    if it == "help":
        return _help(rows)
    if it == "whatif":
        return _recommend(question, rows, scenario_fn, whatif=True, category=r.get("category"), scenario_text=r.get("text"))
    if it == "recommend":
        return _recommend(question, rows, scenario_fn, category=r.get("category"), scenario_text=r.get("text"))
    if it == "alternatives":
        return _alternatives(r["target"], rows)
    if it == "compare":
        return _compare(r["targets"], rows, from_scenario=bool(r.get("from_scenario")))
    if it == "compare_top":
        return _compare(sorted(rows, key=_rank)[:r["n"]], rows, title=f"Comparing the top {r['n']} suppliers")
    if it == "compare_category":
        pool = sorted([x for x in rows if x.get("category") == r["category"]], key=_rank)[:r["n"]]
        return _compare(pool, rows, title=f"Comparing the top {len(pool)} in {r['category']}") if len(pool) >= 2 else _category(r["category"], rows)
    if it == "profile":
        return _profile(r["target"], question, rows)
    if it == "risk_list":
        return _risk_list(rows, question)
    if it == "lowest_risk":
        return _lowest_risk(rows)
    if it == "leaders":
        return _leaders(rows, r["dim"], r["worst"])
    if it == "sustainability":
        return _sustainability(rows)
    if it == "dependency":
        return _dependency(rows, _lazy(extras, "dependency"))
    if it == "trends":
        return _trends(_lazy(extras, "trends"))
    if it == "data_quality":
        return _data_quality(rows)
    if it == "category":
        return _category(r["category"], rows)
    if it == "portfolio":
        return _portfolio_summary(rows)
    if it == "top":
        return _top_list(rows, r.get("n", 3))
    return _fallback(question, rows)
