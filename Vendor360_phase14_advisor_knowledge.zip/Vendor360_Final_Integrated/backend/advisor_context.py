"""Builds the verified data context that Gemini may talk about.

Before this module Gemini only saw name / rank / score / risk for each supplier, so it truthfully answered
"the data does not provide cost, quality, reliability or sustainability scores". It now sees every dimension for
every supplier, category and country summaries, per-dimension leaders, award concentration and monthly trends,
plus a glossary that explains what each number means. All values are engine outputs; nothing is computed by
Gemini. Pure python (no FastAPI/pandas) so it is unit-testable.
"""
from __future__ import annotations

from typing import Any, Iterable, Optional

from .advisor_core import DIMS, ESG_LINE, goodness, num

GLOSSARY = {
    "mcda_score": "Overall recommendation score 0-100 (higher is better) from the engine's default equal-weight MCDA; mcda_rank 1 is best.",
    "percentiles": "cost, quality, reliability, sustainability and capacity are portfolio percentiles 0-100 where 100 is always best "
                   "(cost 100 = cheapest, reliability 100 = shortest lead time).",
    "risk_score": "Operational risk from the Risk Radar, 0-100, LOWER is better. Statuses from worst to best: Critical, Emerging Risk, Watch, Stable.",
    "raw": "Source units: price_percentile (0 = cheapest), quality_score, lead_time_days, esg_score (0-100), capacity_units_per_month "
           "(capacity_estimated=true means the source held a placeholder and the engine used an estimate).",
    "esg_review_line": f"The app flags ESG below {ESG_LINE} for review.",
    "hhi": "Herfindahl-Hirschman index of award shares within a category: 2500+ highly concentrated, 1500-2500 moderate, below 1500 low.",
    "risk_vs_mcda": "Risk Radar (operational exposure) and the MCDA recommendation are separate; a high-ranked supplier can still carry a risk warning.",
}


def _r1(v: Any) -> Optional[float]:
    x = num(v)
    return None if x is None else round(x, 1)


def _split(v: Any) -> list[str]:
    return [x.strip() for x in str(v or "").split(";") if x.strip()]


def supplier_record(r: dict, *, detailed: bool = False) -> dict:
    out = {
        "id": r.get("supplier_id"), "name": r.get("supplier_name"), "category": r.get("category"), "country": r.get("country_hq"),
        "mcda_rank": r.get("rank"), "mcda_score": _r1(r.get("score")),
        "risk_score": _r1(r.get("risk_radar_score")), "risk_status": r.get("risk_radar_status"),
        "risk_flags": _split(r.get("risk_radar_flags")),
        "percentiles": {d: _r1(r.get(f"{d}_score")) for d in DIMS if d != "risk"},
        "raw": {"price_percentile": _r1(r.get("cost_kpi")), "quality_score": _r1(r.get("quality_kpi")),
                "lead_time_days": _r1(r.get("reliability_kpi")), "esg_score": _r1(r.get("sustainability_kpi")),
                "capacity_units_per_month": _r1(r.get("capacity_kpi")), "capacity_estimated": bool(r.get("capacity_estimated"))},
        "strengths": _split(r.get("positive_contributors"))[:3], "concerns": _split(r.get("negative_contributors"))[:3],
        "kpi_completeness_pct": _r1(r.get("kpi_completeness_pct")),
    }
    l2 = [x.strip() for x in str(r.get("category_l2_list") or "").replace("|", ",").replace(";", ",").split(",") if x.strip()]
    if l2:
        out["sub_categories"] = l2[:6]
    if detailed:
        out.update(decision_position=r.get("decision_position"), decision_explanation=r.get("decision_explanation"),
                   risk_explanation=r.get("risk_explanation"), recommended_action=r.get("recommended_action"), risk_action=r.get("risk_radar_action"))
    return out


def _leaders(rows: list[dict], n: int = 5) -> dict:
    out = {}
    for d in DIMS:
        pool = [r for r in rows if goodness(r, d) is not None]
        pool.sort(key=lambda r: goodness(r, d), reverse=True)  # type: ignore[arg-type,return-value]
        val = (lambda r: _r1(r.get("risk_radar_score"))) if d == "risk" else (lambda r, d=d: _r1(r.get(f"{d}_score")))
        out[d] = {"metric": "risk_score (lower is better)" if d == "risk" else f"{d} percentile (100 = best)",
                  "best": [{"name": r.get("supplier_name"), "value": val(r)} for r in pool[:n]],
                  "worst": [{"name": r.get("supplier_name"), "value": val(r)} for r in pool[::-1][:n]]}
    return out


def _by_category(rows: list[dict]) -> list[dict]:
    cats: dict[str, list[dict]] = {}
    for r in rows:
        cats.setdefault(str(r.get("category") or "Unclassified"), []).append(r)
    out = []
    for c, rs in sorted(cats.items()):
        def avg(key: str) -> Optional[float]:
            xs = [num(r.get(key)) for r in rs if num(r.get(key)) is not None]
            return round(sum(xs) / len(xs), 1) if xs else None  # type: ignore[arg-type]
        best = sorted(rs, key=lambda r: num(r.get("rank")) or 1e9)[0]
        out.append({"category": c, "suppliers": len(rs), "avg_mcda_score": avg("score"), "avg_risk_score": avg("risk_radar_score"),
                    "avg_esg_score": avg("sustainability_kpi"), "flagged_suppliers": sum(1 for r in rs if r.get("risk_radar_status") in ("Critical", "Emerging Risk", "Watch")),
                    "best_ranked": best.get("supplier_name")})
    return out


def _trends(tr: Optional[dict]) -> Optional[dict]:
    if not tr or not tr.get("available"):
        return None
    recs = tr.get("records") or []
    counts = sorted(r["awards"] for r in recs)
    med = (counts[len(counts) // 2] if len(counts) % 2 else (counts[len(counts) // 2 - 1] + counts[len(counts) // 2]) / 2) if counts else 0
    partial = [r["period"] for r in ([recs[0], recs[-1]] if len(recs) >= 3 else []) if r["awards"] < 0.5 * med]
    return {"basis": tr.get("basis"), "months": [{"period": r["period"], "awards": r["awards"], "avg_lead_time_days": r.get("avg_lead_time"),
                                                   "avg_risk_at_award": r.get("avg_risk"), "avg_savings_pct": r.get("avg_savings")} for r in recs],
            "months_likely_incomplete": partial, "note": "Months with under half the typical award count are likely incomplete; do not read them as declines."}


def _dependency(dep: Optional[dict]) -> Optional[dict]:
    if not dep or not dep.get("available"):
        return None
    return {"total_awards": dep.get("total_awards"), "categories": dep.get("categories"),
            "top_suppliers_by_awards": [{"name": s.get("name"), "awards": s.get("awards"), "share_pct": s.get("share_pct"), "categories": s.get("categories")}
                                        for s in (dep.get("top_suppliers") or [])[:10]],
            "single_source_sub_categories": dep.get("single_source_categories") or [], "basis": dep.get("basis")}


def build_context(rows: list[dict], *, dependency: Optional[dict] = None, trends: Optional[dict] = None,
                  focus_ids: Iterable[Any] = ()) -> dict:
    focus = {str(i) for i in focus_ids}
    counts: dict[str, int] = {}
    for r in rows:
        counts[str(r.get("risk_radar_status"))] = counts.get(str(r.get("risk_radar_status")), 0) + 1

    def mean(key: str) -> Optional[float]:
        xs = [num(r.get(key)) for r in rows if num(r.get(key)) is not None]
        return round(sum(xs) / len(xs), 1) if xs else None  # type: ignore[arg-type]

    ctx: dict = {
        "glossary": GLOSSARY,
        "portfolio": {"supplier_count": len(rows), "risk_status_counts": counts, "average_mcda_score": mean("score"),
                      "average_risk_score": mean("risk_radar_score"), "average_esg_score": mean("sustainability_kpi"),
                      "suppliers_below_esg_review_line": sum(1 for r in rows if (num(r.get("sustainability_kpi")) or 1e9) < ESG_LINE),
                      "suppliers_with_incomplete_kpi_data": sum(1 for r in rows if (num(r.get("kpi_completeness_pct")) or 100) < 100)},
        "categories": _by_category(rows),
        "leaders_by_dimension": _leaders(rows),
        "suppliers": [supplier_record(r, detailed=str(r.get("supplier_id")) in focus) for r in rows],
    }
    # Why-text for everyone who is flagged, so Gemini can explain a warning without being handed the whole table.
    ctx["risk_explanations"] = [{"name": r.get("supplier_name"), "status": r.get("risk_radar_status"), "why": r.get("risk_explanation")}
                                for r in sorted(rows, key=lambda r: -(num(r.get("risk_radar_score")) or 0)) if r.get("risk_radar_status") in ("Critical", "Emerging Risk")][:6]
    d, t = _dependency(dependency), _trends(trends)
    if d:
        ctx["award_concentration"] = d
    if t:
        ctx["award_trends"] = t
    return ctx
