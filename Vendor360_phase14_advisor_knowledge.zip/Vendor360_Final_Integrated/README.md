# Vendor360 — Supplier Decision Intelligence

React UI -> FastAPI -> deterministic Python engine -> source datasets.
The engine is the only source of scores; the UI never computes or invents them. Gemini is **optional** and is never
called at startup, on page load, in tests or in the pipeline.

## Run in Colab (the supported way)
1. Upload `Vendor360_FINAL_FIGMA_INTEGRATED*.zip` to `/content` (or let the notebook ask for it).
2. Open `Vendor360_Final_Colab.ipynb` and run the cells top to bottom. The launcher:
   - reads the datasets from `<project>/data` and writes generated files to `/content/vendor360_work`,
   - starts the API on `127.0.0.1:8000` and waits until `GET /api/health` says `ready` (~15 s),
   - builds the frontend (`npm ci && npm run build`) and serves it on port 5173 (Vite preview server),
   - prints the Colab proxy URL.

Or from a terminal: `pip install -r requirements.txt && python launch_colab.py` (needs Node 18+).

## Settings (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `VENDOR360_INPUT_DIR` | `<project>/data` via the launcher; otherwise = `VENDOR360_WORKDIR` | where the 4 source datasets are read from |
| `VENDOR360_WORKDIR` | `/content/vendor360_work` via the launcher; `/content` if unset | where generated `Vendor360_*` files are written |
| `VENDOR360_CORS_ORIGINS` | localhost:5173/8000 | comma-separated allowed origins (the UI uses the same-origin `/api` proxy, so none are normally needed) |
| `VENDOR360_CONFIG_DIR` | `<project>/config` | location of `fx_rates.json` |

Only files whose names start with `Vendor360_` are ever deleted from the work folder at startup, and ingestion ignores such
files, so a restart gives the same result.

## Configuration
`config/fx_rates.json` holds the INR conversion rates. **They are indicative placeholder values, not a live feed**; replace them
before presenting money figures.

## Security notes
- The API binds to `127.0.0.1` only; browsers reach it through the frontend's `/api` proxy.
- The Vite server binds `0.0.0.0` with `allowedHosts: true` so Colab's proxy hostnames work. Anyone who can reach that port can
  use the app (it has no login). Use it only for Colab sessions / trusted networks. It is a preview server, not production hosting.

## Layout
- `backend/modules/*.py` — notebook-derived analysis stages. `backend/pipeline.py` executes them with `exec` in **one shared
  namespace** (they share DataFrames across stages); this means `os.chdir` and `sys.path` changes are process-wide.
- `backend/vendor360_engine/` — scenario / MCDA / advisor engine.
- `backend/advisor_core.py`, `backend/advisor_context.py` — conversational advisor and the verified data context given to Gemini (see PHASE8_ADVISOR_CHANGES.md).
- `backend/api.py` — FastAPI endpoints. `frontend/` — React UI. `tests/` — pytest suites.
- `reference/` — the source notebook (outputs cleared); not used at runtime.

Docker is not supported (Colab-only decision).
