"""On-demand Gemini tests. No network and no real key: the model call is replaced by a fake.
Run: VENDOR360_WORKDIR=/content/v360_test pytest tests/test_gemini.py"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
from backend import gemini_client as gc
from test_phase1 import client


@pytest.fixture(autouse=True)
def _no_real_key(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_MODEL", raising=False)


# ---------------------------------------------------------------- helper (pure) ----
def test_no_key_means_no_call(monkeypatch):
    monkeypatch.setattr(gc, "_call_model", lambda p: pytest.fail("must not call Gemini without a key"))
    r = gc.generate("x", {})
    assert r["success"] is False and "GEMINI_API_KEY" in r["failure_reason"]


def test_success_parses_json_and_flags_unmatched_numbers(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "k-test")
    monkeypatch.setattr(gc, "_call_model", lambda p: '```json\n{"headline": "Score 84.2 and 77.7", "key_findings": ["x"]}\n```')
    r = gc.generate("x", {"s": 84.2})
    assert r["success"] and r["unverified_numbers"] == ["77.7"]


def test_rounding_to_displayed_precision_is_accepted():
    assert gc.unverified_numbers("cost about 62,280 and 41.0", {"c": 62279.8, "r": 41.04}) == []


def test_error_text_never_contains_the_key(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "super-secret-key")
    def boom(p): raise RuntimeError("request failed for key super-secret-key")
    monkeypatch.setattr(gc, "_call_model", boom)
    r = gc.generate("x", {})
    assert not r["success"] and "super-secret-key" not in json.dumps(gc.public_meta(r))


def test_non_json_output_is_a_clean_failure(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "k-test")
    monkeypatch.setattr(gc, "_call_model", lambda p: "sorry, no json here")
    assert gc.generate("x", {})["success"] is False


def test_question_is_length_limited_and_fenced():
    p = gc.build_advisor_prompt("q" * 5000, {}, {})
    assert "<question>" in p and len(p) < 3000


# --------------------------------------------------------------------- API ----
def test_status_never_returns_the_key(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "super-secret-key")
    with client() as c:
        body = c.get("/api/gemini/status").json()
    assert body["configured"] is True and "super-secret-key" not in json.dumps(body)


def test_advisor_default_is_unchanged_and_does_not_call_gemini(monkeypatch):
    monkeypatch.setattr(gc, "_call_model", lambda p: pytest.fail("Gemini must be on demand only"))
    with client() as c:
        r = c.post("/api/advisor", json={"question": "Which suppliers require attention?"}).json()
    assert "gemini" not in r and r["title"]


def test_advisor_with_gemini_but_no_key_falls_back_to_engine_answer():
    with client() as c:
        r = c.post("/api/advisor", json={"question": "Compare the top three suppliers", "use_gemini": True})
    assert r.status_code == 200
    body = r.json()
    assert body["ai"] is None and body["gemini"]["success"] is False and body["title"]


def test_advisor_with_gemini_adds_explanation(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "k-test")
    monkeypatch.setattr(gc, "_call_model", lambda p: json.dumps({"explanation": "The top supplier leads on score.", "caveats": []}))
    with client() as c:
        body = c.post("/api/advisor", json={"question": "Compare the top three suppliers", "use_gemini": True}).json()
    assert body["ai"]["explanation"] and body["gemini"]["success"] and body["suppliers"]


def test_insights_on_demand_success_and_fallback(monkeypatch):
    with client() as c:
        off = c.post("/api/insights/gemini").json()
        assert off["insights"] is None and off["gemini"]["success"] is False
        monkeypatch.setenv("GEMINI_API_KEY", "k-test")
        monkeypatch.setattr(gc, "_call_model", lambda p: json.dumps(
            {"headline": "h", "key_findings": ["a"], "risks": ["b"], "recommendations": ["c"], "confidence_note": "n"}))
        on = c.post("/api/insights/gemini").json()
    assert on["insights"]["headline"] == "h" and on["supplier_count"] > 0


def test_prompt_contains_only_engine_values(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "k-test")
    seen = {}
    def fake(p):
        seen["p"] = p
        return json.dumps({"headline": "h"})
    monkeypatch.setattr(gc, "_call_model", fake)
    with client() as c:
        rows = c.get("/api/portfolio").json()["suppliers"]
        c.post("/api/insights/gemini")
    assert rows[0]["supplier_name"] in seen["p"] and "k-test" not in seen["p"]
