"""Tests for the advisor's local knowledge layer (general questions, whys, advice, portfolio suggestions).
    python tests/test_advisor_knowledge.py       (plain runner, no pytest, FastAPI or data files needed)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from backend import advisor_core as ac
from backend import advisor_knowledge as kn
from test_advisor_core import ROWS, ask, scenario


def hist_from(a, q="x"):
    return [{"role": "user", "content": q}, {"role": "assistant", "content": a["reply"], "supplier_ids": [s["supplier_id"] for s in a["suppliers"]],
                                              "intent": a["intent"], "scenario_text": a.get("scenario_text", ""), "topic_ids": a.get("topic_ids", [])}]


# ------------------------------------------------------------------------------ knowledge base ----
def test_kb_is_consistent():
    ids = [e["id"] for e in kn.ENTRIES]
    assert len(ids) == len(set(ids)) >= 55
    for e in kn.ENTRIES:
        assert e["title"] and e["summary"] and e["points"] and e["keywords"], e["id"]
        for r in e.get("related", []):
            assert r in kn.BY_ID, (e["id"], r)
        if e.get("hook"):
            assert e["hook"] in kn.HOOKS, (e["id"], e["hook"])
        for a in (e.get("audience") or {}):
            assert a in kn.AUDIENCE_LABEL, (e["id"], a)
        for s in (e.get("sector") or {}):
            assert s in kn.SECTOR_LABEL, (e["id"], s)
        for text in [e["summary"]] + [t for _, t in e["points"]]:
            assert "*" not in text, (e["id"], "markdown the UI cannot render")


EXPECT = {
    "What key features should a big business seek in a supplier?": "selection_criteria",
    "How do I choose a good supplier?": "selection_criteria",
    "Is the cheapest supplier the best?": "tco",
    "Why is dual sourcing important?": "dual_sourcing",
    "How should I negotiate with a supplier?": "negotiation",
    "What is the difference between an RFP and an RFQ?": "rfx",
    "Should we consolidate our suppliers?": "supplier_consolidation",
    "What should an SLA include?": "contracts_slas",
    "How do I reduce supplier risk?": "risk_mitigation",
    "Why does supplier concentration matter?": "supplier_concentration",
    "What are the warning signs a supplier is in trouble?": "red_flags",
    "What should I look for in a cloud provider?": "sector_it",
    "How does Vendor360 calculate the score?": "app_mcda",
    "Why can a top-ranked supplier still be high risk?": "mcda_vs_risk",
    "What does the Risk Radar status mean?": "app_risk_radar",
    "Is quality or cost more important when selecting suppliers?": "cost_vs_quality",
    "How do I handle price inflation from suppliers?": "inflation_fx",
    "What do I do if a key supplier goes bankrupt?": "business_continuity",
    "What ESG criteria should I use for suppliers?": "esg_sustainability",
    "Should I outsource or keep it in-house?": "make_or_buy",
    "What is vendor lock-in?": "lock_in",
    "How often should I review supplier performance?": "performance_reviews",
    "What are the best practices in procurement?": "best_practices",
    "How do I make sure a supplier delivers on time?": "lead_time_reliability",
    "how do I tell if a supplier is financially stable": "financial_stability",
    "Why do rankings change when I change priorities?": "why_ranking_changes",
    "What payment terms should I offer suppliers?": "payment_terms",
    "How do I make my supply chain resilient?": "risk_mitigation",
    "Is local sourcing better than offshore?": "local_vs_global",
    "What should I do about a supplier flagged Critical?": "critical_playbook",
}


def test_general_questions_are_answered_from_the_knowledge_base():
    bad = []
    for q, want in EXPECT.items():
        a = ask(q)
        got = (a.get("topic_ids") or [None])[0]
        if a["intent"] != "knowledge" or got != want:
            bad.append((q, a["intent"], got, want))
    assert not bad, bad


def test_the_example_question_gets_a_real_answer_for_a_large_buyer():
    a = ask("What key features should a big business seek in a supplier?")
    r = a["reply"]
    assert a["intent"] == "knowledge" and len(r) > 600
    assert "Compliance and audit readiness" in r and "large business" in r          # tailored to a big business
    assert "Financial stability" in r and "Total cost" in r
    assert "In your portfolio" in r                                                  # tied back to the data
    assert "5 of your 12" in r or "of your 12 suppliers" in r
    assert a["follow_ups"] and a["understood"].startswith("advice for")


def test_audience_and_sector_tailoring():
    assert kn.detect_audience("what should a startup look for") == "startup"
    assert kn.detect_audience("what should a small business check") == "sme"
    assert kn.detect_audience("what do large companies need") == "enterprise"
    assert kn.detect_audience("should I choose a large or a small supplier?") is None   # about suppliers, not the buyer
    assert kn.detect_sector("what should I check in a cloud provider") == "it"
    assert kn.detect_sector("should we keep it?") is None                              # pronoun "it" is not IT
    a = ask("What should a startup look for in a supplier?")
    assert "Survivability" in a["reply"] and "Compliance and audit readiness" not in a["reply"]


def test_question_style_changes_the_shape_of_the_answer():
    why = ask("Why is dual sourcing important?")["reply"]
    how = ask("How do I choose a supplier step by step?")["reply"]
    sh = ask("Should we consolidate our suppliers?")["reply"]
    assert "What drives it" in why
    assert "Step 1." in ask("How should I negotiate with a supplier?")["reply"]
    assert "It makes sense when" in sh and "Be careful when" in sh
    assert why != how


def test_two_concepts_side_by_side():
    a = ask("dual sourcing vs single sourcing")
    assert a["intent"] == "knowledge" and set(a["topic_ids"][:2]) == {"dual_sourcing", "single_source"}
    assert "Pros:" in a["reply"] and "Single-source dependency" in a["reply"]


# ------------------------------------------------------------------------------------ follow-ups ----
def test_follow_ups_continue_the_same_topic():
    a = ask("What key features should a big business seek in a supplier?")
    h = hist_from(a)
    more = ask("Tell me more", history=h)
    assert more["intent"] == "knowledge" and more["topic_ids"][0] == "selection_criteria" and "Common mistakes" in more["reply"]
    small = ask("What about for a small business?", history=h)
    assert small["topic_ids"][0] == "selection_criteria" and "small or mid-sized" in small["reply"]
    mis = ask("what mistakes should I avoid?", history=h)
    assert mis["topic_ids"][0] == "selection_criteria" and "Choosing on price alone" in mis["reply"]
    eg = ask("give me an example", history=hist_from(ask("What is total cost of ownership?")))
    assert "Example" in eg["reply"]
    br = ask("explain it simply", history=h)
    assert len(br["reply"]) < len(a["reply"])


def test_a_new_topic_is_not_swallowed_by_a_follow_up():
    h = hist_from(ask("What key features should a big business seek in a supplier?"))
    b = ask("How should I negotiate with a supplier?", history=h)
    assert b["topic_ids"][0] == "negotiation"


def test_garbage_topic_ids_in_history_are_harmless():
    h = [{"role": "assistant", "content": "x", "intent": "knowledge", "topic_ids": ["nope", 5, {"a": 1}]}, {"role": "user", "content": "y", "topic_ids": "zzz"}]
    assert ask("Tell me more", history=h)["reply"]
    assert ac.clean_history([{"role": "assistant", "content": "x", "topic_ids": "abc"}])[0]["topic_ids"] == []


# --------------------------------------------------------------------------- data stays data ----
DATA_QUESTIONS = {
    "Which suppliers need attention?": "risk_list", "Who is the cheapest supplier?": "leaders", "Who has the lowest risk?": "lowest_risk",
    "How concentrated are our awards?": "dependency", "Compare the top three suppliers": "compare", "How is IT doing?": "category",
    "Tell me about Delta Devices": "profile", "Why is Atlas Cloud ranked first?": "profile", "Which suppliers have incomplete data?": "data_quality",
    "I need top quality and reliability, cost is no issue, and risk as low as possible": "recommendation", "What if cost mattered more?": "whatif",
    "What if quality mattered more than cost?": "whatif", "overview of the portfolio": "portfolio", "which supplier should we choose?": "top",
    "How many suppliers do we have?": "portfolio", "Who is best on sustainability?": "leaders",
}


def test_questions_about_the_data_still_go_to_the_engine():
    bad = []
    for q, want in DATA_QUESTIONS.items():
        got = ask(q)["intent"]
        if got != want:
            bad.append((q, got, want))
    assert not bad, bad


def test_named_supplier_with_advice_gets_both():
    a = ask("Should we worry about vendor lock-in with Atlas Cloud?")
    assert a["intent"] == "knowledge" and a["topic_ids"][0] == "lock_in" and "About Atlas Cloud in your data" in a["reply"]
    assert a["suppliers"][0]["supplier_name"] == "Atlas Cloud"


# ------------------------------------------------------------------------------ suggestions ----
def test_portfolio_suggestions_are_prioritised_and_grounded():
    a = ask("What do you suggest we focus on?")
    assert a["intent"] == "suggestions"
    r = a["reply"]
    assert r.index("Critical or Emerging Risk") < r.index("backup")           # risk first
    names = {x["supplier_name"] for x in a["suppliers"]}
    assert "Delta Devices" in names and a["actions"] and len({x["label"] for x in a["actions"]}) == len(a["actions"])
    for q in ("How can we improve our supplier portfolio?", "What are the biggest weaknesses in our supply base?", "any recommendations for us?"):
        assert ask(q)["intent"] == "suggestions", q


def test_suggestions_when_everything_is_healthy():
    healthy = [dict(r, risk_radar_status="Stable", risk_radar_score=10, kpi_completeness_pct=100, capacity_estimated=False, sustainability_kpi=90, quality_score=80, reliability_score=80) for r in ROWS]
    a = ac.answer("what should we do next?", healthy, scenario_fn=scenario)
    assert a["intent"] == "suggestions" and "Nothing urgent" in a["reply"]


def test_critical_playbook_lists_the_actual_suppliers():
    a = ask("What should I do about a supplier flagged Critical?")
    assert a["topic_ids"][0] == "critical_playbook" and "Delta Devices" in a["reply"] and "In your portfolio" in a["reply"]


# ----------------------------------------------------------------------------------- hooks ----
def test_hooks_use_engine_values_only_and_never_raise():
    for name, fn in kn.HOOKS.items():
        out = kn.run_hook(name, ROWS, {})
        assert out is None or isinstance(out.get("text"), str), name
        assert kn.run_hook(name, [], {}) is None
        weird = [{"supplier_id": "S1", "supplier_name": "Odd", "rank": None, "score": None, "risk_radar_status": None}]
        kn.run_hook(name, weird, {})              # must not raise
    cost = kn.run_hook("cost_trap", ROWS, {})
    assert cost and "Delta Devices" in cost["text"]                                 # cheapest quartile includes a Critical supplier
    fit = kn.run_hook("selection_fit", ROWS, {})
    assert "5 of your 12" in fit["text"] and "Atlas Cloud" in fit["text"]


def test_concentration_hook_reads_dependency_payload():
    dep = {"available": True, "categories": [{"category": "IT", "hhi": 3100, "top_supplier": "Atlas Cloud", "top_share_pct": 60, "awards": 20, "suppliers_used": 3}],
           "top_suppliers": [{"supplier_id": "S01", "name": "Atlas Cloud", "share_pct": 40}, {"supplier_id": "S02", "name": "Borealis Data", "share_pct": 20}, {"supplier_id": "S03", "name": "Cirrus Hosting", "share_pct": 10}],
           "total_awards": 100, "single_source_categories": ["Legal"]}
    out = kn.run_hook("concentration", ROWS, {"dependency": lambda: dep})
    assert "HHI 3100" in out["text"] and "70.0%" in out["text"] and "Cirrus Hosting" in out["text"]
    a = ask("Why does supplier concentration matter?", extras={"dependency": lambda: dep})
    assert "HHI 3100" in a["reply"]


# ---------------------------------------------------------------------------- scope and safety ----
def test_unrelated_and_vague_questions():
    assert ask("What is the weather like in Paris today?")["intent"] == "out_of_scope"
    assert ask("zzz qqq")["intent"] == "unknown"
    f = ask("How would I think about moving to a totally different supplier model for our needs?")
    assert f["intent"] in ("knowledge", "framework") and f["reply"]


def test_framework_answer_for_unmatched_procurement_questions():
    a = ac.answer("why do vendor onboarding timelines vary so unpredictably across quarters?", ROWS, scenario_fn=scenario)
    assert a["intent"] in ("knowledge", "framework") and a["follow_ups"]
    fw = kn.framework("why is the thing odd", ROWS)
    assert "Check the usual drivers" in fw["reply"]


def test_general_guidance_works_without_supplier_data():
    a = ac.answer("What should an SLA include?", [], scenario_fn=scenario)
    assert a["intent"] == "knowledge" and "SLAs and KPIs" in a["reply"]
    assert ac.answer("Which suppliers need attention?", [], scenario_fn=scenario)["intent"] == "unknown"


def test_answers_keep_the_shape_the_ui_and_api_expect():
    for q in list(EXPECT)[:8] + ["What do you suggest we focus on?", "dual sourcing vs single sourcing"]:
        a = ask(q)
        for k in ("engine", "intent", "title", "reply", "why", "evidence", "next_step", "suppliers", "follow_ups", "actions", "understood", "scenario_text", "topic_ids"):
            assert k in a, (q, k)
        assert isinstance(a["follow_ups"], list) and len(a["follow_ups"]) <= 4
        assert "General procurement guidance" in " ".join(a["evidence"]) or a["intent"] == "suggestions"


def test_deterministic_and_no_numbers_invented_outside_hooks():
    for q in EXPECT:
        assert ask(q) == ask(q)
    # general text carries no statistics: any digits come only from hooks or from the documented rules of thumb
    import re
    for e in kn.ENTRIES:
        blob = " ".join([e["summary"]] + [t for _, t in e["points"]] + e.get("pitfalls", []) + [e.get("why", "")])
        for m in re.findall(r"\d+(?:[.,]\d+)?%", blob):
            assert e["id"] in ("tco", "dual_sourcing", "inflation_fx", "payment_terms", "capacity_scalability", "app_percentiles", "app_hhi", "supplier_concentration", "supplier_diversity", "cost_reduction", "financial_stability", "geopolitical_risk", "weighting_criteria", "app_mcda", "app_data_quality"), (e["id"], m)


def test_gemini_prompt_knows_when_the_engine_answer_is_general_guidance():
    from backend import gemini_client as gc
    assert "GENERAL GUIDANCE" in gc.build_advisor_prompt("q", {"intent": "knowledge"}, {})
    assert "GENERAL GUIDANCE" not in gc.build_advisor_prompt("q", {"intent": "top"}, {})


if __name__ == "__main__":
    failed = 0
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    for n, f in tests:
        try:
            f()
            print("PASS", n)
        except Exception as e:  # noqa: BLE001
            failed += 1
            import traceback
            print("FAIL", n, "->", repr(e)[:600])
            traceback.print_exc(limit=3)
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
