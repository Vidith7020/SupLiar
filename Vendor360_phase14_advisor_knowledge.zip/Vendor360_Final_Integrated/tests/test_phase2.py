"""Phase 2 tests: rank, risk rule, decision text, INR conversion, capacity, price normalisation.

Runs the real pipeline (execute_ai=False, no Gemini key, no network). Needs /content (or
VENDOR360_WORKDIR) holding ONLY the four source CSVs. Works with pytest or as a plain script.
"""
import os, sys, json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
WORKDIR = os.environ.get("VENDOR360_WORKDIR", "/content")

_NS = None
def ns():
    global _NS
    if _NS is None:
        os.environ.pop("GEMINI_API_KEY", None)
        from backend.pipeline import run_backend
        _NS = run_backend(WORKDIR, execute_ai=False)["namespace"]
    return _NS

def test_pipeline_runs_without_gemini_key():
    k = ns()["supplier_kpi_df"]
    assert len(k) == 40 and k["mcda_score"].notna().all()

def test_rank_consistent_with_score_and_alias():
    k = ns()["supplier_kpi_df"]
    assert (k["mcda_rank"] == k["supplier_mcda_rank"]).all()
    s = k.sort_values("mcda_score", ascending=False)
    assert s["supplier_mcda_rank"].is_monotonic_increasing
    assert "category_level_mcda_rank" in k.columns

def test_risk_status_and_band_agree():
    r = ns()["risk_radar_df"]
    t = ns()["RISK_THRESHOLDS"]
    exp_band = r["risk_radar_status"].map(t["status_to_band"])
    assert (exp_band == r["risk_radar_band"]).all()
    crit = r[r["risk_radar_status"] == "Critical"]["risk_radar_score"]
    stable = r[r["risk_radar_status"] == "Stable"]["risk_radar_score"]
    assert (crit >= t["critical_from"]).all() and (stable < t["watch_from"]).all()

def test_decision_text_depends_on_rank():
    d = ns()["decision_intelligence_df"].sort_values("supplier_mcda_rank")
    assert d.iloc[0]["decision_explanation"].startswith("Recommended")
    assert not d.iloc[-1]["decision_explanation"].startswith("Recommended")
    assert not d.iloc[-2]["decision_explanation"].startswith("Recommended")

def test_inr_conversion_matches_rate_times_original():
    n = ns()
    fx = json.loads((ROOT / "config" / "fx_rates.json").read_text())["rates"]
    raw = pd.read_csv(Path(WORKDIR) / "historical_awards.csv")
    saved = n["VENDOR360_PREP_LOG"]  # vendor360_prepare resets the log; restore it afterwards
    out = n["vendor360_prepare"]({"historical_awards.csv": raw.copy()})["historical_awards.csv"]
    n["VENDOR360_PREP_LOG"] = saved
    exp = raw["total_value"] * raw["currency"].map(fx)
    assert (out["total_value"] - exp).abs().max() < 1e-6
    assert (out["currency"] == "INR").all()

def test_capacity_placeholder_removed_and_logged():
    k = ns()["supplier_kpi_df"]
    assert (k["capacity_kpi"] >= 999999).sum() == 0
    log = ns()["VENDOR360_PREP_LOG"]["capacity"]
    assert log["rows_replaced"] > 0 and len(log["suppliers_affected"]) > 0

def test_cost_kpi_bounded_percentile():
    c = ns()["supplier_kpi_df"]["cost_kpi"]
    assert c.between(0, 1).all()

if __name__ == "__main__":
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            try:
                fn(); print("PASS", name)
            except Exception as e:
                fails += 1; print("FAIL", name, type(e).__name__, e)
    sys.exit(1 if fails else 0)
