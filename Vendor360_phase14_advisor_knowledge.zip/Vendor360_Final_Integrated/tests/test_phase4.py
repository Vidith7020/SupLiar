"""Phase 4 / 5 tests: real PASS checks, onboarding INR unit price, HTTP endpoints, Node test of normalizeSupplier.

No Gemini key, no network needed at run time. Run:  python3 -m pytest tests/test_phase4.py -q
"""
import json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
SRC = ROOT / "data"
CSVS = ["suppliers.csv", "pricing.csv", "categories.csv", "historical_awards.csv"]


@pytest.fixture(scope="module")
def ns():
    from backend.pipeline import run_backend
    d = Path(tempfile.mkdtemp(prefix="v360p4_"))
    for n in CSVS:
        shutil.copy(SRC / n, d / n)
    return run_backend(str(d), execute_ai=False)["namespace"]


# ---- P5: PASS only when backed by executed checks -------------------------------------------------
def test_status_helper_semantics(ns, capsys):
    st = ns["v360_status"]
    assert st("T-pass", {"a": True, "b": lambda: True}) == "PASS"
    assert st("T-partial", {"a": True, "b": None}) == "PARTIAL"
    assert st("T-fail", {"a": True, "b": False}) == "CHECK REQUIRED"
    assert st("T-raises", {"a": lambda: 1 / 0}) == "CHECK REQUIRED"      # a crashing check is a failure, never a pass
    assert st("T-none", {"a": None}) == "PARTIAL"


def test_every_banner_is_a_real_executed_check_and_passes_on_clean_data(ns):
    got = {k: v["status"] for k, v in ns["VENDOR360_STATUS"].items() if not k.startswith("T-")}
    for cell in ("CELL 19", "CELL 19.1", "CELL 20", "CELL 21", "CELL 23", "CELL 24A", "CELL 26C"):
        assert cell in got, f"{cell} produced no status record"
        assert got[cell] == "PASS", (cell, ns["VENDOR360_STATUS"][cell])
        assert ns["VENDOR360_STATUS"][cell]["total"] >= 2


def test_no_unconditional_pass_strings_left():
    import re
    bad = []
    for p in (ROOT / "backend" / "modules").glob("*.py"):
        for i, line in enumerate(p.read_text().splitlines(), 1):
            if re.match(r'print\(\s*"[^"]*STATUS: PASS"\s*\)', line):   # top-level (unconditional) only
                bad.append(f"{p.name}:{i}")
    assert not bad, bad


def test_failed_check_is_reported_not_hidden(ns):
    # break an output file the way a real failure would, then re-evaluate the Cell 23 style check
    f = ns["V360_WORK"] + "/Vendor360_Cell23/Vendor360_KPI_Config.json"
    good = open(f, encoding="utf-8").read()
    try:
        open(f, "w").write("{broken")
        assert ns["v360_json_ok"](f) is False
        assert ns["v360_status"]("T-broken", {"config JSON reloads": lambda: ns["v360_json_ok"](f)}) == "CHECK REQUIRED"
    finally:
        open(f, "w", encoding="utf-8").write(good)


def test_cell26_reads_anomalies_from_the_folder_cell19_writes(ns):
    assert ns["ANOMALY_PATH"].endswith("Vendor360_Cell19/Anomaly_Results.json")
    assert os.path.isfile(ns["ANOMALY_PATH"])


# ---- Onboarding Cost = real INR unit price, MCDA cost KPI untouched ---------------------------------
def test_onboarding_cost_is_real_inr_unit_price(ns):
    from backend import onboarding as o
    k = o.with_unit_price(ns["supplier_kpi_df"], ns["VENDOR360_ONBOARDING_PRICE"])
    cfg = o.config(k)
    cost = next(d for d in cfg["dimensions"] if d["dimension"] == "Cost")
    assert cost["min"] == 0 and 250_000 <= cost["max"] <= 300_000         # about 0 - 300000, like the original screenshot
    assert 50_000 <= cost["median"] <= 80_000
    assert "INR" in cost["meaning"] and cfg["cost_note"]
    # independent recomputation from the source files: rate x price, per-unit models only, supplier median
    import pandas as pd
    fx = json.load(open(ROOT / "config" / "fx_rates.json"))["rates"]
    p = pd.read_csv(SRC / "pricing.csv")
    p["inr"] = p.unit_price * p.currency.map(fx)
    exp = p[p.pricing_model.isin(["tiered", "day_rate", "usage", "blended_rate"])].groupby("supplier_id").inr.median()
    got = ns["VENDOR360_ONBOARDING_PRICE"].set_index("supplier_id").unit_price_inr
    assert len(got) == len(exp) and (abs(got - exp) < 1e-6).all()


def test_onboarding_leaves_mcda_cost_kpi_bounded_and_unchanged(ns):
    c = ns["supplier_kpi_df"]["cost_kpi"]
    assert c.between(0, 1).all()
    before = c.copy()
    from backend import onboarding as o
    o.assess(o.with_unit_price(ns["supplier_kpi_df"], ns["VENDOR360_ONBOARDING_PRICE"]),
             {"supplier_name": "X", "supplier_id": "X1", "category": "IT", "values": {"Cost": 50000, "Quality": 80, "Reliability": 20, "Risk": 20, "Sustainability": 70, "Capacity": 4000}})
    assert ns["supplier_kpi_df"]["cost_kpi"].equals(before)


def test_onboarding_cost_range_and_direction_enforced(ns):
    from backend import onboarding as o
    k = o.with_unit_price(ns["supplier_kpi_df"], ns["VENDOR360_ONBOARDING_PRICE"])
    vals = {"Quality": 80, "Reliability": 20, "Risk": 20, "Sustainability": 70, "Capacity": 4000}
    with pytest.raises(o.OnboardingInputError):
        o.assess(k, {"supplier_name": "X", "supplier_id": "X", "category": "IT", "values": {**vals, "Cost": 5_000_000}})
    cheap = o.assess(k, {"supplier_name": "X", "supplier_id": "X", "category": "IT", "values": {**vals, "Cost": 1000}})
    dear = o.assess(k, {"supplier_name": "X", "supplier_id": "X", "category": "IT", "values": {**vals, "Cost": 200000}})
    pc = {r["dimension"]: r["better_than_pct"] for r in cheap["benchmark"]}["Cost"]
    pd_ = {r["dimension"]: r["better_than_pct"] for r in dear["benchmark"]}["Cost"]
    assert pc > pd_                                                         # lower price is better


# ---- Phase 5: HTTP endpoint / schema tests (real FastAPI app) -----------------------------------------
@pytest.fixture(scope="module")
def client():
    from fastapi.testclient import TestClient
    from backend import api
    work = Path(tempfile.mkdtemp(prefix="v360http_"))
    for n in CSVS:
        shutil.copy(SRC / n, work / n)
    # earlier test modules mutate the shared api module; reset it explicitly instead of trusting its state
    api.WORK, api.INPUT = work, work
    api.STATE, api.BOOT_ERROR, api.NS = "starting", None, {}
    with TestClient(api.app) as c:
        t0 = time.time()
        while time.time() - t0 < 180:
            h = c.get("/api/health").json()
            if h["status"] == "ready":
                break
            assert h["status"] != "error", h
            time.sleep(1)
        else:
            raise AssertionError("backend not ready")
        yield c


def test_http_health_and_portfolio_schema(client):
    h = client.get("/api/health").json()
    assert h["status"] == "ready" and h["ok"] is True
    d = client.get("/api/portfolio").json()
    assert d["count"] == len(d["suppliers"]) == 40
    s = d["suppliers"]
    assert all(k in s[0] for k in ("supplier_id", "supplier_name", "score", "rank", "risk_radar_status"))
    assert all(x["cost_kpi"] is not None for x in s)


def test_http_onboarding_config_and_assess(client):
    cfg = client.get("/api/onboarding/config").json()
    cost = next(d for d in cfg["dimensions"] if d["dimension"] == "Cost")
    assert cost["max"] > 100_000 and cost["min"] == 0
    vals = {d["dimension"]: d["median"] for d in cfg["dimensions"]}
    ok = client.post("/api/onboarding/assess", json={"supplier_name": "Demo", "supplier_id": "D1", "category": cfg["categories"][0], "values": vals}).json()
    assert ok["status"] == "assessed" and 0 <= ok["fit_index"] <= 100
    assert client.post("/api/onboarding/assess", json={"supplier_name": "Demo", "supplier_id": "D1", "category": "x", "values": {**vals, "Cost": 10**9}}).status_code == 422


def test_http_scenarios_change_weights(client):
    a = client.post("/api/scenario", json={"scenario_text": "prioritise lowest cost"}).json()
    b = client.post("/api/scenario", json={"scenario_text": "prioritise quality and sustainability"}).json()
    assert a != b


# ---- Phase 5: Node test of normalizeSupplier on the real payload ---------------------------------------
def test_node_normalize_supplier_on_real_payload(client):
    fe = ROOT / "frontend"
    if not (fe / "node_modules" / "typescript").exists() or shutil.which("node") is None:
        pytest.skip("run `npm ci` in frontend/ (and have node) to enable this test")
    payload = Path(tempfile.mkdtemp()) / "portfolio.json"
    payload.write_text(json.dumps(client.get("/api/portfolio").json()))
    r = subprocess.run(["node", "tests/normalize.test.mjs", str(payload)], cwd=fe, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
