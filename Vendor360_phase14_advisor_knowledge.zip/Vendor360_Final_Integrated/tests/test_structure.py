from pathlib import Path
import py_compile

def test_python_files_compile():
    root=Path(__file__).resolve().parents[1]
    for p in root.rglob("*.py"):
        py_compile.compile(str(p), doraise=True)
