"""Phase 1 tests. Run: VENDOR360_WORKDIR=/content pytest tests/test_phase1.py
Needs the 4 source CSVs in the work dir. Runs with NO Gemini key and no network."""
import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from backend import api

DIMS = ["cost", "quality", "reliability", "risk", "sustainability", "capacity"]


def client():
    return _ReadyClient(api.app)


class _ReadyClient(TestClient):
    """TestClient that, on entering the lifespan, waits until the background boot reports ready."""
    def __enter__(self):
        super().__enter__()
        import time
        t0 = time.time()
        while time.time() - t0 < 180:
            h = self.get("/api/health").json()
            if h["status"] == "ready":
                return self
            assert h["status"] != "error", h
            time.sleep(1)
        raise AssertionError("backend not ready in 180 s")


def test_portfolio_schema_and_values():
    with client() as c:
        d = c.get("/api/portfolio").json()
        s = d["suppliers"]
        assert d["count"] == len(s) == 40
        assert not any(k.endswith("_extra") or k.startswith("entity_") for k in s[0])
        for dim in DIMS:
            assert f"{dim}_kpi" in s[0] and f"{dim}_score" in s[0]
        assert all(0 <= x["score"] <= 100 for x in s)
        # a higher MCDA score never has a worse rank
        for a, b in zip(s, s[1:]):
            assert a["score"] >= b["score"] and a["rank"] <= b["rank"]
        assert sum(1 for x in s if x["cost_score"]) == 40  # no zero-filled KPIs
        assert {x["risk_radar_status"] for x in s} <= {"Stable", "Watch", "Emerging Risk", "Critical"}


def test_scenario_changes_weights_and_ranking():
    with client() as c:
        a = c.post("/api/scenario", json={"scenario_text": "What if reliability becomes more important than cost?"}).json()
        b = c.post("/api/scenario", json={"scenario_text": "sustainability is our top priority"}).json()
        assert a["weights"] != b["weights"]
        assert [r["supplier_id"] for r in a["ranking"][:5]] != [r["supplier_id"] for r in b["ranking"][:5]]
        assert abs(sum(a["weights"].values()) - 1) < 0.01


def test_advisor_is_deterministic_and_varies_by_question():
    with client() as c:
        q1 = c.post("/api/advisor", json={"question": "Which suppliers require attention?"}).json()
        q1b = c.post("/api/advisor", json={"question": "Which suppliers require attention?"}).json()
        q2 = c.post("/api/advisor", json={"question": "Compare the top three suppliers"}).json()
        assert q1 == q1b and q1["title"] != q2["title"]


def test_other_endpoints():
    with client() as c:
        t = c.get("/api/trends").json()
        assert t["basis"] == "awarded rows only" and sum(r["awards"] for r in t["records"]) == 220
        # Phase 2: values are converted to INR per row BEFORE summing (never summed across raw currencies)
        assert t["currency"] == "INR" and t["fx"] and set(t["fx"]["rates"]) >= {"EUR", "USD", "CHF"}
        assert all(r.get("award_value_inr") is not None and "value_by_currency" not in r for r in t["records"])
        assert c.get("/api/dependency").json()["total_awards"] == 220
        assert c.get("/api/quality").json()["suppliers"] == 40
        assert c.get("/api/export/portfolio").headers["content-type"].startswith("text/csv")
        assert c.get("/api/export/nope").status_code == 404
