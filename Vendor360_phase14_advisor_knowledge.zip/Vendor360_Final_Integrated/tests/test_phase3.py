"""Phase 3 tests: configurable paths, idempotent re-runs, startup states, packaging/config hygiene.

No Gemini key, no network. Pipeline-level tests need pandas etc. (+ IPython; stub it if missing).
API tests call the endpoint functions directly so they work with real FastAPI or a light stub.
Run:  python3 -m pytest tests/test_phase3.py -q     (or: python3 tests/test_phase3.py)
"""
import fnmatch, json, os, re, shutil, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
SRC = ROOT / "data"
CSVS = ["suppliers.csv", "pricing.csv", "categories.csv", "historical_awards.csv"]


def _fresh(*names):
    d = Path(tempfile.mkdtemp(prefix="v360_"))
    for n in names:
        shutil.copy(SRC / n, d / n)
    return d


def _content_state():
    p = Path("/content")
    return sorted(x.name for x in p.iterdir()) if p.exists() else None


def _kpi(ns):
    return ns["supplier_kpi_df"].sort_values("supplier_id")[["supplier_id", "mcda_score", "supplier_mcda_rank"]].reset_index(drop=True)


def test_separate_input_and_work_dirs_leave_input_untouched_and_ignore_content():
    from backend.pipeline import run_backend
    inp = _fresh(*CSVS)
    work = Path(tempfile.mkdtemp(prefix="v360w_"))
    before_content = _content_state()
    ns = run_backend(str(work), execute_ai=False, input_dir=str(inp))["namespace"]
    assert len(ns["supplier_kpi_df"]) == 40
    assert sorted(x.name for x in inp.iterdir()) == sorted(CSVS)          # nothing generated next to the sources
    assert (work / "Vendor360_Analysis_Base.csv").exists() and (work / "Vendor360_Cell23").is_dir()
    assert _content_state() == before_content                              # nothing read from / written to /content


def test_rerun_in_shared_dir_without_cleanup_is_identical():
    from backend.pipeline import run_backend
    d = _fresh(*CSVS)  # source CSVs and generated files share one folder (the Colab /content layout)
    a = _kpi(run_backend(str(d), execute_ai=False)["namespace"])
    assert (d / "Vendor360_Analysis_Base.csv").exists()
    b = _kpi(run_backend(str(d), execute_ai=False)["namespace"])           # generated CSVs now present: must not be re-ingested
    assert a.equals(b)


def test_no_hardcoded_content_paths_in_modules():
    bad = []
    for p in (ROOT / "backend").rglob("*.py"):
        for i, line in enumerate(p.read_text().splitlines(), 1):
            code = line.split("#", 1)[0]
            if '"/content' in code or "'/content" in code:
                bad.append(f"{p.name}:{i}")
    # the only allowed defaults are the documented env fallbacks
    assert [b for b in bad if not b.startswith(("api.py", "pipeline.py", "foundation.py"))] == []


def test_api_health_states_boot_and_selective_cleanup():
    from fastapi import HTTPException
    from backend import api
    inp = _fresh(*CSVS)
    work = Path(tempfile.mkdtemp(prefix="v360a_"))
    (work / "keep_me.txt").write_text("user file")
    (work / "Vendor360_stale.csv").write_text("x")
    (work / "Vendor360_Cell19").mkdir()
    api.WORK, api.INPUT = work, inp
    api.STATE, api.BOOT_ERROR, api.NS = "starting", None, {}
    assert api.health()["status"] == "starting" and api.health()["ok"] is False
    try:
        api.get_portfolio()
        raise AssertionError("expected 503 while starting")
    except HTTPException as e:
        assert e.status_code == 503 and "still starting" in str(e.detail)
    api._boot()
    h = api.health()
    assert h["status"] == "ready" and h["ok"] is True and h["error"] is None
    assert (work / "keep_me.txt").exists() and not (work / "Vendor360_stale.csv").exists()
    p = api.get_portfolio()
    assert p["count"] == 40
    assert sorted(x.name for x in inp.iterdir()) == sorted(CSVS)


def _kpi_df():
    from backend.pipeline import run_backend
    d = _fresh(*CSVS)
    ns = run_backend(str(Path(tempfile.mkdtemp(prefix="v360k_"))), execute_ai=False, input_dir=str(d))["namespace"]
    from backend import onboarding as ob
    return ob.with_unit_price(ns["supplier_kpi_df"], ns["VENDOR360_ONBOARDING_PRICE"])   # Cost = real INR unit price (Phase 4)


def test_onboarding_readiness_matches_original_rules():
    from backend import onboarding as ob
    k = _kpi_df()
    cfg = ob.config(k)
    dims = {d["dimension"]: d for d in cfg["dimensions"]}
    assert list(dims) == ob.DIMENSIONS                       # all six dimensions present
    assert dims["Reliability"]["max"] == 51 and dims["Quality"]["max"] == 100 and 250_000 <= dims["Cost"]["max"] <= 300_000
    assert {d: dims[d]["direction"] for d in dims} == ob.DEFAULT_DIRECTION
    med = {d: dims[d]["median"] for d in dims}
    base = {"supplier_name": "X", "supplier_id": "X-1", "category": "Cloud Compute"}
    r = ob.assess(k, {**base, "values": med})
    pct = {b["dimension"]: b["better_than_pct"] for b in r["benchmark"]}
    # original screenshot: portfolio-median input -> 50 everywhere except Reliability 48.7 (ties / 39 values)
    assert pct["Reliability"] == 48.7 and all(pct[d] == 50.0 for d in ("Quality", "Risk", "Sustainability", "Capacity"))
    assert r["fit_index"] == round(sum(pct.values()) / len(pct), 1)
    # original screenshot #2 inputs (Cost is now a real INR unit price; the other five are unchanged)
    r = ob.assess(k, {**base, "values": {"Cost": 1500, "Quality": 89.25, "Reliability": 22.34, "Risk": 20.75, "Sustainability": 76.25, "Capacity": 9000}})
    pct = {b["dimension"]: b["better_than_pct"] for b in r["benchmark"]}
    assert (pct["Quality"], pct["Risk"], pct["Sustainability"], pct["Capacity"]) == (90.0, 40.0, 77.5, 57.5)
    pos = {b["dimension"]: b["position"] for b in r["benchmark"]}
    assert pos["Quality"] == "Strong" and pos["Capacity"] == "Above average" and pos["Risk"] == "Watch"
    assert r["assessment"] == "MANAGEMENT REVIEW" and r["tone"] == "warning"
    assert "Quality" in " ".join(r["strengths"]) and "Risk" in " ".join(r["attention"])
    assert r["recommendation"].startswith("The supplier can proceed to management review, with particular attention to:")


def dims_max_cost(k):
    from backend import onboarding as ob
    return next(d["max"] for d in ob.config(k)["dimensions"] if d["dimension"] == "Cost")


def test_onboarding_weak_ready_and_edge_cases():
    from backend import onboarding as ob
    k = _kpi_df()
    base = {"supplier_name": "X", "supplier_id": "X-1", "category": "C"}
    best = {"Cost": 0.0, "Quality": 100, "Reliability": 0, "Risk": 0, "Sustainability": 100, "Capacity": 36000}
    worst = {"Cost": dims_max_cost(k), "Quality": 0, "Reliability": 51, "Risk": 100, "Sustainability": 0, "Capacity": 0}
    r = ob.assess(k, {**base, "values": best})
    assert r["assessment"] == "READY FOR MANAGEMENT REVIEW" and r["tone"] == "stable" and r["attention"] == [] and r["attention_empty"]
    r = ob.assess(k, {**base, "values": worst})
    assert r["assessment"] == "REVIEW REQUIRED" and r["tone"] == "danger" and r["strengths"] == [] and r["strengths_empty"]
    assert r["recommendation"].startswith("Conduct additional commercial and operational due diligence")
    # incomplete identity -> needs information, no score
    r = ob.assess(k, {"supplier_name": "", "supplier_id": "", "category": "Select category", "values": best})
    assert r["status"] == "needs_information" and "Supplier name" in r["missing"] and "fit_index" not in r
    assert r["completeness"] == {"filled": 6, "total": 9, "pct": 67}
    # out of range / non-numeric are rejected
    for bad in ({**best, "Risk": 150}, {**best, "Cost": 5_000_000}, {**best, "Quality": -1}, {**best, "Capacity": "abc"}):
        try:
            ob.assess(k, {**base, "values": bad}); raise AssertionError("expected rejection")
        except ob.OnboardingInputError:
            pass


def test_onboarding_does_not_modify_portfolio_and_existing_supplier_loads():
    from backend import onboarding as ob
    k = _kpi_df()
    before = k.copy(deep=True)
    cfg = ob.config(k)
    s0 = cfg["suppliers"][0]
    r = ob.assess(k, {"supplier_name": s0["supplier_name"], "supplier_id": s0["supplier_id"], "category": s0["category"] or "C", "values": s0["values"]})
    assert r["status"] in ("assessed", "needs_information")
    assert k.equals(before) and len(cfg["suppliers"]) == len(k) == 40   # nothing added or changed (session-only)


def test_api_error_state_when_sources_missing():
    from backend import api
    work = Path(tempfile.mkdtemp(prefix="v360e_"))
    api.WORK, api.INPUT = work, Path(tempfile.mkdtemp(prefix="v360empty_"))
    api.STATE, api.BOOT_ERROR, api.NS = "starting", None, {}
    api._boot()
    h = api.health()
    assert h["status"] == "error" and h["ok"] is False and h["error"]


def test_cors_is_not_wildcard():
    from backend import api
    assert "*" not in api._CORS and api._CORS


def test_single_requirements_file_with_ipython():
    assert not (ROOT / "backend" / "requirements.txt").exists()
    txt = (ROOT / "requirements.txt").read_text().lower()
    for pkg in ("ipython", "fastapi", "uvicorn", "pandas", "scikit-learn", "httpx"):
        assert pkg in txt, pkg


def test_colab_notebook_valid_and_matches_zip_name():
    nb = json.loads((ROOT / "Vendor360_Final_Colab.ipynb").read_text())
    src = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code")
    pats = re.findall(r"'(/content/[^']*\.zip)'", src)
    assert any(fnmatch.fnmatch("/content/Vendor360_FINAL_FIGMA_INTEGRATED.zip", p) for p in pats)
    assert "rmtree" not in src and "launch_colab" in src and "time.sleep(5)" not in src


def test_launcher_polls_health_and_binds_api_locally():
    s = (ROOT / "launch_colab.py").read_text()
    assert "/api/health" in s and '"127.0.0.1"' in s and "0.0.0.0\", \"--port\", str(API_PORT)" not in s


def test_frontend_docs_and_html_clean():
    html = (ROOT / "frontend" / "index.html").read_text()
    assert "figma:" not in html and "<title>Vendor" in html and 'lang="en"' in html
    for f in ("README_VENDOR360_INTEGRATION.md", ".env.example"):
        assert "/api/vendor360" not in (ROOT / "frontend" / f).read_text()
    assert ".mise.toml" not in (ROOT / "frontend" / "AGENTS.md").read_text()
    assert (ROOT / "frontend" / "package-lock.json").exists()


if __name__ == "__main__":
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("PASS", name)
            except Exception as e:  # noqa: BLE001
                fails += 1; print("FAIL", name, type(e).__name__, e)
    sys.exit(1 if fails else 0)
