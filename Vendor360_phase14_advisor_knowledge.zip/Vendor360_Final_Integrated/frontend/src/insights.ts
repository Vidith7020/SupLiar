// Insight layer for Risk Monitoring, Performance Trends, Dependency Analysis, Sustainability,
// Supplier Directory and Supplier Comparison.
//
// Rules (same as the rest of the UI): every figure below is a count, mean, median, difference or share of
// values that the API already returned. No score is invented here, nothing is estimated for missing data,
// and every sentence is built from those figures. Where a conclusion needs a threshold (e.g. "flat" = under
// 3% change) the threshold is named in the sentence or in the page note.
import type { Dimension, SupplierRecord } from "./api/vendor360";

export type Tone = "danger" | "warning" | "stable" | "info";
export type Insight = { tone: Tone; title: string; body: string; go?: { label: string; page: string; supplierId?: string } };

// ------------------------------------------------------------------ helpers ----
const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0);
const avg = (xs: number[]) => (xs.length ? sum(xs) / xs.length : 0);
const median = (xs: number[]) => {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
const r1 = (n: number) => (Math.round(n * 10) / 10).toLocaleString("en-IN");
const r0 = (n: number) => Math.round(n).toLocaleString("en-IN");
const signed = (n: number, d = 1) => `${n > 0 ? "+" : n < 0 ? "−" : ""}${d === 0 ? r0(Math.abs(n)) : r1(Math.abs(n))}`;
const plural = (n: number, word: string, many = `${word}s`) => `${n} ${n === 1 ? word : many}`;
const verb = (n: number, one: string, many: string) => (n === 1 ? one : many);
const pctOf = (a: number, b: number) => (b ? (a / b) * 100 : 0);
const nameList = (xs: SupplierRecord[], max = 3) => {
  const head = xs.slice(0, max).map((s) => s.name);
  const rest = xs.length - head.length;
  return head.join(", ") + (rest > 0 ? ` and ${rest} more` : "");
};
export const isAtRisk = (s: SupplierRecord) => s.status === "Critical" || s.status === "Emerging Risk";
const isFlagged = (s: SupplierRecord) => isAtRisk(s) || s.status === "Watch";

export function pearson(xs: number[], ys: number[]): number | null {
  const n = Math.min(xs.length, ys.length);
  if (n < 5) return null;
  const mx = avg(xs), my = avg(ys);
  let sxy = 0, sxx = 0, syy = 0;
  for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; }
  const d = Math.sqrt(sxx * syy);
  return d === 0 ? null : sxy / d;
}
const strength = (r: number) => (Math.abs(r) < 0.2 ? "little to no" : Math.abs(r) < 0.5 ? "a moderate" : "a strong");

function groupBy<T>(xs: T[], key: (x: T) => string): Map<string, T[]> {
  const m = new Map<string, T[]>();
  xs.forEach((x) => { const k = key(x); m.set(k, [...(m.get(k) || []), x]); });
  return m;
}

// ---------------------------------------------------------------------- Risk ----
export function riskAnalysis(sup: SupplierRecord[]) {
  const n = sup.length;
  const atRisk = sup.filter(isAtRisk);
  const watch = sup.filter((s) => s.status === "Watch");
  const unrated = sup.filter((s) => s.status === "Unrated");

  const flagCount = new Map<string, number>();
  sup.forEach((s) => s.flags.split(";").map((x) => x.trim()).filter(Boolean).forEach((f) => flagCount.set(f, (flagCount.get(f) || 0) + 1)));
  const drivers = [...flagCount].map(([flag, count]) => ({ flag, count })).sort((a, b) => b.count - a.count);

  const byCategory = [...groupBy(sup, (s) => s.category || "Unclassified")].map(([category, list]) => ({
    category, n: list.length, avgRisk: avg(list.map((s) => s.riskScore)), atRisk: list.filter(isAtRisk).length, flagged: list.filter(isFlagged).length,
  })).sort((a, b) => b.avgRisk - a.avgRisk);

  const riskyTop = sup.filter((s) => s.rank > 0 && s.rank <= 10 && isFlagged(s));
  const alternative = (s: SupplierRecord): SupplierRecord | null =>
    isFlagged(s) ? sup.filter((x) => x.id !== s.id && x.category === s.category && x.status === "Stable").sort((a, b) => a.rank - b.rank)[0] ?? null : null;

  const insights: Insight[] = [];
  if (n) {
    const flaggedAll = atRisk.length + watch.length;
    insights.push({
      tone: atRisk.length ? "danger" : watch.length ? "warning" : "stable",
      title: atRisk.length ? `${plural(atRisk.length, "supplier")} ${verb(atRisk.length, "needs", "need")} action` : watch.length ? "No supplier needs immediate action" : "Portfolio is stable",
      body: `${r0(pctOf(atRisk.length, n))}% of the portfolio (${atRisk.length} of ${n}) is Critical or Emerging Risk and another ${watch.length} ${watch.length === 1 ? "is" : "are"} on Watch, so ${r0(pctOf(flaggedAll, n))}% shows at least one warning.${unrated.length ? ` ${plural(unrated.length, "supplier")} could not be rated and ${unrated.length === 1 ? "is" : "are"} not counted above.` : ""}`,
    });
  }
  if (drivers.length) {
    const d = drivers[0];
    const next = drivers[1];
    insights.push({
      tone: "info", title: next && next.count === d.count ? `Most common signals: ${d.flag} and ${next.flag}` : `Most common signal: ${d.flag}`,
      body: `It is raised on ${plural(d.count, "supplier")} (${r0(pctOf(d.count, n))}% of the portfolio)${next ? (next.count === d.count ? `, tied with "${next.flag}"` : `, ahead of "${next.flag}" on ${next.count}`) : ""}. Fixing the shared cause is likely to clear more warnings than handling suppliers one by one.`,
    });
  }
  if (riskyTop.length) {
    insights.push({
      tone: "warning", title: `${riskyTop.length} of the top 10 recommended suppliers carry a warning`,
      body: `${riskyTop.map((s) => `${s.name} (#${s.rank}, ${s.status})`).slice(0, 4).join("; ")}${riskyTop.length > 4 ? "…" : ""}. A high MCDA rank does not remove operational exposure: check the risk drivers before awarding.`,
      go: { label: "Open top flagged profile", page: "Supplier Profile", supplierId: riskyTop[0].id },
    });
  } else if (n >= 10) {
    insights.push({ tone: "stable", title: "Top 10 recommended suppliers are clean", body: "None of the ten best-ranked suppliers is on Watch, Emerging Risk or Critical." });
  }
  if (byCategory.length > 1) {
    const hi = byCategory[0], lo = byCategory[byCategory.length - 1];
    insights.push({
      tone: hi.atRisk ? "warning" : "info", title: `${hi.category} has the highest average risk`,
      body: `Average risk ${r1(hi.avgRisk)} across ${plural(hi.n, "supplier")}, with ${hi.flagged} flagged, versus ${r1(lo.avgRisk)} in ${lo.category}. Concentrate review time on ${hi.category}.`,
    });
  }
  const countries = [...groupBy(sup.filter(isFlagged).filter((s) => s.country), (s) => s.country)].sort((a, b) => b[1].length - a[1].length);
  if (countries.length && countries[0][1].length >= 2) {
    insights.push({ tone: "info", title: `Flagged suppliers cluster in ${countries[0][0]}`, body: `${countries[0][1].length} of the ${atRisk.length + watch.length} flagged suppliers are headquartered in ${countries[0][0]}. A shared regional factor is worth checking.` });
  }
  const worst = [...sup].sort((a, b) => b.riskScore - a.riskScore)[0];
  if (worst && isFlagged(worst)) {
    const alt = alternative(worst);
    insights.push({
      tone: isAtRisk(worst) ? "danger" : "warning", title: `Highest risk: ${worst.name} (${r1(worst.riskScore)})`,
      body: `${worst.riskExplanation || "No explanation was produced for this supplier."}${alt ? ` Best-ranked Stable alternative in ${worst.category}: ${alt.name} (#${alt.rank}, score ${r1(alt.score)}).` : ` No Stable supplier exists in ${worst.category} to switch to.`}`,
      go: { label: "Review supplier", page: "Supplier Profile", supplierId: worst.id },
    });
  }
  return { insights, drivers, byCategory, alternative, counts: { atRisk: atRisk.length, watch: watch.length, unrated: unrated.length } };
}

// -------------------------------------------------------------------- Trends ----
export type TrendRec = { period: string; awards: number; avg_lead_time: number | null; avg_risk: number | null; avg_savings: number | null; award_value_inr?: number | null };
export type TrendMetric = "awards" | "lead" | "risk" | "savings" | "value";
export const TREND_METRICS: Record<TrendMetric, { label: string; better: "lower" | "higher" | null; pick: (r: TrendRec) => number | null; unit: string }> = {
  awards: { label: "Awards", better: null, pick: (r) => r.awards, unit: "" },
  lead: { label: "Lead time", better: "lower", pick: (r) => r.avg_lead_time, unit: " days" },
  risk: { label: "Risk at award", better: "lower", pick: (r) => r.avg_risk, unit: "" },
  savings: { label: "Savings", better: "higher", pick: (r) => r.avg_savings, unit: "%" },
  value: { label: "Awarded value", better: null, pick: (r) => r.award_value_inr ?? null, unit: "" },
};
const FLAT_PCT = 3;
type Change = { from: number; to: number; fromPeriod: string; toPeriod: string; delta: number; pct: number | null; verdict: "better" | "worse" | "flat" };
function changeOf(rows: TrendRec[], metric: TrendMetric): Change | null {
  const m = TREND_METRICS[metric];
  const pts = rows.map((r) => ({ p: r.period, v: m.pick(r) })).filter((x): x is { p: string; v: number } => x.v !== null);
  if (pts.length < 2) return null;
  const a = pts[0], b = pts[pts.length - 1];
  const delta = b.v - a.v;
  const pct = a.v ? (delta / Math.abs(a.v)) * 100 : null;
  const flat = pct !== null ? Math.abs(pct) < FLAT_PCT : delta === 0;
  const verdict = flat || !m.better ? "flat" : (delta < 0) === (m.better === "lower") ? "better" : "worse";
  return { from: a.v, to: b.v, fromPeriod: a.p, toPeriod: b.p, delta, pct, verdict };
}
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export const monthLabel = (p: string) => { const [y, m] = p.split("-"); return MONTHS[Number(m) - 1] ? `${MONTHS[Number(m) - 1]} ${y}` : p; };

export function trendAnalysis(recs: TrendRec[]) {
  const typical = median(recs.map((r) => r.awards));
  // Only the first and last month can be incomplete (a window that starts/ends mid-month). A month is treated
  // as partial when its award count is under half of the median month.
  const partial = new Set<string>();
  if (recs.length >= 3) [recs[0], recs[recs.length - 1]].forEach((r) => { if (r.awards < typical * 0.5) partial.add(r.period); });
  const full = recs.filter((r) => !partial.has(r.period));
  const insights: Insight[] = [];

  if (partial.size) {
    insights.push({
      tone: "warning", title: `${[...partial].map(monthLabel).join(" and ")} look${partial.size === 1 ? "s" : ""} incomplete`,
      body: `${[...partial].map((p) => `${monthLabel(p)} has ${recs.find((r) => r.period === p)!.awards} awards`).join(" and ")} against a typical month of ${r0(typical)}. They are excluded from the direction checks below so a short month is not read as a decline.`,
    });
  }
  const peak = [...full].sort((a, b) => b.awards - a.awards)[0];
  if (peak) insights.push({ tone: "info", title: `Busiest month: ${monthLabel(peak.period)}`, body: `${peak.awards} awards, versus a typical ${r0(typical)}. Across all ${recs.length} months there were ${sum(recs.map((r) => r.awards))} awarded contracts.` });

  const describe = (metric: TrendMetric, title: string, goodWord: string, badWord: string) => {
    const ch = changeOf(full, metric);
    if (!ch) return;
    const m = TREND_METRICS[metric];
    const move = `${r1(ch.from)} → ${r1(ch.to)}${m.unit} (${signed(ch.delta)}${ch.pct !== null ? `, ${signed(ch.pct)}%` : ""}) from ${monthLabel(ch.fromPeriod)} to ${monthLabel(ch.toPeriod)}`;
    insights.push({
      // With under 4 complete months a movement is a hint, not a trend, so it never raises a warning.
      tone: full.length < 4 ? "info" : ch.verdict === "better" ? "stable" : ch.verdict === "worse" ? "warning" : "info",
      title: ch.verdict === "better" ? `${title} ${goodWord}` : ch.verdict === "worse" ? `${title} ${badWord}` : `${title} is steady`,
      body: ch.verdict === "flat" ? `${move}: under ${FLAT_PCT}% change, treated as flat.` : `${move}. ${m.better === "lower" ? "Lower is better." : "Higher is better."}`,
    });
  };
  describe("lead", "Lead time", "is shortening", "is lengthening");
  describe("risk", "Risk at award", "is falling", "is rising");
  describe("savings", "Savings", "are improving", "are slipping");

  const sv = full.filter((r) => r.avg_savings !== null);
  if (sv.length >= 2) {
    const best = [...sv].sort((a, b) => (b.avg_savings ?? 0) - (a.avg_savings ?? 0))[0];
    const worst = [...sv].sort((a, b) => (a.avg_savings ?? 0) - (b.avg_savings ?? 0))[0];
    insights.push({ tone: "info", title: `Savings range from ${r1(worst.avg_savings!)}% to ${r1(best.avg_savings!)}%`, body: `Best month ${monthLabel(best.period)}, weakest ${monthLabel(worst.period)}. The ${r1(best.avg_savings! - worst.avg_savings!)}-point spread shows how much negotiation outcomes vary month to month.` });
  }
  const val = full.filter((r) => r.award_value_inr != null && r.awards > 0);
  if (val.length >= 2) {
    const per = val.map((r) => ({ p: r.period, v: (r.award_value_inr as number) / r.awards }));
    const hi = [...per].sort((a, b) => b.v - a.v)[0], lo = [...per].sort((a, b) => a.v - b.v)[0];
    insights.push({ tone: "info", title: `Average contract is ₹ ${r0(avg(per.map((x) => x.v)))}`, body: `Per-award value (INR, converted before summing) ranges from ₹ ${r0(lo.v)} in ${monthLabel(lo.p)} to ₹ ${r0(hi.v)} in ${monthLabel(hi.p)}, so a month with more awards is not necessarily a month with more spend.` });
  }
  if (full.length < 4) insights.push({ tone: "info", title: "Short history", body: `Only ${plural(full.length, "complete month")} of data. Treat the directions above as indicative, not as a trend.` });
  return { insights, partial, typical, change: (m: TrendMetric) => changeOf(full, m) };
}

// ---------------------------------------------------------------- Dependency ----
export type DepData = {
  total_awards: number;
  categories: Array<{ category: string; awards: number; suppliers_used: number; top_supplier: string; top_share_pct: number; hhi: number }>;
  top_suppliers: Array<{ supplier_id: string; name: string; awards: number; share_pct: number; categories: number }>;
  single_source_categories: string[];
};
export const hhiBand = (h: number) => (h >= 2500 ? "High" : h >= 1500 ? "Moderate" : "Low");
const splitList = (v: string) => v.split(/[,;|]/).map((x) => x.trim()).filter(Boolean);

export function dependencyAnalysis(d: DepData, sup: SupplierRecord[]) {
  const byId = new Map(sup.map((s) => [s.id, s]));
  const insights: Insight[] = [];
  const cats = [...d.categories].sort((a, b) => b.hhi - a.hhi);
  if (cats.length) {
    const c = cats[0];
    insights.push({
      tone: c.hhi >= 2500 ? "danger" : c.hhi >= 1500 ? "warning" : "stable", title: `${c.category} is the most concentrated category`,
      body: `HHI ${c.hhi} (${hhiBand(c.hhi).toLowerCase()}): ${c.top_supplier} wins ${r1(c.top_share_pct)}% of its ${c.awards} awards and ${plural(c.suppliers_used, "supplier")} ${c.suppliers_used === 1 ? "is" : "are"} used in total.`,
    });
    const thin = cats.filter((x) => x.suppliers_used <= 2);
    const high = cats.filter((x) => x.hhi >= 2500);
    if (!high.length) insights.push({ tone: "stable", title: "No category is highly concentrated", body: `The highest HHI is ${c.hhi}, below the usual 2,500 line, so no single category is dominated by one supplier.` });
    if (thin.length) insights.push({ tone: "warning", title: `${plural(thin.length, "category", "categories")} ${verb(thin.length, "relies", "rely")} on two suppliers or fewer`, body: `${thin.map((x) => `${x.category} (${x.suppliers_used})`).join(", ")}. Losing one supplier here leaves little or no competition.` });
  }
  const top = d.top_suppliers;
  if (top.length >= 3) {
    const share3 = sum(top.slice(0, 3).map((s) => s.share_pct));
    insights.push({ tone: "info", title: `Top 3 suppliers hold ${r1(share3)}% of awards`, body: `${top.slice(0, 3).map((s) => `${s.name} ${r1(s.share_pct)}%`).join(", ")}. The ten largest hold ${r1(sum(top.map((s) => s.share_pct)))}% of ${d.total_awards} awarded contracts.` });
  }
  const exposed = top.map((t) => ({ t, s: byId.get(t.supplier_id) })).filter((x): x is { t: DepData["top_suppliers"][number]; s: SupplierRecord } => !!x.s && isFlagged(x.s));
  if (exposed.length) {
    const e = exposed[0];
    insights.push({
      tone: isAtRisk(e.s) ? "danger" : "warning", title: "Heavily used suppliers with a risk warning",
      body: exposed.slice(0, 3).map((x) => `${x.t.name}: ${r1(x.t.share_pct)}% of awards, ${x.s.status}, risk ${r1(x.s.riskScore)}`).join("; ") + ". Dependency and risk compound here.",
      go: { label: "Review supplier", page: "Supplier Profile", supplierId: e.s.id },
    });
  } else if (top.length) {
    insights.push({ tone: "stable", title: "Largest suppliers are risk-clean", body: "None of the ten most-awarded suppliers is on Watch, Emerging Risk or Critical." });
  }
  const offRank = top.slice(0, 5).map((t) => ({ t, s: byId.get(t.supplier_id) })).filter((x): x is { t: DepData["top_suppliers"][number]; s: SupplierRecord } => !!x.s && x.s.rank > 10);
  if (offRank.length) insights.push({ tone: "info", title: "Awards and MCDA rank disagree", body: `${offRank.map((x) => `${x.t.name} is among the five most-awarded but ranked #${x.s.rank} by MCDA`).join("; ")}. Past awards may reflect incumbency or price rather than the current recommendation.` });

  const sole = d.single_source_categories.map((l2) => {
    const holders = sup.filter((s) => splitList(s.categoriesL2).includes(l2));
    return { l2, holder: holders.length === 1 ? holders[0] : null };
  });
  if (sole.length) {
    insights.push({
      tone: "danger", title: `${plural(sole.length, "sub-category", "sub-categories")} ${verb(sole.length, "depends", "depend")} on a single supplier`,
      body: sole.slice(0, 5).map((x) => (x.holder ? `${x.l2}: ${x.holder.name} (${x.holder.status})` : x.l2)).join("; ") + (sole.length > 5 ? "…" : "") + ". There is no fallback if the supplier fails.",
    });
  } else if (d.categories.length) {
    insights.push({ tone: "stable", title: "No single-source sub-category", body: "Every sub-category in the supplier list has at least two suppliers that could take the work." });
  }
  return { insights, byId };
}

// ------------------------------------------------------------ Sustainability ----
export const ESG_LINE = 70;
export const ESG_BANDS: Array<{ label: string; lo: number; hi: number }> = [
  { label: "Below 50", lo: -Infinity, hi: 50 }, { label: "50 – 69", lo: 50, hi: 70 }, { label: "70 – 84", lo: 70, hi: 85 }, { label: "85 and above", lo: 85, hi: Infinity },
];

export function esgAnalysis(sup: SupplierRecord[]) {
  const list = sup.filter((s) => s.kpi.sustainability !== null).sort((a, b) => (b.kpi.sustainability as number) - (a.kpi.sustainability as number));
  const v = (s: SupplierRecord) => s.kpi.sustainability as number;
  const vals = list.map(v);
  const bands = ESG_BANDS.map((b) => ({ ...b, count: vals.filter((x) => x >= b.lo && x < b.hi).length }));
  const byCategory = [...groupBy(list, (s) => s.category || "Unclassified")].map(([category, l]) => ({ category, n: l.length, avg: avg(l.map(v)), below: l.filter((s) => v(s) < ESG_LINE).length })).sort((a, b) => a.avg - b.avg);
  const below = list.filter((s) => v(s) < ESG_LINE);
  const insights: Insight[] = [];
  if (!list.length) return { list, vals, bands, byCategory, below, insights, laggards: [] as SupplierRecord[], leaders: [] as SupplierRecord[] };

  insights.push({
    tone: below.length ? (pctOf(below.length, list.length) >= 50 ? "danger" : "warning") : "stable",
    title: below.length ? `${below.length} of ${list.length} suppliers score below ${ESG_LINE}` : `Every supplier scores ${ESG_LINE} or above`,
    body: `Portfolio average ${r1(avg(vals))}, median ${r1(median(vals))}, range ${r1(Math.min(...vals))} to ${r1(Math.max(...vals))} (a ${r1(Math.max(...vals) - Math.min(...vals))}-point spread).${below.length ? ` ${r0(pctOf(below.length, list.length))}% sit under the ${ESG_LINE} review line.` : ""}`,
  });
  if (byCategory.length > 1) {
    const lo = byCategory[0], hi = byCategory[byCategory.length - 1];
    insights.push({ tone: lo.below ? "warning" : "info", title: `${lo.category} is the weakest category on ESG`, body: `Average ${r1(lo.avg)} (${lo.below} of ${lo.n} below ${ESG_LINE}) against ${r1(hi.avg)} for ${hi.category}. Category-level supplier engagement would start there.` });
  }
  const topTen = sup.filter((s) => s.rank > 0 && s.rank <= 10 && s.kpi.sustainability !== null && v(s) < ESG_LINE);
  insights.push(topTen.length
    ? { tone: "warning", title: `${plural(topTen.length, "top-10 recommended supplier")} below ${ESG_LINE} on ESG`, body: `${topTen.map((s) => `${s.name} (#${s.rank}, ESG ${r1(v(s))})`).slice(0, 4).join("; ")}. They rank in the top 10 overall, so sustainability is the trade-off to weigh or to raise in the contract.` }
    : { tone: "stable", title: "Top-10 recommended suppliers meet the ESG line", body: `All ten best-ranked suppliers with ESG data score ${ESG_LINE} or above, so the recommendation is not leaning on weak sustainability performers.` });
  const compounded = below.filter(isFlagged);
  if (compounded.length) {
    insights.push({ tone: "danger", title: `${plural(compounded.length, "supplier")} ${verb(compounded.length, "combines", "combine")} low ESG with a risk warning`, body: `${nameList(compounded)}. Weak sustainability and operational risk together make these the first candidates for a supplier review or an exit plan.`, go: { label: "Open first profile", page: "Supplier Profile", supplierId: compounded[0].id } });
  }
  const paired = list.filter((s) => s.score > 0);
  const r = pearson(paired.map(v), paired.map((s) => s.score));
  if (r !== null) insights.push({ tone: "info", title: `ESG and MCDA score show ${strength(r)} relationship`, body: `Correlation ${r >= 0 ? "+" : "−"}${Math.abs(r).toFixed(2)} across ${paired.length} suppliers. ${Math.abs(r) < 0.2 ? "Sustainable suppliers are neither systematically better nor worse overall, so ESG has to be managed explicitly." : r > 0 ? "Suppliers that rank higher overall also tend to be more sustainable." : "Suppliers that rank higher overall tend to be less sustainable, a trade-off to manage."} This is a correlation, not a cause.` });
  if (list.length < sup.length) insights.push({ tone: "info", title: `${sup.length - list.length} supplier(s) have no ESG score`, body: "They are left out of every figure above. Nothing is estimated for them." });
  return { list, vals, bands, byCategory, below, insights, laggards: [...list].reverse().slice(0, 5), leaders: list.slice(0, 5) };
}

// ----------------------------------------------------------------- Directory ----
export function directoryAnalysis(sup: SupplierRecord[]) {
  const n = sup.length;
  const insights: Insight[] = [];
  const leaders = [...groupBy(sup, (s) => s.category || "Unclassified")].map(([category, l]) => {
    const best = [...l].sort((a, b) => a.rank - b.rank)[0];
    return { category, n: l.length, best, flagged: l.filter(isFlagged).length, avgScore: avg(l.map((s) => s.score)) };
  }).sort((a, b) => b.n - a.n);
  if (n) {
    const first = [...sup].sort((a, b) => a.rank - b.rank)[0];
    const last = [...sup].sort((a, b) => b.rank - a.rank)[0];
    insights.push({ tone: "info", title: `${first.name} leads the portfolio`, body: `Rank #${first.rank} with a score of ${r1(first.score)}, ${r1(first.score - last.score)} points ahead of the lowest-ranked supplier (${last.name}, ${r1(last.score)}).`, go: { label: "Open profile", page: "Supplier Profile", supplierId: first.id } });
    const atRisk = sup.filter(isAtRisk);
    insights.push(atRisk.length
      ? { tone: "danger", title: `${plural(atRisk.length, "supplier")} ${verb(atRisk.length, "needs", "need")} risk action`, body: `${nameList([...atRisk].sort((a, b) => b.riskScore - a.riskScore))}. Use the status filter to isolate them.`, go: { label: "Open Risk Monitoring", page: "Risk Monitoring" } }
      : { tone: "stable", title: "No supplier needs risk action", body: `${sup.filter((s) => s.status === "Watch").length} on Watch, none Critical or Emerging.` });
    const upside = sup.filter((s) => s.rank > 0 && s.rank <= Math.max(3, Math.ceil(n / 4)) && isFlagged(s));
    if (upside.length) insights.push({ tone: "warning", title: "Strong performers with a caveat", body: `${nameList(upside)} rank in the top quarter but are flagged on the Risk Radar.` });
    const incomplete = sup.filter((s) => s.completeness < 100);
    insights.push(incomplete.length
      ? { tone: "warning", title: `${plural(incomplete.length, "supplier")} ${verb(incomplete.length, "has", "have")} incomplete KPI data`, body: `${nameList([...incomplete].sort((a, b) => a.completeness - b.completeness))}. Their scores rest on fewer inputs; the lowest has ${r0(Math.min(...incomplete.map((s) => s.completeness)))}% completeness.` }
      : { tone: "stable", title: "All KPI data is complete", body: "Every supplier has every KPI dimension, so scores are directly comparable." });
    if (leaders.length > 1) insights.push({ tone: "info", title: `${leaders[0].category} is the largest category`, body: `${leaders[0].n} of ${n} suppliers (${r0(pctOf(leaders[0].n, n))}%). Smallest: ${leaders[leaders.length - 1].category} with ${leaders[leaders.length - 1].n}.` });
  }
  return { insights, leaders };
}
/** One-line takeaway for a table row, from engine text only. */
export function rowTakeaway(s: SupplierRecord): { up: string; down: string; note: string } {
  return { up: s.strengths[0] || "", down: s.weaknesses[0] || "", note: s.completeness < 100 ? `KPI data ${r0(s.completeness)}% complete` : "" };
}

// ---------------------------------------------------------------- Comparison ----
export type CompareDim = { key: Dimension | "score"; label: string; lower: boolean; get: (s: SupplierRecord) => number | null };
export const COMPARE_DIMS: CompareDim[] = [
  { key: "cost", label: "Cost", lower: false, get: (s) => s.rel.cost },
  { key: "quality", label: "Quality", lower: false, get: (s) => s.rel.quality },
  { key: "reliability", label: "Reliability", lower: false, get: (s) => s.rel.reliability },
  { key: "risk", label: "Risk", lower: true, get: (s) => s.riskScore },
  { key: "sustainability", label: "Sustainability", lower: false, get: (s) => s.rel.sustainability },
  { key: "capacity", label: "Capacity", lower: false, get: (s) => s.rel.capacity },
];

export function compareAnalysis(chosen: SupplierRecord[]) {
  const insights: Insight[] = [];
  if (chosen.length < 2) return { insights, winners: [] as Array<{ dim: CompareDim; winner: SupplierRecord | null; margin: number }>, wins: new Map<string, number>() };
  // "Better" is signed so one rule works for every dimension (risk: lower is better).
  const goodness = (d: CompareDim, s: SupplierRecord) => { const x = d.get(s); return x === null ? null : d.lower ? -x : x; };
  const wins = new Map<string, number>(chosen.map((s) => [s.id, 0]));
  const winners = COMPARE_DIMS.map((d) => {
    const scored = chosen.map((s) => ({ s, g: goodness(d, s) })).filter((x): x is { s: SupplierRecord; g: number } => x.g !== null).sort((a, b) => b.g - a.g);
    if (scored.length < 2 || scored[0].g === scored[1].g) return { dim: d, winner: null, margin: 0 }; // tie or not comparable: nobody wins
    wins.set(scored[0].s.id, (wins.get(scored[0].s.id) || 0) + 1);
    return { dim: d, winner: scored[0].s, margin: scored[0].g - scored[1].g };
  });
  const leader = [...chosen].sort((a, b) => a.rank - b.rank)[0];
  const runner = [...chosen].sort((a, b) => a.rank - b.rank)[1];

  const leaderWins = wins.get(leader.id) || 0;
  const topWinner = [...chosen].sort((a, b) => (wins.get(b.id) || 0) - (wins.get(a.id) || 0))[0];
  insights.push({
    tone: "info", title: `${leader.name} is the stronger overall choice`,
    body: `Rank #${leader.rank} (score ${r1(leader.score)}) against #${runner.rank} for ${runner.name} (${r1(runner.score)}), a ${r1(leader.score - runner.score)}-point gap. It is best on ${leaderWins} of ${COMPARE_DIMS.length} dimensions${topWinner.id !== leader.id ? `, but ${topWinner.name} is best on more (${wins.get(topWinner.id)}), so the overall rank is driven by dimension weights, not by a simple count` : ""}.`,
  });
  // Trade-off: what the leader gives up against the biggest challenger on each dimension.
  chosen.filter((s) => s.id !== leader.id).slice(0, 3).forEach((o) => {
    const diffs = COMPARE_DIMS.map((d) => { const a = goodness(d, o), b = goodness(d, leader); return a === null || b === null ? null : { d, gain: a - b }; }).filter((x): x is { d: CompareDim; gain: number } => x !== null);
    const ahead = diffs.filter((x) => x.gain > 0).sort((a, b) => b.gain - a.gain);
    const behind = diffs.filter((x) => x.gain < 0).sort((a, b) => a.gain - b.gain);
    if (!ahead.length && !behind.length) return;
    insights.push({
      tone: ahead.length ? "warning" : "stable", title: `${o.name} versus ${leader.name}`,
      body: `${ahead.length ? `${o.name} is ahead on ${ahead.slice(0, 3).map((x) => `${x.d.label.toLowerCase()} (${signed(x.gain, 0)})`).join(", ")}` : `${o.name} is not ahead on any dimension`}${behind.length ? `, and behind on ${behind.slice(0, 3).map((x) => `${x.d.label.toLowerCase()} (${signed(x.gain, 0)})`).join(", ")}` : ""}. Points are percentile points; for risk a positive number means lower risk.`,
    });
  });
  const flagged = chosen.filter(isFlagged);
  if (flagged.length) {
    insights.push({ tone: flagged.some(isAtRisk) ? "danger" : "warning", title: "Risk differs between these suppliers", body: chosen.map((s) => `${s.name}: ${s.status} (risk ${r1(s.riskScore)})`).join("; ") + ". A better score does not offset an operational warning without a mitigation plan.", go: { label: "Open Risk Monitoring", page: "Risk Monitoring" } });
  } else {
    insights.push({ tone: "stable", title: "All selected suppliers are Stable", body: "No operational warning separates them, so the decision can rest on the dimension trade-offs." });
  }
  // Raw-unit facts (no percentile maths): lead time days and capacity units.
  const lt = chosen.filter((s) => s.kpi.reliability !== null);
  if (lt.length >= 2) {
    const sorted = [...lt].sort((a, b) => (a.kpi.reliability as number) - (b.kpi.reliability as number));
    const fast = sorted[0], slow = sorted[sorted.length - 1];
    if (fast.kpi.reliability !== slow.kpi.reliability) insights.push({ tone: "info", title: `${fast.name} delivers fastest`, body: `Lead time ${r1(fast.kpi.reliability as number)} days against ${r1(slow.kpi.reliability as number)} for ${slow.name}, ${r1((slow.kpi.reliability as number) - (fast.kpi.reliability as number))} days quicker.` });
  }
  const cats = new Set(chosen.map((s) => s.category));
  if (cats.size > 1) insights.push({ tone: "info", title: "Different categories", body: `These suppliers sell different things (${[...cats].join(", ")}). Percentiles are measured across the whole portfolio, so the comparison shows relative standing, not like-for-like offers.` });
  return { insights, winners, wins };
}
