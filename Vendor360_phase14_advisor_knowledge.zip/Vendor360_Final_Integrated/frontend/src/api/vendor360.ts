export type RiskStatus = "Stable" | "Watch" | "Emerging Risk" | "Critical" | "Unrated";
export type Dimension = "cost" | "quality" | "reliability" | "risk" | "sustainability" | "capacity";
export const DIMENSIONS: Dimension[] = ["cost", "quality", "reliability", "risk", "sustainability", "capacity"];

export type SupplierRecord = {
  id: string;
  name: string;
  category: string;
  country: string;
  rank: number;
  /** MCDA recommendation score x100, straight from the engine. */
  score: number;
  /** Raw engine KPIs in native units (null = missing in source data). */
  kpi: Record<Dimension, number | null>;
  /** Direction-aware percentile 0-100 within the portfolio (100 = best). Display only. */
  rel: Record<Dimension, number | null>;
  /** Operational risk 0-100 from the Risk Radar (lower is better). */
  riskScore: number;
  status: RiskStatus;
  action: string;
  flags: string;
  riskExplanation: string;
  decisionPosition: string;
  decisionExplanation: string;
  strengths: string[];
  weaknesses: string[];
  recommendedAction: string;
  records: number;
  completeness: number;
  categoriesL2: string;
  /** True when the source held a capacity placeholder and the engine substituted an estimate. */
  capacityEstimated: boolean;
};

export type Portfolio = { suppliers: SupplierRecord[]; directions: Record<string, string> };

const API_BASE = (import.meta.env.VITE_VENDOR360_API_URL || "/api").replace(/\/$/, "");
export const apiUrl = (path: string) => `${API_BASE}${path}`;

const num = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};
const str = (v: unknown, fallback = ""): string => (v === null || v === undefined ? fallback : String(v));
const list = (v: unknown): string[] => str(v).split(";").map((x) => x.trim()).filter(Boolean);

function statusOf(raw: unknown): RiskStatus {
  const t = str(raw).toLowerCase();
  if (t.includes("critical")) return "Critical";
  if (t.includes("emerging")) return "Emerging Risk";
  if (t.includes("watch")) return "Watch";
  if (t.includes("stable")) return "Stable";
  return "Unrated"; // never infer a status in the UI
}

export function normalizeSupplier(r: Record<string, unknown>): SupplierRecord {
  const kpi = {} as Record<Dimension, number | null>;
  const rel = {} as Record<Dimension, number | null>;
  for (const d of DIMENSIONS) {
    kpi[d] = num(r[`${d}_kpi`]);
    rel[d] = num(r[`${d}_score`]);
  }
  return {
    id: str(r.supplier_id),
    name: str(r.supplier_name),
    category: str(r.category, "Unclassified"),
    country: str(r.country_hq),
    rank: num(r.rank) ?? 0,
    score: num(r.score) ?? 0,
    kpi,
    rel,
    riskScore: num(r.risk_radar_score) ?? 0,
    status: statusOf(r.risk_radar_status),
    action: str(r.risk_radar_action),
    flags: str(r.risk_radar_flags),
    riskExplanation: str(r.risk_explanation),
    decisionPosition: str(r.decision_position),
    decisionExplanation: str(r.decision_explanation),
    strengths: list(r.positive_contributors),
    weaknesses: list(r.negative_contributors),
    recommendedAction: str(r.recommended_action),
    records: num(r.supplier_record_count) ?? 0,
    completeness: num(r.kpi_completeness_pct) ?? 0,
    categoriesL2: str(r.category_l2_list),
    capacityEstimated: r.capacity_estimated === true,
  };
}

const sleep = (ms: number) => new Promise((res) => setTimeout(res, ms));

/** Thrown for a 503 "backend still starting" answer; these are polled, not counted as failures. */
class StartingError extends Error {}
const STARTUP_WAIT_MS = 90_000;

/** GET with retry + exponential backoff. While the backend reports it is still starting (HTTP 503
 *  from /api/health-aware endpoints) it polls every 2 s for up to 90 s. Throws a readable Error when it finally fails. */
export async function getJson<T = any>(path: string, retries = 3): Promise<T> {
  let last: unknown;
  const startedAt = Date.now();
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const response = await fetch(apiUrl(path), { headers: { Accept: "application/json" } });
      if (!response.ok) {
        let detail = "";
        try { detail = (await response.json()).detail ?? ""; } catch { /* ignore */ }
        const message = `API ${path} returned ${response.status}${detail ? `: ${detail}` : ""}`;
        if (response.status === 503 && /still starting/i.test(detail)) throw new StartingError(message);
        throw new Error(message);
      }
      return (await response.json()) as T;
    } catch (err) {
      last = err;
      if (err instanceof StartingError && Date.now() - startedAt < STARTUP_WAIT_MS) {
        await sleep(2000);
        attempt--; // waiting for startup does not use up a retry
        continue;
      }
      if (attempt < retries) await sleep(1000 * 2 ** attempt);
    }
  }
  throw last instanceof Error ? last : new Error(String(last));
}

export async function fetchPortfolio(): Promise<Portfolio> {
  const payload = await getJson<{ suppliers?: Array<Record<string, unknown>>; schema?: { directions?: Record<string, string> } }>("/portfolio");
  const rows = payload.suppliers ?? [];
  const suppliers = rows.map(normalizeSupplier).sort((a: SupplierRecord, b: SupplierRecord) => a.rank - b.rank);
  return { suppliers, directions: payload.schema?.directions ?? {} };
}

async function postJson<T = any>(path: string, body: unknown): Promise<T> {
  const response = await fetch(apiUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    let detail = "";
    try { detail = (await response.json()).detail ?? ""; } catch { /* ignore */ }
    throw new Error(`${path} returned ${response.status}${detail ? `: ${detail}` : ""}`);
  }
  return response.json() as Promise<T>;
}

export type ScenarioRow = {
  supplier_id: string; supplier_name: string; scenario_rank: number | null; scenario_score: number | null;
  baseline_rank: number | null; baseline_score: number | null; rank_change: number | null;
};
export type ScenarioInterpretation = { priority: string; direction?: string; evidence?: string[] };
export type ScenarioResult = {
  engine: string; weights: Record<string, number>; emphasised: string[]; explanation: string;
  interpretation?: Record<string, ScenarioInterpretation>;
  recommendation?: string; ranking: ScenarioRow[];
};
export type GeminiMeta = { success: boolean; model: string; elapsed_seconds: number | null; failure_reason: string | null; unverified_numbers: string[] };
export type GeminiStatus = { configured: boolean; model: string; sdk_installed: boolean };
export type GeminiInsights = { headline: string; key_findings: string[]; risks: string[]; recommendations: string[]; confidence_note: string };
export type GeminiInsightsResult = { engine: string; insights: GeminiInsights | null; gemini: GeminiMeta; supplier_count: number };

export type AdvisorAction = { label: string; page: string; supplier_id?: string };
export type AdvisorResult = {
  engine: string; title: string; why: string; evidence: string[]; next_step: string;
  suppliers: Array<{ supplier_id: string; supplier_name: string; rank: number; score: number; risk_status?: string | null; risk_score?: number | null }>;
  /** Conversational answer text (light markdown: **bold**, "- " lists). */
  reply?: string; intent?: string; understood?: string; follow_ups?: string[]; actions?: AdvisorAction[]; scenario_text?: string; topic_ids?: string[];
  ai?: { explanation: string; caveats: string[]; follow_ups?: string[] } | null; gemini?: GeminiMeta;
};
/** One turn of the conversation, sent back so the advisor can resolve "them", "the first one", "why?". */
export type AdvisorTurn = { role: "user" | "assistant"; content: string; supplier_ids?: string[]; intent?: string; scenario_text?: string; topic_ids?: string[] };

export const postScenario = (scenario: string) => postJson<ScenarioResult>("/scenario", { scenario_text: scenario });
export const postAdvisor = (question: string, useGemini = false, history: AdvisorTurn[] = []) => postJson<AdvisorResult>("/advisor", { question, use_gemini: useGemini, history });
export const getGeminiStatus = () => getJson<GeminiStatus>("/gemini/status", 1);
export const postGeminiInsights = () => postJson<GeminiInsightsResult>("/insights/gemini", {});

// ---- Supplier Onboarding Readiness (all numbers are computed by the backend; the UI only renders them) ----
export type OnboardingDim = { dimension: string; min: number; max: number; step: number; direction: "higher" | "lower"; meaning: string; median: number };
export type OnboardingConfig = {
  dimensions: OnboardingDim[]; categories: string[]; peer_count: number; notice: string; cost_note?: string;
  suppliers: Array<{ supplier_id: string; supplier_name: string; category: string; values: Record<string, number | null> }>;
};
export type OnboardingInput = { supplier_name: string; supplier_id: string; category: string; values: Record<string, number | null>; preview?: boolean };
export type OnboardingBenchmarkRow = { dimension: string; entered: number; portfolio_median: number; direction: "higher" | "lower"; better_than_pct: number; position: "Strong" | "Above average" | "Watch" | "Weak" };
export type OnboardingResult = {
  completeness: { filled: number; total: number; pct: number };
  preview?: boolean; status?: "assessed" | "needs_information"; missing?: string[]; message?: string;
  fit_index?: number; assessment?: string; tone?: "danger" | "warning" | "stable";
  benchmark?: OnboardingBenchmarkRow[]; strengths?: string[]; strengths_empty?: string | null;
  attention?: string[]; attention_empty?: string | null; recommendation?: string; interpretation?: string[]; caption?: string;
};
export const postOnboarding = (input: OnboardingInput) => postJson<OnboardingResult>("/onboarding/assess", input);
