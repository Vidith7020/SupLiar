import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { COMPARE_DIMS, ESG_LINE, TREND_METRICS, compareAnalysis, dependencyAnalysis, directoryAnalysis, esgAnalysis, hhiBand, monthLabel, riskAnalysis, rowTakeaway, trendAnalysis, type DepData, type Insight, type TrendMetric, type TrendRec } from "./insights";
import { apiUrl, fetchPortfolio, getJson, getGeminiStatus, postAdvisor, postGeminiInsights, postOnboarding, postScenario, type AdvisorResult, type AdvisorTurn, type GeminiInsightsResult, type GeminiStatus, type Dimension, type OnboardingConfig, type OnboardingDim, type OnboardingInput, type OnboardingResult, type RiskStatus, type ScenarioResult, type SupplierRecord } from "./api/vendor360";

type IconName =
  | "grid"
  | "users"
  | "user"
  | "compare"
  | "plus"
  | "shield"
  | "trend"
  | "network"
  | "leaf"
  | "sliders"
  | "database"
  | "spark"
  | "report"
  | "settings"
  | "help"
  | "search"
  | "bell"
  | "chevron"
  | "arrow"
  | "menu"
  | "close"
  | "check"
  | "warning";

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    compare: <><path d="M8 3 4 7l4 4M4 7h14M16 21l4-4-4-4m4 4H6"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="M12 8v4m0 4h.01"/></>,
    trend: <><path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/></>,
    network: <><circle cx="12" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M12 7v5M7 18l5-6 5 6"/></>,
    leaf: <><path d="M11 20A7 7 0 0 1 9.8 6.2C15.5 4.9 20 3 20 3s1 10-4 14c-1.4 1.1-3.1 1.7-5 1.7Z"/><path d="M2 21c3-5 7-8 13-11"/></>,
    sliders: <><path d="M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3"/><path d="M1 14h6M9 8h6m2 8h6"/></>,
    database: <><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v7c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12v7c0 1.7 4 3 9 3s9-1.3 9-3v-7"/></>,
    spark: <><path d="m12 3-1.4 4.1a5 5 0 0 1-3.1 3.1L3 12l4.5 1.8a5 5 0 0 1 3.1 3.1L12 21l1.4-4.1a5 5 0 0 1 3.1-3.1L21 12l-4.5-1.8a5 5 0 0 1-3.1-3.1L12 3Z"/></>,
    report: <><path d="M6 2h9l4 4v16H6z"/><path d="M14 2v5h5M9 13h6m-6 4h6"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/></>,
    help: <><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.5 2.5 0 1 1 3.6 2.3c-.8.4-1.3 1-1.3 1.7m0 4h.01"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5"/>,
    menu: <path d="M4 7h16M4 12h16M4 17h16"/>,
    close: <path d="m6 6 12 12M18 6 6 18"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    warning: <><path d="M10.3 3.5 2.6 17a2 2 0 0 0 1.8 3h15.2a2 2 0 0 0 1.8-3L13.7 3.5a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4m0 3h.01"/></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

const navGroups = [
  { label: "Overview", items: [{ label: "Executive Dashboard", icon: "grid" as IconName }] },
  { label: "Suppliers", items: [
    { label: "Supplier Directory", icon: "users" as IconName },
    { label: "Supplier Profile", icon: "user" as IconName },
    { label: "Supplier Comparison", icon: "compare" as IconName },
    { label: "Supplier Onboarding", icon: "plus" as IconName },
  ]},
  { label: "Risk", items: [
    { label: "Risk Monitoring", icon: "shield" as IconName },
    { label: "Performance Trends", icon: "trend" as IconName },
    { label: "Dependency Analysis", icon: "network" as IconName },
    { label: "Sustainability", icon: "leaf" as IconName },
  ]},
  { label: "Decision Intelligence", items: [
    { label: "What-If Scenarios", icon: "sliders" as IconName },
    { label: "Data Quality & Decisions", icon: "database" as IconName },
  ]},
  { label: "AI", items: [{ label: "AI Advisor", icon: "spark" as IconName }] },
  { label: "Reporting", items: [{ label: "Export & Reports", icon: "report" as IconName }] },
];
// ---------------------------------------------------------------------------
// Data layer: every number on screen comes from the Vendor360 API (deterministic
// engine outputs). Nothing is computed or invented in the UI except plain
// counts / means of engine values.
// ---------------------------------------------------------------------------
type Ctx = { suppliers: SupplierRecord[]; directions: Record<string, string>; selectedId: string; select: (id: string) => void };
const DataCtx = createContext<Ctx>({ suppliers: [], directions: {}, selectedId: "", select: () => {} });
const useData = () => useContext(DataCtx);
const UiCtx = createContext<{ showInsights: boolean }>({ showInsights: true });
const THEMES = [{ id: "indigo", label: "Indigo" }, { id: "ember", label: "Ember" }, { id: "ocean", label: "Ocean" }, { id: "aurora", label: "Aurora" }, { id: "forest", label: "Forest" }];
const loadPref = (k: string, d: string) => { try { return window.localStorage.getItem(k) ?? d; } catch { return d; } };
const savePref = (k: string, v: string) => { try { window.localStorage.setItem(k, v); } catch { /* ignore */ } };

function useEndpoint<T>(path: string) {
  const [state, setState] = useState<{ data: T | null; error: string | null; loading: boolean }>({ data: null, error: null, loading: true });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let active = true;
    setState({ data: null, error: null, loading: true });
    getJson<T>(path).then((data) => active && setState({ data, error: null, loading: false }))
      .catch((e: Error) => active && setState({ data: null, error: e.message, loading: false }));
    return () => { active = false; };
  }, [path, tick]);
  return { ...state, reload: () => setTick((n) => n + 1) };
}

const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
const f1 = (n: number | null | undefined) => (n === null || n === undefined ? "n/a" : (Math.round(n * 10) / 10).toLocaleString("en-IN"));
const f0 = (n: number | null | undefined) => (n === null || n === undefined ? "n/a" : Math.round(n).toLocaleString("en-IN"));
const initials = (name: string) => name.slice(0, 2).toUpperCase();
const toneOf = (s: RiskStatus): "danger" | "warning" | "stable" | "neutral" =>
  s === "Critical" || s === "Emerging Risk" ? "danger" : s === "Watch" ? "warning" : s === "Stable" ? "stable" : "neutral";
const STATUS_ORDER: RiskStatus[] = ["Critical", "Emerging Risk", "Watch", "Stable"];
const countStatus = (list: SupplierRecord[]) => {
  const c: Record<string, number> = {};
  list.forEach((s) => { c[s.status] = (c[s.status] || 0) + 1; });
  return c;
};
const DIM_LABEL: Record<Dimension, string> = { cost: "Cost", quality: "Quality", reliability: "Reliability", risk: "Risk", sustainability: "Sustainability", capacity: "Capacity" };
const KPI_UNIT: Record<Dimension, string> = { cost: "price percentile vs peers (0 = cheapest), INR-normalised", quality: "quality score", reliability: "lead time, days", risk: "risk score", sustainability: "ESG score", capacity: "units / month" };

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className="logo-wrap">
    <div className="logo-mark"><span>V</span><i></i></div>
    {!compact && <div className="wordmark">Vendor<span>360</span></div>}
  </div>;
}

function Button({ children, variant = "ghost", icon, onClick }: { children: ReactNode; variant?: "primary" | "ghost" | "soft"; icon?: IconName; onClick?: () => void }) {
  return <button className={`btn ${variant}`} onClick={onClick}>{icon && <Icon name={icon} size={15}/>}<span>{children}</span></button>;
}

function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "danger" | "warning" | "stable" | "neutral" }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

function Card({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return <section className={`card reveal ${className}`} style={{ animationDelay: `${delay}ms` }}>{children}</section>;
}

function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return <div className="section-title">
    <div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h2>{title}</h2></div>
    {action}
  </div>;
}

function PageHeader({ title, subtitle, actions }: { title: string; subtitle: string; actions?: ReactNode }) {
  return <div className="page-heading">
    <div><div className="heading-line"><h1>{title}</h1></div><p>{subtitle}</p></div>
    {actions && <div className="heading-actions">{actions}</div>}
  </div>;
}

function StateBox({ loading, error, onRetry, label }: { loading: boolean; error: string | null; onRetry: () => void; label: string }) {
  if (loading) return <Skeleton rows={3}/>;
  if (error) return <Card className="state-box error"><span className="eyebrow">Backend error</span><h2>Could not load {label}</h2><p>{error}</p><Button variant="primary" onClick={onRetry}>Retry</Button></Card>;
  return null;
}

function DecisionBar({ navigate }: { navigate: (page: string) => void }) {
  return <div className="decision-bar">
    <span className="decision-label"><Icon name="spark" size={15}/>Decision tools</span>
    {["Why?", "Compare", "What If?", "Risk", "Ask AI"].map((item) =>
      <button key={item} onClick={() => navigate(item === "Compare" ? "Supplier Comparison" : item === "What If?" ? "What-If Scenarios" : item === "Risk" ? "Risk Monitoring" : item === "Ask AI" ? "AI Advisor" : "Supplier Profile")}>{item}<Icon name="arrow" size={13}/></button>
    )}
  </div>;
}

function KpiCard({ icon, label, value, detail, tone, delay }: { icon: IconName; label: string; value: string; detail: string; tone: string; delay: number }) {
  return <Card className={`kpi ${tone}`} delay={delay}>
    <div className="kpi-top"><span className="icon-box"><Icon name={icon}/></span><span className="micro-trend"><span></span>Portfolio</span></div>
    <div><p className="kpi-label">{label}</p><strong>{value}</strong><p className="kpi-detail">{detail}</p></div>
    <div className="kpi-line"><i></i></div>
  </Card>;
}

function SupplierSelect({ value, onChange, allowNone = false }: { value: string; onChange: (id: string) => void; allowNone?: boolean }) {
  const { suppliers } = useData();
  return <select className="select-field" value={value} onChange={(e) => onChange(e.target.value)} aria-label="Select supplier">
    {allowNone && <option value="">— none —</option>}
    {suppliers.map((s) => <option key={s.id} value={s.id}>#{s.rank} {s.name}</option>)}
  </select>;
}

// Shared insight panel: a grid of findings computed in insights.ts from engine values (never invented).
function Skeleton({ rows = 3 }: { rows?: number }) {
  return <div className="skeleton-wrap" aria-busy="true" aria-label="Loading"><div className="sk-kpis">{[0, 1, 2, 3].map((i) => <div key={i} className="sk sk-kpi"></div>)}</div><div className="sk-grid"><div className="sk sk-chart"></div><div className="sk sk-chart"></div></div>{Array.from({ length: rows - 2 }).map((_, i) => <div key={i} className="sk sk-line"></div>)}</div>;
}

function InsightPanel({ insights, navigate, title = "Key insights", eyebrow = "Computed from the engine data", delay = 120 }: { insights: Insight[]; navigate: (page: string) => void; title?: string; eyebrow?: string; delay?: number }) {
  const { select } = useData();
  const { showInsights } = useContext(UiCtx);
  const [open, setOpen] = useState(true);
  if (!insights.length || !showInsights) return null;
  return <Card className={`ins-panel ${open ? "" : "is-closed"}`} delay={delay}>
    <SectionTitle eyebrow={eyebrow} title={title} action={<button className="fold-btn" onClick={() => setOpen(!open)} aria-expanded={open}><span>{insights.length} finding{insights.length === 1 ? "" : "s"}</span><em>{open ? "Hide" : "Show"}</em><Icon name="chevron" size={14}/></button>}/>
    <div className={`fold ${open ? "open" : ""}`}><div className="fold-inner">
      <div className="ins-grid">{insights.map((i) => <div key={i.title} className={`ins-card ${i.tone}`}>
        <div className="ins-head"><i></i><strong>{i.title}</strong></div>
        <p>{i.body}</p>
        {i.go && <button className="ins-go" onClick={() => { if (i.go!.supplierId) select(i.go!.supplierId); navigate(i.go!.page); }}>{i.go.label}<Icon name="arrow" size={13}/></button>}
      </div>)}</div>
    </div></div>
  </Card>;
}

function MiniBar({ value, max = 100, tone = "" }: { value: number; max?: number; tone?: string }) {
  return <div className={`ins-bar ${tone}`}><i style={{ width: `${Math.min(100, Math.max(0, max ? (value / max) * 100 : 0))}%` }}></i></div>;
}

// ------------------------------------------------------------- Dashboard ----
function PerformanceChart() {
  const { suppliers } = useData();
  const [metric, setMetric] = useState("Overall Score");
  const data = suppliers.slice(0, 8);
  const valueOf = (s: SupplierRecord): number | null => {
    if (metric === "Overall Score") return s.score;
    if (metric === "Risk") return s.riskScore;
    return s.rel[metric.toLowerCase() as Dimension];
  };
  return <Card className="performance" delay={300}>
    <SectionTitle eyebrow="MCDA recommendation" title="Supplier performance" action={<span className="link-btn">Top 8 by MCDA rank</span>}/>
    <div className="metric-tabs">
      {["Overall Score", "Cost", "Quality", "Reliability", "Risk", "Sustainability", "Capacity"].map((item) => <button key={item} className={metric === item ? "active" : ""} onClick={() => setMetric(item)}>{item}</button>)}
    </div>
    <div className="chart-area">
      <div className="chart-scale"><span>100</span><span>75</span><span>50</span><span>25</span><span>0</span></div>
      <div className="bars" style={{ gridTemplateColumns: `repeat(${data.length}, minmax(0, 1fr))` }}>
        {data.map((supplier, i) => {
          const value = valueOf(supplier);
          return <div className="bar-col" key={supplier.id} title={`${supplier.name}: ${f1(value)}`}>
            <div className="bar-value">{f1(value)}</div>
            <div className="bar-track"><div className={`bar-fill b${i}`} style={{ height: `${Math.max(value ?? 0, 2)}%`, animationDelay: `${340 + i * 60}ms` }}></div></div>
            <span title={supplier.name}>{supplier.name.split(" ")[0]}</span>
          </div>;
        })}
      </div>
    </div>
    <div className="chart-note"><span><i className="orange-dot"></i>{metric === "Overall Score" ? "MCDA score (engine)" : metric === "Risk" ? "Operational risk, lower is better" : "Portfolio percentile, 100 = best"}</span><span><i className="gray-dot"></i>Operational risk is shown separately</span></div>
  </Card>;
}

function AIInsight({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, select } = useData();
  const attention = suppliers.filter((s) => s.status === "Critical" || s.status === "Emerging Risk");
  const top = [...suppliers].sort((a, b) => b.riskScore - a.riskScore)[0];
  if (!top) return null;
  return <Card className="ai-card" delay={360}>
    <div className="ai-orbit"><Icon name="spark" size={22}/></div>
    <span className="eyebrow">Decision insight · deterministic</span>
    <h2>{attention.length > 0 ? `${attention.length} of ${suppliers.length} suppliers need attention.` : "No supplier is in a critical state."}</h2>
    <p>Highest operational risk: {top.name} (risk {f1(top.riskScore)}, {top.status}). {top.riskExplanation}</p>
    <div className="evidence">
      <div><span>Primary signal</span><strong>{top.flags.split(";")[0] || "Operational risk"}</strong></div>
      <div><span>Recommended next step</span><strong>{top.action || "Review"}</strong></div>
    </div>
    <div className="ai-actions">
      <Button variant="primary" onClick={() => { select(top.id); navigate("Supplier Profile"); }}>Why?</Button>
      <Button onClick={() => navigate("Supplier Comparison")}>Compare</Button>
      <Button onClick={() => navigate("What-If Scenarios")}>What if?</Button>
    </div>
    <small>Text is assembled from engine outputs. No AI model generates scores.</small>
  </Card>;
}

function GeminiInsights() {
  const [status, setStatus] = useState<GeminiStatus | null>(null);
  const [res, setRes] = useState<GeminiInsightsResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { getGeminiStatus().then(setStatus).catch(() => setStatus(null)); }, []);
  const { showInsights } = useContext(UiCtx);
  const notSetUp = status !== null && !status.configured;
  const run = () => { setBusy(true); setError(null); postGeminiInsights().then(setRes).catch((e: Error) => setError(e.message)).finally(() => setBusy(false)); };
  const ins = res?.insights ?? null;
  const failed = res && !res.gemini.success ? res.gemini.failure_reason : null;
  const column = (title: string, items: string[]) => <div><span>{title}</span>{items.length > 0 ? <ul>{items.map((t, i) => <li key={i}>{t}</li>)}</ul> : <p>None reported.</p>}</div>;
  if (!showInsights) return null;
  return <Card className="gemini-card" delay={390}>
    <div className="gemini-head">
      <div className="ai-orbit small"><Icon name="spark" size={17}/></div>
      <div className="gemini-title"><span className="eyebrow">AI insights · Gemini · on demand</span><h2>{ins ? ins.headline : "Get a written summary of the whole portfolio"}</h2></div>
      <button className="btn primary" onClick={run} disabled={busy || notSetUp}><Icon name="spark" size={15}/><span>{busy ? "Generating…" : ins ? "Regenerate" : "Generate Gemini insights"}</span></button>
    </div>
    {!ins && !busy && !error && !failed && <p className="gemini-note">{notSetUp ? "Gemini is not set up. Add a Colab secret named GEMINI_API_KEY and start the app again. Everything else on this page works without it." : "Nothing is sent to Gemini until you click the button. The text is written from the engine's verified results; Gemini never produces scores."}</p>}
    {error && <p className="gemini-note error">{error}</p>}
    {failed && <p className="gemini-note error">Gemini could not produce insights: {failed}. The engine insight above is still accurate.</p>}
    {ins && <div className="gemini-grid">{column("Key findings", ins.key_findings)}{column("Risks", ins.risks)}{column("Recommendations", ins.recommendations)}</div>}
    {ins && res && <small className="gemini-foot">Written by {res.gemini.model} in {res.gemini.elapsed_seconds}s from engine outputs for {res.supplier_count} suppliers. {ins.confidence_note}{res.gemini.unverified_numbers.length > 0 && <b className="gemini-warn"> Check these numbers against the tables, they could not be matched to engine data: {res.gemini.unverified_numbers.join(", ")}.</b>}</small>}
  </Card>;
}

function Dashboard({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, select } = useData();
  const counts = countStatus(suppliers);
  const attention = (counts["Critical"] || 0) + (counts["Emerging Risk"] || 0);
  const records = suppliers.reduce((a, s) => a + s.records, 0);
  const warnings = [...suppliers].sort((a, b) => b.riskScore - a.riskScore).slice(0, 2);
  return <>
    <PageHeader title="Executive Overview" subtitle="Supplier portfolio health, performance and decision intelligence"/>
    <div className="kpi-grid">
      <KpiCard icon="users" label="Total suppliers" value={String(suppliers.length)} detail={`${records} supplier records analysed`} tone="orange" delay={100}/>
      <KpiCard icon="trend" label="Average supplier score" value={f1(mean(suppliers.map((s) => s.score)))} detail="MCDA portfolio score (0-100)" tone="orange" delay={150}/>
      <KpiCard icon="shield" label="Average operational risk" value={f1(mean(suppliers.map((s) => s.riskScore)))} detail="Distinct from recommendation score" tone="red" delay={200}/>
      <KpiCard icon="warning" label="Requiring attention" value={String(attention)} detail="Critical or emerging risk" tone="red" delay={250}/>
    </div>
    <div className="main-grid"><PerformanceChart/><AIInsight navigate={navigate}/></div>
    <GeminiInsights/>
    <div className="bottom-grid">
      <Card delay={420}>
        <SectionTitle eyebrow="Operational risk" title="Risk radar" action={<button className="round-link" onClick={() => navigate("Risk Monitoring")}><Icon name="arrow" size={15}/></button>}/>
        <div className="risk-content">
          <div className="risk-ring"><div><strong>{suppliers.length}</strong><span>Suppliers</span></div></div>
          <div className="risk-list">
            {[["Critical", "danger"], ["Emerging Risk", "danger2"], ["Watch", "warning"], ["Stable", "stable"]].map(([l, c]) => <div key={l}><span><i className={c}></i>{l}</span><strong>{counts[l] || 0}</strong></div>)}
          </div>
        </div>
      </Card>
      <Card delay={460}>
        <SectionTitle eyebrow="MCDA ranking" title="Top suppliers" action={<button className="round-link" onClick={() => navigate("Supplier Directory")}><Icon name="arrow" size={15}/></button>}/>
        <div className="compact-list">
          {suppliers.slice(0, 3).map((s) => <button key={s.id} onClick={() => { select(s.id); navigate("Supplier Profile"); }}><b>{String(s.rank).padStart(2, "0")}</b><span className="supplier-avatar">{initials(s.name)}</span><div><strong>{s.name}</strong><small>{s.category}</small></div><em>{f1(s.score)}</em></button>)}
        </div>
      </Card>
      <Card delay={500}>
        <SectionTitle eyebrow="Signals" title="Early warnings" action={<span className="live-indicator"><i></i>Live</span>}/>
        <div className="warning-list">
          {warnings.map((s, i) => <div key={s.id}><span className={`warn-icon ${i ? "amber" : ""}`}><Icon name={i ? "trend" : "warning"} size={16}/></span><div><strong>{s.name}</strong><small>{s.flags || s.riskExplanation}</small></div><Badge tone={toneOf(s.status)}>{s.status}</Badge></div>)}
          <Button variant="soft" onClick={() => navigate("Risk Monitoring")}>Review all signals <Icon name="arrow" size={14}/></Button>
        </div>
      </Card>
    </div>
    <DecisionBar navigate={navigate}/>
  </>;
}

// ------------------------------------------------------------- Directory ----
function Directory({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, select } = useData();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("All");
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("rank");
  const [page, setPage] = useState(0);
  const counts = countStatus(suppliers);
  const analysis = useMemo(() => directoryAnalysis(suppliers), [suppliers]);
  const categories = useMemo(() => ["All", ...Array.from(new Set(suppliers.map((s) => s.category || "Unclassified"))).sort()], [suppliers]);
  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    const list = suppliers.filter((s) => `${s.name} ${s.id} ${s.category}`.toLowerCase().includes(q) && (status === "All" || s.status === status) && (category === "All" || (s.category || "Unclassified") === category));
    return list.sort((a, b) => sort === "risk" ? b.riskScore - a.riskScore : sort === "name" ? a.name.localeCompare(b.name) : a.rank - b.rank);
  }, [suppliers, query, status, category, sort]);
  const PAGE = 10;
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const cur = Math.min(page, pages - 1);
  const rows = filtered.slice(cur * PAGE, cur * PAGE + PAGE);
  return <>
    <PageHeader title="Supplier Directory" subtitle="Search, assess and manage the supplier portfolio"/>
    <div className="mini-kpis">{[["Total suppliers", suppliers.length], ["Critical", counts["Critical"] || 0], ["Watch", counts["Watch"] || 0], ["Stable", counts["Stable"] || 0]].map(([l, v], i) => <Card key={l as string} delay={80 + i * 50}><span>{l}</span><strong>{v}</strong></Card>)}</div>
    <InsightPanel insights={analysis.insights} navigate={navigate} title="Portfolio insights" delay={140}/>
    <Card className="ins-panel" delay={200}>
      <SectionTitle eyebrow="Best in each category" title="Category leaders"/>
      <div className="ins-leaders">{analysis.leaders.map((l) => <button key={l.category} className="ins-leader" onClick={() => { select(l.best.id); navigate("Supplier Profile"); }}>
        <span>{l.category}</span>
        <strong>{l.best.name}</strong>
        <em>Rank #{l.best.rank} · score {f1(l.best.score)}</em>
        <small>{l.n} suppliers · {l.flagged} flagged · avg score {f1(l.avgScore)}</small>
      </button>)}</div>
    </Card>
    <Card className="table-card" delay={260}>
      <div className="table-tools">
        <label className="search-field"><Icon name="search" size={17}/><input value={query} onChange={(e) => { setQuery(e.target.value); setPage(0); }} placeholder="Search supplier, ID or category"/></label>
        <select className="select-field" value={category} onChange={(e) => { setCategory(e.target.value); setPage(0); }} aria-label="Filter by category">{categories.map((o) => <option key={o} value={o}>{o === "All" ? "All categories" : o}</option>)}</select>
        <select className="select-field" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }} aria-label="Filter by status">{["All", ...STATUS_ORDER].map((o) => <option key={o}>{o}</option>)}</select>
        <select className="select-field" value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort"><option value="rank">Sort: MCDA rank</option><option value="risk">Sort: highest risk</option><option value="name">Sort: name</option></select>
      </div>
      <div className="data-table-wrap"><table className="data-table wide"><thead><tr>{["Rank", "Supplier", "Category", "Overall score", "Cost", "Quality", "Reliability", "Risk", "Sustainability", "Capacity", "Status", "Key takeaway"].map((h) => <th key={h}>{h}</th>)}</tr></thead>
        <tbody>{rows.map((s) => { const k = rowTakeaway(s); return <tr key={s.id} onClick={() => { select(s.id); navigate("Supplier Profile"); }}><td><b>#{s.rank}</b></td><td><div className="supplier-cell"><span className="supplier-avatar">{initials(s.name)}</span><div><strong>{s.name}</strong><small>{s.id}</small></div></div></td><td>{s.category}</td><td><strong className="score">{f1(s.score)}</strong></td><td>{f0(s.rel.cost)}</td><td>{f0(s.rel.quality)}</td><td>{f0(s.rel.reliability)}</td><td><span className={s.status === "Critical" ? "risk-num" : ""}>{f1(s.riskScore)}</span></td><td>{f0(s.rel.sustainability)}</td><td>{f0(s.rel.capacity)}</td><td><Badge tone={toneOf(s.status)}>{s.status}</Badge></td>
          <td><div className="ins-take">{k.up && <span className="up"><Icon name="check" size={12}/>{k.up}</span>}{k.down && <span className="down"><Icon name="warning" size={12}/>{k.down}</span>}{k.note && <small>{k.note}</small>}{!k.up && !k.down && !k.note && "—"}</div></td></tr>; })}</tbody>
      </table></div>
      <div className="table-footer"><span>Showing {rows.length} of {filtered.length} suppliers · scores 0-100, 100 = best (Risk: lower is better)</span><div><button onClick={() => setPage(Math.max(0, cur - 1))}>Previous</button>{Array.from({ length: pages }, (_, i) => <button key={i} className={i === cur ? "active" : ""} onClick={() => setPage(i)}>{i + 1}</button>)}<button onClick={() => setPage(Math.min(pages - 1, cur + 1))}>Next</button></div></div>
    </Card>
  </>;
}

// --------------------------------------------------------------- Profile ----
function Profile({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, selectedId, select, directions } = useData();
  const supplier = suppliers.find((s) => s.id === selectedId) || suppliers[0];
  if (!supplier) return null;
  const metrics: Array<[string, number | null, string]> = [
    ["Overall Score", supplier.score, "MCDA recommendation"],
    ...(["cost", "quality", "reliability"] as Dimension[]).map((d): [string, number | null, string] => [DIM_LABEL[d], supplier.rel[d], `Raw: ${f1(supplier.kpi[d])} (${KPI_UNIT[d]})`]),
    ["Risk", supplier.riskScore, "Operational risk · lower is better"],
    ...(["sustainability", "capacity"] as Dimension[]).map((d): [string, number | null, string] => [DIM_LABEL[d], supplier.rel[d], `Raw: ${f1(supplier.kpi[d])} (${KPI_UNIT[d]})`]),
  ];
  return <>
    <PageHeader title={supplier.name} subtitle={`${supplier.id}  ·  ${supplier.category}${supplier.country ? `  ·  HQ ${supplier.country}` : ""}`} actions={<><SupplierSelect value={supplier.id} onChange={select}/><Button onClick={() => navigate("Supplier Comparison")}>Compare</Button><Button onClick={() => navigate("What-If Scenarios")}>What if?</Button><Button variant="primary" onClick={() => navigate("AI Advisor")} icon="spark">Ask AI</Button></>}/>
    <div className="profile-status"><span>Current status</span><Badge tone={toneOf(supplier.status)}>{supplier.status}</Badge><i></i><span>MCDA rank</span><strong>#{supplier.rank}</strong><i></i><span>Decision position</span><strong>{supplier.decisionPosition || "n/a"}</strong></div>
    <div className="metric-row">{metrics.map(([label, value, note], i) => <Card key={label} delay={70 + i * 35} className={label === "Risk" ? "risk-metric" : ""}><span>{label}</span><strong>{f1(value)}</strong><div className="tiny-bar"><i style={{ width: `${Math.min(100, Math.max(0, value ?? 0))}%` }}></i></div><small>{note}</small></Card>)}</div>
    <div className="profile-grid">
      <Card className="dimension-card" delay={340}><SectionTitle eyebrow="Dimension profile" title="Supplier performance"/><div className="dimension-chart">{metrics.slice(1).map(([l, v]) => <div key={l}><span>{l}</span><div><i style={{ width: `${Math.min(100, Math.max(0, v ?? 0))}%` }}></i></div><strong>{f1(v)}</strong></div>)}</div><p className="chart-disclaimer"><Icon name="shield" size={14}/>Cost, reliability and capacity bars are portfolio percentiles (direction: {Object.entries(directions).map(([k, v]) => `${k} ${v}`).join(", ") || "from KPI config"}). Risk is the raw operational risk value.</p></Card>
      <Card className="why-card" delay={400}><SectionTitle eyebrow="Explainability" title="Why this supplier?"/>
        <div className="pros-cons"><div><span>Strengths</span>{supplier.strengths.slice(0, 3).map((t) => <strong key={t}><Icon name="check" size={14}/>{t}</strong>)}</div><div><span>Concerns</span>{supplier.weaknesses.slice(0, 3).map((t) => <strong className="negative" key={t}><Icon name="warning" size={14}/>{t}</strong>)}</div></div>
        <div className="decision-summary"><span>Decision summary</span><p>{supplier.decisionExplanation}</p></div>
        <div className="decision-summary"><span>Risk explanation</span><p>{supplier.riskExplanation}</p></div>
        <div className="recommendation"><Icon name="spark" size={17}/><div><span>Recommended action</span><strong>{supplier.recommendedAction || supplier.action}</strong></div></div></Card>
    </div>
    <DecisionBar navigate={navigate}/>
  </>;
}

// ------------------------------------------------------------------ Risk ----
function RiskPage({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, select } = useData();
  const counts = countStatus(suppliers);
  const n = suppliers.length;
  const analysis = useMemo(() => riskAnalysis(suppliers), [suppliers]);
  const queue = [...suppliers].sort((a, b) => b.riskScore - a.riskScore).slice(0, 10);
  const top = queue[0];
  const needAction = (counts["Critical"] || 0) + (counts["Emerging Risk"] || 0);
  const notes: Record<string, [string, string]> = { Critical: ["Immediate escalation", "critical"], "Emerging Risk": ["Action required", "emerging"], Watch: ["Monitor closely", "watch"], Stable: ["No active signals", "stable"] };
  return <>
    <PageHeader title="Risk Radar" subtitle="Operational supplier risk and early-warning signals"/>
    <div className="risk-summary">{STATUS_ORDER.map((l, i) => <Card className={`risk-summary-card ${notes[l][1]}`} key={l} delay={80 + i * 50}><span>{l}</span><strong>{counts[l] || 0}</strong><small>{notes[l][0]}</small></Card>)}</div>
    <InsightPanel insights={analysis.insights} navigate={navigate} title="Risk insights" eyebrow="What the radar is telling us" delay={160}/>
    <div className="risk-main">
      <Card className="risk-visual" delay={300}><SectionTitle eyebrow="Portfolio distribution" title="Operational risk visualization"/><div className="risk-visual-body"><div className="large-ring"><div><strong>{f1(n ? (needAction / n) * 100 : 0)}%</strong><span>Critical / emerging</span></div></div><div className="distribution-bars">{STATUS_ORDER.map((l) => <div key={l}><div><span>{l}</span><strong>{counts[l] || 0}</strong></div><div className="dist-track"><i style={{ width: `${n ? ((counts[l] || 0) / n) * 100 : 0}%` }}></i></div></div>)}</div></div><div className="metric-distinction"><Icon name="shield" size={18}/><div><strong>Operational risk ≠ MCDA recommendation</strong><span>Risk Radar monitors supplier exposure. Recommendation ranking combines configured decision dimensions.</span></div></div></Card>
      {top && <Card className="risk-insight" delay={360}><div className="ai-orbit small"><Icon name="spark" size={18}/></div><span className="eyebrow">Risk summary · deterministic</span><h2>{needAction > 0 ? `${needAction} supplier(s) need action.` : "No supplier needs immediate action."}</h2><p>Review {top.name} first (risk {f1(top.riskScore)}). {top.riskExplanation}</p><Button variant="primary" onClick={() => navigate("AI Advisor")}>Ask about this risk</Button></Card>}
    </div>
    <div className="profile-grid">
      <Card className="dimension-card" delay={380}><SectionTitle eyebrow="Where the risk sits" title="Average risk by category"/>
        <div className="ins-rows">{analysis.byCategory.map((c) => <div key={c.category}><span>{c.category}</span><MiniBar value={c.avgRisk} tone="hot"/><strong>{f1(c.avgRisk)}</strong><small>{c.flagged} of {c.n} flagged</small></div>)}</div>
        <p className="chart-disclaimer"><Icon name="shield" size={14}/>Mean of the supplier risk scores in each category (0-100, lower is better).</p></Card>
      <Card className="why-card" delay={420}><SectionTitle eyebrow="What triggers the warnings" title="Risk signals across suppliers"/>
        {analysis.drivers.length ? <div className="ins-rows">{analysis.drivers.map((d) => <div key={d.flag}><span>{d.flag}</span><MiniBar value={d.count} max={Math.max(n, 1)} tone="hot"/><strong>{d.count}</strong><small>{f0(n ? (d.count / n) * 100 : 0)}% of suppliers</small></div>)}</div> : <p className="note-line">No supplier currently raises a risk signal.</p>}
      </Card>
    </div>
    <Card className="table-card risk-table" delay={430}><SectionTitle eyebrow="Prioritized review" title="Supplier risk queue"/><div className="data-table-wrap"><table className="data-table wide"><thead><tr>{["Supplier", "Risk score", "Risk status", "MCDA rank", "Signals", "Drivers", "Management action", "Safer alternative"].map((h) => <th key={h}>{h}</th>)}</tr></thead><tbody>{queue.map((s) => { const alt = analysis.alternative(s); return <tr key={s.id} onClick={() => { select(s.id); navigate("Supplier Profile"); }}><td><div className="supplier-cell"><span className="supplier-avatar">{initials(s.name)}</span><strong>{s.name}</strong></div></td><td><strong className={s.status === "Critical" ? "risk-num" : ""}>{f1(s.riskScore)}</strong></td><td><Badge tone={toneOf(s.status)}>{s.status}</Badge></td><td>#{s.rank}</td><td>{s.flags ? s.flags.split(";").length : 0}</td><td>{s.flags || "—"}</td><td>{s.action || "—"}</td><td>{alt ? <span className="ins-alt" title="Best-ranked Stable supplier in the same category" onClick={(e) => { e.stopPropagation(); select(alt.id); navigate("Supplier Profile"); }}>{alt.name}<small>#{alt.rank} · score {f1(alt.score)}</small></span> : s.status === "Stable" || s.status === "Unrated" ? "—" : "None Stable in category"}</td></tr>; })}</tbody></table></div></Card>
  </>;
}

// --------------------------------------------------------------- What-If ----
const BASE_WEIGHT = 100 / 6;
const DEFAULT_SCENARIO = "What if we prioritize reliability and risk?";
const WI_DIMS = ["Cost", "Quality", "Reliability", "Risk", "Sustainability", "Capacity"];
const WI_PRESETS: Array<{ icon: IconName; title: string; text: string; blurb: string }> = [
  { icon: "shield", title: "Reliability & risk", text: "What if we prioritize reliability and risk?", blurb: "Favour dependable, low-risk suppliers" },
  { icon: "trend", title: "Cost first", text: "What if cost becomes the top priority?", blurb: "Chase the best price position" },
  { icon: "leaf", title: "Sustainability push", text: "What if sustainability becomes much more important?", blurb: "Reward greener suppliers" },
  { icon: "warning", title: "Risk-averse", text: "What if we prioritize low risk over everything else?", blurb: "Minimise operational exposure" },
  { icon: "network", title: "Capacity growth", text: "What if capacity becomes the most important factor?", blurb: "Scale with high-volume suppliers" },
];
const prioLabel = (p: string) => (p === "strong_positive" ? "Strongly emphasised" : p === "positive" ? "Emphasised" : p === "mild" ? "Slightly emphasised" : p.includes("negative") ? "De-emphasised" : "Neutral");
const prioTone = (p: string) => (p === "neutral" ? "flat" : p.includes("negative") ? "down" : "up");
const dirHint = (dim: string, d?: string) => (dim === "Reliability" ? "shorter lead time wins" : d === "lower" ? "lower is better" : "higher is better");
const evidenceText = (ev?: string) => { if (!ev) return ""; const m = ev.match(/'(.+)'/); return m ? m[1] : ev; };

type WiRow = { id: string; name: string; category: string; sRank: number | null; bRank: number | null; change: number | null; sScore: number | null; bScore: number | null };

function WhatIf() {
  const [scenario, setScenario] = useState(DEFAULT_SCENARIO);
  const [ranText, setRanText] = useState("");
  const [result, setResult] = useState<ScenarioResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<"top" | "all" | "up" | "down">("top");
  const { suppliers } = useData();
  const run = useCallback((text: string) => {
    if (!text.trim()) return;
    setBusy(true); setError(null);
    postScenario(text).then((r) => { setResult(r); setRanText(text); setView("top"); }).catch((e: Error) => setError(e.message)).finally(() => setBusy(false));
  }, []);
  const catOf = useMemo(() => new Map(suppliers.map((s) => [s.id, s.category])), [suppliers]);

  const rows: WiRow[] = useMemo(() => result
    ? result.ranking.filter((r) => r.scenario_rank !== null).map((r) => ({ id: r.supplier_id, name: r.supplier_name, category: catOf.get(r.supplier_id) ?? "", sRank: r.scenario_rank, bRank: r.baseline_rank, change: r.rank_change, sScore: r.scenario_score, bScore: r.baseline_score }))
    : [...suppliers].sort((a, b) => a.rank - b.rank).map((s) => ({ id: s.id, name: s.name, category: s.category, sRank: null, bRank: s.rank, change: null, sScore: null, bScore: s.score })), [result, suppliers, catOf]);

  const stats = useMemo(() => {
    if (!result || rows.length === 0) return null;
    const top = rows[0];
    const climbers = rows.filter((r) => (r.change ?? 0) > 0).sort((a, b) => (b.change ?? 0) - (a.change ?? 0));
    const fallers = rows.filter((r) => (r.change ?? 0) < 0).sort((a, b) => (a.change ?? 0) - (b.change ?? 0));
    const moved = rows.filter((r) => r.change).length;
    const top5 = rows.slice(0, 5);
    const top5Changed = top5.filter((r) => r.bRank !== r.sRank).length;
    const newInTop5 = top5.filter((r) => (r.bRank ?? 999) > 5).length;
    const baseLeader = rows.find((r) => r.bRank === 1);
    const heavy = Object.entries(result.weights).sort((a, b) => b[1] - a[1]);
    const margin = rows.length > 1 && top.sScore !== null && rows[1].sScore !== null ? top.sScore - rows[1].sScore : null;
    return { top, climbers, fallers, moved, top5Changed, newInTop5, baseLeader, heavy, margin };
  }, [result, rows]);

  const insights = useMemo(() => {
    if (!result || !stats) return [];
    const out: Array<{ tone: "up" | "down" | "flat"; text: string }> = [];
    const { top, baseLeader, heavy, margin, moved, top5Changed, newInTop5 } = stats;
    out.push({ tone: top.bRank === 1 ? "flat" : "up", text: top.bRank === 1 ? `${top.name} keeps the #1 spot with a score of ${f1(top.sScore)}.` : `${top.name} takes #1 with ${f1(top.sScore)}, up from #${top.bRank} (${f1(top.bScore)}).` });
    if (baseLeader && baseLeader.sRank !== 1) out.push({ tone: "down", text: `The baseline leader, ${baseLeader.name}, slips to #${baseLeader.sRank} under this scenario.` });
    if (margin !== null) out.push({ tone: margin < 3 ? "down" : "flat", text: margin < 3 ? `The lead is thin: #1 beats #2 by only ${f1(margin)} points, so small weight changes could flip it.` : `#1 leads #2 by ${f1(margin)} points, a clear gap.` });
    out.push({ tone: "flat", text: `${moved} of ${rows.length} suppliers changed rank; ${top5Changed} of the top 5 positions are different and ${newInTop5} top-5 supplier${newInTop5 === 1 ? " was" : "s were"} outside the baseline top 5.` });
    if (heavy.length) out.push({ tone: "up", text: `${heavy[0][0]} now carries ${f1(heavy[0][1] * 100)}% of the weight (neutral is ${f1(BASE_WEIGHT)}%)${heavy[1] && Math.abs(heavy[1][1] - heavy[0][1]) < 0.005 ? `, tied with ${heavy[1][0]}` : ""}.` });
    return out;
  }, [result, stats, rows.length]);

  const shown = useMemo(() => {
    if (!result) return rows.slice(0, 10);
    if (view === "all") return rows;
    if (view === "up") return rows.filter((r) => (r.change ?? 0) > 0).sort((a, b) => (b.change ?? 0) - (a.change ?? 0));
    if (view === "down") return rows.filter((r) => (r.change ?? 0) < 0).sort((a, b) => (a.change ?? 0) - (b.change ?? 0));
    return rows.slice(0, 10);
  }, [rows, result, view]);

  const reset = () => { setResult(null); setRanText(""); setError(null); setScenario(DEFAULT_SCENARIO); setView("top"); };
  const interp = result?.interpretation ?? {};
  const wMax = result ? Math.max(40, Math.ceil(Math.max(...Object.values(result.weights).map((v) => v * 100)) / 10) * 10) : 40;

  return <>
    <PageHeader title="What-If Scenarios" subtitle="Change business priorities and see how supplier decisions change." actions={result ? <Button onClick={reset}>Reset</Button> : undefined}/>

    <Card className="wi-composer" delay={60}>
      <div className="wi-composer-head"><div><span className="eyebrow">Describe a decision scenario</span><p>Write it in plain English. The text only sets intent; the engine calculates weights, scores and ranks.</p></div><span className="wi-engine"><i/>{result?.engine || "Local Deterministic"}</span></div>
      <div className="wi-field"><Icon name="spark" size={22}/><textarea value={scenario} onChange={(e) => setScenario(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) run(scenario); }} aria-label="Scenario input" placeholder="What if reliability becomes more important than cost?"/><Button variant="primary" onClick={() => run(scenario)}>{busy ? "Running…" : "Run scenario"} <Icon name="arrow" size={15}/></Button></div>
      <div className="wi-presets"><span>Quick scenarios</span><div>{WI_PRESETS.map((p) => <button key={p.title} className={scenario === p.text ? "on" : ""} onClick={() => { setScenario(p.text); run(p.text); }}><Icon name={p.icon} size={17}/><strong>{p.title}</strong><em>{p.blurb}</em></button>)}</div></div>
    </Card>

    {error && <Card className="state-box error"><span className="eyebrow">Scenario error</span><p>{error}</p></Card>}

    {!result && <Card className="wi-empty" delay={120}><Icon name="sliders" size={26}/><div><strong>No scenario run yet</strong><p>Run a scenario to see how the engine reads your query, how the weights shift, who moves up or down, and a plain-language summary. The baseline ranking is shown below for reference.</p></div></Card>}

    {result && stats && <div className={busy ? "wi-results wi-busy" : "wi-results"}>
      <Card className="wi-reading" delay={80}>
        <SectionTitle eyebrow="Query insight" title="How the engine read your scenario"/>
        <blockquote className="wi-quote"><Icon name="spark" size={15}/><span>“{ranText}”</span></blockquote>
        <div className="wi-dims">{WI_DIMS.map((d) => {
          const it = interp[d]; const p = it?.priority ?? "neutral"; const w = (result.weights[d] ?? 0) * 100; const delta = w - BASE_WEIGHT; const tone = prioTone(p);
          return <div key={d} className={`wi-dim ${tone}`}>
            <div className="wi-dim-top"><strong>{d}</strong><span className="wi-pill">{prioLabel(p)}</span></div>
            <div className="wi-dim-w"><b>{f1(w)}%</b><em className={delta > 0.05 ? "up" : delta < -0.05 ? "down" : ""}>{delta > 0.05 ? "▲" : delta < -0.05 ? "▼" : "•"} {f1(Math.abs(delta))} pp</em></div>
            <small>{it?.evidence?.length ? `Matched “${evidenceText(it.evidence[0])}”` : dirHint(d, it?.direction)}</small>
          </div>;
        })}</div>
      </Card>

      <div className="wi-kpis">
        <div className="wi-kpi hero"><span><Icon name="check" size={13}/> Recommended supplier</span><strong>{stats.top.name}</strong><p>{f1(stats.top.sScore)} score · {stats.top.bRank === 1 ? "unchanged at #1" : `was #${stats.top.bRank ?? "n/a"}`}</p></div>
        <div className="wi-kpi"><span>Biggest climber</span><strong>{stats.climbers[0]?.name ?? "No one"}</strong><p className="up">{stats.climbers[0] ? `▲ ${stats.climbers[0].change} places · #${stats.climbers[0].bRank} → #${stats.climbers[0].sRank}` : "No supplier moved up"}</p></div>
        <div className="wi-kpi"><span>Biggest drop</span><strong>{stats.fallers[0]?.name ?? "No one"}</strong><p className="down">{stats.fallers[0] ? `▼ ${Math.abs(stats.fallers[0].change ?? 0)} places · #${stats.fallers[0].bRank} → #${stats.fallers[0].sRank}` : "No supplier moved down"}</p></div>
        <div className="wi-kpi"><span>Suppliers re-ranked</span><strong>{stats.moved}<small> / {rows.length}</small></strong><p>{stats.top5Changed} of the top 5 positions changed</p></div>
      </div>

      <div className="wi-two">
        <Card className="wi-weights" delay={160}>
          <SectionTitle eyebrow="Weight shift" title="Neutral vs scenario weights"/>
          <div className="wi-legend"><span><i className="n"/>Neutral {f1(BASE_WEIGHT)}%</span><span><i className="s"/>Scenario</span></div>
          <div className="wi-wlist">{WI_DIMS.map((d) => { const v = (result.weights[d] ?? 0) * 100; const up = v >= BASE_WEIGHT; return <div key={d}><span>{d}</span><div className="wi-track"><b className={up ? "up" : "down"} style={{ width: `${(v / wMax) * 100}%` }}/><u style={{ left: `${(BASE_WEIGHT / wMax) * 100}%` }}/></div><em>{f1(v)}%</em></div>; })}</div>
        </Card>
        <Card className="wi-insights" delay={220}>
          <SectionTitle eyebrow="Why did the ranking change?" title="Scenario summary"/>
          <p className="wi-lead">{result.explanation}</p>
          <ul>{insights.map((i, k) => <li key={k} className={i.tone}><i/><span>{i.text}</span></li>)}</ul>
        </Card>
      </div>
    </div>}

    <Card className="wi-table-card" delay={260}>
      <SectionTitle eyebrow={result ? "Baseline vs scenario" : "Baseline ranking"} title={result ? "Ranking movement" : "Current supplier ranking"} action={result ? <div className="wi-tabs">{([["top", "Top 10"], ["all", `All ${rows.length}`], ["up", `Climbers ${rows.filter((r) => (r.change ?? 0) > 0).length}`], ["down", `Fallers ${rows.filter((r) => (r.change ?? 0) < 0).length}`]] as const).map(([k, l]) => <button key={k} className={view === k ? "on" : ""} onClick={() => setView(k)}>{l}</button>)}</div> : undefined}/>
      <div className="wi-table" role="table">
        <div className="wi-row head" role="row"><span>{result ? "New #" : "Rank"}</span><span>Supplier</span><span>Baseline</span><span>Movement</span><span>Score</span></div>
        {shown.length === 0 && <p className="note-line">No suppliers in this view.</p>}
        {shown.map((r) => { const max = 100; const tone = (r.change ?? 0) > 0 ? "up" : (r.change ?? 0) < 0 ? "down" : "flat"; return <div key={r.id} className={`wi-row ${tone}`} role="row">
          <b>{String(result ? r.sRank ?? 0 : r.bRank ?? 0).padStart(2, "0")}</b>
          <div className="supplier-cell"><span className="supplier-avatar">{initials(r.name)}</span><div><strong>{r.name}</strong><small>{r.category || "—"}</small></div></div>
          <span className="wi-base">{result ? `#${r.bRank ?? "n/a"}` : "—"}</span>
          <span className={`wi-move ${tone}`}>{result ? ((r.change ?? 0) > 0 ? `▲ ${r.change}` : (r.change ?? 0) < 0 ? `▼ ${Math.abs(r.change ?? 0)}` : "—") : "—"}</span>
          <div className="wi-score"><div className="wi-bar"><i className="b" style={{ width: `${Math.min(100, ((r.bScore ?? 0) / max) * 100)}%` }}/>{result && <i className={`s ${tone}`} style={{ width: `${Math.min(100, ((r.sScore ?? 0) / max) * 100)}%` }}/>}</div><span>{result ? <>{f1(r.bScore)} <em>→</em> <strong>{f1(r.sScore)}</strong></> : <strong>{f1(r.bScore)}</strong>}</span></div>
        </div>; })}
      </div>
      <div className="wi-foot"><p>Natural language only sets intent. Weights, scores and ranks are calculated by the deterministic scenario engine ({result?.engine || "Local Deterministic"}).</p><div><Button onClick={reset}>Reset</Button><Button variant="primary" onClick={() => run(scenario)}>{busy ? "Running…" : "Run scenario"}</Button></div></div>
    </Card>
  </>;
}

// ------------------------------------------------------------- AI Advisor ----
// Chat-style advisor. The engine always answers (deterministic). Gemini is an optional, on-demand
// explanation layer that the user switches on by tapping the sparkle button.
function GeminiSpark({ size = 18 }: { size?: number }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <path d="M10.5 2c.7 5.6 4.2 9.1 9.8 9.8-5.6.7-9.1 4.2-9.8 9.8-.7-5.6-4.2-9.1-9.8-9.8C6.3 11.1 9.8 7.6 10.5 2Z"/>
    <path d="M19 1.5c.25 2 1.5 3.25 3.5 3.5-2 .25-3.25 1.5-3.5 3.5-.25-2-1.5-3.25-3.5-3.5 2-.25 3.25-1.5 3.5-3.5Z" opacity=".9"/>
  </svg>;
}

function AdvisorMark({ on, switching, shake, onClick, small = false }: { on: boolean; switching: boolean; shake: boolean; onClick: () => void; small?: boolean }) {
  return <button type="button" className={`adv-mark${small ? " sm" : ""}${on ? " on" : ""}${switching ? " switching" : ""}${shake ? " shake" : ""}`}
    onClick={onClick} aria-pressed={on} aria-label={on ? "Turn Gemini off" : "Turn Gemini on"} title={on ? "Gemini is on. Click to turn off" : "Click to turn Gemini on"}>
    <span className="ring r1"></span><span className="ring r2"></span><span className="ring r3"></span>
    <span className="orb">
      <span className="glyph g-off"><Icon name="spark" size={small ? 20 : 32}/></span>
      <span className="glyph g-on"><GeminiSpark size={small ? 22 : 34}/></span>
    </span>
  </button>;
}

// Tiny, safe markdown for chat replies: **bold**, "- " bullet lists and paragraphs. No HTML is ever injected.
function RichText({ text, className = "adv-text" }: { text: string; className?: string }) {
  const inline = (s: string) => s.split(/(\*\*[^*]+\*\*)/g).map((p, i) => (p.length > 4 && p.startsWith("**") && p.endsWith("**") ? <strong key={i}>{p.slice(2, -2)}</strong> : <span key={i}>{p}</span>));
  const blocks: ReactNode[] = [];
  let para: string[] = [];
  let list: string[] = [];
  const flush = () => {
    if (para.length) blocks.push(<p key={`p${blocks.length}`}>{para.map((l, i) => <span key={i}>{i > 0 && <br/>}{inline(l)}</span>)}</p>);
    if (list.length) blocks.push(<ul key={`u${blocks.length}`}>{list.map((l, i) => <li key={i}>{inline(l)}</li>)}</ul>);
    para = []; list = [];
  };
  text.split("\n").forEach((line) => {
    if (!line.trim()) { flush(); return; }
    if (/^\s*[-•]\s+/.test(line)) { if (para.length) flush(); list.push(line.replace(/^\s*[-•]\s+/, "")); }
    else { if (list.length) flush(); para.push(line); }
  });
  flush();
  return <div className={className}>{blocks}</div>;
}

// Words appear progressively, like a streamed reply. Only the newest answer animates; skipped for reduced motion.
function Reveal({ text, animate }: { text: string; animate: boolean }) {
  const words = useMemo(() => text.split(/(\s+)/), [text]);
  const [n, setN] = useState(animate ? 0 : words.length);
  useEffect(() => {
    if (!animate || (typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches)) { setN(words.length); return; }
    setN(0);
    const t = setInterval(() => setN((v) => { if (v >= words.length) { clearInterval(t); return v; } return v + 3; }), 24);
    return () => clearInterval(t);
  }, [words, animate]);
  let shown = words.slice(0, n).join("");
  if ((shown.match(/\*\*/g) || []).length % 2) shown += "**";   // never show a dangling bold marker mid-stream
  return <RichText text={shown}/>;
}

type AdvMsg = { id: number; q: string; gemini: boolean; status: "loading" | "done" | "error"; answer?: AdvisorResult; error?: string };

/** Last turns of the chat in the shape the backend expects, so follow-ups like "compare them" work. */
function historyFor(list: AdvMsg[]): AdvisorTurn[] {
  return list.filter((m) => m.status === "done" && m.answer).slice(-4).flatMap((m) => {
    const a = m.answer as AdvisorResult;
    return [{ role: "user" as const, content: m.q },
      { role: "assistant" as const, content: a.ai?.explanation || a.reply || a.title, supplier_ids: a.suppliers.map((s) => s.supplier_id), intent: a.intent, scenario_text: a.scenario_text, topic_ids: a.topic_ids }];
  });
}

function AIAdvisor({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, select } = useData();
  const [question, setQuestion] = useState("");
  const [msgs, setMsgs] = useState<AdvMsg[]>([]);
  const [geminiOn, setGeminiOn] = useState(false);
  const [switching, setSwitching] = useState(false);
  const [shake, setShake] = useState(false);
  const [hint, setHint] = useState(false);
  const [gStatus, setGStatus] = useState<GeminiStatus | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { getGeminiStatus().then(setGStatus).catch(() => setGStatus(null)); }, []);
  const gOff = gStatus !== null && !gStatus.configured;
  const busy = msgs.some((m) => m.status === "loading");
  const topRisk = [...suppliers].sort((a, b) => b.riskScore - a.riskScore)[0];

  const toggleGemini = () => {
    if (gOff) { setShake(true); setHint(true); setTimeout(() => setShake(false), 500); return; }
    if (switching) return;
    setHint(false);
    setSwitching(true);
    setTimeout(() => setGeminiOn((v) => !v), 380);   // swap at the peak of the animation
    setTimeout(() => setSwitching(false), 1100);
  };

  const ask = (raw: string) => {
    const q = raw.trim();
    if (!q || busy) return;
    const id = Date.now();
    const gem = geminiOn && !gOff;
    const history = historyFor(msgs);
    setMsgs((m) => [...m, { id, q, gemini: gem, status: "loading" }]);
    setQuestion("");
    if (inputRef.current) inputRef.current.style.height = "auto";
    postAdvisor(q, gem, history)
      .then((answer) => setMsgs((m) => m.map((x) => (x.id === id ? { ...x, status: "done", answer } : x))))
      .catch((e: Error) => setMsgs((m) => m.map((x) => (x.id === id ? { ...x, status: "error", error: e.message } : x))));
  };
  useEffect(() => { if (msgs.length) endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [msgs.length, msgs[msgs.length - 1]?.status]);

  const suggestions: Array<[IconName, string]> = [
    ["sliders", "I need top quality and reliability, cost is no issue, and risk as low as possible"],
    ["shield", topRisk ? `Why is ${topRisk.name} high risk?` : "Which suppliers require attention?"],
    ["compare", "Compare the top three suppliers"],
    ["users", "What key features should a big business seek in a supplier?"],
  ];
  const started = msgs.length > 0;
  const last = msgs[msgs.length - 1];

  const composer = <div className="adv-dock">
    <div className={`adv-composer${geminiOn ? " on" : ""}${switching ? " switching" : ""}`}>
      <textarea ref={inputRef} rows={1} value={question} placeholder={started ? "Reply, ask a follow-up, or describe what you need…" : geminiOn ? "Ask anything about your suppliers. Gemini will analyse the verified data…" : "Describe what you need, or ask about a supplier…"} aria-label="Ask the advisor"
        onChange={(e) => { setQuestion(e.target.value); e.target.style.height = "auto"; e.target.style.height = `${Math.min(e.target.scrollHeight, 140)}px`; }}
        onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(question); } }}/>
      <div className="adv-composer-row">
        <button type="button" className={`adv-mode${geminiOn ? " on" : ""}`} onClick={toggleGemini} aria-pressed={geminiOn}>
          <GeminiSpark size={15}/><span>Gemini</span><i className="adv-switch"><b></b></i>
        </button>
        <span className="adv-keys">Enter to send · Shift+Enter for a new line</span>
        <button type="button" className="adv-send" onClick={() => ask(question)} disabled={!question.trim() || busy} aria-label="Send"><Icon name="arrow" size={18}/></button>
      </div>
    </div>
    {hint && <p className="adv-hint">Gemini is not set up. Add a Colab secret named GEMINI_API_KEY and start the app again. The engine advisor works without it.</p>}
  </div>;

  return <div className={`adv-page${geminiOn ? " on" : ""}${started ? " has-thread" : ""}`}>
    {!started && <div className="adv-hero">
      <AdvisorMark on={geminiOn} switching={switching} shake={shake} onClick={toggleGemini}/>
      <span className="adv-kicker" key={String(geminiOn)}>{geminiOn ? "Vendor360 Advisor · Gemini on" : "Vendor360 Advisor"}</span>
      <h1 className="adv-greeting">Hello, analyst</h1>
      <h2 className="adv-sub">What decision can I help you with?</h2>
      <p className="adv-tip">{geminiOn ? "Gemini analyses the full verified data (every dimension, risk, concentration and trends) and answers in plain language. Scores and ranks still come from the engine." : "Talk to me normally: describe what matters to you, ask about a supplier, or ask for advice (what to look for, why something matters, how to negotiate, what to focus on). Turn Gemini on for deeper written analysis."}</p>
      {composer}
      <div className="adv-suggest">{suggestions.map(([ic, text]) => <button key={text} onClick={() => ask(text)} disabled={busy}><span className="adv-s-icon"><Icon name={ic} size={17}/></span><span>{text}</span></button>)}</div>
    </div>}

    {started && <>
      <div className="adv-topline">
        <AdvisorMark small on={geminiOn} switching={switching} shake={shake} onClick={toggleGemini}/>
        <div><strong>Vendor360 Advisor</strong><span>{geminiOn ? "Gemini analysis on" : "Engine answers"} · remembers this conversation</span></div>
        <button className="btn" onClick={() => { setMsgs([]); setQuestion(""); }}>New chat</button>
      </div>
      <div className="adv-thread">
        {msgs.map((m) => <div className="adv-turn" key={m.id}>
          <div className="adv-user"><span>{m.q}</span></div>
          <div className="adv-answer">
            <span className={`adv-avatar${m.gemini ? " on" : ""}${m.status === "loading" ? " pulse" : ""}`}>{m.gemini ? <GeminiSpark size={17}/> : <Icon name="spark" size={17}/>}</span>
            <div className="adv-body">
              {m.status === "loading" && <div className="adv-thinking"><span>{m.gemini ? "Gemini is analysing the data…" : "Reading engine results…"}</span><i></i><i></i><i></i></div>}
              {m.status === "error" && <div className="ai-explain off"><span>Advisor error</span><p>{m.error}</p></div>}
              {m.status === "done" && m.answer && (() => {
                const a = m.answer;
                // The "How I read this" banner already shows the interpretation, so drop the engine reply's opening sentence about it.
                const main = a.ai?.explanation || (a.understood ? (a.reply || "").replace(/^Here's how I read[^\n]*\n\n/, "") : a.reply) || a.why;
                const follow = m === last ? ((a.ai?.follow_ups?.length ? a.ai.follow_ups : a.follow_ups) ?? []) : [];
                return <>
                  {a.understood && <div className="adv-read"><Icon name="spark" size={13}/><span>How I read this</span><RichText text={a.understood} className="adv-inline"/></div>}
                  {a.ai && <div className="adv-gemini-label"><GeminiSpark size={14}/>Gemini analysis</div>}
                  <Reveal text={main} animate={m === last}/>
                  {a.ai?.caveats.map((c, i) => <small className="adv-caveat" key={i}>{c}</small>)}
                  {a.gemini && a.gemini.unverified_numbers.length > 0 && <small className="gemini-warn">Check these numbers against the tables, they could not be matched to engine data: {a.gemini.unverified_numbers.join(", ")}.</small>}
                  {a.gemini && !a.gemini.success && <div className="ai-explain off"><span>Gemini unavailable</span><p>{a.gemini.failure_reason} The engine answer above is complete.</p></div>}
                  {a.suppliers.length > 0 && <div className="adv-sup">{a.suppliers.slice(0, 5).map((s) => <button key={s.supplier_id} onClick={() => { select(s.supplier_id); navigate("Supplier Profile"); }} title={s.risk_status ? `Risk Radar: ${s.risk_status}` : undefined}>
                    <b>#{s.rank}</b>{s.supplier_name}<em>{f1(s.score)}</em>{s.risk_status && s.risk_status !== "Stable" && <i className={`dot ${toneOf(s.risk_status as RiskStatus)}`}></i>}</button>)}</div>}
                  {(a.actions?.length ?? 0) > 0 && <div className="adv-actions">{a.actions!.map((x) => <button key={x.label} onClick={() => { if (x.supplier_id) select(x.supplier_id); navigate(x.page); }}>{x.label}<Icon name="arrow" size={13}/></button>)}</div>}
                  {follow.length > 0 && <div className="adv-follow">{follow.map((f) => <button key={f} disabled={busy} onClick={() => ask(f)}>{f}</button>)}</div>}
                  <details className="adv-details"><summary>How this answer was built</summary>
                    <div className="adv-details-body">
                      <span className="adv-meta">{a.engine}{a.intent ? ` · ${a.intent.replace(/_/g, " ")}` : ""}</span>
                      <strong>{a.title}</strong>
                      {a.why && <p>{a.why}</p>}
                      {a.evidence.length > 0 && <ul>{a.evidence.map((e, i) => <li key={i}>{e}</li>)}</ul>}
                      {a.ai && a.reply && <p className="adv-engine-reply"><b>Engine answer:</b> {a.reply.replace(/\*\*/g, "")}</p>}
                      {a.next_step && <p><b>Suggested next step:</b> {a.next_step}</p>}
                      {a.gemini?.success && <small>Written by {a.gemini.model} in {a.gemini.elapsed_seconds}s from verified engine data.</small>}
                    </div>
                  </details>
                </>;
              })()}
            </div>
          </div>
        </div>)}
        <div ref={endRef}></div>
      </div>
      {composer}
    </>}
  </div>;
}

// ------------------------------------------------------------ Comparison ----
function Comparison({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers } = useData();
  const [ids, setIds] = useState<string[]>(() => suppliers.slice(0, 3).map((s) => s.id).concat(""));
  const chosen = ids.map((id) => suppliers.find((s) => s.id === id)).filter(Boolean) as SupplierRecord[];
  const analysis = compareAnalysis(chosen);
  const rowsDef: Array<{ label: string; get: (s: SupplierRecord) => number | null; lower?: boolean }> = [
    { label: "Overall score", get: (s) => s.score },
    { label: "Cost", get: (s) => s.rel.cost },
    { label: "Quality", get: (s) => s.rel.quality },
    { label: "Reliability", get: (s) => s.rel.reliability },
    { label: "Risk (lower is better)", get: (s) => s.riskScore, lower: true },
    { label: "Sustainability", get: (s) => s.rel.sustainability },
    { label: "Capacity", get: (s) => s.rel.capacity },
  ];
  const best = (def: (typeof rowsDef)[number]) => {
    const vals = chosen.map(def.get).filter((v): v is number => v !== null);
    return vals.length ? (def.lower ? Math.min(...vals) : Math.max(...vals)) : null;
  };
  return <>
    <PageHeader title="Compare Suppliers" subtitle="Evaluate recommendation dimensions and decision differences side by side."/>
    <Card delay={80}><div className="compare-pickers">{ids.map((id, i) => <SupplierSelect key={i} value={id} allowNone={i >= 2} onChange={(v) => setIds(ids.map((x, n) => (n === i ? v : x)))}/>)}{ids.length < 4 && <Button variant="soft" icon="plus" onClick={() => setIds([...ids, ""])}>Add supplier</Button>}</div></Card>
    {chosen.length < 2 ? <Card className="state-box"><h2>Select at least two suppliers.</h2></Card> : <>
      <InsightPanel insights={analysis.insights} navigate={navigate} title="Comparison insights" eyebrow="What separates these suppliers" delay={120}/>
      <div className="profile-grid">
        <Card className="dimension-card" delay={180}><SectionTitle eyebrow="Head to head" title="Dimension by dimension"/>
          <div className="ins-legend">{chosen.map((s, i) => <span key={s.id}><i className={`c${i}`}></i>{s.name}<em>{(analysis.wins.get(s.id) || 0)} win{(analysis.wins.get(s.id) || 0) === 1 ? "" : "s"}</em></span>)}</div>
          <div className="ins-h2h">{COMPARE_DIMS.map((d) => { const w = analysis.winners.find((x) => x.dim.key === d.key); return <div key={d.key}><span>{d.label}{d.lower ? " (lower is better)" : ""}</span>
            <div className="ins-h2h-bars">{chosen.map((s, i) => { const v = d.get(s); const win = !!w?.winner && w.winner.id === s.id; return <div key={s.id} className={win ? "win" : ""}><div className="ins-bar"><i className={`c${i}`} style={{ width: `${Math.min(100, Math.max(0, v ?? 0))}%` }}></i></div><strong>{f1(v)}</strong></div>; })}</div></div>; })}</div>
          <p className="chart-disclaimer"><Icon name="shield" size={14}/>Bars show portfolio percentiles (100 = best); risk is the raw operational risk value. A bold bar marks the unique best supplier on that dimension.</p></Card>
        <Card className="why-card" delay={240}><SectionTitle eyebrow="Decision guide" title="Best supplier by priority"/>
          <div className="ins-rows plain">{analysis.winners.map((w) => <div key={w.dim.key}><span>If {w.dim.label.toLowerCase()} matters most</span><strong className="wide-text">{w.winner ? w.winner.name : "No clear winner"}</strong><small>{w.winner ? `${f0(w.margin)} point lead` : "tied / not comparable"}</small></div>)}</div>
        </Card>
      </div>
      <Card className="table-card" delay={300}><div className="data-table-wrap"><table className="data-table compare-table"><thead><tr><th>Dimension</th>{chosen.map((s) => <th key={s.id}>{s.name}</th>)}</tr></thead><tbody>
        <tr><td>MCDA rank</td>{chosen.map((s) => <td key={s.id}><b>#{s.rank}</b></td>)}</tr>
        {rowsDef.map((d) => { const b = best(d); return <tr key={d.label}><td>{d.label}</td>{chosen.map((s) => { const v = d.get(s); return <td key={s.id} className={v !== null && v === b ? "best" : ""}>{f1(v)}</td>; })}</tr>; })}
        <tr><td>Lead time (days, raw)</td>{chosen.map((s) => <td key={s.id}>{f1(s.kpi.reliability)}</td>)}</tr>
        <tr><td>Capacity (units / month, raw)</td>{chosen.map((s) => <td key={s.id}>{f0(s.kpi.capacity)}{s.capacityEstimated ? " (estimated)" : ""}</td>)}</tr>
        <tr><td>Risk status</td>{chosen.map((s) => <td key={s.id}><Badge tone={toneOf(s.status)}>{s.status}</Badge></td>)}</tr>
        <tr><td>Decision position</td>{chosen.map((s) => <td key={s.id}>{s.decisionPosition}</td>)}</tr>
        <tr><td>Strengths</td>{chosen.map((s) => <td key={s.id}>{s.strengths.slice(0, 2).join(", ")}</td>)}</tr>
        <tr><td>Weaknesses</td>{chosen.map((s) => <td key={s.id}>{s.weaknesses.slice(0, 2).join(", ")}</td>)}</tr>
      </tbody></table></div><p className="note-line">Highlighted cell = best value in the row. Cost, reliability and capacity are portfolio percentiles (100 = best); score and risk are engine values; the two raw rows are in source units.</p></Card></>}
    <DecisionBar navigate={navigate}/>
  </>;
}

// --------------------------------------------------------------- Trends ----
type TrendPayload = { available: boolean; basis?: string; reason?: string; records: TrendRec[]; fx?: { rates: Record<string, number>; as_of?: string; indicative?: boolean } | null };
function Trends({ navigate }: { navigate: (page: string) => void }) {
  const { data, error, loading, reload } = useEndpoint<TrendPayload>("/trends");
  const [metric, setMetric] = useState<TrendMetric>("awards");
  const analysis = useMemo(() => (data?.available ? trendAnalysis(data.records) : null), [data]);
  const box = <StateBox loading={loading} error={error} onRetry={reload} label="trends"/>;
  if (loading || error) return <><PageHeader title="Performance Trends" subtitle="Analyze validated award history over time."/>{box}</>;
  if (!data?.available || !analysis) return <><PageHeader title="Performance Trends" subtitle="Analyze validated award history over time."/><Card className="state-box"><h2>No historical trend available.</h2><p>{data?.reason}</p></Card></>;
  const recs = data.records;
  const total = recs.reduce((a, r) => a + r.awards, 0);
  // Award-weighted means so a month with few awards does not count as much as a busy month; empty values are skipped, not zeroed.
  const wmean = (pick: (r: TrendRec) => number | null) => { let s = 0, w = 0; recs.forEach((r) => { const v = pick(r); if (v !== null) { s += v * r.awards; w += r.awards; } }); return w ? s / w : null; };
  const m = TREND_METRICS[metric];
  const values = recs.map((r) => m.pick(r));
  const max = Math.max(...values.filter((v): v is number => v !== null), 1);
  const fmtBar = (v: number | null) => v === null ? "n/a" : metric === "value" ? (v >= 1e7 ? `₹${f1(v / 1e7)} Cr` : `₹${f0(v)}`) : metric === "awards" ? String(v) : f1(v);
  const delta = (i: number, pick: (r: TrendRec) => number | null, better: "lower" | "higher") => {
    if (i === 0 || analysis.partial.has(recs[i].period) || analysis.partial.has(recs[i - 1].period)) return null;
    const a = pick(recs[i - 1]), b = pick(recs[i]);
    if (a === null || b === null || a === b) return null;
    const d = b - a;
    return <small className={(d < 0) === (better === "lower") ? "d-good" : "d-bad"}>{d > 0 ? "▲" : "▼"} {f1(Math.abs(d))}</small>;
  };
  return <>
    <PageHeader title="Performance Trends" subtitle={`Monthly award history · basis: ${data.basis}`}/>
    <div className="mini-kpis">{[["Awards", total], ["Months", recs.length], ["Avg lead time (days)", f1(wmean((r) => r.avg_lead_time))], ["Avg savings %", f1(wmean((r) => r.avg_savings))]].map(([l, v], i) => <Card key={l as string} delay={80 + i * 50}><span>{l}</span><strong>{v}</strong></Card>)}</div>
    <InsightPanel insights={analysis.insights} navigate={navigate} title="Trend insights" eyebrow="What the award history shows" delay={140}/>
    <Card className="performance" delay={200}><SectionTitle eyebrow="Awarded contracts" title={`${m.label} per month`}/>
      <div className="metric-tabs">{(Object.keys(TREND_METRICS) as TrendMetric[]).map((k) => <button key={k} className={metric === k ? "active" : ""} onClick={() => setMetric(k)}>{TREND_METRICS[k].label}</button>)}</div>
      <div className="chart-area"><div className="bars" style={{ gridTemplateColumns: `repeat(${recs.length}, minmax(0, 1fr))` }}>{recs.map((r, i) => { const v = values[i]; const part = analysis.partial.has(r.period); return <div className={`bar-col ${part ? "partial" : ""}`} key={r.period}><div className="bar-value">{fmtBar(v)}</div><div className="bar-track"><div className={`bar-fill b${i % 8}`} style={{ height: `${v === null ? 0 : Math.max((v / max) * 100, 2)}%` }}></div></div><span>{monthLabel(r.period).split(" ")[0]}{part ? " · partial" : ""}</span></div>; })}</div></div>
      <div className="chart-note"><span><i className="orange-dot"></i>{m.better === "lower" ? "Lower is better" : m.better === "higher" ? "Higher is better" : "Volume metric, no good or bad direction"}</span><span><i className="gray-dot"></i>Dimmed bars are months with unusually few awards (likely an incomplete month)</span></div></Card>
    <Card className="table-card" delay={300}><div className="data-table-wrap"><table className="data-table"><thead><tr>{["Period", "Awards", "Avg lead time (days)", "Avg risk at award", "Avg savings %", "Awarded value (₹ INR)"].map((h) => <th key={h}>{h}</th>)}</tr></thead><tbody>{recs.map((r, i) => <tr key={r.period}><td>{r.period}{analysis.partial.has(r.period) && <> <Badge tone="warning">Partial</Badge></>}</td><td>{r.awards}</td><td>{f1(r.avg_lead_time)} {delta(i, (x) => x.avg_lead_time, "lower")}</td><td>{f1(r.avg_risk)} {delta(i, (x) => x.avg_risk, "lower")}</td><td>{f1(r.avg_savings)} {delta(i, (x) => x.avg_savings, "higher")}</td><td>{r.award_value_inr != null ? `₹ ${f0(r.award_value_inr)}` : "n/a"}</td></tr>)}</tbody></table></div><p className="note-line">Arrows compare with the previous month (green = improvement, red = deterioration) and are hidden next to incomplete months. {data.fx ? `Awarded values converted to INR before summing (EUR ${data.fx.rates.EUR}, USD ${data.fx.rates.USD}, CHF ${data.fx.rates.CHF} per unit; as of ${data.fx.as_of}${data.fx.indicative ? ", indicative rates" : ""}).` : "Currency conversion unavailable."}</p></Card>
  </>;
}

// -------------------------------------------------------- Sustainability ----
function Sustainability({ navigate }: { navigate: (page: string) => void }) {
  const { suppliers, select } = useData();
  const a = useMemo(() => esgAnalysis(suppliers), [suppliers]);
  const { list, vals } = a;
  const open = (id: string) => { select(id); navigate("Supplier Profile"); };
  return <>
    <PageHeader title="Sustainability" subtitle="Supplier ESG scores from the source data (average per supplier)."/>
    <div className="mini-kpis">{[["Suppliers with ESG data", `${list.length}/${suppliers.length}`], ["Portfolio average", list.length ? f1(mean(vals)) : "n/a"], ["Highest", list.length ? f1(Math.max(...vals)) : "n/a"], [`Below ${ESG_LINE}`, vals.filter((v) => v < ESG_LINE).length]].map(([l, v], i) => <Card key={l as string} delay={80 + i * 50}><span>{l}</span><strong>{v}</strong></Card>)}</div>
    <InsightPanel insights={a.insights} navigate={navigate} title="Sustainability insights" eyebrow="What the ESG data shows" delay={140}/>
    {list.length > 0 && <>
      <div className="profile-grid">
        <Card className="dimension-card" delay={200}><SectionTitle eyebrow="Distribution" title="How suppliers spread across ESG bands"/>
          <div className="ins-rows">{a.bands.map((b) => <div key={b.label}><span>{b.label}</span><MiniBar value={b.count} max={Math.max(list.length, 1)} tone={b.hi <= ESG_LINE ? "hot" : ""}/><strong>{b.count}</strong><small>{f0((b.count / list.length) * 100)}% of suppliers</small></div>)}</div>
          <p className="chart-disclaimer"><Icon name="shield" size={14}/>Bands are fixed 50 / 70 / 85 cut-offs on the 0-100 ESG score; {ESG_LINE} is the review line used on this page.</p></Card>
        <Card className="why-card" delay={260}><SectionTitle eyebrow="By category" title="Average ESG score"/>
          <div className="ins-rows">{[...a.byCategory].reverse().map((c) => <div key={c.category}><span>{c.category}</span><MiniBar value={c.avg}/><strong>{f1(c.avg)}</strong><small>{c.below} of {c.n} below {ESG_LINE}</small></div>)}</div></Card>
      </div>
      <div className="profile-grid">
        <Card className="dimension-card" delay={320}><SectionTitle eyebrow="Leaders" title="Highest ESG scores"/>
          <div className="ins-rows plain">{a.leaders.map((s) => <div key={s.id} className="clickable" onClick={() => open(s.id)}><span>{s.name}</span><strong>{f1(s.kpi.sustainability)}</strong><small>MCDA #{s.rank} · {s.status}</small></div>)}</div></Card>
        <Card className="why-card" delay={380}><SectionTitle eyebrow="Laggards" title="Lowest ESG scores"/>
          <div className="ins-rows plain">{a.laggards.map((s) => <div key={s.id} className="clickable" onClick={() => open(s.id)}><span>{s.name}</span><strong className={(s.kpi.sustainability ?? 0) < ESG_LINE ? "risk-num" : ""}>{f1(s.kpi.sustainability)}</strong><small>MCDA #{s.rank} · {s.status}</small></div>)}</div></Card>
      </div>
      <Card className="dimension-card" delay={440}><SectionTitle eyebrow="ESG ranking" title="All suppliers"/><div className="dimension-chart scroll-box">{list.map((s) => <div key={s.id} className="clickable" onClick={() => open(s.id)}><span>{s.name}</span><div><i style={{ width: `${s.kpi.sustainability}%` }}></i></div><strong>{f1(s.kpi.sustainability)}</strong></div>)}</div></Card>
    </>}
  </>;
}

// ------------------------------------------------------------ Dependency ----
type DepPayload = DepData & { available: boolean; basis?: string };
function Dependency({ navigate }: { navigate: (page: string) => void }) {
  const { data, error, loading, reload } = useEndpoint<DepPayload>("/dependency");
  const { suppliers, select } = useData();
  const analysis = useMemo(() => (data?.available ? dependencyAnalysis(data, suppliers) : null), [data, suppliers]);
  if (loading || error) return <><PageHeader title="Dependency Analysis" subtitle="Identify supplier, category and award concentration."/><StateBox loading={loading} error={error} onRetry={reload} label="dependency data"/></>;
  if (!data?.available || !analysis) return <><PageHeader title="Dependency Analysis" subtitle="Identify supplier, category and award concentration."/><Card className="state-box"><h2>Not available for this dataset.</h2></Card></>;
  const high = data.categories.filter((c) => c.hhi >= 2500).length;
  return <>
    <PageHeader title="Dependency Analysis" subtitle={`Award concentration · basis: ${data.basis}`}/>
    <div className="mini-kpis">{[["Awarded contracts", data.total_awards], ["Categories", data.categories.length], ["Highly concentrated (HHI ≥ 2500)", high], ["Single-source sub-categories", data.single_source_categories.length]].map(([l, v], i) => <Card key={l as string} delay={80 + i * 50}><span>{l}</span><strong>{v}</strong></Card>)}</div>
    <InsightPanel insights={analysis.insights} navigate={navigate} title="Dependency insights" eyebrow="Where the portfolio is exposed" delay={140}/>
    <Card className="table-card" delay={200}><SectionTitle eyebrow="Per category" title="Who wins the awards?"/><div className="data-table-wrap"><table className="data-table"><thead><tr>{["Category", "Awards", "Suppliers used", "Top supplier", "Top share %", "HHI", "Concentration"].map((h) => <th key={h}>{h}</th>)}</tr></thead><tbody>{data.categories.map((c) => <tr key={c.category}><td>{c.category}</td><td>{c.awards}</td><td>{c.suppliers_used}</td><td>{c.top_supplier}</td><td><div className="ins-cell"><span>{f1(c.top_share_pct)}</span><MiniBar value={c.top_share_pct} tone={c.hhi >= 2500 ? "hot" : ""}/></div></td><td>{c.hhi}</td><td><Badge tone={c.hhi >= 2500 ? "danger" : c.hhi >= 1500 ? "warning" : "stable"}>{hhiBand(c.hhi)}</Badge></td></tr>)}</tbody></table></div></Card>
    <Card className="table-card" delay={300}><SectionTitle eyebrow="Supplier exposure" title="Largest share of awarded contracts"/><div className="data-table-wrap"><table className="data-table"><thead><tr>{["Supplier", "Awards", "Share of all awards %", "Categories", "MCDA rank", "Risk status"].map((h) => <th key={h}>{h}</th>)}</tr></thead><tbody>{data.top_suppliers.map((s) => { const p = analysis.byId.get(s.supplier_id); return <tr key={s.supplier_id} onClick={p ? () => { select(p.id); navigate("Supplier Profile"); } : undefined}><td>{s.name}</td><td>{s.awards}</td><td><div className="ins-cell"><span>{f1(s.share_pct)}</span><MiniBar value={s.share_pct} max={Math.max(...data.top_suppliers.map((x) => x.share_pct), 1)}/></div></td><td>{s.categories}</td><td>{p ? `#${p.rank}` : "n/a"}</td><td>{p ? <Badge tone={toneOf(p.status)}>{p.status}</Badge> : "n/a"}</td></tr>; })}</tbody></table></div><p className="note-line">HHI = sum of squared award shares ×10,000 within a category (≥2500 is the usual "highly concentrated" convention, 1500-2500 moderate). Counts are used instead of money because currencies are mixed. {data.single_source_categories.length === 0 ? "No sub-category depends on a single supplier." : `Single-source: ${data.single_source_categories.join(", ")}.`}</p></Card>
  </>;
}

// ------------------------------------------------------------ Onboarding ----
// Portfolio-fit readiness assessment. The backend (backend/onboarding.py) owns every calculation: ranges,
// medians, better-than %, fit index, positions, strengths, attention areas, recommendation. This page only
// collects input, sends it, and renders the structured result. Nothing is saved; a new supplier is session-only.
const NEW_SUPPLIER = "__new__";
const NO_CATEGORY = "Select category";
const posTone = (p: string) => (p === "Weak" ? "danger" : p === "Watch" ? "warning" : "stable") as "danger" | "warning" | "stable";
const dirLabel = (d: string) => (d === "higher" ? "Higher ↑" : "Lower ↓");
const fmtNum = (n: number) => n.toLocaleString("en-IN", { maximumFractionDigits: 2 });

function Onboarding() {
  const { data: cfg, error, loading, reload } = useEndpoint<OnboardingConfig>("/onboarding/config");
  const [record, setRecord] = useState<string>(NEW_SUPPLIER);
  const [name, setName] = useState("");
  const [sid, setSid] = useState("");
  const [category, setCategory] = useState(NO_CATEGORY);
  const [vals, setVals] = useState<Record<string, string>>({});
  const [result, setResult] = useState<OnboardingResult | null>(null);
  const [live, setLive] = useState<OnboardingResult["completeness"] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const existing = cfg && record !== NEW_SUPPLIER ? cfg.suppliers.find((x) => x.supplier_id === record) : undefined;
  const dims = cfg?.dimensions ?? [];

  // (Re)load the form whenever the config arrives or the chosen record changes.
  useEffect(() => {
    if (!cfg) return;
    setResult(null); setErr(null);
    const next: Record<string, string> = {};
    cfg.dimensions.forEach((d) => {
      const v = existing?.values[d.dimension];
      next[d.dimension] = String(v ?? d.median);   // existing supplier: its own values; new supplier: portfolio median start
    });
    setVals(next);
    setName(existing ? existing.supplier_name : "");
    setSid(existing ? existing.supplier_id : "");
    setCategory(existing && existing.category && cfg.categories.includes(existing.category) ? existing.category : NO_CATEGORY);
  }, [cfg, record]); // eslint-disable-line react-hooks/exhaustive-deps

  const toInput = (preview: boolean): OnboardingInput => ({
    supplier_name: name, supplier_id: sid, category, preview,
    values: Object.fromEntries(dims.map((d) => [d.dimension, vals[d.dimension] === undefined || vals[d.dimension].trim() === "" ? null : Number(vals[d.dimension])])),
  });

  // Live completeness comes from the backend (debounced), not from UI logic.
  useEffect(() => {
    if (!cfg || !dims.length) return;
    let active = true;
    const t = setTimeout(() => { postOnboarding(toInput(true)).then((r) => active && setLive(r.completeness)).catch(() => {}); }, 250);
    return () => { active = false; clearTimeout(t); };
  }, [cfg, name, sid, category, vals]); // eslint-disable-line react-hooks/exhaustive-deps

  const head = <PageHeader title="Supplier Onboarding Readiness" subtitle="Assess a prospective supplier against the current Vendor360 supplier portfolio."/>;
  if (loading || error) return <>{head}<StateBox loading={loading} error={error} onRetry={reload} label="onboarding configuration"/></>;
  if (!cfg || !dims.length) return <>{head}<Card className="state-box"><h2>Not available for this dataset.</h2><p>No supplier dimensions with data were found.</p></Card></>;

  const setVal = (d: OnboardingDim, raw: string) => {
    // Enforce the allowed range: a value outside it cannot be entered.
    let v = raw;
    if (raw.trim() !== "" && !Number.isNaN(Number(raw))) {
      const n = Number(raw);
      if (n > d.max) v = String(d.max); else if (n < d.min) v = String(d.min);
    }
    setVals((p) => ({ ...p, [d.dimension]: v }));
  };
  const assess = async () => {
    setBusy(true); setErr(null);
    try { setResult(await postOnboarding(toInput(false))); } catch (e) { setErr((e as Error).message); setResult(null); }
    setBusy(false);
  };
  const comp = result?.completeness ?? live;

  return <>
    {head}
    <Card className="state-box" delay={40}><p style={{ margin: 0 }}>{cfg.notice}</p></Card>

    <Card delay={80}><SectionTitle eyebrow="Step 1" title="Supplier record"/>
      <select className="select-field" value={record} onChange={(e) => setRecord(e.target.value)}>
        <option value={NEW_SUPPLIER}>➕ New supplier</option>
        {cfg.suppliers.map((x) => <option key={x.supplier_id} value={x.supplier_id}>{x.supplier_id} — {x.supplier_name}</option>)}
      </select>
      {existing && <p className="note-line">Existing supplier loaded: <strong>{existing.supplier_name}</strong> ({existing.supplier_id}). Its actual dataset values are shown below and assessed like any other supplier.</p>}
    </Card>

    <Card className="table-card" delay={120}><SectionTitle eyebrow="Step 2" title="Allowed input ranges"/>
      <div className="data-table-wrap"><table className="data-table"><thead><tr>{["Dimension", "Allowed range", "Better when", "Meaning"].map((h) => <th key={h}>{h}</th>)}</tr></thead>
        <tbody>{dims.map((d) => <tr key={d.dimension}><td>{d.dimension}</td><td>{fmtNum(d.min)} – {fmtNum(d.max)}</td><td>{dirLabel(d.direction)}</td><td>{d.meaning}</td></tr>)}</tbody></table></div>
      {cfg.cost_note && <p className="note-line">{cfg.cost_note}</p>}
      <p className="note-line">The controls enforce these ranges; a value outside the displayed range cannot be entered. Directions come from the engine's KPI configuration.</p>
    </Card>

    <Card delay={160}><SectionTitle eyebrow="Step 3" title="Supplier assessment"/>
      <div className="onb-grid">
        <label className="onb-field"><span>Supplier name</span><input className="select-field" value={name} disabled={!!existing} placeholder="e.g. Demo Supplier" onChange={(e) => setName(e.target.value)}/></label>
        <label className="onb-field"><span>Supplier ID</span><input className="select-field" value={sid} disabled={!!existing} placeholder="e.g. DEMO-001" onChange={(e) => setSid(e.target.value)}/></label>
        <label className="onb-field"><span>Primary category</span><select className="select-field" value={category} onChange={(e) => setCategory(e.target.value)}>{[NO_CATEGORY, ...cfg.categories].map((c) => <option key={c} value={c}>{c}</option>)}</select></label>
      </div>
      <h3 className="onb-sub">Performance, risk &amp; sustainability metrics</h3>
      <div className="onb-grid">{dims.map((d) => <label className="onb-field" key={d.dimension} title={`Allowed range ${fmtNum(d.min)} – ${fmtNum(d.max)}. ${d.direction === "higher" ? "Higher" : "Lower"} is better.`}>
        <span>{d.dimension} value <small>({fmtNum(d.min)}–{fmtNum(d.max)}, {d.direction === "higher" ? "higher" : "lower"} is better)</small></span>
        <input className="select-field" type="number" inputMode="decimal" min={d.min} max={d.max} step={d.step} value={vals[d.dimension] ?? ""} onChange={(e) => setVal(d, e.target.value)}/></label>)}</div>
      <div style={{ marginTop: 14 }}><Button variant="primary" icon="search" onClick={assess}>{busy ? "Assessing…" : "Assess onboarding readiness"}</Button></div>
      {err && <p className="note-line" style={{ color: "#ff8a80" }}>{err}</p>}
    </Card>

    <Card delay={200}><SectionTitle eyebrow="Step 4" title="Data completeness"/>
      {comp ? <><div className="onb-progress"><i style={{ width: `${comp.pct}%` }}></i></div><p className="note-line"><strong>{comp.pct}% complete</strong> ({comp.filled}/{comp.total} fields)</p></> : <p className="note-line">Checking…</p>}
    </Card>

    {result?.status === "needs_information" && <Card className="state-box" delay={0}><span className="eyebrow">Step 5 · Onboarding readiness</span><h2>Needs information</h2><p>{result.message}</p></Card>}

    {result?.status === "assessed" && <>
      <Card delay={0}><SectionTitle eyebrow="Step 5" title="Onboarding readiness"/>
        <div className="mini-kpis" style={{ gridTemplateColumns: "1fr 2fr" }}>
          <Card><span>Portfolio Fit Index</span><strong>{f1(result.fit_index)}/100</strong></Card>
          <Card><span>Assessment</span><strong><Badge tone={result.tone === "danger" ? "danger" : result.tone === "warning" ? "warning" : "stable"}>{result.assessment}</Badge></strong></Card>
        </div>
        <p className="note-line">{result.message}</p>
      </Card>

      <Card className="table-card" delay={0}><SectionTitle eyebrow="Step 6" title="Dimension-by-dimension benchmark"/>
        <div className="data-table-wrap"><table className="data-table"><thead><tr>{["Dimension", "Entered value", "Portfolio median", "Better when", "Better than %", "Position"].map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>{(result.benchmark ?? []).map((r) => <tr key={r.dimension}><td>{r.dimension}</td><td>{fmtNum(r.entered)}</td><td>{fmtNum(r.portfolio_median)}</td><td>{dirLabel(r.direction)}</td><td>{f1(r.better_than_pct)}</td><td><Badge tone={posTone(r.position)}>{r.position}</Badge></td></tr>)}</tbody></table></div>
        <p className="note-line">Better than % = share of current suppliers this profile beats, respecting each dimension's direction. Strong ≥ 75, Above average ≥ 50, Watch ≥ 25, Weak &lt; 25. The Portfolio Fit Index is the average of these percentages.</p>
      </Card>

      <div className="profile-grid">
        <Card delay={0}><SectionTitle eyebrow="Positives" title="Supplier strengths"/>
          {(result.strengths ?? []).length ? (result.strengths ?? []).map((t) => <p key={t} className="onb-line">{t}</p>) : <p className="note-line">{result.strengths_empty}</p>}
        </Card>
        <Card delay={0}><SectionTitle eyebrow="Concerns" title="Areas requiring attention"/>
          {(result.attention ?? []).length ? (result.attention ?? []).map((t) => <p key={t} className="onb-line">{t}</p>) : <p className="note-line">{result.attention_empty}</p>}
        </Card>
      </div>

      <Card delay={0}><SectionTitle eyebrow="Step 7" title="Management recommendation"/><div className="recommendation"><Icon name="spark" size={17}/><div><strong>{result.recommendation}</strong></div></div></Card>
      <Card delay={0}><SectionTitle eyebrow="Step 8" title="Business interpretation"/>{(result.interpretation ?? []).map((t) => <p key={t} className="onb-line">{t}</p>)}<p className="note-line">{result.caption}</p></Card>
    </>}
  </>;
}

// ------------------------------------------------------------ Data quality ----
function Quality() {
  const { data, error, loading, reload } = useEndpoint<any>("/quality");
  if (loading || error) return <><PageHeader title="Data Quality & Decisions" subtitle="Understand dataset health and decision readiness."/><StateBox loading={loading} error={error} onRetry={reload} label="data-quality report"/></>;
  const q = data;
  return <>
    <PageHeader title="Data Quality & Decisions" subtitle="Understand dataset health and decision readiness."/>
    <div className="mini-kpis">{[["Suppliers", q.suppliers], ["Supplier records", q.supplier_records], ["KPI completeness < 100%", q.completeness_below_100], ["Capacity estimated from category median", q.preparation?.capacity?.suppliers_affected?.length ?? 0]].map(([l, v], i) => <Card key={l as string} delay={80 + i * 50}><span>{l}</span><strong>{v}</strong></Card>)}</div>
    <div className="profile-grid">
      <Card className="why-card" delay={200}><SectionTitle eyebrow="Source files" title="Rows loaded"/><div className="dimension-chart">{(() => { const mx = Math.max(1, ...Object.values(q.sources).map((v: any) => v.rows)); return Object.entries(q.sources).map(([k, v]: any) => <div key={k}><span>{k}</span><div><i style={{ width: `${(v.rows / mx) * 100}%` }}></i></div><strong>{v.rows}</strong></div>); })()}</div></Card>
      <Card className="dimension-card" delay={260}><SectionTitle eyebrow="Dimension availability" title="Missing KPI values"/><div className="data-table-wrap"><table className="data-table"><thead><tr><th>Dimension</th><th>Available</th><th>Missing suppliers</th></tr></thead><tbody>{(q.dimension_availability.length ? q.dimension_availability : Object.keys(q.missing_kpi_by_dimension).map((d) => ({ dimension: d, available: true }))).map((d: any) => <tr key={d.dimension}><td>{d.dimension}</td><td>{String(d.available)}</td><td>{q.missing_kpi_by_dimension[d.dimension] ?? 0}</td></tr>)}</tbody></table></div></Card>
    </div>
    <div className="profile-grid">
      <Card className="why-card" delay={320}><SectionTitle eyebrow="Pricing" title="Currencies and pricing models"/><div className="dimension-chart">{(() => { const rows: Array<[string, any]> = [...Object.entries(q.pricing_currencies), ...Object.entries(q.pricing_models)] as any; const mx = Math.max(1, ...rows.map(([, v]) => Number(v))); return rows.map(([k, v]) => <div key={k}><span>{k}</span><div><i style={{ width: `${(Number(v) / mx) * 100}%` }}></i></div><strong>{v}</strong></div>); })()}</div></Card>
      <Card className="dimension-card" delay={380}><SectionTitle eyebrow="Decision readiness" title="Decision positions"/><div className="dimension-chart">{Object.entries(q.decision_positions).map(([k, v]: any) => <div key={k}><span>{k}</span><div><i style={{ width: `${(v / q.suppliers) * 100}%` }}></i></div><strong>{v}</strong></div>)}</div><ul className="note-list">{q.notes.map((n: string) => <li key={n}>{n}</li>)}</ul></Card>
    </div>
  </>;
}

// ------------------------------------------------------------------ Export ----
function ExportPage() {
  const items: Array<[string, string, string]> = [
    ["Supplier Portfolio", "portfolio", "All suppliers with scores, ranks, KPIs, risk and decision text."],
    ["Risk Radar Report", "risk", "Risk Radar score, status, flags and actions per supplier."],
    ["Decision Intelligence Report", "decision", "MCDA position, explanation and recommended action."],
    ["Supplier KPI Comparison", "kpi", "Raw supplier-level KPIs per dimension."],
  ];
  return <>
    <PageHeader title="Reports & Export" subtitle="Download the engine's outputs as CSV."/>
    <div className="report-grid">{items.map(([t, k, d], i) => <Card key={k} delay={120 + i * 40}><Icon name="report" size={22}/><h2>{t}</h2><p>{d}</p><a className="btn soft" href={apiUrl(`/export/${k}`)} download><span>Download CSV</span></a></Card>)}</div>
  </>;
}

// ----------------------------------------------------------- Settings / Help ----
function Settings() {
  const { directions } = useData();
  return <>
    <PageHeader title="Settings" subtitle="How the analysis is configured (read-only)."/>
    <Card delay={100}><SectionTitle eyebrow="KPI direction" title="Configured by the backend"/><div className="direction-list">{Object.entries(directions).map(([k, v]) => <div className="direction-row" key={k}><span>{k}</span><Badge tone={v === "higher" ? "stable" : "warning"}>{v === "higher" ? "Higher is better" : "Lower is better"}</Badge></div>)}</div><p className="note-line" style={{ marginTop: 18 }}>Directions come from the KPI config produced by the notebook backend. The UI never changes them. AI is optional and not required for any page.</p></Card>
  </>;
}
function Help() {
  const items = [["MCDA score", "Weighted multi-criteria score across cost, quality, reliability, risk, sustainability and capacity, computed by the backend engine."], ["Risk Radar", "Operational risk, kept separate from the MCDA recommendation."], ["Percentile bars", "For cost, reliability and capacity the bars show the supplier's position inside this portfolio (100 = best), because raw units differ widely."], ["What-If", "Scenario text sets priorities; the engine recalculates weights, scores and ranks."]];
  return <><PageHeader title="Vendor360 Help" subtitle="Learn how supplier analytics become explainable decisions."/><div className="report-grid">{items.map(([t, d], i) => <Card key={t} delay={100 + i * 40}><h2>{t}</h2><p>{d}</p></Card>)}</div></>;
}

// -------------------------------------------------------------------- App ----
export default function App() {
  const [page, setPage] = useState("Executive Dashboard");
  const visitedRef = useRef(new Set<string>());
  const [collapsed, setCollapsed] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [load, setLoad] = useState<{ status: "loading" | "ready" | "error"; suppliers: SupplierRecord[]; directions: Record<string, string>; error?: string }>({ status: "loading", suppliers: [], directions: {} });
  const [tick, setTick] = useState(0);
  const [theme, setTheme] = useState(() => loadPref("v360-theme", "ember"));
  const [showInsights, setShowInsights] = useState(() => loadPref("v360-insights", "on") === "on");
  const [themeOpen, setThemeOpen] = useState(false);
  useEffect(() => { document.documentElement.dataset.theme = theme; savePref("v360-theme", theme); }, [theme]);
  useEffect(() => { savePref("v360-insights", showInsights ? "on" : "off"); }, [showInsights]);

  useEffect(() => {
    let active = true;
    setLoad((l) => ({ ...l, status: "loading" }));
    fetchPortfolio().then((p) => {
      if (!active) return;
      if (p.suppliers.length === 0) setLoad({ status: "error", suppliers: [], directions: {}, error: "The API returned no suppliers." });
      else { setLoad({ status: "ready", suppliers: p.suppliers, directions: p.directions }); setSelectedId((id) => id || p.suppliers[0].id); }
    }).catch((e: Error) => active && setLoad({ status: "error", suppliers: [], directions: {}, error: e.message }));
    return () => { active = false; };
  }, [tick]);

  const suppliers = load.suppliers;
  const searchResults = useMemo(() => search ? suppliers.filter((s) => s.name.toLowerCase().includes(search.toLowerCase())).slice(0, 4) : [], [search, suppliers]);
  const navigate = (next: string) => { setPage(next); setSearch(""); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const title = page === "Executive Dashboard" ? "Executive Overview" : page;
  const counts = countStatus(suppliers);
  const notes: Array<[string, string]> = suppliers.length ? [
    [`${counts["Critical"] || 0} supplier(s) are Critical on the Risk Radar.`, "danger"],
    [`${suppliers.filter((s) => s.completeness < 100).length} supplier(s) have incomplete KPI data.`, "warning"],
    [`Top ranked: ${suppliers[0].name} (${f1(suppliers[0].score)}).`, "info"],
  ] : [];

  let content: ReactNode;
  if (load.status === "loading") content = <><p className="note-line sk-note">Starting the data engine. This can take about 15 seconds on first load.</p><Skeleton rows={3}/></>;
  else if (load.status === "error") content = <Card className="state-box error"><span className="eyebrow">Backend unavailable</span><h2>Could not load supplier data.</h2><p>{load.error}</p><Button variant="primary" onClick={() => setTick((n) => n + 1)}>Retry</Button></Card>;
  else content = null;
  // Keep-alive: every page the user has opened stays mounted (just hidden) so its local state
  // (typed text, results, filters, tabs, chat history) survives navigation.
  const renderPage = (p: string): ReactNode => {
    switch (p) {
      case "Executive Dashboard": return <Dashboard navigate={navigate}/>;
      case "Supplier Directory": return <Directory navigate={navigate}/>;
      case "Supplier Profile": return <Profile navigate={navigate}/>;
      case "Supplier Comparison": return <Comparison navigate={navigate}/>;
      case "Supplier Onboarding": return <Onboarding/>;
      case "Risk Monitoring": return <RiskPage navigate={navigate}/>;
      case "Performance Trends": return <Trends navigate={navigate}/>;
      case "Dependency Analysis": return <Dependency navigate={navigate}/>;
      case "Sustainability": return <Sustainability navigate={navigate}/>;
      case "What-If Scenarios": return <WhatIf/>;
      case "Data Quality & Decisions": return <Quality/>;
      case "AI Advisor": return <AIAdvisor navigate={navigate}/>;
      case "Export & Reports": return <ExportPage/>;
      case "Settings": return <Settings/>;
      default: return <Help/>;
    }
  };
  visitedRef.current.add(page);
  if (load.status === "ready") content = [...visitedRef.current].map((p) => <div key={p} hidden={p !== page}>{renderPage(p)}</div>);

  const ctx: Ctx = { suppliers, directions: load.directions, selectedId, select: setSelectedId };
  const statusText = load.status === "ready" ? "Live backend connected" : load.status === "loading" ? "Connecting…" : "Backend unavailable";

  return <DataCtx.Provider value={ctx}><UiCtx.Provider value={{ showInsights }}><div className={`app-shell ${collapsed ? "collapsed" : ""}`}>
    <div className="aurora" aria-hidden="true"><i className="a1"></i><i className="a2"></i><i className="a3"></i><i className="a4"></i><i className="a5"></i></div>
    <aside className="sidebar">
      <div className="sidebar-head"><Logo compact={collapsed}/><button className="collapse-btn" onClick={() => setCollapsed(!collapsed)} aria-label="Toggle sidebar"><Icon name={collapsed ? "chevron" : "close"} size={16}/></button></div>
      <nav>{navGroups.map((group) => <div className="nav-group" key={group.label}><span className="nav-label">{group.label}</span>{group.items.map((item) => <button title={item.label} className={page === item.label ? "active" : ""} onClick={() => navigate(item.label)} key={item.label}><Icon name={item.icon}/><span>{item.label}</span>{page === item.label && <i></i>}</button>)}</div>)}</nav>
      <div className="sidebar-bottom">{[{ label: "Settings", icon: "settings" as IconName }, { label: "Help", icon: "help" as IconName }].map((item) => <button key={item.label} onClick={() => navigate(item.label)}><Icon name={item.icon}/><span>{item.label}</span></button>)}<div className="data-status"><i></i><div><strong>Data engine</strong><span>{statusText}</span></div></div></div>
    </aside>
    <div className="workspace">
      <header className="topbar">
        <div className="breadcrumb"><span>Vendor360</span><Icon name="chevron" size={13}/><strong>{title}</strong></div>
        <div className="top-actions">
          <div className="global-search"><Icon name="search" size={17}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search suppliers…"/><kbd>⌘ K</kbd>{searchResults.length > 0 && <div className="search-results">{searchResults.map((s) => <button key={s.id} onClick={() => { setSelectedId(s.id); navigate("Supplier Profile"); }}><span className="supplier-avatar">{initials(s.name)}</span><div><strong>{s.name}</strong><small>{s.id} · #{s.rank}</small></div></button>)}</div>}</div>
          <button className={`pill-toggle ${showInsights ? "on" : ""}`} onClick={() => setShowInsights(!showInsights)} aria-pressed={showInsights} title="Show or hide insight panels"><Icon name="spark" size={15}/><span>Insights</span><b><u></u></b></button>
          <div className="theme-wrap"><button className="icon-button" onClick={() => setThemeOpen(!themeOpen)} aria-label="Colour theme" title="Colour theme"><span className="theme-dot"></span></button>{themeOpen && <div className="theme-menu">{THEMES.map((t) => <button key={t.id} className={theme === t.id ? "active" : ""} onClick={() => { setTheme(t.id); setThemeOpen(false); }}><span className={`sw sw-${t.id}`}></span>{t.label}</button>)}</div>}</div>
          <button className="icon-button notification-button" onClick={() => setNotifications(!notifications)} aria-label="Notifications"><Icon name="bell"/><i></i></button>
          <button className="ai-shortcut" onClick={() => navigate("AI Advisor")}><Icon name="spark" size={16}/><span>Advisor</span></button>
          <button className="profile-button"><span>V3</span><div><strong>Vendor360</strong><small>Analyst view</small></div><Icon name="chevron" size={13}/></button>
        </div>
        {notifications && <div className="notification-panel"><div><h2>Notifications</h2><button onClick={() => setNotifications(false)}><Icon name="close" size={15}/></button></div>{notes.map(([t, c]) => <button key={t}><i className={c}></i><div><strong>{t}</strong><span>From current data</span></div></button>)}</div>}
      </header>
      <main>{content}</main>
      <footer><Logo/><span>Adaptive Supplier Analytics & Decision Intelligence</span><small>{load.status === "ready" ? "Live backend data · scores are deterministic engine outputs" : load.status === "loading" ? "Connecting to backend…" : "Backend unavailable · no data shown"}</small></footer>
    </div>
  </div></UiCtx.Provider></DataCtx.Provider>;
}
