import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'node:path'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { '@': path.resolve(process.cwd(), './src') },
  },
  // NOTE: host 0.0.0.0 + allowedHosts:true are needed for Colab's proxy hostnames; there is no login. See ../README.md.
  server: {
    proxy: {
      "/api": "http://127.0.0.1:8000",
    },
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
  },
  preview: {
    proxy: { "/api": "http://127.0.0.1:8000" },
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
  },
})
