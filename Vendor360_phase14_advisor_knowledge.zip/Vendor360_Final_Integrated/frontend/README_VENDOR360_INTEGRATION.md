# Vendor360 frontend — backend contract

React 19 + Vite 8 + Tailwind 4. The UI only **displays** engine output; it never computes MCDA, risk or rank.

## Base URL
Default `/api` (relative). The Vite dev/preview server proxies `/api` to `http://127.0.0.1:8000`
(`vite.config.ts`). Override with `VITE_VENDOR360_API_URL` only if the API lives elsewhere and is reachable from the browser.

## Startup behaviour
The backend runs its pipeline (~15 s) in the background. Until it is done, data endpoints answer
`503 {"detail": "... still starting ..."}` and the UI polls every 2 s (up to 90 s) before showing an error.
`GET /api/health` returns `{"status": "starting" | "ready" | "error", "ok": bool, "error": str|null, ...}`.

## Endpoints used by the UI
| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | `status` = `starting`, `ready` or `error` |
| GET | `/api/portfolio` | `{count, schema, suppliers[]}`; one row per supplier (40), see `schema` for column meanings |
| GET | `/api/supplier/{supplier_id}` | one portfolio row |
| GET | `/api/risk` | Risk Radar table |
| GET | `/api/trends` | monthly awards (awarded rows only), value in INR + the FX table used |
| GET | `/api/onboarding/config` | dimensions, allowed ranges, directions, portfolio medians, categories, existing suppliers (+ their values) |
| POST | `/api/onboarding/assess` | body `{supplier_name, supplier_id, category, values:{Cost,...}, preview?}`; returns completeness, Portfolio Fit Index, benchmark, strengths, attention, recommendation, interpretation. 422 for out-of-range values. Nothing is stored. |
| GET | `/api/dependency`, `/api/onboarding` | derived from source data when columns exist, else `{"available": false}` (`/api/onboarding` is the older contract/pricing checklist; the UI no longer uses it) |
| GET | `/api/quality` | data-health report incl. preparation log (FX, capacity estimate, cost normalisation) |
| GET | `/api/export/{portfolio|risk|decision|kpi}` | CSV download |
| POST | `/api/scenario` | body `{"scenario_text": "What if reliability matters more than cost?"}` |
| POST | `/api/advisor` | body `{"question": "Which suppliers require attention?"}`; deterministic, no Gemini |

## Demo data
There is no demo fallback. If the backend is unreachable the UI shows an explicit error state with a retry button.
