// Node test of normalizeSupplier on a REAL /api/portfolio payload.
// Usage: node tests/normalize.test.mjs <payload.json>      (run from frontend/; needs `npm ci` for typescript)
import ts from "typescript";
import assert from "node:assert/strict";
import { readFileSync, writeFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const payloadPath = process.argv[2];
assert.ok(payloadPath, "pass the path of a saved /api/portfolio response");
const out = join(mkdtempSync(join(tmpdir(), "v360-norm-")), "vendor360.mjs");
// Transpile the real source file (types stripped; Vite's import.meta.env is not defined under plain Node).
const src = readFileSync(resolve("src/api/vendor360.ts"), "utf8").replaceAll("import.meta.env.VITE_VENDOR360_API_URL", "undefined");
writeFileSync(out, ts.transpileModule(src, { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 } }).outputText);
const { normalizeSupplier, DIMENSIONS } = await import(pathToFileURL(out).href);

const payload = JSON.parse(readFileSync(payloadPath, "utf8"));
const rows = payload.suppliers;
assert.equal(rows.length, 40, "40 suppliers expected");
const s = rows.map(normalizeSupplier);

assert.equal(new Set(s.map((x) => x.id)).size, 40, "unique supplier ids");
assert.ok(s.every((x) => x.id && x.name), "id and name resolve");
for (const d of DIMENSIONS) {
  assert.ok(s.some((x) => x.kpi[d] !== null && x.kpi[d] !== 0), `${d} KPI is not all zero/null`);
  assert.ok(s.every((x) => x.rel[d] === null || (x.rel[d] >= 0 && x.rel[d] <= 100)), `${d} relative score within 0-100`);
}
assert.ok(s.every((x) => x.score >= 0 && x.score <= 100), "score within 0-100");
assert.ok(s.every((x) => x.rank >= 1), "rank >= 1");
const byScore = [...s].sort((a, b) => b.score - a.score);
for (let i = 1; i < byScore.length; i++) assert.ok(byScore[i].rank >= byScore[i - 1].rank, "higher score never ranks worse");
const known = ["Stable", "Watch", "Emerging Risk", "Critical"];
assert.ok(s.every((x) => known.includes(x.status)), "every supplier has a real risk status");
// edge cases: missing / junk values must not throw and must not invent numbers
const e = normalizeSupplier({ supplier_id: "X", supplier_name: "Y", cost_kpi: "abc", quality_kpi: null });
assert.equal(e.kpi.cost, null); assert.equal(e.kpi.quality, null); assert.equal(e.status, "Unrated"); assert.equal(e.category, "Unclassified");
console.log(`normalizeSupplier OK on ${s.length} real suppliers`);
